# CAMBIOS tools v80w — Victoria's Secret #679 Downey (runner --sin-api, 2026-11-01)
| Regla | Error | Solución | Tool |
|---|---|---|---|
| R80e.98 | Lectura listó RTU support de madera con cantidades + RFI | Madera EXCLUIDA directo (Scope Checklist), sin cantidad ni RFI | SKILL.md, reglas_clasificacion |
| R80e.99 | completitud.py se caía con types_none_reason en lista | acepta lista [{type, why, source}] | runner/completitud.py |
| R80e.100 | Storefront estructural dentro de "header / box beam" (A_HEADER_LF 963 vs 208) | familia "storefront structural framing (printed)" | canon, familias, plantilla_excel |
| R80e.101 | "no dimension string read" disparaba G_CADENA | la negación no dispara | reglas.py |
| R80e.102 | R73.7 falso en sets por hatch (board un lado) y en cajas | espesor = stud + capas por LADO; cajas fuera | chequeos_v73.py |
| R80e.103 | Lecturas no leyeron el demolition plan (deck 17'-0" / structure 12'-1") | lectura.md: demolition plan obligatorio antes de "no impreso" | runner/prompts/lectura.md |
| R80e.104 | trazabilidad "track - other": 809.46 != 49.36 | filtra sin tamaño + resto de familia | trazabilidad.py |
| R80e.105 | _val_op tomaba "= 6\" strip" de una cita | prefiere "= V <unidad>" | trazabilidad.py |
| R80e.106 | ALC-12 exigía furring/carrying con drywall grid; ALC-16 solo FRT | grid y blocking metálico cierran | alcances.py |
| R80e.107 | Productos impresos sin familia (reveal P-224, plate 24x24 20 ga, metal FRP trim) | 3 familias impresas | canon, familias, plantilla_excel |
| R80e.108 | markups_bluebeam: 0 anotaciones (sheet number en curvas) | usa la página del canon | markups_bluebeam.py |
Suite correr_suite.py: 5/5 OK.
