# CAMBIOS tools v80x — VS #679 Downey rev2 (paso 11 auditor + paso 12 biblioteca)
| Regla | Error (paso 12) | Solución | Tool |
|---|---|---|---|
| R80e.109 | BE-102 citas truncadas (C/A12) y ids de wall leídos como hojas | RX_NH: punto primero; sin guion 3 dígitos | trazabilidad.py |
| R80e.110 | BE-46 storefront y clips mezclaban productos | split por miembro / designación de clip | trazabilidad.py |
| R80e.111 | BE-46 foil-backed como "regular", 1/2" MR como "exterior sheathing" | boards "5/8 foil-backed" y "1/2 MR" con familia / renglón | canon, familias, plantilla, trazabilidad, inventario |
| R80e.112 | BE-15 blocking como stud 3-5/8"; split duplicaba familia | split backing track / plate + guard NET | trazabilidad, plantilla |
| R80e.113 | track de soffits por tamaño no sumaba sus ítems | + items_filas | trazabilidad |
| compra | BE-51 reveal: piezas = LF | trim stick 10 ft | plantilla_excel |
Suite 5/5 OK.
