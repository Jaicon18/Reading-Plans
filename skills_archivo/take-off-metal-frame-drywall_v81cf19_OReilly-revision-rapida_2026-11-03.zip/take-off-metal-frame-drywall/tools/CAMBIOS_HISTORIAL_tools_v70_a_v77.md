
<!-- ===== CAMBIOS_tools_v70.md ===== -->
# CAMBIOS tools v70

Una línea por cambio: archivo · qué · test (todos sintéticos; cada test falla con el código / dato viejo).

1. particion.py · `MODO_DEFAULT = "run"` (decisión del estimador: run continuo del mismo type con quiebres o esquinas = un solo wall; una T no encadena; "tramo" queda como opción) · test_particion_v70.py `test_default_es_run`, `test_l_de_dos_segmentos_es_un_wall_por_default`, `test_t_no_encadena_por_default`
2. particion.py · `door_bulkhead` tipado `BULKHEAD-<familia>` (familia = letras iniciales, misma convención que partition_types R7; sin tag usa `bulkhead_of`): nunca se une con sus walls G / G1 · test_particion_v70.py `test_bulkhead_entre_dos_stubs_g`, `test_familia_igual_a_partition_types`
3. particion.py · unión de "tramo" por componentes conexas (union-find): el resultado no depende del orden de los walls; aviso "sin band H|V (ori …)" cuando la band no es H / V · test_particion_v70.py `test_tramo_no_depende_del_orden`
4. inventario_tags.py · nombre canónico de la Etapa 1 (antes inventario.py en v69, que tapaba al inventario de walls de canon.py); docstrings y `inventario.md` lo citan así · test_inventario_tags.py (import corregido), test_sin_colisiones.py
5. etapas.py / comparar.py / README_etapas.md · menciones de la Etapa 1 → `inventario_tags.py` ("ETAPA 1: python3 inventario_tags.py …"); README explica que inventario.py es el inventario de walls que usa canon.py; salidas `1_inventario/inventario.json` sin cambio · test_sin_colisiones.py
6. test_sin_colisiones.py (nuevo) · falla si `canon.inventario` no expone `verificar` / `PURLIN_ELEMS`, si `inventario_tags` no expone `inventario()`, o si un módulo de la carpeta no expone los nombres que otros módulos leen de él (choques previos a v70 en tagband / verif_coherencia / zoom quedan como AVISO) · autoprueba
7. inventario_tags.py · prefijo de id propio por lista (`PT` `PA` `PC` `PX` `DW` `DB` `DR` `KN` `CO`): ids únicos en todo `ocurrencias`; candidatos con `type` = texto y recorte PNG propio verificado · test_inventario_tags_v70.py
8. comparar.py / etapas.py · los candidatos `PC####` entran al cruce (`tags_inventario`): sin wall → alerta "tag sin wall"; sin wall y sin alerta → compuerta FALLA · test_etapas_v70.py `test_compuerta_candidato_sin_wall_y_sin_alerta`
9. etapas.py unir · clave lista en un fragmento y dict / escalar en otro → ERROR "<key>: list in X, dict in Y", rc 1, sin crash · test_etapas_v70.py `test_a_lista_vs_dict_sin_crash`
10. etapas.py unir · texto tipo `notes` distinto → `{fragmento: texto}` + aviso; otro escalar distinto → ERROR con los dos fragmentos · test_etapas_v70.py `test_b_notes_por_fragmento_y_escalar_distinto`
11. etapas.py unir · convención de band: caras > 2 ft × escala en partitions, extensión vs length_ft fuera de ±3 % y 1 ft (salvo `band_length_ok_reason`), "banda traspuesta"; column_wrap / pier no se chequean · test_etapas_v70.py `test_c_banda_traspuesta_y_fuera_de_convencion`, `test_c_escala_del_canon`
12. etapas.py unir / comparar.py · `page` 0-based contra el inventario (`../1_inventario`, `../../1_inventario` o `--inventario`) → ERROR "page 0-based"; comparar rechaza (rc 1) · test_etapas_v70.py `test_d_page_0_based`, `test_d_comparar_rechaza_page_0_based`
13. etapas.py unir · refs de `walls[].openings[]` y `openings_extra[]` contra `opening_schedule` / `opening_list` / `openings` (lista o `{items}`): ref desconocida → ERROR (la tarea de openings escribe las refs primero, Etapa 2a) · test_etapas_v70.py `test_e_refs_de_openings`
14. canon.py · `canopy_soffit` en walls → ValueError (va en runs / ceilings) · test_canon_v70.py `test_a_canopy_soffit_en_walls_rechazado`; test_canon.py: los dos tests de canopy soffit pasan a runs
15. canon.py · roof_step, ceiling_transition, soffit_side, ceiling_bulkhead, vestibule_head, grille_head sin faces ni `faces_none_reason` → ValueError · test_canon_v70.py `test_b_elementos_con_board_exigen_faces`; fixtures de test_canon.py / test_canon_v68.py con `faces_none_reason`
16. canon.py · claves de wall fuera de `WALL_KEYS` con números → ValueError que nombra la clave y el campo del esquema (plywood → plywood_strips, blocking → blocking_items…); sin números → aviso; sufijos de traza `_info` `_note` `_check` `_source` `_status` `_img` `_reason` `_basis` `_desc` `_op` aceptados · test_canon_v70.py `test_c_claves_fuera_de_esquema`
17. canon.py · operación de canopy_joist / framed_soffit: "ROUNDUP(<run_ft>/<oc_ft>)+1 = <n> joists x <joist_len_ft> = <LF>" con el RUN que cuenta joists (oc no exacto se escribe "(16/12)") · test_canon_v70.py `test_d_operacion_canopy_joist_imprime_el_run`
18. canon.py · `constants.deck_breaks.value[]` con `sheet`: el quiebre solo se compara con bandas de esa hoja · test_canon_v70.py `test_e_deck_breaks_por_hoja`
19. accesorios.py · `sill_return: false` + `sill_return_source` N/HOJA: jamb return y trim sin el borde del sill; sill track (headers.py) sin cambio; sin fuente → ValueError · test_accesorios_v70.py `test_sill_return_false_omite_borde_del_sill`, `test_sill_return_false_sin_source`, `test_canon_sill_track_igual_return_y_trim_sin_sill`
20. accesorios.py · `atm_recess.*_status = "CRITERIO"` aceptado con `rfi` (o `<dato>_rfi`); sin rfi → ValueError · test_accesorios_v70.py `test_atm_recess_criterio_con_rfi`
21. plantilla_excel.py verificar · renglón del Material Summary que cita `<tool>_out.json … '<familia>'` con Net 0 mientras la salida da > 0 → error (salidas junto al Excel o `--salidas dir`) · test_plantilla_v70.py
22. closer.py · `abertura(..., piezas=0, header="steel_by_others", header_source="N/HOJA")` = header 0 con fuente (se sella); 0 piezas sin eso → rechazo · test_closer_v70.py
23. headers.py `_src` · partes separadas fuera de paréntesis (mismo splitter que corridas.py) y prefijo "N/HOJA:" aceptado · test_headers_v70.py

## Fase 2

24. partition_types.py · criterio E28: agrupa los walls de cada type con `particion.particion` y `particion.MODO_DEFAULT` ("run"); se conservan PT1 (tipado EXT-6CFMF / EXT-PARAPET / BULKHEAD-<familia> / CANOPY-COL), PT4 (door_bulkheads colineales de un frente = un wall), PT5 (OTHER FRAMING), R8 (chase por cara), R9 (LF de wraps / piers interiores) y R10 en `modo="tramo"` · test_partition_types_v70.py; test_partition_types.py: los asserts de conteo por tramo pasan a `modo="tramo"` y se agrega el caso run
25. canon.py R70.1 · ceiling que no es furring sin `system_callout {detail N/HOJA, on_plan: true, source}` → ValueError (con aviso si la leyenda dice SUSPENDED); fixtures de ceilings stud_joist / framed_soffit / canopy_joist con system_callout · test_canon_v70.py `test_r70_1_system_callout`
26. canon.py R70.6 · pier / column_wrap con parts y tag interior: length_ft = perímetro completo de la caja (Σ caras de todas las partes, o `parts[].faces_ft`) → ValueError; debe ser las caras interiores o declarar `type_lf_basis` · test_canon_v70.py `test_r70_6_pier_interior_no_suma_perimetro`
27. canon.py R70.7 · storefront / curtain_wall desde el piso (sill 0 o sin sill) dentro de un wall → ValueError (framing sobre el head = storefront_cripples) salvo `storefront_in_lf_reason`; G / G1 siguen con la regla 59.7 · test_canon_v70.py `test_r70_7_storefront_desde_el_piso`
28. accesorios.py R70.9 · grille head: si `head_chain_source` dice chain / cadena o la fuente cita al menos dos cotas pies-pulgadas, `head_chain_in` lista todos los eslabones (un solo eslabón → ValueError); stud = Σ cadena − n_box × box_depth − board · test_accesorios_v70.py `test_r70_9_cadena_del_head`
29. accesorios.py · storefront_cripples fuera del bottom track sobre losa de pins / anchors (ON_SLAB ya los excluía; queda con test) · test_accesorios_v70.py `test_storefront_cripples_fuera_de_pins_y_anchors`
30. plantilla_excel.py verificar R70.8 · NET de drywall screws / joint compound / joint tape: fórmula viva a Inputs, o igual a yield de Inputs (celda citada en Yield check) × driver dentro de medio por ciento; si no → "R70.8 yield must come from Inputs" · test_plantilla_v70.py `test_r70_8_yield_desde_inputs`
31. etapas.py compuerta · corre `esquinas.revisar` sobre `4_canon/takeoff_canon.json` si existe y falla con sus fallas (prefijo "esquinas:") · test_etapas_v70.py `test_compuerta_corre_esquinas_sobre_el_canon_final`
32. esquinas.py + test_esquinas.py · incluidos en el paquete (sin cambios) · test_esquinas.py

<!-- ===== CAMBIOS_tools_v71.md ===== -->
# CAMBIOS tools v71 (2026-10-19)

Origen: arbitraje de dos pruebas ciegas (fuera del paquete). Todo genérico; cada cambio con test en `test_v71.py`.

| Tool | Cambio | Regla |
|---|---|---|
| particion.py | modo "eje" (nuevo default): línea recta por tag; esquina / jog / T entre dos líneas con tag corta; segmento sin tag se suma al wall con tag que toca; grupo sin tag = un wall; hueco colineal solo se cruza con un R.O. del wall dentro; exteriores por eje; un pier exterior no vuelve exterior a un type interior; sin tag_ids = corte en esquinas + jogs sumados. "run" y "tramo" quedan como opciones | E28 v71 / R71.12 |
| partition_types.py | pasa `tag_ids` y `openings` a particion; exterior por type (no por un wall suelto); Layers = Σ(layers × largo de face) / LF | R71.12 / R71.13 |
| chequeos_v71.py (nuevo) | R71.1 flecha norte con fachadas; R71.2 box contado dos veces; R71.3 accesorios de bulkhead > Σ vanos; R71.5 (un tag descartado "por otra tarea") | compuerta 0c |
| etapas.py | `compuerta` corre chequeos_v71 sobre el canon conciliado | compuerta 0c |
| headers.py | header_type "ASSUMED" / "NOT PRINTED" = error; CONT. BOX BEAM exige `run_ends` | R71.10 / R71.11 |
| canon.py | pasa `run_ends` / `run_ends_source` a headers; docstrings sin casos de proyecto | R71.11 |
| plantilla_excel.py | `verificar_r71_track`: con ≥ 2 tamaños de stud, bottom / top track un renglón por tamaño; ejemplo sin nombre de proyecto | R71.8 |
| track_por_tamano.py (nuevo) | reparte la familia de track por tamaño / gauge; resto "other"; resto negativo = falla | R71.8 |
| mep.py | sin offsets, página ni comentarios de un set; `arq` obligatorio; registro en cada corrida | R71.9 / E24 |
| vigas_sobre_walls.py | eje dentro de la band manda; dos vigas paralelas con rótulo distinto = `candidatas` + decisión; un dueño por rótulo | R71.14 |
| accesorios.py | slab pins también en chase; PAFs ROUNDUP por run de parapet (`_runs_parapet`) | A7 |
| framed_openings.py | `_src`: la primera parte cita N/HOJA, el resto puede ser texto | — |

Tests viejos ajustados (el default dejó de ser "run"): test_particion_v70, test_partition_types_v70, test_partition_types
(prueban "run" de forma explícita); test_headers y test_canon (fixture CONT. BOX BEAM con `run_ends`); test_plantilla_v68
(fixture con track por tamaño).

<!-- ===== CAMBIOS_tools_v72.md ===== -->
# CAMBIOS tools v72 (2026-10-19)

Origen: arbitraje de dos pruebas ciegas con el mismo skill (fuera del paquete). Todo genérico; cada cambio con test
en `test_v72.py` (18 tests; 17 fallan con las tools v71, el otro es protección).

| Tool | Cambio | Regla |
|---|---|---|
| chequeos_v72.py (nuevo) | compuerta 0d: type K por hatch y sin segmentos sin tag (R72.1); diagonal = promedio de caras (R72.2); `part_of` de la parte sin tag de un box (R72.3); vigas_sobre_walls manda (R72.4); MEP de mep.cruces y FD una vez (R72.5); side A\|B\|END (R72.6); jogs del FRP (R72.10); ATM con alternativas (R72.11). `partes_de_box()` compartida | §18 |
| etapas.py | `compuerta` corre chequeos_v72 (con vigas_out.json si está en 4_canon/ u out/); `unir`: 18 = 18.0, misma constante con fuentes distintas se une, metadatos de primer nivel por fragmento | 0d / P-02 |
| partition_types.py | la parte sin tag de un box va a OTHER FRAMING (`pier_part`): un box = un wall | R72.3 |
| particion.py | `STUB_MAX_FT` = 0.5: grupo suelto sin tag ≤ 6" se suma al wall con tag más cercano | R72.7 |
| accesorios.py | anchors solo element wall exterior; column wrap → pins; parte de box → RFI (R72.8); FD de openings / schedule y del barrido con el mismo WxH una vez (R72.5); plates × filas de studs + RFI (R72.9); jogs del FRP < 6" sin inside corner + RFI (R72.10); ATM: un RFI por alternativa (R72.11) | §18 |
| plantilla_excel.py | `fusionar`: familia citada por ≥ 2 renglones = repartida, conserva NET y Σ = familia; `verificar_r71_track` compara Σ con familias_out.json | R72.12 / R71.8b |
| vigas_sobre_walls.py | docstring: la salida manda (R72.4) | R72.4 |
| board_caras.py | `side: "END"` (return de un box): largo + fuente, fuera de Σ(side) = L, suma board (propuesta de una prueba) | R72.6 |
| cruzar_diagonal.py | genérico: muro desde la band D del canon, offset de mep.registro; sin geometría de un proyecto ni `mep.OFF` (test_sin_colisiones pasa) | R71.9 |
| idioma_es.py (nuevo en el paquete) | `es_espanol(texto)`; antes solo existía en el entorno de la prueba | — |

Tests viejos: ninguno cambiado. Fuera del zip (pedían argumentos o datos externos, ya fallaban así en el stack v71):
test_plantilla.py, test_alcances.py, test_eval_takeoff.py. inventario.py / test_inventario.py de las capas
etapas13 / v69 (inventario de TAGS, renombrado a inventario_tags.py en v70) no viajan: tapaban al inventario de walls.

<!-- ===== CAMBIOS_tools_v72b.md ===== -->
# CAMBIOS tools v72b (2026-10-19) — reglas inviolables

| Tool | Cambio |
|---|---|
| reglas.py (nuevo) | `compuerta <work_dir> [--excel]`: 67 chequeos (a) + motor de evidencia (b) por caso + catálogo completo; absorbe chequeos_v71, chequeos_v72, esquinas.py y la compuerta de etapas; recalcula las salidas con canon.py (vigencia); sale rc 1 con una falla; `faltantes`, `tabla`; sello del Excel (hoja oculta `_reglas`). Sin flag de override. |
| reglas_catalogo.py (nuevo) | extrae cada regla del SKILL.md y de referencias/ con id estable (ids explícitos E/R/PT/D/A/REGLA nn.n; viñetas por sección + huella del texto). |
| reglas_clasificacion.py (nuevo) | decisión a / b / c de cada regla; 35 specs de evidencia (b); una regla nueva sin decisión = falla. |
| plantilla_excel.py | `armar(d, salida, trabajo)`: corre `reglas.exigir(trabajo)` antes de escribir; exige `--familias` del familias_out.json de la carpeta de trabajo (`_familias_sha` de `fusionar`); sella el libro. CLI: `armar … --familias f [--trabajo d]`. El escritor interno `_escribir` solo lo usan los tests de formato: su libro no trae un sello válido y bitacora / reglas --excel lo rechazan. Ejemplo del docstring sin valores de proyecto. |
| etapas.py | `compuerta(d)` = `estructura(d)` + reglas.py compuerta (fallas "reglas: …"); `estructura` = la compuerta v69–v72. |
| bitacora.py | `compuerta` corre reglas.py en modo final (carpeta de trabajo por $TAKEOFF_WORK o junto al takeoff.json; Excel con sello vigente) y exige `reglas.py compuerta` en la bitácora con rc 0. |
| fixture_reglas.py (nuevo) | proyecto sintético de un wall con todo lo que la compuerta exige (etapas, canon, salidas, registro, bitácora, evidencia). |
| test_reglas.py (nuevo) | un test por regla (668): (a) caso malo / bueno por chequeo; (b) sin evidencia falla, con evidencia pasa, valor "a ojo" contradice; (c) fusión no vacía; armar no escribe con una regla violada. |
| test_ciego_tools.py (nuevo) | E24 sobre las tools (comentarios / docstrings + nombre del proyecto en todo el código). |
| ~50 tools | limpieza ciega: rutas por defecto con el proyecto → $TAKEOFF_WORK; nombres de archivo → $TAKEOFF_PREFIJO; cantidades / refs de proyecto en comentarios → `<n>` / `<ref>`; datos de proyecto en código (handoff, resumen_global, dataset, localizar, verif_*) → JSON de la carpeta de trabajo o variables de entorno. |
| test_etapas.py, test_etapas_v70.py, test_bitacora.py, test_plantilla_v67/v68.py | ajustados al comportamiento nuevo (la compuerta exige reglas OK; casos nuevos 25–28 en test_bitacora y 9 en test_etapas). |

Pendiente conocido (no se tocó para no aflojar compuertas): trinquetes medidos de un proyecto en `verif_idioma.py`
(TOPE_*) y `corpus.TOPE_CIERRES_MIN`, coordenadas de `indice_set.py` y la convención de nombres de bloques de cierre
de las tools v38–v60 (`verif_*`, `dataset`, `resumen_total`): siguen funcionando, pero su genericización completa es
trabajo aparte.

<!-- ===== CAMBIOS_tools_v73.md ===== -->
# CAMBIOS tools v73 (arbitraje #21)

Nuevas: cotas_banda.py, chequeos_v73.py, planmark.py (+ test_planmark), glosario.py, vocab_trade.py,
verif_respuesta.py (+ test_glosario, test_verif_respuesta), correr_suite.py, test_v73.py, test_indice_set.py,
test_registro_v73.py.

Cambiadas:
- reglas.py: v73; chequeos A_R73_1, _2, _5, _6, _7, _8 (consistencia con el plano); fos_chain acepta la forma dict
  de canon.py (P02); regex de anchors / pins aceptan el texto en inglés.
- reglas_clasificacion.py: R73.1–R73.18 clasificadas; R70.5 / R72.5 / R72.9 suman los chequeos v73.
- canon.py: WALL_KEYS + hatch_extent, dim_scan (P01); FRT plywood por material, espesor y USO con nombre de la
  plantilla; track_by_element; metal_blocking_by_origin; nombres_contexto.
- accesorios.py: stud reinforcement MEP solo con ductos de mep.cruces (R73.5; lo demás a RFI con delta); familia
  "deflection clips" (R73.6, P04); todos los textos que llegan al Excel en inglés (P08, R73.9).
- plantilla_excel.py: nombres de renglón de la plantilla (NOMBRES_PLANTILLA, track por elemento, metal blocking por
  origen) (R73.3); regex de yields aceptan el texto en inglés.
- particion.py: R72.7 con límite de distancia (R73.18).
- indice_set.py: genérico, sin coordenadas de un set; arma su propio cache (P05).
- registro.py: `corregir` (F01).
- eval_takeoff.py: rango min == max manda; _partition_types; modo "consistencia" no califica; bloque OTHER no sobra.
- test_ciego_tools.py: revisa test_*.py y fixtures; P6 rooms de tres dígitos, P7 ids de wall de planta, P8 lista externa.
- tests con datos sintéticos (rooms, ids y hojas inventados): test_canon, test_closer, test_headers,
  test_inventario, test_studs_nodos, test_corridas, test_etapas_v70, test_esquinas, test_framed_openings…

<!-- ===== CAMBIOS_tools_v74.md ===== -->
# CAMBIOS v74 (2026-10-20) — estudio de partición de walls + limpieza del paquete ciego

Origen: alineación wall por wall de la lista del estimador contra dos lecturas del mismo plano. Cada diferencia de
CONTEO se explicó con una regla genérica; ningún número, conteo ni wall de un proyecto entra al skill. Las
diferencias de LF que quedan son de lectura (cota, cara, esquina, door) y van como RFI con delta.

## Partición (particion.py modo "eje" = partition_types.py; SKILL §21)
- R74.1 type por espesor en la línea: segmento sin tag con el espesor de los walls con tag de su línea toma ese type
  (no el de la nota general).
- R74.2 stub aparte: grupo sin tag ≤ 6" que no toca un wall con tag de su type no es wall ni LF de la lista
  (reemplaza R72.7 / R73.18; va a `stubs` / OTHER FRAMING "stub", material en el canon).
- R74.3 nicho / alcove: grupo sin tag que cierra el hueco entre dos tramos colineales de otro type no es wall de la
  lista (va a `anexos` / OTHER FRAMING "alcove").
- R74.4 frente de bulkheads también en particion.py (comparar.py y partition_types dan lo mismo).
- R74.5 box sin tag con la huella de uno con tag = duplicado (no cuenta).
- R74.6 nombres exteriores únicos (EXT-<stud>CFMF, EXT-PARAPET, CANOPY-COL) en particion.py.
- inventario.py avisa R74.1 / R74.5. reglas_clasificacion: R74.1–R74.6.
- Tests: test_particion_v74.py (13 casos, datos inventados); test_v72 actualizado a R74.2.

## Limpieza ciega
- Fugas menores de adendas (v26, v30, v31, v34, v36, v37, v38, v42, v44, v45, v47), herramientas.md, SKILL y
  tools de producción (entregar, traducir_docs, verif_idioma, framed_openings, verif_planos, adyacencia,
  inventario, verif_blocking_schedule, vigas_sobre_walls, handoff, accesorios, headers, contar_tags): conteos,
  coordenadas pt, fechas, ids y títulos de detalle reales pasan a forma genérica.
- Archivos de cierre con nombre genérico: EJEMPLO_cierre.json, PUNTOS_cierres.json (un proyecto con el nombre viejo
  debe renombrarlo).
- test_ciego_tools.py --estricto: P17 conteos de corrida, P18 % de resultado en adendas, P19 nombres / ids / ángulos,
  P20 fechas en referencias/, P21 coordenadas pt, P22 título de detalle junto a N/HOJA.

## Sin cambio (decisiones del usuario)
- Conteo de 3-5/8" stud de las pruebas: aceptado. MEP fuera de calificación.

<!-- ===== CAMBIOS_tools_v75.md ===== -->
# CAMBIOS tools v75

- canon.py: TRACK_NOMBRES sin "soffit"; renglón "other framing" (R75.2); `ids_partition_takeoff`,
  `verificar_track_nombres` (R75.1); track_by_element después de partition_types; llama chequeos_v75.
- familias.py: EXCLUYE de "track de ceilings / soffits" lo que empieza con bottom / top (R75.1).
- accesorios.py: `_sill_return` sin default cuando hay return y sill; `_label_gyp` (R75.3); `_storefront_de_cripples`
  (R75.4).
- chequeos_v75.py (nuevo): R75.5 `verificar_r75_5`, R75.6 `alcove_con_esquina`, R75.7 `returns_sin_esquina`.
- reglas_clasificacion.py: R75.1–R75.7.
- test_v75.py (nuevo, 7 casos sintéticos); fixtures de test_canon / test_accesorios con jamb_return_label y
  sill_return.
- test_ciego_tools.py: P23 / P24 / P25 (estricto).
- inventario.py, studs_nodos.py, dataset.py: textos genéricos.
- v75b: textos genéricos (canon.py, familias.py, partition_types.py, inventario.py, README_etapas.md); test_ciego_tools P25 con comas y P18 con signo en comentarios.

<!-- ===== CAMBIOS_tools_v76.md ===== -->
# CAMBIOS tools v76

- chequeos_v76.py (nuevo): R76.1 `r76_1` (fascia_box ↔ canopy_joist por facade, canopy_joist → run canopy_soffit,
  hand-off de `otros_ceilings` consumido), R76.2 `r76_2` + `sheathing_column_wraps`, R76.3 `jogs_k` + `r76_3`
  (jog ballistic = hueco entre caras), R76.4 `aberturas_ext` + `r76_4` (substrate de aberturas), R76.5 `r76_5`
  (box con tag), R76.6 `bordes_transicion` + `r76_6_perimetro`.
- canon.py: llama `chequeos_v76.verificar`; `_column_wrap_sheathing` (R76.2); `_opening_substrate` (R76.4); track
  de perímetro de ceiling = perímetro − transiciones con `edge_of` (R76.6); `_polyiso` (nombre del nailbase con el
  espesor impreso); `stud_by_element` (framed soffit en su renglón); blocking material `wood` + `frt_basis`;
  `fos_chain_faces`; R70.6 no exige `type_lf_basis` cuando hay caras interiores con largo; WALL_KEYS con
  `sheathing`, `edge_of`, `beam_override`, `part_of`, `same_box_ok`, `opening_ref`, `type_change_rfi`,
  `anchorage`, `orientation`, `sheets_searched` (las leen otras tools).
- partition_types.py: `TAG_TYPE`; pier / column_wrap con tag de type sigue en su type aunque `location` sea exterior
  (R76.5); parte `part_of` interior de un box con tag suma sus caras al LF del box.
- plantilla_excel.py: `verificar_r71_track` clasifica con familias.py (en su unidad) y toma los tamaños de las filas
  de partition types (no de OTHER FRAMING); renglones `stud_by_element` y "Blocking 2X wood (not labeled FRT)".
- reglas.py: `A_BLOCKING` lee el rótulo (y `frt_basis`), no el source; `A_WRAP_FOS` acepta `fos_chain_faces`.
- reglas_clasificacion.py: R76.1–R76.9.
- bitacora.py: el paso E24 acepta `test_ciego.py` o `test_ciego_tools.py`. armar_ciego.py: `test_ciego.py` viaja.
- test_ciego.py: texto genérico. test_ciego_tools.py: comentario de P18B genérico.
- test_v76.py (nuevo, casos sintéticos por regla).

<!-- ===== CAMBIOS_tools_v77.md ===== -->
# CAMBIOS tools v77 — decisiones del usuario D1-D6 y compuertas R76.7

- canon.py: `_atm_wall` (D1): la wall del ATM con `atm_recess` pasa completa a "extra framing ATM" (studs de
  studs_nodos + bottom + top runner de corridas) y sale de su familia de stud / track (una vez); `front_line` viaja a
  headers.py; R77.7 `carrying_direction` obligatoria con ceilings suspendidos (joists con span propio siguen con span);
  llama chequeos_v77.
- accesorios.py: `atm_recess_valido` ({source N/HOJA, drawn}); la fórmula sistered + furring y `extra_framing` kind
  atm_recess = error; renglón "Extra framing - ATM wall (full wall framing, floor to deck + bottom and top runner)".
- headers.py (D2 / D5): CONT. BOX BEAM con `front_line` (primera a última jamb, ro_w_ft = jambs / escala, dos runs en
  la misma línea = error, run_ends solo jamb_to_jamb); piezas de cada fila del schedule = su rótulo (SINGLE 1,
  DOUBLE 2, "2-…" 2); door con with_sill = error.
- chequeos_v72.py: R72.11 = compuerta D1 (fórmula vieja o atm_recess fuera de un wall = falla).
- chequeos_v77.py (nuevo, D3 / D4): strips de pier por vector con scale_check, jambs × alto impreso, plies del rótulo
  + rfi; pier con `jamb_strips` o `jamb_strips_none_reason`.
- reglas.py: A_BLOCKING lee "F.R.T." (RX_FRT_ROTULO); A_TRACK_RUNS salta el renglón movido a ATM (`moved_to`).
- plantilla_excel.py: `es_texto_es` quita rutas, archivos, ids y coordenadas (R76.7 b); FRT plywood no se valida
  como repartido cuando se rehace desde `frt_plywood_by_material`.
- vigas_sobre_walls.py: `cruzar(..., hoja=)` solo bands de la hoja de planta (R76.7 c).
- bitacora.py: lock fcntl en `anotar` y realpath en hashes / vigencia (R76.7 d).
- copia_limpia.py (nuevo) + inventario_tags.py + alcances.py + arranque.py: siempre la copia sin /Annots; arranque.json
  en la carpeta de trabajo (R76.7 e).
- test_v77.py (nuevo, 13 casos); tests ATM / CONT / ceilings actualizados al esquema v77.

<!-- ===== CAMBIOS_tools_v77b.md ===== -->
# CAMBIOS tools v77b

- canon.py `_atm_wall`: el extra framing del ATM = la partición interior que contiene el ATM de lobby (studs_nodos +
  bottom + top runner de corridas), sin restar de las familias de stud / track; atm_recess en wall exterior = error;
  la wall exige `to_deck: true`; deja `rfi_una_vez` con el delta de contarla una sola vez.
- accesorios.py: suma la wall de `_atm_wall` y emite el RFI "counted once"; mensajes v77b.
- chequeos_v72.py R72.11: atm_recess en una wall exterior (tag EXT*, location exterior) = falla.
- chequeos_v77.py `r77_10`: R.O. de una door fuera del largo del wall (band + xy_pt) = falla.
- reglas.py A_TRACK_RUNS: sin el salto `moved_to`; comentario del rótulo F.R.T. sin N/HOJA de un set.
- reglas_clasificacion.py: R77.10 en vigencia.
- test_v77.py (D1 v77b, R77.10) y test_v72.py (R72.11 v77b) actualizados.

<!-- ===== CAMBIOS_tools_v77c.md ===== -->
# CAMBIOS tools v77c

- canon.py `_atm_wall` (U1, R77.11): el recess de ATM / equipo empotrado está en la wall que lo contiene; esa wall
  tiene que pasar por studs_nodos y corridas (su type lleva el metal); extra framing ATM = 0 (ya no suma la wall,
  ya no exige `to_deck`, ya no rechaza la wall exterior, ya no emite el RFI "counted once").
- accesorios.py (U1): `atm_recess_valido` acepta `extra_printed {source N/HOJA, text impreso, lf, op}` (RFI con
  delta, no suma); `extra_framing` de ATM a mano (kind atm_recess o ref ATM) = error; renglón "Extra framing - ATM
  recess (0: ...)".
- chequeos_v72.py R72.11 (U1): sin falla por wall exterior; extra_framing de ATM a mano = falla.
- canon.py `_sealant` (U8, R77.12): acoustical sealant EXCLUIDO (no calcula details[*].sealant ni sealant_items;
  aviso; `excluidas`); familia propia "sealant at base of gypsum (exterior)" (fuera de OBLIGATORIAS).
- familias.py (U8): familia "sealant at base of gypsum (exterior)" antes de "acoustical sealant".
- eval_takeoff.py (U8): modo "excluir" (sin renglón = EXCLUIDA OK; con renglón = MAL).
- alcances.py (U8): `EXCLUIDOS` (ALC-19 se cierra "EXCLUIDO: ..."; renglón de acoustical sealant en el Excel = falla).
- plantilla_excel.py: `acoustical_err` (U8, en validar y verificar), `EXCLUIDAS_SIEMPRE` (fusionar sobrescribe el
  alcance), `ordenar_revisar` / `revisar_err` / `verificar_v77c` (U9 / U10: fase, type, orden_plano, n/N, total
  anunciado, floor plan A-Z antes que los detalles); hoja Review Items con fila de total y columnas Phase / Type.
- reglas_clasificacion.py: R77.11–R77.16.
- Tests: test_v77.py (U1 reemplaza a D1), test_v77c.py (U7, U8 x3, U9/U10 x2, SKILL), test_v72.py, test_accesorios*.py,
  test_canon*.py, test_plantilla_v68.py actualizados.
