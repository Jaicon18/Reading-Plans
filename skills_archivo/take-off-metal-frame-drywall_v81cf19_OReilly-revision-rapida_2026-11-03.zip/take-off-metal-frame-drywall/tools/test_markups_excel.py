#!/usr/bin/env python3
"""test_markups_excel.py — R80f.7 / BE-117: verificar_markups_excel.py (compuerta A_MARKUPS_EXCEL) pasa con markups =
Excel = escala impresa y falla con (1) un LF del Excel distinto, (2) /Measure con otra escala que la impresa, (3) una
hoja con elementos del canon sin markups. Sintético (PDF de 2 hojas, Excel mínimo)."""
import json
import subprocess
import os
import shutil
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import openpyxl  # noqa: E402
import pymupdf as fitz  # noqa: E402
import markups_bluebeam as MB  # noqa: E402
import verificar_markups_excel as V  # noqa: E402

d = tempfile.mkdtemp()
doc = fitz.open()
for h in ("X101", "X102"):
    pg = doc.new_page(width=800, height=500)
    pg.insert_text((600, 470), h, fontsize=30)
    pg.insert_text((40, 470), "FLOOR PLAN  SCALE: 1/4\" = 1'-0\"", fontsize=10)
bid = os.path.join(d, "bid.pdf")
doc.save(bid)
W = {"id": "W1", "tag": "T1", "sheet": "X101", "page": 1, "length_ft": 11.111, "height_ft": 9.0, "detail": "1/X301",
     "band": {"ori": "H", "c0": 99, "c1": 101, "lo": 100, "hi": 300, "sheet": "X101"}}
can = {"constants": {"plan_scale_pt_per_ft": {"value": 18.0, "source": "X101 1/4\" = 1'-0\""},
                     "plan_scale_by_sheet": {"X101": {"value": 18.0, "source": "X101 1/4\" = 1'-0\""}}},
       "walls": [W]}
cp = os.path.join(d, "canon.json")
json.dump(can, open(cp, "w"))
mk = os.path.join(d, "6_markups", "markups.pdf")
MB.escribir(bid, cp, mk, os.path.join(d, "6_markups", "markups.json"))


def excel(p, lf=11.111):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Partition Takeoff"
    ws.append(["PARTITION TAKEOFF"])
    ws.append(["Partition / Scope", "Wall #", "Length (LF)", "Height (FT)", "Layers", "Stud Size", "Stud O.C. (in)",
               "Board (SF)", "Location", "Source (DETAIL/SHEET)", "Status"])
    ws.append(["TYPE T1"])
    ws.append(["T1  #W1  -  room", "W1", lf, 9.0, 1, "3-5/8\"", 16, round(11.111 * 9, 2), "room", "1/X301", "[DERIVED]"])
    ms = wb.create_sheet("Material Summary")
    ms.append(["MATERIAL SUMMARY"])
    ms.append(["Material", "Unit", "Net", "Waste %", "Waste", "Purchase", "Selling unit", "Pieces to buy",
               "Where it comes from", "Yield check (live formula)"])
    wb.save(p)
    return p


xl = excel(os.path.join(d, "ok.xlsx"))
f, lin, res = V.verificar(mk, xl, cp)
assert f == [] and res["annots"] == 1 and len(lin) == 1 and lin[0].startswith("OK"), (f, lin)
assert V.buscar_pdf(d, cp, None) == os.path.abspath(mk)

# (1) LF del Excel distinto
f, _, _ = V.verificar(mk, excel(os.path.join(d, "lf.xlsx"), lf=12.5), cp)
assert any("LF 11.11 != Excel 12.5" in x for x in f), f

# (2) /Measure con 1/8" = 1'-0" (9 pt/ft) sobre una hoja impresa a 1/4"
mal = os.path.join(d, "escala.pdf")
dd = fitz.open(mk)
for a in dd[0].annots():
    MB._measure(dd, a, 9.0)
dd.save(mal)
f, _, _ = V.verificar(mal, xl, cp)
assert any("/Measure" in x and "!= escala de la hoja 18.0" in x for x in f), f
# escala del canon que no es la impresa
c2 = json.loads(json.dumps(can))
c2["constants"]["plan_scale_by_sheet"]["X101"]["value"] = 9.0
cp2 = os.path.join(d, "canon_esc.json")
json.dump(c2, open(cp2, "w"))
f, _, _ = V.verificar(mk, xl, cp2)
assert any("rótulo SCALE" in x for x in f), f

# (3) hoja X102 con elementos en el canon y sin markups
c3 = json.loads(json.dumps(can))
c3["walls"].append(dict(W, id="W2", sheet="X102", page=2, band=dict(W["band"], sheet="X102")))
cp3 = os.path.join(d, "canon_hoja.json")
json.dump(c3, open(cp3, "w"))
f, _, _ = V.verificar(mk, xl, cp3)
assert any(x.startswith("hoja X102") for x in f) and any(x.startswith("W2:") for x in f), f

# CLI: rc 1 con falla, rc 0 bien, reporte de una línea por anotación
rep = os.path.join(d, "r.md")
assert V.main(["v", mk, xl, cp, "--out", rep]) == 0
assert "- OK   | p.1 X101 W1 |" in open(rep, encoding="utf-8").read()
assert V.main(["v", mal, xl, cp]) == 1

# compuerta de reglas.py registrada
import reglas  # noqa: E402
assert "A_MARKUPS_EXCEL" in reglas.CHEQUEOS
shutil.rmtree(d, ignore_errors=True)
# R80e.136 (O'Reilly 3-nov): revision_markups.py (revisión rápida VERDE/ROJA + mapa de alturas) — su test sintético
_rm = subprocess.run([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), "revision_markups.py"),
                      "--selftest"], capture_output=True, text=True)
assert _rm.returncode == 0 and "OK selftest revision_markups" in _rm.stdout, _rm.stdout + _rm.stderr
print("test_markups_excel OK")
