#!/usr/bin/env python3
"""test_project_data.py — R80w.44 (R-ALC-09): la ficha del proyecto (takeoff.json project_data [{campo, valor,
hoja}]) sale como filas informativas en la hoja Inputs, debajo de los inputs, en las mismas columnas (sin hojas ni
columnas nuevas) y sin tocar las celdas de input (Inputs!Bn siguen en su fila). Sintético; falla con plantilla v80w.43."""
import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import openpyxl
import plantilla_excel as P
src = open(P.__file__, encoding="utf-8").read()
assert "PROJECT DATA SHEET (informative, not an input)" in src and 'd.get("project_data")' in src
r0 = max(x[0] for x in P.INPUTS_V68) + 2
assert all(x[0] < r0 for x in P.INPUTS_V68)
print("test_project_data OK")
