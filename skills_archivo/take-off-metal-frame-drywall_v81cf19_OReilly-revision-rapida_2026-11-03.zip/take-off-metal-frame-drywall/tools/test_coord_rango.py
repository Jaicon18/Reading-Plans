#!/usr/bin/env python3
"""test_coord_rango.py — R80w.19: una coordenada con rango ("y 1813-1875", "x 10.5-20") en un texto del Excel no deja una
"y" suelta que el chequeo de idioma lea como español. Sintético; falla con plantilla_excel v80v. Protección: una "y"
española de verdad sigue detectada."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import plantilla_excel as P
assert P.es_texto_es("Room X1 sink area (W face of V, y 1813-1875) 1.76 x 12.08 ft") == [], \
    P.es_texto_es("Room X1 sink area (W face of V, y 1813-1875) 1.76 x 12.08 ft")
assert P.es_texto_es("north face (x 10.5-20.25 pt) of the wall") == []
assert P.es_texto_es("la cara norte y la cara sur del muro"), "español real no detectado (protección)"
print("test_coord_rango OK")
