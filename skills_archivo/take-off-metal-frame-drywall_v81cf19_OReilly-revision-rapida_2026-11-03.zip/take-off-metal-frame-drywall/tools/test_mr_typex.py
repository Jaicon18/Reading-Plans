#!/usr/bin/env python3
"""test_mr_typex.py — R80w.45: un renglón "5/8 Type X MR (moisture resistant)" (MR con núcleo Type X, como lo pide el
spec) es de la familia MR, no de Type X; Type X y Type X W.R. siguen en las suyas. Sintético; falla con familias v80w.44."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import familias as F
assert F.familia('5/8" gypsum board, Type X MR (MOISTURE RESISTANT, 09 29 00 2.3.E)', "sf") == '5/8" gyp MOISTURE RESISTANT'
assert F.familia('5/8" gypsum board, Type X', "sf") == '5/8" gyp board Type X'
assert F.familia('5/8" gypsum board, Type X W.R. (water resistant)', "sf") == '5/8" gyp Type X W.R.'
print("test_mr_typex OK")
