#!/usr/bin/env python3
"""test_revision_markups.py — test sintético de revision_markups.py (R80e.100).
Arma un PDF de 1 página (label A1.1) con 2 markups PolyLine (/Contents TYPE · LF · H · SF · DETAIL · ID, /Depth) y un
Excel mínimo (Partition Takeoff) y comprueba: el wall correcto sale GREEN; el que tiene la línea 2 % más larga y la
Depth distinta sale RED con las dos fallas; el mapa de alturas y el recorte rojo se escriben."""
import os
import subprocess
import sys
import tempfile

import openpyxl
import pymupdf

AQUI = os.path.dirname(os.path.abspath(__file__))


def main():
    d = tempfile.mkdtemp()
    pdf, xlsx, out = os.path.join(d, "m.pdf"), os.path.join(d, "t.xlsx"), os.path.join(d, "out")
    doc = pymupdf.open()
    p = doc.new_page(width=2592, height=1728)
    doc.set_page_labels([{"startpage": 0, "prefix": "A1.1", "style": "", "firstpagenum": 1}])
    # escala impresa 1/8" = 1'-0" -> 9 pt/ft
    for wid, x0, length_ft, h_lbl, depth in (("W-1", 100, 20.0, "10'-0\"", 10.0), ("W-2", 400, 10.2, "8'-0\"", 9.0)):
        a = p.add_polyline_annot([(x0, 200), (x0 + length_ft * 9, 200)])
        lf = 20.0 if wid == "W-1" else 10.0
        h = 10.0 if wid == "W-1" else 8.0
        a.set_info(content=f"A1 · {lf:.2f} LF · H {h_lbl} · {lf * h:,.1f} SF · 1/A5.1 · {wid}", subject="A1")
        a.update()
        doc.xref_set_key(a.xref, "Depth", str(depth))
    doc.save(pdf)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Partition Takeoff"
    for _ in range(4):
        ws.append([None])
    ws.append(["TYPE A1"])
    ws.append(["A1 #W-1", "W-1", 20.0, 10.0, 1, "3-5/8\"", 16, 200, "x", "1/A5.1", "[CONFIRMED]"])
    ws.append(["A1 #W-2", "W-2", 10.0, 8.0, 1, "3-5/8\"", 16, 80, "x", "1/A5.1", "[CONFIRMED]"])
    wb.save(xlsx)
    r = subprocess.run([sys.executable, os.path.join(AQUI, "revision_markups.py"), pdf, xlsx, out, "--scale", "A1.1=1/8"],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    assert "GREEN 1 / RED 1" in r.stdout, r.stdout
    assert "RED W-2" in r.stdout and "LF measured" in r.stdout and "Depth 9.000 vs H 8.000" in r.stdout, r.stdout
    assert os.path.exists(os.path.join(out, "height_map_A1.1.png"))
    assert os.path.exists(os.path.join(out, "img", "RED_W-2.png"))
    print("OK test_revision_markups")


if __name__ == "__main__":
    main()
