#!/usr/bin/env python3
"""test_hoja_sufijo.py — R80w.12: una hoja con sufijo de letra (RCP / elevaciones "A421.A", "A000.B") es una HOJA válida
para reglas.py (HOJA / NHOJA) y para runner/evidencia.py (HOJA). Sintético: falla con reglas.py / evidencia.py v80v."""
import os, sys
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
sys.path.insert(0, os.path.join(AQUI, "..", "runner"))
import reglas

ok_hoja = ["X421.A 10'-0\" ceiling tag", "elev 3/X426.A", "X000.B note", "X101", "X-101", "X2.10", "X421.AB"]
for t in ok_hoja:
    assert reglas.HOJA.search(t), f"HOJA no reconoce {t!r}"
assert reglas.NHOJA.search("3/X426.A"), "NHOJA no reconoce 3/X426.A"
assert reglas.NHOJA.search("D/X301"), "NHOJA protección"
# protecciones: un número suelto / keynote con dígitos tras el punto siguen como antes
assert not reglas.HOJA.search("421.5 pt"), "un número no es hoja"
assert reglas.HOJA.search("X421.5") is None or reglas.HOJA.search("X421.5").group(0) != "X421", "X421.5 no es X421"
try:
    import evidencia
    assert evidencia.HOJA.search("X421.A ceiling").group(1) == "X421.A", "evidencia.HOJA corta el sufijo .A"
    assert evidencia.HOJA.search("X-101 plan").group(1) == "X-101"
    assert evidencia.HOJA.search("X4.2 plan").group(1) == "X4.2"
except ImportError:          # el paquete de tools sin runner: solo reglas
    pass

# BE-GK02 (Grand Kia): página vectorial sin capa de texto = necesita capa OCR; página con texto no.
def test_be_gk02_hojas_sin_texto():
    import pymupdf, palabras_fitz
    d = pymupdf.open()
    p1 = d.new_page(); p1.insert_text((72, 72), "PARTITION TYPE A FULL HEIGHT")
    p2 = d.new_page(); p2.draw_line((10, 10), (300, 300)); p2.draw_rect(pymupdf.Rect(50, 50, 90, 70))
    p3 = d.new_page()
    assert palabras_fitz.hojas_sin_texto(d) == [2], palabras_fitz.hojas_sin_texto(d)


# BE-GK01 (Grand Kia): el arranque asegura también openpyxl (el Excel fijo) además de pikepdf / pymupdf / pdfplumber.
def test_be_gk01_deps():
    import arranque
    mods = [m for m, _ in arranque.DEPS]
    for m in ("pikepdf", "fitz", "pdfplumber", "openpyxl"):
        assert m in mods, m


test_be_gk02_hojas_sin_texto()
test_be_gk01_deps()
print("test_hoja_sufijo OK")
