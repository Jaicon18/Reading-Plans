#!/usr/bin/env python3
"""checklist_revision.py — U-168 (usuario 11-nov: "todo esas maneras de revisar y asegurarte que todo este sin errores, los
combiertas en reglas inviolables para a que no se me ooviden ami tampoco, incluyendo las cvs").

Genera CHECKLIST_REVISION.xlsx para la raíz de toda entrega FINAL: lo que el USUARIO revisa al recibir (parte B del protocolo),
ya llenado con lo que Claude verificó por programa (parte A: A1 re-medición en vectores, A2 alturas contra la cota impresa).
Texto del entregable en inglés; las instrucciones en español solo en las celdas de ayuda (fila 2 de cada hoja, 'AYUDA (ES)').

  B1 Longest walls             las A1_N walls más largas: Wall ID, hoja, Length del Excel, re-medición A1, casilla Bluebeam, diferencia
  B2 Heights                   cada altura distinta (Depth): detalle N/HOJA, cota impresa, resultado A2, casilla OK
  B3 Sheets to walk            hojas de planta / RCP / ampliadas con markups: casilla "no blank rooms / walls"
  B4 Exclusions & decisions    toda exclusión del Scope Checklist y toda decisión de Review Items con su delta: casilla "agree"
  B5 Bluebeam CSV              pasos para exportar el CSV de Bluebeam y subirlo (U-157 / U-167): casilla por paso
  B6 Coverage                  (U-193, --b6 Auditoria/COBERTURA.csv) hojear 'MAPA DE COBERTURA - IMAGE ONLY.pdf': 0 rojos por hoja

Uso: python3 -I checklist_revision.py <takeoff.xlsx> <markups.pdf> <bidset_limpio.pdf> <canon.json> <salida.xlsx>
         [--proy CR] [--b5-hecho "<texto de la comparación ya hecha>"] [--b2-3lados Auditoria/COMPARACION_ALTURAS.csv (U-175)] [--b2-muestra Auditoria/ALTURAS_MUESTRA.json (U-176)]
La compuerta CE_CHECKLIST_USUARIO comprueba el archivo (5 secciones, las A1_N walls más largas, todas las alturas, todas las exclusiones)."""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import compuerta_entrega as CE  # noqa: E402

NO, SI = "☐", "☑"           # casilla vacía / marcada
AYUDA = "AYUDA (ES): "


def _delta(texto, defecto):
    t = str(texto or "")
    m = re.search(r"(?i)\bdelta\b[^.;|]{0,160}", t)
    if m:
        return m.group(0).strip()
    if re.search(r"(?i)\bno change\b", t):
        return "No change"
    return defecto


def datos(xlsx, markups_pdf, plano_pdf, canon):
    import openpyxl
    import pymupdf
    a1, f1 = CE.a1_remedir(xlsx, markups_pdf, plano_pdf)
    a2, f2 = CE.a2_alturas(xlsx, markups_pdf, plano_pdf, canon)
    wb = openpyxl.load_workbook(xlsx, data_only=True)
    b4 = []
    if "Scope Checklist" in wb.sheetnames:
        for r in wb["Scope Checklist"].iter_rows(min_row=2, values_only=True):
            if r and r[0] and (str(r[2] or "").upper() == "NOT APPLICABLE" or str(r[3] or "").upper().startswith("EXCLUDED")):
                b4.append(("Scope exclusion", str(r[0]).strip(), f"{r[1]} - {r[3]}", _delta(r[3], "Not in this bid (0)")))
    if "Review Items" in wb.sheetnames:
        for r in wb["Review Items"].iter_rows(min_row=3, values_only=True):
            if r and r[0] and "/" in str(r[0]):
                b4.append(("Review Item", str(r[0]).strip(), f"{r[2]}: {r[3]} ({r[4]})", _delta(r[3], "See item")))
    d = pymupdf.open(markups_pdf)
    b3 = []
    for i in range(d.page_count):
        lab = d[i].get_label() or f"p{i + 1}"
        mk = ex = 0
        for a in d[i].annots() or []:                    # una pasada: la annot solo vale mientras el iterador la tiene
            nm, sub = (a.info or {}).get("id", ""), str((a.info or {}).get("subject") or "")
            if nm.startswith(("TO-", "TOX-", "DEMO-")) and not nm.startswith("TO-LEGEND-"):
                mk += 1
            elif "EXCLUDED" in sub and a.type[1] == "FreeText":
                ex += 1
        if mk or ex:
            kind = "RCP" if re.match(r"A3\.", lab) else ("Floor plan" if re.match(r"A2\.", lab) else "Enlarged plan / detail")
            b3.append((lab, kind, mk, ex))
    return a1, f1, a2, f2, b3, b4


def escribir(salida, xlsx, markups_pdf, a1, f1, a2, f2, b3, b4, proy="", b5_hecho="", b2_3lados="", b2_muestra="", b6=""):
    import openpyxl
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.worksheet.datavalidation import DataValidation
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    neg, gris = Font(bold=True), PatternFill("solid", fgColor="EEEEEE")
    amar = PatternFill("solid", fgColor="FFF2CC")
    mk = os.path.basename(markups_pdf)

    def hoja(nombre, titulo, ayuda, enc, anchos):
        ws = wb.create_sheet(nombre)
        ws["A1"] = titulo
        ws["A1"].font = Font(bold=True, size=12)
        ws["A2"] = AYUDA + ayuda
        ws["A2"].alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=len(enc))
        ws.row_dimensions[2].height = 48
        for k, (h, w) in enumerate(zip(enc, anchos), 1):
            c = ws.cell(row=3, column=k, value=h)
            c.font, c.fill = neg, gris
            c.alignment = Alignment(wrap_text=True)
            ws.column_dimensions[openpyxl.utils.get_column_letter(k)].width = w
        dv = DataValidation(type="list", formula1=f'"{NO},{SI}"', allow_blank=True)
        ws.add_data_validation(dv)
        ws.freeze_panes = "A4"
        ws.page_setup.orientation = "landscape"          # impresa: todas las columnas en el ancho de la hoja
        ws.page_setup.fitToWidth, ws.page_setup.fitToHeight = 1, 0
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        return ws, dv

    ws, dv = hoja("B1 Longest walls", f"B1 - The {len(a1)} longest walls: measure each one in Bluebeam",
                  f"Abre '{mk}' en Bluebeam, busca cada Wall ID (Markups List, columna ID), mide la wall con la herramienta Length "
                  "y escribe la medida en la columna G. La diferencia se calcula sola; si pasa de 1 ft avísale a COORDINACIÓN. "
                  "Las columnas E y F son la re-medición que Claude hizo en los vectores del plano (A1).",
                  ["#", "Wall ID", "Sheet", "Excel Length (LF)", "Claude A1 vector re-measure (LF)", "A1 delta (ft)",
                   "Measured in Bluebeam (LF)", "Difference (ft)", "Checked"], [5, 22, 9, 14, 16, 11, 16, 13, 10])
    for k, r in enumerate(a1, 1):
        f = 3 + k
        ws.append([k, r["wall"], r["sheet"], r["lf"], r["medido"], r["delta"], None, f'=IF(G{f}="","",G{f}-D{f})', NO])
        ws.cell(row=f, column=7).fill = amar
        dv.add(f"I{f}")
    ws.append([])
    ws.append(["", "Claude A1 result: " + ("PASS - every |delta| <= 1 ft" if not f1 else f"FAIL - {len(f1)} wall(s) over 1 ft")])

    ws, dv = hoja("B2 Heights", "B2 - Every distinct wall height (Bluebeam Depth) against its printed dimension",
                  "Para cada altura abre el detalle N/HOJA de la columna E y confirma la cota impresa (columna F). "
                  "PRINTED = la cota está impresa; DERIVED = sale de cotas impresas u otras alturas ya verificadas (la operación "
                  "está en la columna H); VECTOR = medida en el plano a la escala impresa (no hay cota): revisala en Bluebeam. "
                  "Marca OK cuando estés de acuerdo.",
                  ["Depth (ft)", "Depth (ft-in)", "Rows", "Example Wall ID", "Detail N/SHEET", "Printed dimension",
                   "Claude A2 status", "Note", "OK"], [11, 13, 7, 22, 14, 22, 14, 70, 7])
    for r in a2:
        ws.append([r["depth"], r["ftin"], r["walls"], r["ejemplo"], r["cita"], r["impresa"], r["estado"], r["nota"], NO])
        ws.cell(row=ws.max_row, column=8).alignment = Alignment(wrap_text=True, vertical="top")
        dv.add(f"I{ws.max_row}")
    ws.append([])
    ws.append(["", "Claude A2 result: " + ("PASS - every height checked" if not f2 else f"FAIL - {len(f2)} height(s): see Note")])
    if b2_3lados:                                   # U-175: comparación de alturas a tres lados (Bluebeam / Excel / impresa)
        import csv as _csv
        fl = list(_csv.DictReader(open(b2_3lados, encoding="utf-8-sig")))
        ok_ = sum(1 for r in fl if r.get("Result") == "OK")
        ws.append(["", f"Three-way height check (U-175): {ok_}/{len(fl)} markups OK - Bluebeam Depth = Excel Height = printed height "
                       "(Auditoria/COMPARACION_ALTURAS.csv; printed heights read independently in Auditoria/ALTURAS_IMPRESAS.csv)"])
    if b2_muestra:                                  # U-176 control 6: walls al azar, una por altura distinta como mínimo
        import json as _json
        ws.append([])
        ws.append(["", "Random sample (U-176): check these walls yourself in Bluebeam (Depth) and in Planos marcados/ALTURAS_REVISADAS.pdf"])
        ws.append(["Wall ID", "H (ft)", "ALTURAS_REVISADAS page", "", "", "", "", "Open the page: printed dimension circled + operation", "OK"])
        for m in _json.load(open(b2_muestra)):
            ws.append([m["Wall ID"], m["H (ft)"], m["ALTURAS_REVISADAS page"], "", "", "", "", "", NO])
            dv.add(f"I{ws.max_row}")

    ws, dv = hoja("B3 Sheets to walk", "B3 - Sheets to walk in Bluebeam: no room / wall left blank",
                  "Recorre cada hoja en Bluebeam: en las plantas toda wall dibujada debe tener su markup de color o un texto rojo "
                  "EXCLUDED; en los RCP todo cuarto debe tener su polígono de cielo o EXCLUDED. Marca la casilla si no hay nada en blanco.",
                  ["Sheet (Page Label)", "Kind", "Take-off markups", "EXCLUDED texts", "No blank rooms / walls"], [16, 22, 16, 15, 20])
    for lab, kind, n_, e_ in b3:
        ws.append([lab, kind, n_, e_, NO])
        dv.add(f"E{ws.max_row}")

    ws, dv = hoja("B4 Exclusions & decisions", "B4 - Every scope exclusion and every Review Item decision, with its delta",
                  "Lee cada exclusión del Scope y cada decisión de los Review Items con su delta (lo que cambia si se decide lo "
                  "contrario). Marca 'Agree' si estás de acuerdo; si no, escribe tu decisión en la columna F para COORDINACIÓN.",
                  ["Kind", "ID", "Item", "Delta", "Agree", "Your decision (if not agree)"], [16, 14, 90, 40, 8, 30])
    for kind, i_, txt, dl in b4:
        ws.append([kind, i_, txt, dl, NO, None])
        ws.cell(row=ws.max_row, column=3).alignment = Alignment(wrap_text=True, vertical="top")
        dv.add(f"E{ws.max_row}")

    ws, dv = hoja("B5 Bluebeam CSV", "B5 - Export the Bluebeam Markups List to CSV and upload it",
                  "Estos pasos le permiten a COORDINACIÓN comparar por programa cada markup de Bluebeam contra el Excel "
                  "(comparar_csv_bluebeam.py). Marca cada paso cuando lo hagas.",
                  ["Step", "Action", "Done"], [6, 110, 8])
    nombre_csv = f"{proy + '_' if proy else ''}markups - CSV.csv"
    pasos = [f"Open '{mk}' in Bluebeam Revu.",
             "Open the Markups List (Window > Markups List, or Alt+L).",
             "Columns: make sure ID, Subject, Page Label, Length, Area, Wall Area and Depth are shown (right-click a column header).",
             "Markups List menu > Summary > CSV Summary; export ALL markups (no filter).",
             f"Save it as '{nombre_csv}'.",
             "Upload the CSV to this same revision folder in Drive and tell COORDINACION it is there.",
             "COORDINACION runs comparar_csv_bluebeam.py and reports matched N / N; the project is closed only at N / N."]
    hecho = SI if b5_hecho else NO
    for k, p in enumerate(pasos, 1):
        ws.append([k, p, hecho])
        dv.add(f"C{ws.max_row}")
    ws.append([])
    ws.append(["", "CSV comparison: " + (b5_hecho or "pending (upload the CSV)")])
    if b6:                                              # U-193: hojear el mapa de cobertura, 0 rojos
        import csv as _csv
        ws, dv = hoja("B6 Coverage", "B6 - Walk 'MAPA DE COBERTURA - IMAGE ONLY.pdf': 0 red walls / rooms",
                      "Abre 'Planos marcados/MAPA DE COBERTURA - IMAGE ONLY.pdf': lo verde tiene markup, lo ROJO (grueso, circulado y numerado) es un "
                      "muro o cuarto dibujado SIN markup ni disposición. Marca la casilla de cada hoja cuando no quede ningún rojo.",
                      ["Sheet (Page Label)", "Walls detected", "Wall LF covered %", "Rooms (ceiling / excluded)", "RED", "0 red (checked)"],
                      [16, 16, 18, 24, 8, 16])
        filas = list(_csv.DictReader(open(b6, encoding="utf-8")))
        for h in dict.fromkeys(f["hoja"] for f in filas):
            fh = [f for f in filas if f["hoja"] == h]
            mu = [f for f in fh if f["tipo"] == "muro"]
            lf = sum(float(f["largo_ft"] or 0) for f in mu)
            ok = sum(float(f["largo_ft"] or 0) for f in mu if f["estado"] != "ROJO")
            cu = [f for f in fh if f["tipo"] == "cielo"]
            ws.append([h, len(mu), round(100 * ok / lf) if lf else None,
                       f"{sum(1 for f in cu if f['estado'] == 'CUBIERTO')} / {sum(1 for f in cu if f['estado'] in ('EXCLUDED', 'DISPUESTO'))}",
                       sum(1 for f in fh if f["estado"] == "ROJO"), NO])
            dv.add(f"F{ws.max_row}")
    os.makedirs(os.path.dirname(os.path.abspath(salida)) or ".", exist_ok=True)
    tmp = salida + ".tmp.xlsx"
    wb.save(tmp)
    os.replace(tmp, salida)
    return salida


def main(argv):
    if len(argv) < 6:
        print(__doc__)
        return 2
    proy = argv[argv.index("--proy") + 1] if "--proy" in argv else ""
    b5 = argv[argv.index("--b5-hecho") + 1] if "--b5-hecho" in argv else ""
    b23 = argv[argv.index("--b2-3lados") + 1] if "--b2-3lados" in argv else ""
    b2m = argv[argv.index("--b2-muestra") + 1] if "--b2-muestra" in argv else ""
    b6 = argv[argv.index("--b6") + 1] if "--b6" in argv else ""          # U-193: Auditoria/COBERTURA.csv
    xlsx, mk, plano, canon, salida = argv[1:6]
    a1, f1, a2, f2, b3, b4 = datos(xlsx, mk, plano, canon)
    escribir(salida, xlsx, mk, a1, f1, a2, f2, b3, b4, proy, b5, b23, b2m, b6)
    fs = CE.checklist_fallas(salida, xlsx)
    print(f"{salida}: B1 {len(a1)} walls (A1 {'PASS' if not f1 else 'FAIL ' + str(len(f1))}), B2 {len(a2)} heights "
          f"(A2 {'PASS' if not f2 else 'FAIL ' + str(len(f2))}), B3 {len(b3)} sheets, B4 {len(b4)} items, B5 "
          f"{'done' if b5 else 'pending'}; CE_CHECKLIST_USUARIO {'PASS' if not fs else 'FAIL: ' + '; '.join(fs)}")
    for x in f1 + f2:
        print("  " + x)
    return 1 if fs else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
