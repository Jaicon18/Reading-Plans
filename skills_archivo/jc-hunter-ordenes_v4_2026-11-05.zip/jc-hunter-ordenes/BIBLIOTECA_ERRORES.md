# BIBLIOTECA DE ERRORES — pruebas que se corren en TODO proyecto (Paso 12 b)

Cada error confirmado en un proyecto (BOA Broomfield, B&N Colorado Springs, …) es una PRUEBA. En el Paso 12 de cada
entrega se corren TODAS contra el Excel + markups + planos del proyecto, con resultado **PASS / FAIL / N/A** y evidencia
(N/HOJA + recorte circulado). Un FAIL bloquea la entrega hasta corregirse; un error nuevo se agrega aquí el mismo turno.

Formato de cada prueba: **ID · origen · qué falló · cómo se prueba · criterio PASS**.
Los términos del trade van en inglés.

## A. Lectura del plano (detalles, notas, capas)

| ID | Origen | Qué falló | Cómo se prueba | PASS si… |
|---|---|---|---|---|
| BE-01 | B&N rev4 (auditor) — R80e.25 c | Fire-stop track "METAL STUD/TRACK FIRE STOP AT CEILING LINE, TYP." (8/A-410) no se había cuantificado | Buscar en el set todo detalle de top track / ceiling line con "FIRE STOP" o "TYP."; en el Excel debe existir el track de fire stop por tamaño de stud, sobre los walls a deck con ceiling en al menos una cara, + RFI de confirmación | Hay renglón (o parte de renglón con desglose) por tamaño, LF ≤ Σ LF de walls a deck de ese tamaño, y RFI/nota que lo cita |
| BE-02 | B&N rev4 (auditor) — R80e.25 a | Nota "W.R. … FOR WALL AND CEILING CONSTRUCTION" aplicada solo a walls | Leer las partition notes / specs de W.R.; si dicen "ceiling", los GWB ceilings de esos rooms van en W.R. | El desglose del board W.R. incluye los GWB ceilings de cada wet room con GWB ceiling (los de ACT no) |
| BE-03 | B&N rev1–rev6 — RFI-11 | W.R. en walls de wet rooms (todas las caras de restrooms, janitor, alcove) | Para cada room húmedo (finish schedule + notas) listar sus caras; cada cara con gypsum debe estar en W.R. | Toda cara con gypsum de esos rooms está en W.R.; ninguna queda en Type X regular |
| BE-04 | B&N rev6 — R80e.26 | Se cargó W.R. (y plywood) en caras que NO llevan gypsum (Cafe Work Room = FRT plywood + FRP) | Por cada cara en W.R., abrir la sección del type y confirmar que esa cara lleva gypsum board dibujado | Ninguna cara sin gypsum aparece en W.R. / board |
| BE-05 | B&N rev0–rev5 — R80e.26 (RFI-37) | Capas por cara mal contadas: "X = A, B" con dos flechas leído como dos capas por lado; plywood cargado detrás del GWB del lado Sales | Para cada partition type con sección: contar capas lado por lado en el DIBUJO (punteado = gypsum, rayado cruzado = plywood) y seguir cada leader; comparar con "Board by face" del Excel | Cada cara del Excel tiene exactamente las capas y materiales dibujados en su lado |
| BE-06 | B&N rev3–rev5 — RFI-14 / 2/A-221 | Soffit cargado en una sola cara / un solo lado | Todo soffit (framed soffit, header soffit) con sus caras: todos los lados abiertos (N, E, …) y el fondo; board y substrate por cara según su sección | Existen filas para cada lado expuesto del soffit + su fondo, cada uno con su detalle |
| BE-07 | B&N rev5 — R80e.23 | Remate de type por tag "SIM." (cara de extremo de un wall con tag de otro type) no cuantificado | Barrer los tags con "SIM." en la planta; cada uno ubica una cara de remate | Cada tag "SIM." tiene su fila (LF = espesor impreso) con su acabado |
| BE-08 | §0.F (todo proyecto) | Lectura A/B que contradecía una cota impresa | Para walls con cota impresa, comparar LF del Excel con la cota | Todo LF con cota impresa coincide (± 1") o la diferencia es decisión del estimador citada |
| BE-09 | B&N rev1 — RFI-01 | Perímetro existing cuantificado como nuevo | Leer demo plan (legend existing/to remain, key notes) + construction legend + responsibility schedule; los walls existing quedan EXCLUDED con cita y sus markups marcados "EXISTING – EXCLUDED" | Ningún wall existing en el Excel; patch & repair como allowance/RFI |
| BE-10 | B&N rev4 — R80e.25 d | Soffit con cota "HOLD" dejado como "not priced" | Toda cota HOLD + altura RCP + sección = soffit cuantificado; lo no impreso (T.O. WD-1) = RFI con supuesto conservador | Soffit HOLD cuantificado + RFI |
| BE-11 | B&N rev4 — R80e.25 e | Área rotulada "AREA OF 3/4" FIRE RESISTANT PLYWOOD" no cargada | Barrer plantas ampliadas por "AREA OF … PLYWOOD / BACKING / BLOCKING" | Cada área rotulada tiene SF en plywood + RFI de extensión si no está acotada |
| BE-12 | B&N rev4 — R80e.25 f / RFI-31 | Criterio por defecto del skill citado como nota impresa ("ADD FULL LENGTH ADDL HEAD TRACK…") | Cada nota entre comillas del Excel debe existir impresa en la hoja citada | Toda cita textual existe en su hoja; los defaults dicen "not printed / skill default" + RFI |
| BE-13 | B&N rev6 (Paso 12) | Backboard / plywood "BY GC" en hojas E (server room 2/E-103) sin destino | Barrer hojas E/M/P por PLYWOOD, BACKBOARD, BACKING, BLOCKING, ACCESS PANEL, "BY GC" | Cada uno tiene destino: renglón, EXCLUDED con motivo (p. ej. EC por spec) o RFI con delta |
| BE-14 | B&N rev6 (Paso 12, C-01/C-02/C-05) | RFI o Scope que dice "not printed / not specified" cuando el set sí lo imprime (T.O. WD-1 15'-0", alturas de FRP, Level 4) | Por cada RFI / ALC con "not printed", "not specified", "not dimensioned": buscar en specs (A-001A), notas, elevaciones y detalles | Ninguna afirmación "no impreso" tiene la cota o nota impresa en el set |
| BE-15 | B&N rev6 C-06..C-08 + rev7 C7-01 | Detalle leído con otra función: bubble 3 leído como 8; "1 5/8" x 16 GA. METAL JOIST FRAMING @ 48" O.C." (horizontal) cargado como poste vertical | Abrir cada N/HOJA citada a ≥ 200 dpi y confirmar que el miembro rotulado es el que el Excel describe (orientación, función, espaciamiento) | La descripción del renglón coincide con lo dibujado y rotulado |
| BE-16 | B&N rev6 GAP (R80e.27) + rev7 C7-03 | Accesorio impreso por un detalle sin renglón (clip angles, P.A.F. de cross members, #8 screws del relief channel) | Barrer cada detalle del trade por fasteners / clips / runners / plates impresos | Cada accesorio impreso tiene renglón, EXCLUDED con motivo o RFI |
| BE-17 | B&N rev6 (gauge) + rev7 C7-04 / C7-05 | Gauge por fila aplicado, pero los productos que dependen del gauge no se separan (8.A #8 vs #10, 2 vs 3 por conexión; 8.E Type S vs S-12) | Con el gauge de cada fila, recalcular framing screws y drywall screws por gauge | Un renglón por producto y gauge, con su conteo |
| BE-18 | B&N rev6 GAP (ACT, Unistrut, seismic, caulk) | Ítem del set sin destino (ni cuantificado ni excluido ni RFI) | Matriz de cobertura Paso 12 | 0 GAP (cobertura 100 %) |
| BE-19 | B&N rev7 C7-02 / C7-03 | Espaciamiento de fastener impreso reemplazado por un default no impreso (slab pins 12" vs 9/A-410 @ 24" y 8.F 2 rows @ 16"; X-EDNI 8.C vs 8/A-410 #8 @ 24") | Por cada fastener: buscar el espaciamiento en el detalle específico y en la nota típica; el detalle específico manda; conflicto = conservador impreso + RFI | Ningún fastener usa un espaciamiento no impreso sin RFI que cite los impresos |
| BE-52 | B&N rev8 C8-03 | Una pasada anterior dio un ítem por "cubierto por el renglón X" (#8 screws de 8/A-410 → framing screws) y el renglón X no lo contenía | En cada revisión, todo "covered by row X" heredado se re-verifica contra el desglose del renglón X | Cada cobertura heredada aparece en el desglose del renglón citado |
| BE-53 | B&N rev8 C8-02 | El delta de un RFI omitía un accesorio impreso en el mismo detalle que cita (A/A-410 "(1) #10-16 SCREW @ EACH FLANGE" fuera de RFI-28) | Por cada RFI con delta: leer todas las flechas del detalle citado y listar cada pieza impresa | El delta incluye todas las piezas impresas del detalle |
| BE-56 | B&N rev8 C8-01 | Fastener de nota típica (8.F X-DNI) cargado sobre un largo cuya sección de type imprime otro anclaje (types 3/4: HUS-EZ + moment clip, A/A-410) | Por cada fastener con yield por LF: restar los largos cuyos types / detalles imprimen otro anclaje | Ningún LF lleva el fastener típico donde la sección del type imprime otro |

## B. Reglas de método (BOA Broomfield, aplican a todo proyecto)

| ID | Origen | Qué falló | Cómo se prueba | PASS si… |
|---|---|---|---|---|
| BE-20 | BOA — §0.F | Framed soffit cargado solo por perímetro | Framed soffit = studs verticales @ 16" O.C. (L/1.333 + 1) × alto + 2 tracks a todo lo largo | Studs y 2 tracks por soffit |
| BE-21 | BOA — §0.F / R78.13 | Glass mat cargado sin rótulo | Glass mat solo donde un detalle/tag lo rotula | Ningún glass mat sin cita impresa |
| BE-22 | BOA — §0.F / R73.11 / R75.3 | Jamb return de gypsum sin detalle que lo dibuje | Jamb return solo en openings sin frame con return dibujado | Jamb return = 0 o con cita del detalle |
| BE-23 | BOA — §0.F | Acoustical sealant cargado | Debe estar EXCLUDED (solo Clarifications) | Sin renglón de acoustical sealant |
| BE-24 | BOA — reglas inviolables (track) | Top track duplicado / track combinado | bottom track = top track = Σ LF de walls con track (salvo caras de remate sin track); renglones separados | Igualdad (± explicación) y renglones separados |
| BE-25 | BOA — R70.1 / R79.3 | Sistema de ceiling inventado | Suspension (furring + carrying + hanger) solo en ceilings "SUSPENDED GYPSUM BOARD"; otro sistema solo con detalle llamado o que lo corta | Cada ceiling cita su detalle de sistema |
| BE-26 | BOA — R72.1 / R73.1 | Type K (ballistic) medido a nodo y no al hatch/cota | Solo si hay type K / ballistic | N/A si no hay ballistic |
| BE-27 | BOA — R78.36 / R79.2 / R80.3 | ATM / recess sin las piezas impresas | Solo si hay recess de ATM/equipo | N/A si no hay recess |
| BE-28 | BOA — R76.1 / R78.37 | Canopy incompleta / parapet que no sigue la wall exterior | Solo si hay canopy / parapet nuevo | N/A si no hay |
| BE-29 | BOA — R71.10 / R80e.5 | Header "assumed" sin schedule | Header que ningún schedule llama = 0 LF + RFI con delta | Headers 0 + RFI, o con cita |

## C. Formato y trazabilidad (todo proyecto)

| ID | Origen | Qué falló | Cómo se prueba | PASS si… |
|---|---|---|---|---|
| BE-40 | §0.F / R80e.24 (B&N rev4) | Material Summary sin N/HOJA o sin desglose que reproduzca el NET | Cada renglón de Material Summary: "N/SHEET:" + "Breakdown [DERIVED]" (o la operación) cuya suma = NET | Todos los renglones con cita y desglose que suma el NET (± 0.1) |
| BE-41 | R80e.24 | Nombres de archivos internos en el Excel | Buscar .json / .py / carpetas de trabajo en todas las hojas visibles | Ninguno |
| BE-42 | §0.F / R80e.9 | Partitions fuera del orden del schedule / sin subtotales | Orden de los types = orden del schedule del proyecto; SUBTOTAL por type; GRAND TOTAL = Σ subtotales | Orden correcto, subtotales cuadran |
| BE-43 | §0.F | Formato del Excel cambiado | 6 hojas visibles fijas (Inputs, Partition Takeoff, Material Summary, Pending Items, Review Items, Scope Checklist) | Exactamente esas 6 visibles |
| BE-44 | §0.F / R78.20–R78.24 | Markups Bluebeam ausentes o que no cuadran | PDF con una annot por wall (Subject = type, Depth = alto); Σ Length y Σ Wall Area por type = Excel | Cuadre por type ≤ 0.5 % |
| BE-45 | §0.F | Proporciones fuera de rango sin explicación | board vs Σ LF × alto × caras; screws/SF; studs/LF según O.C.; track vs partitions; compound/tape vs board | Todo dentro de rango o explicado en el Excel |
| BE-46 | B&N rev7 C7-06 + rev8 C8-04 | Dos espesores / productos en un mismo renglón (cement board 1/2" de A-221 + 5/8" de 22/A-201); track 3-5/8" + 6" + ledger 8" + ceiling track en un renglón | Leer el espesor impreso de cada fuente del desglose | Un espesor y un producto por renglón |
| BE-47 | B&N rev7 C7-07 / C7-08 | Cantidades o IDs en textos (RFI, Scope, README) que no coinciden con su renglón (585.27 vs 568.27; ALC-X26..X30 vs X40..X44) | Cruce automático de cada número y cada ID ALC- / RFI- citado contra Material Summary / Scope Checklist / Pending Items | Todo número e ID citado existe y coincide |
| BE-48 | B&N rev7 C7-09 | Nombre de archivo interno en el PDF de markups ("Source: takeoff_canon.json" en la leyenda) | Buscar .json / .py / carpetas de trabajo en el texto de las páginas agregadas y en Contents de los markups | Ninguno |
| BE-49 | B&N rev7 (verificación Paso 12) | Cota impresa atribuida al elemento equivocado (46'-0" del track LWT-01 cerca de la nube) | Antes de aplicar o corregir con una cota: seguir sus extension lines y cerrar la cadena con las cotas vecinas (1'-5" + 46'-0" + 1'-5" = 48'-10") | Cada cota usada pertenece al elemento cuantificado |
| BE-50 | B&N rev7 N-03 | Traslape de alcance entre hojas A y E/M/P sin RFI (E-301 265119 soportes de luminarias por el EC vs wires en luminarias cargados por 5/A-121) | Por cada renglón del trade que una spec E/M/P asigne a otro contratista: RFI con delta | Todo traslape tiene RFI |
| BE-51 | B&N rev8 C8-05 | Renglones en LF con selling unit "piece" y Pieces to buy = ROUNDUP(LF) (2x blocking, main / cross tee, molding, 16 ga wire) | Por cada renglón: Unit vs Selling unit vs fórmula de Pieces to buy | Pieces to buy en piezas reales (stock length de Inputs) o venta por LF / coil |
| BE-54 | B&N rev8 C8-08 | Partición por producto (Type S / S-12) sobre board bruto por wall, con la deducción (base de cement board) aplicada solo al total | Recalcular cada partición por cara, aplicando cada deducción a las mismas caras | La suma por producto respeta las deducciones de cada cara |
| BE-55 | B&N rev8 C8-07 | Códigos internos del plan check (C7-0x, C-0x, N-0x, "rev7 plan check") en textos al cliente | Buscar con regex en todas las hojas visibles y en el README | Ninguno |
| BE-57 | B&N rev10 (estimador 27-oct) | Blocking de madera (2x / FRT) con el waste de METAL (Inputs B5 15 %) | Por cada renglón de Material Summary: material madera / board / plywood / cement board → waste NO metal (B6) | Ningún renglón no metálico usa B5 |
| BE-58 | Prueba API B&N 28-oct | Materiales calculados por el modelo a mano y compuerta reglas.py apagada (studs −33 %, FRP −52 %, blocking −70 %) | Verificar en la bitácora de la corrida que canon.py + reglas.py + plantilla_excel.py generaron el Excel y que reglas.py terminó en PASS | Ningún número del Excel sale fuera de los programas; reglas.py nunca stub |
| BE-59 | Runner real B&N 30-oct | Lectura A incompleta: 11 walls, solo A-101, de 77 (terminó antes, con presupuesto de sobra) | Compuerta de completitud por script después de cada lectura (completitud.py): todas las hojas de planta del trade con walls, todo type del schedule con walls o types_none_reason, y todo type / element que encontró la otra lectura; si falla, continuación de la misma lectura (máx. 2) | completitud.py OK en A y B antes de comparar.py |
| BE-60 | Runner real B&N 30-oct | Canon con claves fuera de esquema (HG1 / HG2.curved) y ceilings sin system_callout: canon.py lo rechazó al final de la cadena | El modelo valida su canon con validar_canon.py (= canon.py) dentro de su sandbox antes de responder, y el runner lo revalida antes de comparar | validar_canon.py imprime CANON OK en A, B y AB |
| BE-61 | Runner real B&N 30-oct | La resolución partió siempre de A (la incompleta) y bajó el total de 617 a 535 LF | La resolución parte de la lectura más completa (walls, luego LF) y solo resuelve las diferencias | El canon AB tiene al menos los walls de la lectura más completa |
| BE-62 | Runner real B&N 30-oct | Reconciliación con 19 / 42 walls: column wraps como tag "C25" (no element) y otra partición de tramos | Normalizar element / type (BOX o tag de columna = column_wrap) y emparejar también por traslape >= 80 % sobre la misma línea | >= 80 % de walls emparejados en una lectura completa (canon B real: 33 / 41) |
| BE-63 | Runner real B&N 30-oct (revisión propia) | El overlay reemplazaba walls completos con los de la referencia: metía largos, bands y alturas de la rev13 en la lectura | Overlay por PARCHES de campo (overlay.parche): una decisión solo toca los campos que cambia | Los walls emparejados conservan largo y band de la lectura (32 / 33; el otro lo cambia una decisión del estimador, RI 1) |
| BE-64 | Runner real B&N 30-oct (revisión propia) | Riesgo de contaminación: la llamada de lectura corría en un directorio que enlaza las respuestas del proyecto (rev13, RFIs) | Cada llamada claude -p corre en un sandbox aislado fuera del workdir, solo con el PDF, el inventario, las tools y el validador | Ninguna ruta del proyecto en el sandbox |
| BE-65 | Runner real #2 B&N 30-oct | validar_canon pasó la lectura A sin `plan_scale_pt_per_ft`; sin escala canon.py no cruza band vs length_ft (W2-01 band 50.0 vs 48'-4" A-101) | validar_canon exige plan_scale_pt_per_ft y band.sheet y corre también inventario.py; el prompt de lectura lo pide | Canon sin escala = CANON ERROR |
| BE-66 | Runner real #2 B&N 30-oct | La lectura B agotó su tope (error_max_budget_usd) y el gasto no quedó en costos.csv | claude() registra el costo antes de revisar rc; las lecturas pagadas se reusan con --reusar-lecturas (continuación pagada solo con --continuar-lados) | Toda llamada fallida tiene su fila en costos.csv |
| BE-67 | Runner real #2 B&N 30-oct | Decisiones con lista completa (ceilings, opening_schedule, faces sin identidad) usan nombres / largos de la referencia y rompen las referencias de la lectura (soffit_of, D14 vs Door 14, Σ tramos ≠ L, node en wall ausente, wet_fixture sin MR) | reconcile: ceilings por número + system, openings por dígitos en el wall o el que lo contiene, nodes colgados = sin objeto, tramos reescalados [DERIVED] con operación, wet_fixtures sincronizados | canon.py pasa sobre la lectura real con decisiones |
| BE-68 | Runner real #2 B&N 30-oct | La lectura por API no trae evidencia visual por face / height ni estados #0: reglas.py da 3881 fallas (diagnóstico) | Pendiente de diseño: la lectura debe producir img + estado por cantidad, o el runner no puede entregar Excel | Ninguna corrida API entrega Excel sin evidencia |
| BE-69 | Runner real #3 B&N 30-oct | trazabilidad.py desglosaba todo board 5/8" como "5/8 type X" (regular / MR sumaban Type X) y el FRT substrate con el sheathing de column wraps del mismo espesor; un gauge numérico rompía el join | Renglón = board / material Y uso (R80e.39); gauge como texto. Diffs en costeo_api/runner/skill_patches/ | Excel armado con board regular y column wrap FRT |
| BE-70 | Runner real #3 B&N 30-oct | Lecturas sin ceilings ni soffit sides (B declaró ceilings_none_reason) y planmark rechazó un soffit side en línea discontinua | Errores de canon.py / reglas.py / alcances.py van a una corrección dirigida en ids de la lectura; planmark sondea denso los elementos dashed | Soffit sides agregados por la corrección; SS-N pasa planmark |
| BE-71 | Runner real #3 B&N 30-oct | Resolución y cobertura terminaron sin escribir: la resolución no editó el archivo y la cobertura usó Bash heredoc (permiso negado) hasta agotar el tope | La resolución parte de la lectura base copiada (se declara si no cambia); la cobertura escribe con Write; la respuesta del modelo se guarda por paso | Cobertura 102/109 escrita al segundo intento |
| BE-72 | Runner real #3 B&N 30-oct (pedido del parent) | La compuerta de completitud solo miraba hojas y types: dejó pasar lecturas de 27 / 31 walls (sin 9 column wraps, sin soffit sides, con tags de type 2 / 3 / I sin wall) y aceptaba "no lo encontré" como types_none_reason | R80e.40: conteos por type y hoja contra el inventario de tags, los símbolos de columna (hatch repetido) y las líneas discontinuas de los planos ampliados; la continuación recibe los tags concretos con coordenadas | Con las lecturas reales de la #3: A = 11 tags + 9 columnas + 7 discontinuas; B = 5 tags + 9 + 7; control rev13: 0 columnas faltantes |
| BE-73 | Runner real #4 B&N 30-oct | Return sin tag con part_of: la fila del Partition Takeoff salía sin type y el sealer se caía al ordenar tags None | R80e.41: va en el type de su wall (partition_types.py + sealer) | Excel armado con los returns 2-11 / 2-12 / 5-01b en su type |
| BE-74 | Runner real #4 B&N 30-oct | La decisión parchaba un node por id (N24 de la lectura ≠ N24 de rev13), borraba una door leída (DR-104) de opening_schedule y los ceilings decididos quedaban sin su supuesto RFI (carrying_direction) | R80e.42 1-3: nodes por walls, aberturas leídas conservadas, supuestos RFI viajan con la decisión | canon.py pasa sin corrección pagada |
| BE-75 | Runner real #4 B&N 30-oct | La corrección no podía escribir el canon (Edit no permitido), traducía mal un id con punto (C-E1-P.2) y la corrida terminó en $15.0078 contra un tope de $15 (claude -p se pasa unos centavos) | Edit permitido en el sandbox; id completo más largo; 1 % de margen y --max-budget-usd = 97 % del tope del paso (R80e.42 4-5) | Ninguna corrida pasa su tope total |
| BE-76 | Análisis B&N #4 30-oct | Las decisiones generales (RFI-27 Type X, RFI-11 W.R.) solo llegaban a los walls emparejados: 46 faces "5/8 regular" + 2 "5/8 MR" en walls sin emparejar (Type X −42 %) | R80e.43: `generales` por atributo en todos los walls | Type X −8.9 %, W.R. +8.0 %, 0 SF de regular |
| BE-77 | Análisis B&N #4 30-oct | Cement board +126 %: la lectura A puso 1/2" cement board 20 ft en la cara Workroom de C-E2 (E/A-221 = "E2-5/8" FRT PLYWOOD" only); B lo tenía bien, pero comparar.py solo compara LF | R80e.44 1: difieren_atributos (altura + board por face) va a la resolución | La comparación A/B de la #4 detecta E2 (board) y 24 diferencias de altura |
| BE-78 | Análisis B&N #4 30-oct | Studs −33 / −38 %: alturas placeholder 20 ft (A) / 15 ft (B) donde 1/A-400A y 1/A-400B imprimen B.O. DECK 25'-0"; el prompt no listaba A-300 / A-400 | R80e.44 2-3: compuerta de alturas placeholder contra las secciones / elevaciones del SHEET_MAP + hojas en el prompt | Lectura A: 29 walls → A-226A / A-400A / A-400B; rev13 0; diagnóstico con 25 ft: studs −20 % / −19 % |
| BE-79 | Runner real #5 B&N 31-oct | Un parche parcial de una decisión sobre faces que la lectura no trae creaba faces a medias (solo board), y canon.py caía con KeyError 'layers'; 3 correcciones pagadas sin efecto | R80e.45: parche parcial sobre un ítem ausente = sin objeto | canon.py pasa sin corrección |
| BE-80 | Runner real #5 B&N 31-oct | Column wraps 0 de 9: A los excusó como existentes (C23) y B los puso en misc_items COL-* (C25, 10/A-101); la resolución partió de A sin ver la contradicción | R80e.46 1: razones none y misc_items en la comparación A/B | La comparación de la #5 detecta las 7 COL-* que solo trae B |
| BE-81 | Runner real #5 B&N 31-oct | Fila del type F PENDING: la corrección solo recibía "partition_types sin dato obligatorio" (R9: box con tag sin fos_chain) | R80e.46 2: el motivo exacto de partition_types va a la corrección | Cerrada en 1 ronda: Excel entregable (1 falla = back-check) |
| BE-82 | Back-check v5 31-oct | Doble conteo entre hojas: W2-04 extendido 30.0 ft en A-101 sobre el muro norte del Cafe Workroom 104, ya contado en A-221 como C-H1-N (type 2 +9.3 %) | R80e.47 en el prompt de lectura (compuerta automática pendiente de registro entre hojas) | Pendiente de la próxima corrida |
| BE-83 | Back-check v5 31-oct | Faces de restrooms a deck (25 ft) con ceiling GWB 9'-0" (A-121): W.R. +44.7 % | R80e.48: caras_sobre_ceiling después de las decisiones → corrección | Detecta 11 faces en el v5 y 0 en rev13 |
| BE-84 | Preparación #6, 31-oct | Metal trim −95.6 % (42 LF de 957): la lectura no deriva el corner bead de oficio; E1 / E2 3-5/8" (A) vs 6" (B), y la comparación no miraba stud_size | R80e.49: trim.py + stud_size / oc / gauge en difieren_atributos | Trim con las lecturas de la #5: −31.2 % (faltan los column wraps) |
| BE-85 | Corrida #6 31-oct | canon.py rechazó "accesorios_none PAFs and duct sleeves" + la cantidad de la decisión (mep_estimator_count); 3 correcciones pagadas inútiles | R80e.51: el none que contradice una decisión se quita y se lista | canon.py pasa con el AB de la #6 |
| BE-86 | Corrida #6 31-oct | 154 fallas "falta HOJA" en length_source de bands ("band 67.6 pt / 9") | R80e.52: la hoja de la band se antepone (hecho del dato) | reglas.py 248 → 38 |
| BE-87 | 31-oct | Choque de numeración: dos reglas distintas como R80e.49 (trim / formato de RFI) | El formato de RFI pasa a R80e.50; antes de numerar, leer el último R80e del archivo | Una sola R80e.49 |
| BE-88 | 31-oct | El formato de RFI (R80e.50) se implementó con 3 columnas nuevas en Pending Items: viola el formato FIJO del Excel (nunca agregar / quitar / cambiar hojas ni columnas) | Las opciones van dentro de "Delta of each alternative"; A_RFI_FORMATO rechaza cualquier columna extra | test_rfi_formato.py cubre columna extra + delta sin (A)/(B)/(C) |
| BE-89 | 31-oct | La lectura dejó 76 de 87 nodes free: faltan los studs de esquina (L) e intersección (T) | nodos.py deriva L / T / free de las bands cuando > 60 % es free (R80e.53) | cada wall con exactamente 2 extremos (canon.py lo valida) |
| BE-90 | 31-oct | La lectura no declaró ningún opening con door schedule en A-500 (puertas leídas como huecos entre walls): faltan jambs, header y cripples | completitud.aberturas_faltantes manda la lectura a corrección (R80e.54) | la referencia (12 openings) pasa; la #6b (0) queda marcada |
| BE-91 | 31-oct | claude -p heredó ANTHROPIC_BASE_URL / CLAUDE_CODE_* de la sesión: las corridas no usaron $TAKEOFF_API_KEY (session_id = la de la sesión anfitriona; la consola sin costo) | env_api limpia el entorno; verificar_key hace una llamada mínima antes de gastar y corta si falta la key, 401 o hereda la sesión (R80e.55) | sin key -> fail-fast; key inválida -> 401 detenido antes del paso 1 |
| BE-92 | 31-oct | 22 decisiones del estimador sobre items (cross members, nested bracing, cement board base, FRT backboard) quedaron sin objeto porque la lectura no trae el item | items_sin_lectura manda la lista (id + operación con N/HOJA) a una corrección (R80e.56) | la #7 lista los 18 items; el dry-run no cambia |
| BE-93 | 31-oct | R80e.43 (W.R. en wet rooms por atributo) cayó sobre faces a la altura del stud (25 ft contra ceiling 9'-0"): W.R. +44.7 % en la #5 | completitud.topar_caras baja la face al ceiling de su cuarto después de las decisiones (R80e.57) | banco: #5 W.R. −10.1 %, Type X +7.3 %; ningún material empeora |
| BE-94 | 31-oct | Los arreglos se validaban contra una sola lectura: uno mejoraba una corrida y empeoraba otra | Banco de regresión sin API con las lecturas guardadas (#3, #4, #5, #7) y aceptación solo si nada empeora (R80e.58) | correr_banco.py --base marca ▲ / ▼ por material y corrida |
| BE-95 | 31-oct | Errores sistemáticos de lectura que se repiten en todas las corridas: la figura curva leída en 4 piezas, un wall de la planta ampliada a 4.5 ft contra 12.2 ft acotados, puertas leídas como huecos | Prompt de lectura R80e.59 (cuerdas, cadenas cerradas, puertas dentro del wall); R80e.54 / R80e.56 por corrección | se mide en la corrida #8 (lecturas nuevas) |
| BE-96 | 31-oct | La #8 se detuvo en canon.py ("nodo NP3: wall EXT-07 no existe"): 25 nodes derivados citaban walls que la decisión RFI-01 excluyó. Se gastaron 3 correcciones (≈ $2.4) en un error del programa | nodos.podar ajusta los nodes después de las decisiones (R80e.60) | la #8 re-armada sin API pasa canon.py; el banco no empeora nada |
| BE-97 | 31-oct | El closer rechazó un wall E1 con las dos faces en el mismo cuarto y alturas distintas (12.0 / 25.0): las dos se juntaban en un solo renglón de board | El sellador nombra la face con su side cuando el cuarto se repite (R80e.61) | la #8 re-armada sella el wall |
| BE-98 | 31-oct | Exclusión general por type (RFI-01: types 1 / 1A / 1B / 1C existentes) para walls exteriores que no emparejan: el banco la marcó como empeora (bottom track y bracing en la #8) porque el wall excluido tapaba faltantes de lectura | Se APLICA (decisión del estimador, rev13 también excluye; R80e.58: las decisiones quedan fuera de la prueba de regresión). Los faltantes destapados son gaps de lectura | banco6: r8 bottom track −25.8 %, bracing −17.1 % = gaps de lectura |
| BE-99 | 31-oct | Leí el take-off humano de la prueba ciega O'Reilly/Olive Garden para elegir proyecto (R80e.62) |
| BE-100 | 31-oct | O'Reilly: el bid set de Drive traía 79 markups de Bluebeam de otro estimador (take-off humano) | copia_limpia.py antes de todo; declarar lo visto; nunca leer los Subjects | 0 /Annots en la copia; original borrado del área de trabajo |
| BE-101 | 31-oct | O'Reilly: el runner con TAKEOFF_API_KEY en el entorno hizo 31 llamadas a la API en corrección / cobertura en una corrida por suscripción | R80e.69 `--sin-api` + `env -u TAKEOFF_API_KEY` | costos.csv sin filas nuevas en la corrida |
| BE-102 | 31-oct | O'Reilly: citas fijas de B&N (A-410, A-001A, DM-101) en el Material Summary de otro proyecto | R80e.72 textos genéricos | 0 citas de hojas que no existen en el set (grep de hojas del Excel contra SHEET_MAP) |
| BE-103 | 31-oct | O'Reilly: hojas raster sin texto: markups sin geometría, contar_tags y tag_ids fallan | R80e.66 / R80e.70 / R80e.71 | markups.json annots = walls del canon; 0 sin_geometria |
| BE-104 | 31-oct | O'Reilly: type S24 imprime Z-furring sobre CMU además del stud lining; la lectura no lo cargó por falta de familia | R80e.65 familia Z-furring; misc_item ZF-S24 | todo type con dos sistemas (furring + studs) carga los dos |
| BE-105 | 31-oct | O'Reilly rev1: productos impresos en S1.1 nota 7 y S5.x (Titen HD @ 48", #10 stud-to-track, deep-leg 3" x 14 ga, sheathing screws, FCB43.5) quedaron como RFI y se cargaron defaults (pins @ 12", Kwik Bolt @ 8", #8) | R80e.75 / R80e.76 | ningún producto impreso queda solo en RFI; ningún default donde el set imprime el producto |
| BE-106 | 31-oct | O'Reilly rev1: defaults citados como "Estimator criterion / Handoff - Approved" y "estimator decision 2026-10-27" (otro proyecto) | R80e.73 | grep "estimator" en el Excel: solo reglas permanentes escritas o precedentes rotulados como tales |
| BE-107 | 31-oct | O'Reilly rev3: orden del estimador "excluye toda la tornillería": la tool no tenía forma de excluir todas las familias de fasteners a la vez | R80e.77 `fasteners_excluded` | con la orden: todo renglón de screws / anchors / pins en 0 con nota EXCLUDED; sin la orden: sin cambio |
| BE-108 | 1-nov | O'Reilly rev4: 24 RFI respondidos por el estimador; varios eran casos que el plano dibuja (RC, 1/4", corner bead de header, J molding, strap, runner, W-4, Level 5) | R80e.78 precedente en SKILL_working.md | antes de abrir un RFI, comparar con R80e.34 (B&N) y R80e.78 (O'Reilly): si el caso ya fue decidido, cargarlo como precedente |

---

## Resultados por proyecto

(Se agrega una tabla por entrega. Detalle y evidencia en la carpeta PASO12 del proyecto.)

### B&N Colorado Springs — rev6 (Paso 12, 2026-10-27)

21 PASS · 5 FAIL · 3 N/A. Evidencia: `barnes_noble/PASO12_rev6/` (MATRIZ_COBERTURA.xlsx › Error Library, CERTIFICADO_PASO12.md, img/).

| Prueba | Resultado | Nota |
|---|---|---|
| BE-01 | PASS | 264.21 LF carried (3-5/8" 157.81 + 6" 106.40) + RFI-35; citation must read 3/A-410 (C-07) |
| BE-02 | PASS | Women's 61.19 + Men's 61.11 SF W.R. (Material Summary!R20); Janitor 107 has no GWB ceiling |
| BE-03 | PASS | R20 breakdown covers W2-05..W2-08, W5-01; A-510 does not contradict. Base 1'-2" must be cement board (C-03) |
| BE-04 | PASS | No C-* face in the W.R. breakdown; Work Room = FRT plywood (G/A-221) |
| BE-05 | PASS | G, H, E, F, I, A-D/A-221 checked side by side against "Board by face" - all match |
| BE-06 | PASS | SS-N, SS-E, SS-IN-N, SS-IN-E, SS-GG + bottoms carried. Open: plywood above WD-1 (2/A-221) and soffit corner bead = GAP rows |
| BE-07 | PASS | I SIM. x2 on 1/A-221 = C-I-E1, C-I-E2 |
| BE-08 | FAIL | 19'-0" HOLD ignored for C-E1-S cement board (C-04); T.O. WD-1 printed but RFI-34 says not printed (C-01); FRP heights printed (C-02) |
| BE-09 | PASS | RFI-01 (1/DM-101, A-101, A-002); 17 EXT markups "EXISTING - EXCLUDED". New RFI proposed: A-410 types 1/1A/1B/1C "5/8" GYP BD BY FUTURE TENANT" |
| BE-10 | PASS | SS-GG 6'-2" HOLD quantified (RFI-20 closed); T.O. WD-1 now printed (C-01) |
| BE-11 | PASS | Janitor 17.0 SF 3/4" FRT (11/A-200) + RFI-33 |
| BE-12 | FAIL | 8/A-410 should be 3/A-410 (C-07); 6/A-410 plates not printed (C-08); 6/A-210 is the glazing base detail (C-06) |
| BE-13 | FAIL | 2/E-103 server room 4'x8' FRT plywood "BY GC" - no row / exclusion / RFI |
| BE-20 | PASS | SS-N/E/IN studs in R12 + R28; track = 2 x length (R13) |
| BE-21 | PASS | None carried; ALC-09 NOT APPLICABLE |
| BE-22 | PASS | R36 = 0 citing 1/A-500, 2/A-500 |
| BE-23 | PASS | ALC-19 EXCLUDED; no row |
| BE-24 | PASS | 450.02 + 118.59 = 568.61 LF each = 569.816 - end faces C-I-E1/E2 1.206 (R80e.23) |
| BE-25 | PASS | 5/A-121 suspension; 4/A-121 USG grid for the cloud |
| BE-26 | N/A | No ballistic type in A-410 |
| BE-27 | N/A | R34 none (A-101, A-500, A-221) |
| BE-28 | N/A | ALC-03, ALC-14 NOT APPLICABLE (A-300: no new canopy) |
| BE-29 | PASS | RFI-09 (0 LF + delta 83.32 LF) |
| BE-40 | FAIL | R28 "3-5/8" stud, framed soffit 2/A-221" 61.31 LF has no breakdown / operation; R13 FIRESTOP-TRACK lines have no per-wall breakdown. All other breakdowns sum the NET (+/- 0.1) |
| BE-41 | FAIL | Pending Items RFI-06 "ri07_rcp/", RFI-12, -13, -20, -31, -32, -33, -35, -36 cite "AUDITORIA_rev4/COMPARATIVA_AUDITORIA.xlsx" |
| BE-42 | PASS | Subtotals = rows; GRAND TOTAL 569.816 = sum of subtotals. Observation: A-410 prints no schedule table; order 2, 5, 3, 4 is the declared order (rev1); by type number it would be 2, 3, 4, 5 |
| BE-43 | PASS | 6 visible + hidden "_reglas" gate signature |
| BE-44 | PASS | Sum Length and sum Wall Area (Length x Depth) match on all 18 types (max delta 0.01 LF, type I rounding) |
| BE-45 | PASS | See sheet Proportions; 3 traceability observations |

### B&N Colorado Springs — rev7 (Paso 12, 2.ª pasada, 2026-10-27)

**27 PASS · 10 FAIL · 3 N/A** (40 pruebas). Evidencia: `barnes_noble/PASO12_rev7/` (MATRIZ_COBERTURA.xlsx › Error Library, CERTIFICADO_PASO12.md, img/).

| Prueba | Resultado | Nota |
|---|---|---|
| BE-01 … BE-11 | PASS | Fire-stop track, W.R., capas, soffits, SIM., cotas LF, existing, HOLD, áreas rotuladas |
| BE-12 | FAIL | "24" (type K box)" en RFI-ACC-slab-pins; "compression post" atribuido a 5/A-121; N/SHEET "GA-216" |
| BE-13 | PASS | 2/E-103 + RFI-50 |
| BE-14 | PASS | Muestreo de "not printed" sin hallazgos |
| BE-15 | FAIL | C7-01 (1-5/8" joist framing @ 48" leído como poste) |
| BE-16 | FAIL | C7-03 (#8 screws @ 24" y P.A.F. de 8/A-410) |
| BE-17 | FAIL | C7-04, C7-05 (screws por gauge) |
| BE-18 | FAIL | 2 GAP (N-01, N-03) |
| BE-19 | FAIL | C7-02, C7-03 (espaciamientos impresos) |
| BE-20 … BE-25, BE-29 | PASS | |
| BE-26 … BE-28 | N/A | |
| BE-40 … BE-45 | PASS | |
| BE-46 | FAIL | C7-06 |
| BE-47 | FAIL | C7-07, C7-08 |
| BE-48 | FAIL | C7-09 |
| BE-49 | PASS | rev7 nube 38'-10" correcta |
| BE-50 | FAIL | N-03 |

## Corrida B&N rev8 (2026-10-27)
Back-check final: LIBRARY 37 PASS · 0 FAIL · 3 N/A (`barnes_noble/takeoff_work/etapas/5_auditoria/BACKCHECK_rev8_recheck.md`). Los 10 FAIL (BE-12, 15, 16, 17, 18, 19, 46, 47, 48, 50) quedan corregidos. Las lecciones nuevas están en la regla R80e.29 del skill v80o.


## Corrida B&N rev8 — Paso 12 independiente (2026-10-27)
46 pruebas: 32 PASS · 11 FAIL · 3 N/A. FAIL: BE-16 (C8-02, C8-03), BE-19 (C8-01), BE-40 (C8-08), BE-46 (C8-04), BE-47 (C8-06), BE-51…BE-56 (C8-05, C8-03, C8-02, C8-08, C8-07, C8-01). N/A: BE-26, 27, 28. Veredicto: NO PASA (cobertura 100 %, 0 GAP, 8 CORREGIR). Nota: el back-check rev8 (37/0) dejó C8-01/02/03/08 como "no bloqueantes"; son piezas impresas o reglas del skill → CORREGIR.
## Corrida B&N rev9 (2026-10-27)
Back-check final: 43 PASS · 0 FAIL · 3 N/A (46 pruebas). El detalle está en `barnes_noble/takeoff_work/etapas/5_auditoria/BACKCHECK_rev9.md`. Las pruebas BE-16, 19, 40, 46, 47 y 51 a 56 quedan corregidas. Las lecciones nuevas están en la regla R80e.31 del skill v80p.

## Corrida B&N rev12 (2026-10-28)
Back-check final: 44 PASS · 0 FAIL · 3 N/A (con BE-57), en `barnes_noble/takeoff_work/etapas/5_auditoria/BACKCHECK_rev12.md`. En la primera pasada fallaron BE-41 (nombres de carpetas internas en Pending Items) y BE-40 (desglose del head track cortado); los dos quedaron corregidos.

## Corrida B&N rev13 (2026-10-28)
Back-check final: 44 PASS · 0 FAIL · 3 N/A (`barnes_noble/takeoff_work/etapas/5_auditoria/BACKCHECK_rev13.md`). En la primera pasada falló BE-47: RFI-13 y RFI-22 tenían las cifras viejas; se corrigió con la nota "Revised by RFI-55".

## BE-99 — Leí el take-off humano de la prueba ciega (31-oct)
Error: para elegir un proyecto de prueba abrí con read_file_content "Oreally Takeoff.xlsx" y "OLIVE GARDEN TAKEOFF.xlsx"; el usuario quiere que la referencia humana sea solo suya.
Prueba: en una prueba de exactitud, ¿algún paso abrió/leyó un take-off humano o se lo pasó a una sesión? Debe ser NO. Selección solo por metadatos. Regla R80e.62.

## BE-100 — Bid set de prueba con markups del take-off previo (31-oct)
Error: copié para O'Reilly un PDF con 79 markups Bluebeam de un take-off anterior. La sesión lo limpió antes de leer (vio solo títulos en 2 hojas). Prueba: antes de entregar un bid set, un programa cuenta /Annots por hoja; si > 0, se entrega copia limpia sin leer su contenido.

## BE-101 — Lo impreso quedó como RFI y una decisión del estimador inventada (31-oct, O'Reilly #1)
Error: Titen HD @ 48", #10 screws, deep-leg 14 ga track y sheathing screws impresos quedaron como RFI con el default de la tool. Error mío adicional: acusé de inventada la exclusión MEP (RFI-08) y era una orden textual del usuario a la sesión hija (07:04 UTC). Antes de corregir una decisión atribuida, verificarla en la sesión de origen. Prueba: (1) todo Pending Item cuya opción (A) cite un elemento impreso con hoja debe estar CARGADO (RFI solo por dimensión faltante); (2) toda frase "estimator"/"estimador" debe citar respuesta escrita del usuario o precedente R80e.34.

## BE-110 — Repetibilidad O'Reilly pasada 2, elemento 1 (31-oct)
Diferencias entre pasadas por criterios no fijados por programa: (1) altura del purlin medida a escala (prohibido #0) en vez del supuesto 8" con RFI; (2) board con aberturas descontadas en una pasada y sin descontar en la otra; (3) dueño de esquina S24/S43 distinto (S24 +4.8 %, S43 −1.6 %, combinado +1 %). Prueba: canon.py debe rechazar alturas "medidas a escala", calcular board siempre sin descontar aberturas (precedente B&N rev13) y asignar el dueño de esquina por regla fija (R70.2) — mismo resultado en cualquier pasada.

## BE-111 — Pasada 1 O'Reilly: altura del board interior del head del storefront tomada de una cota EXTERIOR (31-oct)
Error (detectado por la pasada 2): rev4 cargó el head interior a 5.06 ft (cota exterior 5'-0 3/4" de 1/A3.1, 111'-4" → T.O. high eave) en vez de 0.667 ft impresos (11'-4" R.O. A5.2 → 12'-0" 1/A5.2). Sobrecarga ≈ +135 SF 5/8" X en el head (y RC / 1/4" de RFI-06 calculados con 4 filas en vez de 1). Prueba: toda altura de board debe citar una cota cuyos DOS extremos sean bordes del board en esa cara (interior/exterior); una cota de fachada exterior nunca define el board interior.

## BE-112 — O'Reilly pasada 2: lecturas que el estimador corrigió con sus respuestas (01-nov)
(1) Control joints en juntas de masonería en vez de la regla de 30 ft y sin esquinas (RFI-27 B, 30 B); (2) framing colgado de la estructura con top track estándar en vez de deep-leg (RFI-20 B); (3) conteo de clips / L4x4 solo en el wall cuyo detalle los dibuja (RFI-26 B); (4) key note leído como "wall construction" donde el estimador quiere blocking continuo (RFI-25 B); (5) ties de piers cargados conservadores sin corte en planta (RFI-11 A: van 0). Prueba: cada caso del precedente SKILL_working 22–36 se revisa en todo proyecto con PEMB / header walls colgados / CMU con furring.

## VS #679 Downey (2026-11-01)
| ID | Origen | Qué falló | Cómo se prueba | PASS si… |
|---|---|---|---|---|
| BE-VS-01 | VS Downey, orquestador | Las dos lecturas no leyeron el demolition plan A01.01 (LOWEST POINT OF DECK 17'-0" / STRUCTURE 12'-1") y declararon la altura "no impresa" | Barrer demolition plan / RCP / secciones / S por "LOWEST POINT", "B.O. DECK", "HEIGHTS NOTED" antes de un RFI de altura | Toda altura de estructura cita la hoja impresa o el RFI lista las hojas barridas incluida la de demolición |
| BE-VS-02 | VS Downey, orquestador | Cielos de gyp cargados regular cuando A15.04 dice "UL listed fire resistant board throughout" | Leer specs en hojas A15.xx / project manual: board type de walls Y cielos | Board de cielos = el de las specs |
| BE-VS-03 | VS Downey, cobertura | 18 alcances impresos sin destino (blocking de signage / lockers / paging, platform framing, reveal, metal FRP trim, bridging clips) | Paso 12 cobertura con destino por ítem ANTES de entregar | 0 GAP reales en la cobertura |
| BE-VS-04 | VS Downey, orquestador | Pasada de gaps sumó C.R. channel de bridging ya contado en "bracing C.R. channel" | Toda cantidad nueva se cruza contra la familia existente del mismo producto | Sin doble conteo |
| BE-VS-05 | VS Downey rev2, paso 12 | Dos renglones de una misma familia recibieron cada uno la familia entera al partir por producto (blocking duplicado) | Σ renglones de una familia en el Material Summary = NET de la familia en familias_out | Ningún producto aparece dos veces; Σ = familia |
| BE-VS-06 | VS Downey rev2, paso 12 | Producto impreso reemplazado por default: blocking 6" x 18 GA backing track / plate (E/F A12.01) comprado como stud 3-5/8"; foil-backed como regular; 1/2" MR como exterior sheathing | Cada renglón de board / blocking nombra el producto impreso de su detalle | Producto del renglón = el del detalle citado |
| BE-VS-07 | VS Downey rev2, paso 12 | Bridging R/S03.01 cargado en todo wall aunque la nota lo excluye donde hay board en las dos caras | Leer la nota de bridging; filas solo en la zona sin board en ambas caras | Filas de bridging = zona sin sheathing doble |

## BE-113 — Jamb studs (king + jack) contados en walls de Z-furring sobre CMU (O'Reilly pasada 2, back-check 02-nov)
studs_nodos.py sumaba 4 jambs por abertura también en S21 (Z-furring 150ZF125-18 sobre CMU): +20 piezas ≈ +297 LF (+13.4 %). El jamb del furring es FRT wood blocking (2/A5.1, 12/A5.2), ya contado en blocking. Prueba: en walls de furring (Z / hat channel) jambs = 0 (R80e.98, studs_nodos.py + closer.py Wall.furring).

## BE-CH01 (Chuze, 2026-11-02) — sesión sin las reglas fijas del usuario
Una sesión arrancada en otra rama (v77c) no leyó REGLAS_USUARIO_CLAUDE.md / REGLAS_ALCANCE.md y cargó tornillería y refuerzos de ductos que el estimador excluye siempre; además usó un skill (v80v) que no era el último archivado. Prueba: antes del primer número, la sesión cita las reglas fijas vigentes (tornillería EXCLUDED, R-ALC-01/02/03) y el skill de skills_archivo/INDICE.md con el que arranca.
## BE-CH02 (Chuze) — walls entre plantas ampliadas
Lecturas por zona con regla "hoja menor" dieron dobles conteos (~50 LF A6D) y un hueco (28 LF D3G) dentro de UNA misma lectura. Prueba: cierre global independiente en la planta general por type y hoja ampliada; Σ zonas vs cierre por type antes de conciliar.
## BE-CH03 (Chuze) — escala supuesta
Escala de plantas ampliadas copiada de otra hoja (1/4") cuando dos eran 3/16". Prueba: cada hoja lleva su escala del rótulo "SCALE:" de esa hoja, verificada con cota o grid.
| BE-VS-08 | VS Downey rev5 (usuario) | Demo cuantificada sin cruce contra el floor plan nuevo, con alturas supuestas (±12'-0") sin buscar en todas las hojas, y sin markup de línea | Para cada elemento de demo: (a) altura con fuente N/HOJA o la lista de hojas revisadas si PENDIENTE; (b) tabla de cruce demo vs floor plan nuevo con las diferencias; (c) una PolyLine DEMO con /Measure por elemento en el markups PDF | Las tres cosas existen para el 100 % de los elementos de demo |
| BE-VS-09 | VS Downey (usuario) | Specs (A15.xx) leídas solo por secciones sueltas; materiales sin cruce contra la spec | Cada renglón del Material Summary cita sección / párrafo de spec o "no spec section" con el barrido declarado; tabla de cruce material vs spec | 100 % de los renglones cruzados; conflictos como RFI con delta |
| BE-VS-10 | VS Downey (usuario) | RFI-31: lateral bracing del ceiling NO cargado porque el RCP no lo dibuja (se aplicó "manda el plano" a una omisión) | R-ALC-11: lo no dibujado se busca en specs, metal schedule y S y se carga con su fuente; "manda el plano" (R-ALC-10) es solo para conflictos, no para omisiones | reglas.py A_NO_DIBUJADO (v81cf4) + A_BARRIDO_NO_DIBUJADO (BE-116): ningún cierre "not carried … not drawn"; rev9 falla, rev10 pasa |
| BE-VS-11 | VS Downey (mío) | Las compuertas nuevas A_NO_DIBUJADO (rev10) no corrían: reglas.py solo ejecuta un chequeo si una regla con ENCABEZADO del SKILL.md lo referencia en reglas_clasificacion.py; mis reglas eran viñetas | Toda regla con compuerta va con encabezado ## R80e.N y su entrada A("CHEQUEO") en reglas_clasificacion.py el mismo turno | Probar la compuerta contra un caso que DEBE fallar (VS rev13 con EMT falla A_STRUT_STUD; rev14 pasa) |
| BE-VS-12 | VS Downey (back-check ciego) | 3-5/8" stud: los 7 framed_soffit ya generaban sus miembros (renglones propios 148.61 LF) y además estaban como misc_items dentro del renglón del stud; también: altura del display window tomada del tag vecino (10'-2" vs 11'-2"), esquinas de pier contadas 2 veces + como box posts, grille head con 2 de 3 líneas de stud, diagonales del storefront a estructura sin cargar | Back-check ciego por material antes de entregar el total; un framed_soffit no se repite en misc_items; altura por el tag del cuarto | reglas.py A_SOFFIT_DOBLE (rev14 falla, rev15 pasa); test_soffit_doble.py |
| BE-VS-13 | VS Downey (compuerta BE-117 de CFA) | Los markups de VS nunca cuadraron con el Excel: Contents SF = LF x H en vez del board del Excel, renglones agrupados "W026+W118" no reconocidos, valances sin geometría, 2 largos de banda sin causa; además rev10-rev14 se entregaron sin Planos marcados | markups_bluebeam SF = board_out; verificador suma los walls de un renglón agrupado; band para todo wall con LF; length_cause; los markups van en cada entrega | verificar_markups_excel: VS rev15 118/118 OK (antes 130 fallas) |
| BE-VS-14 | VS Downey (sesión principal) | Nota impresa en la sección típica ("ADDITIONAL STUD REQ'D AT EQ. STUDS", A/A12.01) dejada como pregunta en vez de cargarla; demo marcada fuera del formato del verificador (sin page label, sin ID del Excel) y fuera del PDF de entrega | Lo impreso se carga por programa con su nota y hoja; markups_demo con formato del verificador y dentro del PDF de entrega | VS rev16: +3,041 LF 3-5/8" + 24 LF 6"; verificar_markups_excel 178/178 (A02.01 + A01.01) |
| BE-VS-15 | VS Downey (sesión principal) | rev16 se entregó sin markups del RCP (A03.01): el verificador solo exigía hojas con walls / demo; ceilings, soffits y bracing no contaban | verificar_markups_excel exige toda hoja con renglones (ceilings por rcp_sheet, demolición por su fuente); markups_rcp.py dibuja cada ceiling / soffit con el SF del Excel y los clusters de bracing; el runner los mete en el PDF de entrega | rev16 sin RCP falla la compuerta; con RCP 208/208 OK (A01.01 + A02.01 + A03.01) |

## BE-114 — Hoja de datos del proyecto y hojas obligatorias olvidadas en las entregas (usuario 2-nov, todos los proyectos)
Error: el skill pedía en PASO 1 (Building Code Analysis) y en el FORMATO DE ENTREGA punto 1 los datos generales (nombre, tipo de proyecto, SF, pisos, Construction Classification, Occupancy, códigos, occupancy load), pero las entregas de B&N, O'Reilly, VS Downey y Chuze solo traían nombre/bid set/fecha; la regla vivía en texto y ningún programa la exigía, así que se olvidó. El usuario: "lo has estado olvidando, esa es una regla inviolable".
Prueba (compuerta por PROGRAMA, reglas.py/plantilla_excel): la entrega FALLA si en Inputs, README_REVIEW.md o PARA_REVISAR falta cualquiera de: nombre+ciudad, dirección, tipo de proyecto, owner/tenant, arquitecto, GC, fecha de bid, bid set, SF total, pisos, Construction Classification, Occupancy Group, códigos (año), occupancy load, sprinklered, demo sí/no, specs sí/no — cada uno con HOJA o [PENDIENTE] con lista de hojas barridas. FALLA también si la lista de hojas obligatorias revisadas (portada/índice, code analysis/G, notas generales, demo, specs, partition types+detalles, floor plans, RCP, elevaciones/secciones, enlarged/elev. interiores, schedules, estructurales, MEP) no está completa o no declara "no existe en el set".

## BE-115 — Skill partido en ramas y "mejor" mal marcado (usuario 2-nov)
Error: Chuze arrancó desde v80v mientras VS seguía en v80w→v80z3 (corridas en paralelo); sus reglas R80w.1–40 quedaron en una rama aparte sin unir, y INDICE.md seguía marcando v80s como "mejor", de modo que el próximo proyecto podía arrancar sin las órdenes nuevas del usuario. El usuario: "en cada proyecto te he estado dando órdenes nuevas… todo eso se tiene que estar actualizando y usando en el siguiente proyecto".
Prueba: antes de lanzar un proyecto, verificar por programa que la versión de arranque contiene TODAS las R80e.*/R80w.*/R-ALC-* archivadas (diff de índices de reglas = 0 faltantes) y que no hay ramas sin unir en skills_archivo/INDICE.md. Si falla, no se lanza hasta unir.

## Chick-fil-A #2284 River Point (2026-11-02) — errores de herramienta encontrados al arrancar
| ID | Origen | Error | Prueba | PASS si |
|---|---|---|---|---|
| BE-CF01 | CFA #2284 | La "copia limpia" borró 519 anotaciones "AutoCAD SHX Text": en las hojas M/P/E ese es el ÚNICO texto del dibujo (no son markups) | Antes de limpiar: contar anotaciones por autor/título; las "AutoCAD SHX Text" se conservan en una 2.ª copia para el barrido MEP; solo se quitan markups de personas (GC, estimadores) | El barrido MEP lee texto en todas las hojas M/P/E |
| BE-CF02 | CFA #2284 | inventario_tags.py no encontró types: TYPE_RE no aceptaba decimales (W4.1, M3.5) y el schedule estaba dentro de una hoja de PLANTA (A-202) bajo "MARK" | test: schedule "WALL TYPE SCHEDULE - INTERIOR" en hoja de planta con types X.n y una fila suelta bajo MARK | inventario lista todos los types del schedule con sus tags |
| BE-CF03 | CFA #2284 | No existía la familia 1/2" gyp board regular (solo 5/8, 3/8, 1/2 exterior) | canon con faces / existing_walls board "1/2 regular" | sale renglón "1/2\" gypsum board regular" con tape/compound por driver |
| BE-CF04 | CFA #2284 | Walls de MADERA (Div. 06) con nuestro gyp / cement board no tenían bloque: el bloque board-only decía "EXISTING WALLS TO REMAIN" | Bloque "BOARD ONLY - EXISTING OR WOOD-FRAMED WALLS (FRAMING NOT IN SCOPE)" | wood walls salen con board y 0 framing, con su markup |
| BE-CF05 | CFA #2284 | arranque.py no leyó NINGÚN sheet number (172 hojas) aunque inventario_tags sí | Mapa de hojas por title block con inventario_tags / contacto visual de title blocks vectorizados | toda hoja con número o marcada "vectorizada" con imagen |
| BE-CF06 | CFA #2284 | comparar.py solo compara walls[]: con board-only (existing_walls), cielos, misc y demo dio 113 "alertas" falsas y NO comparó A vs B en board / demo | comparar_extra.py: tags dentro de existing_walls cierran la alerta; totales A/B por board, cielos, familias misc y demo | toda familia del canon tiene su A vs B en revision_extra.md |
| BE-CF07 | CFA #2284 | ceilings[] no soporta joists de 6" (S-241 LGS CEILING JOIST SCHEDULE) ni cielo board-only; framed_soffit toma un solo furring_oc_in global (furr-down a 32" contado a 16"); familia "1-1/2\" Z-furring" con etiqueta fija (M2.1 es 2" Z); demo_geom sin validar (h_ft 0 en cielos) | Lecturas lo pasan a misc_items con traza; el Excel lo rotula con el tamaño impreso; demo de cielos va con área, no L×H | ningún material con etiqueta distinta a lo impreso; demo de cielos con SF > 0 en el markup |

## BE-116 — "El plano no lo dibuja" usado para no cargar (usuario 2-nov)
Error: al aplicar "opción A = plano" (R-ALC-10) se quitó el lateral bracing del gyp ceiling de VS (RFI-31: −2,046.98 LF splay wire, −361.91 LF struts) porque el RCP no lo dibuja, aunque el spec 092900 N.1 lo exige. Silencio del plano ≠ conflicto.
Prueba: todo renglón en 0 / excluido / quitado con motivo "no dibujado" debe tener barrido registrado en specs, metal/framing schedule y hojas S; si alguna fuente lo pide, se carga con su cita. reglas.py falla si un renglón "no dibujado" no tiene ese barrido.
| BE-CF08 | CFA #2284 (mío) | Agregué referencias/INDICE_REGLAS_ACUMULADAS.md al skill y el catálogo de reglas lo leyó como regla SIN clasificar: reglas.py compuerta fallaba en todo proyecto real; la suite (30/30) no lo detectó | Todo archivo nuevo en referencias/ se clasifica en reglas_clasificacion.py el mismo turno; correr `reglas.py compuerta` sobre un proyecto real del banco además de la suite | A_CATALOGO sin entradas sin clasificar |
| BE-CF09 | CFA #2284 | Límites de tool en el cálculo: vigas_sobre_walls.py no registra un roof plan de madera sin grid; markups de board-only con Subject genérico (no el type); cielos nuevos sin geometría no se dibujan; canon.py cuenta bracing en el Z-furring vertical (28.33 LF) | Subject = type del wall; cielos con polígono; bracing solo donde el detalle lo pide | markups por type; sin bracing en Z-furring salvo detalle |
| BE-CF10 | CFA #2284 (paso 12) | Productos de la spec no aplicados cuando el plano calla: ceiling board sag-resistant (C09250 2.1.E), board water-resistant detrás de sinks / toilets / mop (2.2.A), mesh tape + setting compound en joints de cement board (2.4.B.2) | Por cada familia de board: cruce con la sección de spec (tipo, ubicación, tratamiento de joints); compound / tape explican board vs cement board | cada renglón de board cita su párrafo de spec y el producto coincide |
| BE-CF11 | CFA #2284 (paso 12) | Detalle que imprime "2x6 wood OR 6\" metal" (D3/A-624) leído como "no impreso" (RFI) en vez de cargar la opción metálica (R-ALC-01) | grep "OR .*METAL|METAL .*OR" en detalles del trade antes de abrir un RFI de material | 0 RFI de material cuando el detalle da la opción metálica |
| BE-CF12 | CFA #2284 (paso 11/12) | canon.py pone C.R. channel bracing por defecto en todo tramo vertical (incluso Z-furring y walls con su propio brace impreso: kicker 362S162-33 @ 48" de C2/S-801, schedule de braces de S-801) | El bracing sale del detalle / schedule impreso; sin detalle = barrido R-ALC-11 + RFI; nunca C.R. channel por defecto en furring | ningún renglón de bracing sin N/HOJA que lo dibuje |
| BE-CF13 | CFA #2284 (paso 11) | Markups: Page Label numérico ("6"/"7") en vez de la hoja, estados en español (DERIVADO / PENDIENTE), infill de otro type rotulado con el type vecino, cielos / soffit bottoms / Level 5 sin markup | markups_bluebeam verifica Page Label = sheet number, idioma inglés, un Subject por type real, y un polígono por cielo / área | auditor (7) PASS |
| BE-CF14 | CFA #2284 (rev2) | accesorios.BOARD_DRIVER no incluía "1/2\" gyp MOISTURE RESISTANT" ni "5/8\" gyp FOIL-BACKED": joint compound / tape omitían ese board (CFA −10.66 lb / −54.77 LF; VS rev9 −76.1 lb / −391.1 LF) | Toda familia de gypsum board nueva entra al driver de finishing el mismo turno (test: familia de board en FAMS ⇒ en BOARD_DRIVER salvo cement board / ballistic / sheathing exterior) | compound y tape = yield × Σ todas las familias de gypsum board |
| BE-CF15 | CFA #2284 (back-check rev2) | Límites de plantilla aceptados como "nota" (rótulo fijo 1-1/2" Z-furring y "5/8\" regular" para un producto distinto, setting compound sin renglón, waste en un yield, Other Framing sin subtotal, hoja oculta de sello = 7 hojas) y trim cargado en la cara equivocada: el comprador lee el renglón, no la nota | Un límite de tool se ARREGLA en la tool con su test, nunca se tapa con una nota; el back-check revisa rótulo = producto impreso | back-check sin FAIL de rótulo / formato |
| BE-CF16 | CFA #2284 (usuario 3-nov) | 13 RFI abiertos en rev3 cuya respuesta probablemente está impresa en el set (hojas K / E / vendor vectorizadas, specs, S) sin barrido completo registrado | Antes de cualquier RFI: barrido de TODAS las hojas + grep del texto completo del set (incl. SHX) + mirar como imagen las hojas vectorizadas; el RFI lleva barrido {hojas, terminos, grep}; compuerta A_RFI_BARRIDO (reglas.py) | 0 RFI abiertos sin barrido registrado; cada RFI resuelto con N/HOJA + recorte |

## BE-117 — Verificación abierta DESPUÉS de entregar (usuario 3-nov)
Error: con O'Reilly pasada 2 FINAL ya entregada y el usuario revisándola, lancé una verificación/corrección de markups (DETAIL, escala contra rótulo, hojas sin marcar). El usuario: "una vez que tú termines, para mí está 100 % terminado; de no ser así me haces perder el tiempo".
Prueba (compuerta de entrega, reglas.py): antes de subir FINAL, verificar por programa en el PDF de markups que CADA annot tiene TYPE·LF·H·SF·DETAIL·Wall ID idénticos al Excel, /Measure = escala impresa (rótulo SCALE) de su hoja, Length vs LF ≤ 0.5 % (o causa escrita), y que toda hoja con elementos del take-off tiene markups. Sin esa compuerta en verde no se entrega.
| BE-CF17 | CFA #2284 rev4 (back-check) | Al resolver "smoke partition to deck" se subió a deck también la cara PÚBLICA del wall; A-221 A.11 lleva a deck solo la cara de kitchen / BOH (pública a 6" sobre el cielo) | Toda nota de altura por cara se aplica por SIDE (cuarto que mira); una resolución de RFI que cambia alturas se verifica cara por cara contra la nota | ninguna cara pública sobre el cielo + nota donde la nota lo limita a la cara BOH |
| BE-CF18 | CFA #2284 (mío, varias veces) | Horas de TIEMPOS.md escritas a ojo (16:10, 17:05, 18:15) en vez de leer el reloj; corregidas después | Toda hora se toma de `TZ=America/Los_Angeles date +%H:%M` en el MISMO comando que escribe la fila; nunca una hora futura | ninguna fila con hora > reloj al escribirla |
| BE-CF19 | CFA #2284 rev4 (compuerta v81cf16) | verificar_markups_excel v81cf16 tomaba la hoja de un renglón de demo del texto de su fuente y agarraba la hoja de la ALTURA ("TJI/L65", "A4/S-601"): 2 FALLAS falsas "hoja sin markups" con la demo ya marcada en A-050 | La hoja de la demo = la de su demo_geom; sin demo_geom, la hoja del texto antes de "height:" (test_demo_hoja_geom.py) | CFA rev4: 0 fallas con todas las demos marcadas en su demo plan |

## BE-118 — Proyecto sin monitoreo completo (usuario 3-nov, inviolable)
Riesgo: un proyecto lanzado sin estar en la vigilancia de addenda/otro GC o sin check-ins de avance puede entregarse con planos viejos o no terminarse a tiempo.
Prueba: al lanzar un proyecto, en el mismo turno: (a) el proyecto aparece en el prompt de la tarea "Vigilar addenda de bids activos" (o se pidió a COORDINACIÓN agregarlo y se confirmó), (b) existe un check-in programado (send_later/trigger) sobre su sesión, (c) búsqueda de otros GC hecha en Gmail. Sin las tres, no se reporta el proyecto como "en marcha".

## BE-HF01 — Brief de lectura con el resumen de wall types mal asignado (HFT Loveland, 3-nov, mío)
Error: escribí el resumen de types del BRIEF_LECTURA leyendo el texto extraído de A4.1 en orden de flujo; el texto de cada sección cae junto al TÍTULO de la sección vecina (A/B/C corridos: puse B = 6" a deck y C = 2-1/2" cuando A4.1 dibuja A = 6" x 20 GA a deck, B = 2-1/2" furring 8'-6", C = 3-5/8" furring 8'-6"). La lectura B lo detectó al abrir las secciones. Riesgo: lecturas sesgadas por el brief.
Prueba: todo resumen de types en un brief sale de recortes de CADA sección (imagen abierta y verificada), nunca del orden del texto; o el brief no resume types y solo manda a abrir la hoja. PASS si cada type del brief coincide con su sección dibujada.

## HFT Loveland (2026-11-03) — back-check rev1
| ID | Origen | Qué falló | Cómo se prueba | PASS si… |
|---|---|---|---|---|
| BE-HF02 | HFT rev1 back-check F1 | Bracing a estructura impreso (A1.1 nota 1 "@ 4'-0" O.C. MAX" + 2/A4.1 Spazzer 9200 + brace studs) quedó como Review Item con cantidad 0: R-ALC-11 / BE-116 repetido (la tool no tiene familia → se dejó en 0) | Todo detalle / nota de bracing impreso tiene renglón con el producto impreso; largo no impreso = valor conservador CARGADO + RFI; reglas.py debe fallar si un Review Item dice "qty 0" de algo impreso | ningún Review Item con un elemento impreso en 0 |
| BE-HF03 | HFT rev1 back-check F3 | Top track del bulkhead (llama 3/A5.3 = slip track) cargado en el renglón de "heads", fuera de las dos familias de track | Todo top track sale en estándar o slip según el detalle que llama (R80e.95) | ningún track fuera de las dos familias |
| BE-HF04 | HFT rev1 back-check F4 | C.R. channel bracing cargado en walls de 8'-6" cuando A4.1 nota 7 lo pide solo en walls > 12'-0"; texto del desglose con un spacing distinto al usado | El bracing sigue la condición impresa (altura mínima, spacing) y el desglose dice el spacing real | renglón = Σ walls que cumplen la condición |
| BE-HF05 | HFT rev1 back-check F6 / F2 | Partition Takeoff agrupó walls (A-14+A-12+A-13, C-01+C-02) que los markups llevan separados; Review Items con español y nombres internos ("DISCREPANCIA", "TOOL_LIMITS_CALC #4", "misc_info") | Una fila por Wall ID igual a los markups; grep de español / nombres internos en TODAS las hojas, incl. Review Items | 0 filas agrupadas distintas al markup; 0 textos internos |

## HFT Loveland (2026-11-03) — tool fixes de la corrida (v81cf21, R80f.17–R80f.28)
Nota de numeración: los ids de los arreglos de tools en TOOL_LIMITS_CALC del proyecto son BE-HF1..BE-HF17 (código y tests); aquí van como errores BE-HF06..BE-HF17. BE-HF02..05 (back-check rev1) quedaron resueltos por los tool fixes BE-HF12 / BE-HF11 / BE-HF13 / BE-HF14 (R80f.25 / R80f.26 / R80f.19 / R80f.27).
| ID | Origen | Qué falló | Cómo se prueba | PASS si… |
|---|---|---|---|---|
| BE-HF06 | HFT calc, tool fix BE-HF1 / BE-HF1b | Vertical metal hat channel furring (type E) sin familia: rotulado "1-1/2" Z-furring channel" en el Material Summary | R80f.17: "hat channel" -> familia vertical furring con rótulo impreso; familias.py lo lee de vuelta | el renglón dice el producto impreso |
| BE-HF07 | HFT calc, tool fix BE-HF2 | misc_items.familia "FRP panels" (nombre del Excel) paró canon.py | R80f.18: canon.MISC_ALIAS | canon.py corre con el nombre del Excel |
| BE-HF08 | HFT calc, tool fix BE-HF3 | C.R. channel bracing generado en furring vertical fijado a CMU / masonry | R80f.19 (a): furring sin bracing_rows declarado = 0 rows con fuente | 0 LF de bracing en walls de furring |
| BE-HF09 | HFT calc, tool fix BE-HF4 | vigas_sobre_walls con rótulos de grid de 9–10 pt: 0 grids comunes | R80f.20: --min-size | registro con >= 2 grids comunes |
| BE-HF10 | HFT calc, tool fix BE-HF5 | Compuerta A_BRACING con 48" fijo cuando el set imprime CRC @ 8'-0" | R80f.19 (c): spacing impreso (constants.bracing_spacing_in) | 0 fallas falsas de 53.4 |
| BE-HF11 | HFT calc, tool fix BE-HF6 / BE-HF6b | Box beams / box headers de detalle (misc_items) fuera de la suma E1 y del desglose del header | R80f.21: A_HEADER_LF + trazabilidad suman los misc de la familia | E1 = familia completa; desglose = NET |
| BE-HF12 | HFT calc, tool fix BE-HF7 | Desglose de track por tamaño comparaba stud_size exacto: '6" (600S162-54)' quedaba fuera ("desglose suma != NET") | R80f.22 (a): tamano_stud | desglose = NET |
| BE-HF13 | HFT calc, tool fix BE-HF8 | Renglón con citas de hoja suelta (sin N/SHEET) -> "default (no sheet)" y verificar rechazó el Excel | R80f.22 (b): hoja suelta citada | 0 renglones "default (no sheet)" |
| BE-HF14 | HFT calc, tool fix BE-HF9 | Wall sin gypsum board (faces_none_reason) con LF x H SF en el markup vs 0 SF en el Excel (BE-117 FALLA) | R80f.23 (a): board_sf = 0 | verificar_markups_excel OK en esos walls |
| BE-HF15 | HFT calc, tool fix BE-HF10 | auditoria_entrega fallaba toda entrega con RFIs abiertos pedidos por el brief e ignoraba la causa escrita del largo | R80f.24: --rfis-abiertos (A/B/C + delta) + length_cause | auditoría OK con RFIs completos y causas escritas |
| BE-HF16 | HFT back-check rev2 O5 / O2, tool fixes BE-HF15 / BE-HF17 | Demo con "2 layer(s)" para 2 faces x 1 layer; página LEGEND alfabética | R80f.23 (b)(c): layers_info y orden del schedule | rótulo "2 faces x 1 layer"; leyenda = orden del schedule |
| BE-HF17 | HFT back-check rev2 F5 / O6, tool fix BE-HF16 | Sill track sin desglose; desgloses distintos del NET por redondeo sin nota | R80f.22 (c): desglose por abertura + nota de redondeo | todo renglón con desglose; diferencia de redondeo anotada |
| BE-HF18 | HFT rev2 (COORDINACIÓN, BE-CF16) | RFI-01 (altura del demising bajo deck inclinado) se dejó abierto con el punto alto cargado aunque A1.2 / A2.0 imprimen B.O. DECK por zona (±16'-11", ±17'-3½", ±17'-6", ±18'-0½", ±18'-3"); la resolución lo listó como "opción A" en vez de aplicarlo | Antes de dejar un RFI, si una de sus opciones cita valores IMPRESOS (A = "use printed …"), se aplica esa opción por zona con su N/HOJA (DERIVADO) y el RFI se cierra; RFI solo si la ubicación no se puede asignar | ningún RFI cuya opción (A) sea un valor impreso aplicable |

## BE-119 — Revisión de markups validada contra el Excel (circular) (coordinación, 3-nov)
revision_markups.py comparó Depth contra la H del Excel, de donde sale el markup: siempre da verde. Prueba: el reporte trae por fila "Printed source H" con N/HOJA (RCP C.H., sección, detalle, B.O.) y marca ROJO si Depth ≠ altura impresa; sin fuente impresa = ÁMBAR con la hoja barrida.

## BE-120 — RFI con respuesta impresa llegó a la entrega (Harbor Freight rev2, 3-nov)
El barrido BE-CF16 se hizo después de entregar; RFI-01 estaba en A1.2 (B.O. DECK por zona) → rev3. Prueba: compuerta previa a la entrega que exige, por cada RFI abierto, la lista de hojas y términos barridos + grep del texto del set sin coincidencias; si falta = FALLA y no se entrega.

## BE-121 — Reglas en texto que nadie hacía cumplir (usuario 3-nov, INVIOLABLE, "cómo se arregla")
Toda regla inviolable lleva compuerta de programa de fondo + test que reproduce el error original; ninguna entrega sale sin compuerta_entrega.py en verde y subir_entrega.py; COORDINACIÓN no reporta resultados al usuario sin ENTREGA_OK.json verde. (1) regla sin compuerta = regla no terminada; (2) COORDINACIÓN revisa cada resultado punto por punto contra la orden ANTES de pasarlo; (3) toda orden a una sesión lleva la orden TEXTUAL + lista de entregables y la sesión devuelve la prueba de cada punto; (4) archivo de reglas limpio (históricas a REGLAS_HISTORICO.md, arriba las 15 más rotas). Prueba: `verificar_version.py` FALLA si una regla "programa" del registro REGLAS_REGISTRO.json no tiene chequeo + test existentes; `compuerta_entrega.py <workdir>` escribe ENTREGA_OK.json (rc 1 con cualquier FAIL); `subir_entrega.py` se niega a subir sin ENTREGA_OK.json verde, vigente (sha256 de cada archivo) y con la carpeta del proyecto hija EN VIVO de Claude outputs de la raíz. Tests: tools/test_compuerta_entrega.py (HFT RFI-01 / A1.2, O'Reilly altura circular, Drive equivocado, sin TIEMPOS) y jc-hunter-ordenes/test_verificar_version.py.

## BE-122 — Materiales vs Partition Type Schedule sin revisión independiente (usuario 3-nov)
Chequeo (j) de la compuerta de entrega: lectura independiente por type del Partition Type Schedule (stud size / gauge / spacing, board por cara: capas / tipo / espesor, track / slip, cobertura de altura, extras) comparada por programa contra lo cargado en el Excel por wall / type (GREEN / RED / AMBER) + totales del Material Summary = suma de walls por type (RED si un material no tiene type de origen). Herramienta: tools/revision_materiales.py (sesión O'Reilly, R80e.140) dentro de compuerta_entrega.py como CE_MATERIALES_SCHEDULE: sin fichas.json (lectura independiente del schedule) = FAIL; type RED o renglón del Material Summary sin origen / que no suma = FAIL. Test: tools/test_compuerta_entrega.py (test_materiales_schedule, test_revision_materiales).

## BE-123 — Pregunté si arreglar el trabajo propio (usuario 3-nov, U-112)
Le pregunté al usuario si arreglaba las 11 fallas de la compuerta de O'Reilly: era trabajo de Claude. Prueba: ningún reporte al usuario presenta como pendiente una falla de compuerta / archivo faltante / error de tool; se arregla y se reporta terminado (conducta; la compuerta de entrega es la parte verificable).

## BE-124 — Burbujas de detalle sin seguir: las tools existían y la compuerta no las corría (usuario 3-nov, U-113)
verif_callouts.py / cadena_detalles.py / verif_detalles.py estaban en el skill pero compuerta_entrega.py nunca las llamaba. Prueba (CE_CALLOUTS, tools/chequeos_biblioteca.py::ce_callouts): toda burbuja N/HOJA de las hojas del trade y de cada detalle que la cadena alcanza (cierre transitivo) está citada como fuente N/HOJA en el Excel / canon o declarada fuera de alcance con motivo en callouts_no_aplican.json; un detalle / hoja referido que no existe se reporta. Test: test_chequeos_biblioteca.py (D/A9.22 citado, 7/A9.26 de la marquesina sin seguir -> FAIL).

## Programas de la biblioteca (v81cf24, 3-nov, orden "haz los programas")
Desde v81cf24 TODA prueba de esta biblioteca tiene chequeo de programa en tools/chequeos_biblioteca.py (o verificar_version.py / reglas.py, ver REGLAS_REGISTRO.json) que corre dentro de compuerta_entrega.py, con su caso en tools/test_chequeos_biblioteca.py que reproduce el error original. La lectura del Paso 12 b sigue, pero ya no es la única prueba.


## BE-125 — Set RASTER sin OCR: el barrido de RFI (BE-120) quedaba ciego (O'Reilly rev5, 3-nov)
O'Reilly A1.1–A6.1 / S1.1 son escaneos sin capa de texto: `compuerta_entrega.py texto` sacaba 1 carácter por hoja y el barrido de
términos de cada RFI "pasaba" sin haber leído nada. Prueba (R80e.151): texto_set pasa por OCR (tesseract) toda hoja con
< 200 caracteres, lee el número de hoja del title block y separa las páginas en blanco; CE_RFI_BARRIDO_IMPRESO falla si queda
una hoja sin texto. Test: test_compuerta_entrega.py::test_oreilly_rev5 (bloque test_texto_set_ocr).

## BE-126 — Head track adicional cargado sin hoja impresa en walls de furring (O'Reilly rev5, 3-nov)
32.73 LF de "additional head track at openings over 4'-0\"" salían del criterio del skill (N/SHEET: default) sobre Door 3 y
Windows D1 / D2, que están en S21 = Z-furring 150ZF125-18 sobre CMU (sin studs, lintel de mampostería S4.1); ninguna hoja
imprime head track (7/A5.1 = solo box header). Prueba (R80e.144): accesorios.additional_head_track no cuenta aberturas de
walls de furring y el 0 cita su fuente; CE_MATERIALES_SCHEDULE marca RED toda fila con cantidad y N/SHEET: default.
Test: bloque test_head_track_furring.

## BE-127 — Cita no literal del plano ("FLAT STRAP" por "FLAT STRIP") (O'Reilly rev5, 3-nov)
El rótulo del strap citaba 'DIAGONAL WALL BRACING (3" x 16 GA FLAT STRAP)'; A1.1 Interior Wall Notes 2.B imprime
"( 3" X 16 GA. FLAT STRIP )". Toda cita entre comillas va copiada de la imagen, letra por letra; BE-12 (chequeos_biblioteca)
la busca en el texto del set (con OCR desde R80e.151). Conducta + chequeo BE-12.

## BE-128 — Insumos del proyecto copiados sin conservar fechas (O'Reilly rev5, 3-nov)
`cp -r` dejó revision.json "más viejo" que canon_A / canon_B (mismo segundo) y reglas.py marcó la revisión como vencida:
2 fallas falsas. Regla: copiar insumos y carpetas de trabajo SIEMPRE con fechas (`cp -a`, shutil.copy2 / copytree).
Conducta (la compuerta de etapas de reglas.py es la que lo detecta).

## BE-129 — Dos compuertas que se contradicen y chequeos con falsos positivos en sets OCR (O'Reilly rev5, 3-nov)
verificar_markups_excel exige SF del markup = board SF (BE-117) y revision_markups exigía LF x H: todo wall con 2 caras
fallaba en una de las dos; revision_markups no aceptaba la causa escrita (length_cause) que la otra sí. Además 8 chequeos de la
biblioteca daban FAIL por texto OCR, negaciones ("not deducted") o listas de types ("S21/S24"). Prueba (R80e.143 / R80e.145 /
R80e.150): cada arreglo con test que reproduce el falso positivo de O'Reilly Y el error real que sigue fallando.
Test: bloques test_revision_markups_be117, test_chequeos_ocr_oreilly, test_auditoria_raster.

## BE-130 — El runner de la versión vigente no arrancaba (O'Reilly rev5, 3-nov)
v81cf24 importaba chequeos_biblioteca (tools/) desde runner/run_takeoff.py sin tools/ en el path: ModuleNotFoundError antes
del paso 1; la suite no lo vio porque los tests importan con tools/ en el path. Prueba (R80e.148): el test importa el runner
SOLO con runner/ en el path; además comparar_extra.py corre después de comparar.py (R80e.147, U-081).
Test: bloque test_runner_comparar_extra.

## BE-131 — Preferencias del día 1 sin compuerta de fondo (usuario 3-nov, U-114..U-125)
Queja del usuario: la regla de las burbujas (DETALLES) se dio en los primeros días y nunca se hizo cumplir; lo mismo pasaba con el resto de sus preferencias de cuenta del día 1. Casos reales encontrados al calibrar: HFT D-01 cara vecina "[DERIVED]" sin operación y D-03/D-04 "same as" sin estado; O'Reilly rev4 Material Summary "N/SHEET: not applicable (see note)" (CE_FUENTES_MS lo dejaba pasar), renglones 'S42-H1+S42-H2' (dos walls en un número) y height_img = página entera sin marca (0 px rojos); Chuze tag_ids con 1 de 3 ubicaciones del inventario y "ASSUMED ... RFI." sin número; HFT sin inventario de tags y sin imagen por wall; CE_SIN_DOLARES solo miraba los .md; chequeos_biblioteca no leía 1_inventario/inventario.json (nombre distinto). Prueba (tools/chequeos_biblioteca.py u_114 / u_115 / u_116 / u_117 / u_118 / u_119 / u_120 / u_121 / u_125 + compuerta_entrega.py CE_SIN_DOLARES, todos dentro de compuerta_entrega.py): ver R80e.152. Test: test_chequeos_biblioteca.py (caso MALO por preferencia + test_u118_evidencia_circula) y test_compuerta_entrega.py (monto en el Excel).

## BE-CF20 — Dos sesiones archivaron el mismo número de versión (CFA #2284 rev5, 3-nov)
| CFA #2284 rev5 (3-nov) | La sesión CFA y la de O'Reilly archivaron las DOS un v81cf25 con contenido distinto, y después CFA y COORDINACIÓN las dos un v81cf26 (línea partida, BE-115); el push de CFA chocó en INDICE.md | Antes de archivar: git pull y tomar el siguiente número libre; si ya existe el número, unir 3-way sobre la versión del otro (base = la anterior) y archivar v+1. verificar_version.revisar_indice falla si la versión vigente tiene más de un zip (test_verificar_version.py) | CFA rev5: v81cf27 = v81cf26 (COORDINACIÓN) + arreglos CFA; suite 51/51 |


## BE-132 — Dos compuertas contradictorias: la imagen del Review Item (U-118) vs texto interno (R80e.84) (O'Reilly rev6, 4-nov)
U-118 exige la imagen circulada de cada Review Item en la columna Image; plantilla_excel.verificar_texto_cliente rechazaba todo
".png" en una hoja visible: el runner no armaba el Excel y la cobertura (BE-71) no se escribía. Prueba (R80e.153): la columna
Image acepta el nombre de la imagen sin ruta; una ruta o un nombre de archivo en otra columna sigue fallando.
Test: test_compuerta_entrega.py::test_oreilly_rev5 (bloque test_review_image_name).

## BE-133 — Barrido de tags en hoja RASTER: 0 ocurrencias por programa (O'Reilly rev6, 4-nov)
inventario_tags.py lee la capa de texto; en un escaneo da 0 tags y U-117 falla (el barrido "a mano" no dejaba lista numerada).
Regla: en hoja raster el barrido se hace visual por cuadrantes (todos los tiles vistos), cada tag con su recorte circulado
reabierto (png_verificado), escrito en 1_inventario/inventario.json con center_pt / bbox_pt, asignado a su wall (tag_ids) y
comparar.py re-corrido con ese inventario. Conducta + chequeo U-117 (chequeos_biblioteca.u_117).

## BE-CF21 — Compuerta de las preferencias del día 1 sobre CFA rev5: 7 FAIL (CFA #2284 rev6, 3-nov)
| CFA #2284 rev6 (3-nov) | La compuerta con las preferencias del día 1 (U-114..U-125) dio ROJA en CFA rev5: 7 FAIL. Reales: alturas de cara sin estado, fuentes board-only sin N/HOJA, imágenes de Review Items / RFI no nombradas o sin círculo (item 6 mostraba otros tags, item 5 otra hoja), 22 board-only + DEMO-02 en L = dos ejes en un número, demos de cielo como Polylength sin Depth. Falsos positivos: U-117 no leía existing_walls[].tag_ids ni tags_descartados; U-120 leía 'KN3 + KN4' / 'A-202 + A-622' de la fuente como walls juntados; R80e.84 prohibía el nombre de la imagen que U-118 exige | chequeos_biblioteca u_117 (existing_walls + tags_descartados) y u_120 (solo el Wall ID, sin keynotes / notas); markups_demo: área = Polygon con /Measure de área, polilínea que dobla > 60° = una pieza por eje; plantilla_excel R80e.84 acepta proceso/review_img|rfi_img/*.png solo en Review Items; verificar_markups_excel: elemento marcado por sus piezas; regla de datos: un eje por número (partir en el canon, suma igual) (test_cf_pruebas.py::test_cf_rev6_dia1) | CFA rev6: compuerta v81cf28 (CFA) 146 PASS / 3 AMBER / 0 FAIL |

## BE-134 — La compuerta de entrega v1 falló por herramientas del skill que se contradecían (SF board vs LF x H, MR vs X MR, PDF intermedio) y por alturas redondeadas del canon (Chuze FINAL6, 3-nov)
Chequeo(s): take-off:tools/compuerta_entrega.py::ce_altura_impresa, take-off:tools/compuerta_entrega.py::ce_materiales_schedule, take-off:tools/compuerta_entrega.py::ce_reglas, take-off:tools/alturas_exactas.py::corregir. Test: take-off:tools/test_chuze_r80f8_11.py (test_sf_parte). Skill v81cf30 (Chuze FINAL6, rondas de compuerta 3/4-nov).

## BE-135 — La compuerta de entrega v25 sobre Chuze FINAL6 dio 15 FAIL: set_texto con hojas mal rotuladas, chequeos con falsos positivos y errores reales del take-off (demolición sin cuantificar, MR en locker rooms, alturas sin fuente visible) (3-nov)
Chequeo(s): take-off:tools/compuerta_entrega.py::hoja_de_etiqueta, take-off:tools/chequeos_biblioteca.py::ce_callouts, take-off:tools/chequeos_biblioteca.py::r_alc_04. Test: take-off:tools/test_chuze_r80f8_11.py (test_hoja_etiqueta). Skill v81cf30 (Chuze FINAL6, rondas de compuerta 3/4-nov).

## BE-136 — La compuerta v27 (preferencias del día 1 U-114..U-121) sobre Chuze FINAL6 dio 8 FAIL: caras sin estado #0, alturas sin imagen circulada, supuestos sin su decisión escrita (take-off) y chequeos que no leían keynotes, Review Items, column wraps, descartes del canon ni hojas A421.A (herramientas) (4-nov)
Chequeo(s): take-off:tools/chequeos_biblioteca.py::u_114, take-off:tools/chequeos_biblioteca.py::u_118, take-off:tools/markups_bluebeam.py::tramos_rectos. Test: take-off:tools/test_chuze_r80f8_11.py (test_u120_tramos). Skill v81cf30 (Chuze FINAL6, rondas de compuerta 3/4-nov).

## BE-137 — Compuerta v30 sobre Chuze FINAL6: lectura B sin los soffits del RCP ni A101 (segunda lectura independiente agregada), lecturas sin constants, comparar_extra y cobertura sin correr, largos del canon sin su decisión citada, y la altura impresa leída de la alternativa (4-nov)
Chequeo(s): take-off:tools/chequeos_biblioteca.py::u_034, take-off:tools/chequeos_biblioteca.py::be_60, take-off:tools/chequeos_biblioteca.py::be_63. Test: take-off:tools/test_chuze_r80f8_11.py (test_u034_misma_cosa). Skill v81cf30 (Chuze FINAL6, rondas de compuerta 3/4-nov).

## BE-138 — Chuze FINAL5: 7 walls tipo A con una sola cara de board aunque A/A301 imprime "- BOTH SIDES" (usuario 4-nov: ya lo había ordenado)
La cara al chase de plomería / hueco contra el muro existente se omitió en silencio (+218.46 SF MR en FINAL6). Programa: chequeos_biblioteca.both_sides = CB_BOTH_SIDES en compuerta_entrega.py (U-127): por wall, caras con board y capas por cara = schedule (fichas.json, lectura independiente BE-122); falta de cara / capa = FAIL. Test: tools/test_chuze_r80f8_11.py (test_both_sides) + caso both_sides en tools/test_chequeos_biblioteca.py. Skill v81cf31.

## BE-140 — Chuze FINAL7: un error 500 de Google Drive cortó la subida a mitad y subir_entrega.py no podía retomarla
gdrive_fetch put rechaza un archivo que ya existe en la carpeta (no sobrescribe), así que la segunda corrida chocaba con lo ya subido y la única salida era subir a mano, lo que está prohibido. Arreglo (R80f.42): subir_entrega.py lista cada carpeta destino y da por subido el archivo con el mismo nombre y tamaño; con otro tamaño se bloquea. Test: tools/test_chuze_r80f8_11.py (test_subida_retoma). Skill v81cf35.

## BE-CF22 — Cadena de burbujas de CFA rev6 con la compuerta v81cf33 (CFA #2284 rev7, 4-nov)
| CFA #2284 rev7 (4-nov) | La compuerta v81cf33 (burbujas de dos líneas) dio 78 burbujas sin disposición en CFA rev6 y otros 3 FAIL. Huecos de tool: (1) CE_CALLOUTS: el patrón CALLOUT solo aceptaba etiquetas de 1 carácter ('1', 'A'): 'A3/A-601', 'C4/A-624', 'D1-A/A-625' nunca contaban como cita (C4/A-624 estaba citado y salía 'sin disposición'); (2) una referencia impresa a una vista inexistente (D1/A-602 'RE: B3/A-623'), ya reportada en su RFI, daba FAIL sin poder declararse; (3) revision_materiales leía '1/2" SHEATHING' (sin material) como gyp regular -> RED contra el cement board de la nota G.4; (4) BE-VS-13 sumaba el markup DEMO del board existente (DEMO-14 <wall>) al board del wall. Datos: 101 vistas leídas; EX-KIT-02 era un hueco (A3/A-601 OPEN TO BEYOND) | CALLOUT acepta letra+número(-letra); vista inexistente declarada con RFI = AMBER; tipo_board 'SHEATHING' = material por wall notes (AMBER); BE-VS-13 ignora Subject DEMO (test_cf_pruebas.py::test_cf_rev7_burbujas, falla con v81cf34). Regla: toda burbuja se sigue con su recorte circulado, se cita en el renglón que gobierna o va a callouts_no_aplican.json con motivo | CFA rev7: compuerta 147 PASS / 4 AMBER / 0 FAIL |

## BE-CF23 — RFI abierto con 'nothing loaded' (CFA #2284 rev8, 4-nov)
| CFA #2284 rev7 → rev8 (4-nov, COORDINACIÓN) | RFI-27 (furr down del drive-thru, C1/A-603 B.O. 7'-8") quedó abierto con 'Plans: nothing loaded' y CB_U_116 pasó: el chequeo no veía 'nothing loaded / not carried' en un RFI abierto (U-048: el supuesto conservador va CARGADO con su delta) | chequeos_biblioteca.u_116: RFI abierto cuya opción A / pregunta dice 'nothing loaded', 'not loaded', 'not carried', 'no cargado' = FAIL (test_cf_pruebas.py::test_cf_rev8_no_cargado, falla con v81cf36). Datos: furr down cargado (cara 2.833 ft + fondo 2'-0" supuesto 1/2" cement board, framing como C4/A-624, 11.011 LF) | CFA rev8: compuerta 147 PASS / 4 AMBER / 0 FAIL |

## BE-CF24 — Auditoría de rev8: alturas viejas en la Source, furr down sin RCP, demo fuera del demo plan, copia limpia sin comparar (CFA #2284 rev9, 4-nov)
| CFA #2284 rev8 → rev9 (4-nov, auditoría adversarial de COORDINACIÓN, U-138) | (1) La Source de los renglones board-only arrastraba el texto de altura VIEJO ('G.3/A-202 1'-0" [CONFIRMED]' en renglones cargados a 1.25 ft de C3/A-604; restroom 6.708 / 2.625 cargado 6.521 / 2.8125): CONFIRMED con otra fuente viola #0; (2) W6-09-OUT-1 a 1.0 ft y su hermano -2 a 1.25 en el mismo cuarto; (3) rev8 cargó un furr down en el drive-thru que el RCP A-221 no dibuja (el 7'-8" de C1/A-603 es el datum del acabado); (4) DEMO-14 marcado en A-202 en vez del demo plan (R-ALC-06); (5) la copia limpia nunca se comparó por programa con el original (16 XObjects Xop faltantes: también faltan en el original, hojas civiles 151-166) | compuerta_entrega.copia_limpia + CE_COPIA_LIMPIA (páginas, XObjects por página, faltantes solo-en-copia, render sin anotaciones; entrega.json bidset_original / bidset_limpio); chequeos_biblioteca.be_cf24 (la altura de la Source '= N ft' = height_ft cargado) y r_alc_06 (markup Subject DEMO solo en hojas DEMOLITION) (test_cf_pruebas.py::test_cf_rev9_auditoria). Regla: un furr down / soffit se carga solo si el RCP o una sección lo dibuja; un rótulo de elevación sin RCP = datum + RFI con la alternativa | CFA rev9: compuerta 150 PASS / 4 AMBER / 0 FAIL |

## BE-141 — Chuze FINAL7 (auditoría U-138): Scope Checklist ALC-07 / ALC-08 con cifras tecleadas viejas (Type X 58,393.09 vs 57,241.60; existing walls 27,973.17 vs 26,818.18)
Chequeo(s): take-off:tools/chequeos_biblioteca.py::cifras_texto, take-off:tools/plantilla_excel.py::verificar_cifras. Test: take-off:tools/test_chuze_r80f8_11.py (test_cifras_texto). Skill v81cf40 (Chuze FINAL8, auditoría U-138 4-nov).


## BE-142 — Chuze FINAL8 (compuerta v40): CB_U_037 contaba como walls faltantes los tags de A101 descartados en el canon (wall contado en el plano ampliado, ONE WALL ONCE)
Chequeo(s): take-off:tools/chequeos_biblioteca.py::u_037. Test: take-off:tools/test_chuze_r80f8_11.py (test_u037_duenos). Skill v81cf40 (Chuze FINAL8, auditoría U-138 4-nov).

## BE-143 — Hook U-136 guardaba avisos automáticos como órdenes del usuario (5-nov)
La bandeja _entrantes.jsonl tenía 32 entradas y ninguna era del usuario: task-notification, informes de subagentes y avisos de otras sesiones entran por UserPromptSubmit. Arreglo: registrar_orden.py descarta todo prompt que empieza con un envoltorio automático (es_del_usuario). Las 32 quedaron clasificadas "no es regla" en MAPA_ORDENES.json.
Chequeo(s): .claude/hooks/registrar_orden.py::es_del_usuario. Test: jc-hunter-ordenes/test_verificar_version.py (hook_solo_usuario).
