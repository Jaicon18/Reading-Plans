#!/usr/bin/env python3
"""subir_entrega.py — BE-121 (usuario 3-nov, INVIOLABLE): CANDADO DE SUBIDA. Única forma de subir una entrega a Drive.

Envuelve /opt/takeoff/gdrive_fetch.py (no lo modifica). Se NIEGA a subir si:
  1. no existe <workdir>/ENTREGA_OK.json, o no es verde (ok = true, 0 FAIL), o viene de una corrida parcial;
  2. algún archivo de la carpeta de entrega cambió, se agregó o se borró DESPUÉS de la compuerta (sha256 distinto al
     registrado, o archivo más nuevo que ENTREGA_OK.json);
  3. drive.parent_id != 1UReOABlgJPIkGLe8-nRO6U-6i7xpKoIc (Claude outputs de la RAÍZ) o es el prohibido de Projects;
  4. la carpeta del proyecto (drive.carpeta_proyecto_id) no aparece EN VIVO como hija de la raíz (gdrive_fetch list).
Sube la carpeta de entrega como subcarpeta NUEVA (nombre de la carpeta de entrega) dentro de la carpeta del proyecto,
archivo por archivo (gdrive_fetch put nunca sobrescribe), y escribe SUBIDA_OK.json.

Uso: python3 subir_entrega.py <project_workdir> [--revisar]      (--revisar = solo los candados, sin subir)
     $GDRIVE_FETCH = ruta alternativa del script de Drive (tests); por defecto /opt/takeoff/gdrive_fetch.py
"""
import datetime
import json
import os
import subprocess
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import compuerta_entrega as CE  # noqa: E402

GDRIVE = os.environ.get("GDRIVE_FETCH") or "/opt/takeoff/gdrive_fetch.py"


class Bloqueo(Exception):
    pass


def _g(*args):
    p = subprocess.run([sys.executable, "-I", GDRIVE, *args], capture_output=True, text=True, timeout=3600)
    if p.returncode:
        raise Bloqueo(f"gdrive_fetch {args[0]} falló rc {p.returncode}: {(p.stderr or p.stdout)[-300:]}")
    return p.stdout


def candados(workdir):
    """-> (ENTREGA_OK dict, lista de archivos a subir). Lanza Bloqueo con el motivo."""
    w = os.path.abspath(workdir)
    okp = os.path.join(w, "ENTREGA_OK.json")
    if not os.path.isfile(okp):
        raise Bloqueo("no existe ENTREGA_OK.json: correr compuerta_entrega.py primero")
    ok = json.load(open(okp, encoding="utf-8"))
    malos = [c["id"] for c in ok.get("chequeos") or [] if c.get("estado") == "FAIL"]
    if not ok.get("ok") or malos:
        raise Bloqueo(f"ENTREGA_OK.json NO está en verde (FAIL: {', '.join(malos) or 'corrida parcial'})")
    ed = ok.get("entrega_dir")
    if not ed or not os.path.isdir(os.path.join(w, ed)):
        raise Bloqueo("ENTREGA_OK.json sin carpeta de entrega existente")
    t_ok = os.path.getmtime(okp)
    reg = ok.get("archivos") or {}
    real = {os.path.relpath(os.path.join(r, f), w) for r, _, fs in os.walk(os.path.join(w, ed)) for f in fs}
    nuevos, quitados = sorted(real - set(reg)), sorted(set(reg) - real)
    if nuevos or quitados:
        raise Bloqueo(f"la entrega cambió después de la compuerta: nuevos {nuevos[:5]} / faltan {quitados[:5]}")
    for rel, sha in reg.items():
        p = os.path.join(w, rel)
        if CE._sha(p) != sha:
            raise Bloqueo(f"{rel} cambió después de la compuerta (sha256 distinto): volver a correr compuerta_entrega.py")
        if os.path.getmtime(p) > t_ok + 1:
            raise Bloqueo(f"{rel} es más nuevo que ENTREGA_OK.json: volver a correr compuerta_entrega.py")
    d = ok.get("drive") or {}
    if d.get("parent_id") != CE.DRIVE_RAIZ or d.get("parent_id") == CE.DRIVE_PROHIBIDO:
        raise Bloqueo(f"drive.parent_id {d.get('parent_id')} != {CE.DRIVE_RAIZ} (Claude outputs de la RAÍZ)")
    if not d.get("carpeta_proyecto_id"):
        raise Bloqueo("entrega.json sin drive.carpeta_proyecto_id (crearla con gdrive_fetch mkdir "
                      f"{CE.DRIVE_RAIZ} '<proyecto>' y anotar el id)")
    return ok, sorted(reg)


def verificar_padre_en_vivo(d):
    hijos = [json.loads(x) for x in _g("list", CE.DRIVE_RAIZ).splitlines() if x.strip().startswith("{")]
    h = next((x for x in hijos if x.get("id") == d["carpeta_proyecto_id"]), None)
    if not h:
        raise Bloqueo(f"la carpeta {d['carpeta_proyecto_id']} NO es hija de Claude outputs de la raíz ({CE.DRIVE_RAIZ})")
    if d.get("carpeta_proyecto") and h.get("name") != d["carpeta_proyecto"]:
        raise Bloqueo(f"la carpeta {h['id']} se llama '{h.get('name')}', no '{d['carpeta_proyecto']}'")
    return h


def subir(workdir, solo_revisar=False):
    w = os.path.abspath(workdir)
    ok, archivos = candados(w)
    d = ok["drive"]
    verificar_padre_en_vivo(d)
    if solo_revisar:
        return {"revisado": True, "archivos": len(archivos)}
    raiz_ed = ok["entrega_dir"]
    ids = {raiz_ed: _g("mkdir", d["carpeta_proyecto_id"], os.path.basename(raiz_ed)).strip().splitlines()[-1]}
    log = []
    for rel in archivos:
        sub = os.path.dirname(rel)
        partes = os.path.relpath(sub, raiz_ed).split(os.sep) if sub != raiz_ed else []
        cur = raiz_ed
        for pt in partes:
            if pt in ("", "."):
                continue
            nxt = os.path.join(cur, pt)
            if nxt not in ids:
                ids[nxt] = _g("mkdir", ids[cur], pt).strip().splitlines()[-1]
            cur = nxt
        out = _g("put", os.path.join(w, rel), ids[cur])
        log.append({"archivo": rel, "carpeta_id": ids[cur], "salida": out.strip()[-200:]})
    res = {"fecha_iso": datetime.datetime.now(datetime.timezone.utc).isoformat(), "entrega_ok_sha": CE._sha(os.path.join(w, "ENTREGA_OK.json")),
           "drive": d, "carpetas": ids, "subidos": log}
    json.dump(res, open(os.path.join(w, "SUBIDA_OK.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return res


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    try:
        r = subir(argv[1], "--revisar" in argv)
    except Bloqueo as e:
        print(f"SUBIDA BLOQUEADA: {e}")
        return 1
    print("CANDADOS OK" + ("" if r.get("revisado") else f" — {len(r['subidos'])} archivos subidos; SUBIDA_OK.json"))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
