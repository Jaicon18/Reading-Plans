#!/usr/bin/env python3
"""test_compuerta_entrega.py — BE-121: cada chequeo de compuerta_entrega.py / subir_entrega.py REPRODUCE el error original.
  - BE-120 (Harbor Freight rev2): RFI-01 abierto con la respuesta IMPRESA en A1.2 (B.O. DECK por zona) -> FAIL.
  - BE-119 (O'Reilly 3-nov): Depth del markup = H del Excel (comparación circular) pero la altura IMPRESA es otra -> FAIL.
  - Drive: carpeta bajo Projects › Claude outputs (O'Reilly / VS) -> FAIL; sin ENTREGA_OK verde -> subida bloqueada.
  - O'Reilly sin TIEMPOS.md -> FAIL. + formato Excel, tornillería, tracks, RFI A/B/C, RFI prohibidos.
Tokens que verificar_version.py busca en este archivo: ce_tiempos ce_drive_parent ce_rfi_barrido ce_altura_impresa
ce_formato_excel ce_tornilleria ce_track_familias ce_rfi_formato ce_rfi_prohibidos ce_entregables ce_sin_proposal
ce_sin_dolares ce_horas ce_seguimiento ce_atribucion ce_decisiones ce_fuentes_ms ce_datos_proyecto candados
ce_materiales_schedule revision_materiales texto_hoja_rotada
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import openpyxl  # noqa: E402
import pymupdf  # noqa: E402
import compuerta_entrega as CE  # noqa: E402
import subir_entrega as SE  # noqa: E402

RFI_OK = ("(A) Drawings (A2.0): printed B.O. deck per bay - delta -380 SF | (B) Code (ASTM C754): high point (loaded) - "
          "delta 0 (loaded) | (C) Other: ____")


def libro(p, pending=(("RFI-01", "Demising wall D-01 height basis per bay", RFI_OK),), ms=None, extra_hoja=False,
          extra_col=False, scope=None):
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    for h in CE.HOJAS6:
        ws = wb.create_sheet(h)
        fila, cab = CE.CABECERAS[h]
        for _ in range(fila - 1):
            ws.append(["x"])
        ws.append(cab + (["Extra"] if extra_col and h == "Material Summary" else []))
    ws = wb["Partition Takeoff"]
    ws.append(["TYPE S21"])
    ws.append(["S21 #S21-N", "S21-N", 20.0, 14.84375, 1, '6"', 16, 296.9, "Sales", "1/A3.2", "[CONFIRMED]"])
    for r in ms if ms is not None else (
            ["Bottom track 6\"", "LF", 20, 0.15, 0, 0, "run", 1, "N/SHEET: 1/A3.2"],
            ["Top slip / deflection track 6\" (2\" leg)", "LF", 20, 0.15, 0, 0, "run", 1, "N/SHEET: 10/A4.1"],
            ["Drywall screws #6 x 1-1/4\" Type S", "PCS", 0, 0, 0, 0, "each", 0, "N/SHEET: GA-216 | EXCLUDED - estimator decision 2026-10-31 (U-053)"]):
        wb["Material Summary"].append(list(r))
    for r in pending:
        wb["Pending Items"].append(list(r))
    for r in scope if scope is not None else (["ALC-30", "Fasteners", "EXCLUDED", "All screws / anchors EXCLUDED (U-053)"],):
        wb["Scope Checklist"].append(list(r))
    if extra_hoja:
        wb.create_sheet("Notas")
    wb.save(p)
    return p


def workdir(tiempos=True, drive=CE.DRIVE_RAIZ, set_texto=None, rfi=None):
    w = tempfile.mkdtemp(prefix="ce_test_")
    e = os.path.join(w, "FINAL_FOR_REVIEW")
    os.makedirs(os.path.join(e, "Take-off"))
    os.makedirs(os.path.join(e, "Planos marcados"))
    libro(os.path.join(e, "Take-off", "P_Takeoff_FINAL.xlsx"))
    for n in ("README_REVIEW.md", "PARA_REVISAR_EN_LA_MANANA.md"):
        open(os.path.join(e, n), "w").write("# PROJECT DATA\nHoras en PST.\n")
    open(os.path.join(e, "SEGUIMIENTO.md"), "w").write("| RFI-01 | A1.2 | ... |\n")
    if tiempos:
        open(os.path.join(w, "TIEMPOS.md"), "w").write(
            "START 2026-11-02 20:26 PST\n| 1 | arranque | 20:26 | 20:32 |\n| 2-3 | lecturas | 20:33 | 20:53 |\n"
            "| 4 | comparar | 20:54 | 20:54 |\n| 5 | resolver | 20:54 | 21:05 |\n| 6-9 | calc+excel+markups+gates | 20:55 | 21:31 |\n"
            "| **TOTAL** | | 20:26 | 21:31 |\n")
    json.dump({"drive": {"parent_id": drive, "carpeta_proyecto": "Proyecto X", "carpeta_proyecto_id": "FOLDER123"}},
              open(os.path.join(w, "entrega.json"), "w"))
    json.dump({"rfis": [rfi or HFT_RFI01]}, open(os.path.join(w, "takeoff.json"), "w"))
    if set_texto is not None:
        json.dump({"hojas": set_texto}, open(os.path.join(w, "set_texto.json"), "w"))
    return w


# RFI-01 de HFT Loveland rev2 (barrido real, takeoff_canon_FINAL_rev2.json): A1.2 SÍ estaba en la lista y aun así la
# respuesta impresa (B.O. DECK por zona) se quedó como RFI.
HFT_RFI01 = {"id": "RFI-01", "pregunta": "Demising wall D-01 (+-209'-1\", A1.1) runs under a sloped deck. Loaded 18.17 ft "
             "full length (conservative value loaded)", "barrido": {
                 "hojas": ["A0.0", "A1.1", "A1.2", "A2.0", "A4.1", "S2.1"], "terminos": ["DECK", "B.O.", "SLIP"],
                 "grep": "full set text: 'DECK' 93 hits ..."}}
SET_HFT = {"A1.1": "WALL LEGEND ALL WALLS BRACED TO STRUCTURE", "A1.2": "ZONE 1 B.O. DECK +-16'-9\" ZONE 2 B.O. DECK +-17'-5 1/2\"",
           "A2.0": "ROOF PLAN", "S2.1": "JOIST BEARING"}


def chk(fn, c):
    est, ev = fn(c)
    return est, " ".join(ev)


def test_hft_rfi01_impreso():
    w = workdir(set_texto=SET_HFT)
    est, ev = chk(CE.ce_rfi_barrido, CE.Ctx(w))
    assert est == "FAIL" and "A1.2" in ev and "IMPRESA" in ev, ev            # BE-120 reproducido
    # la vieja compuerta A_RFI_BARRIDO solo pedía la lista: con 6 hojas falla por cantidad, con 'ALL' pasaba
    r = dict(HFT_RFI01, barrido=dict(HFT_RFI01["barrido"], hojas="ALL"))
    w = workdir(set_texto=SET_HFT, rfi=r)
    assert chk(CE.ce_rfi_barrido, CE.Ctx(w))[0] == "FAIL"
    # hoja con el término fuera del barrido
    st = dict(SET_HFT, **{"S3.0": "DECK BEARING"})
    w = workdir(set_texto=st, rfi=dict(HFT_RFI01, barrido=dict(HFT_RFI01["barrido"], descartes={"A1.2": "x"})))
    est, ev = chk(CE.ce_rfi_barrido, CE.Ctx(w))
    assert est == "FAIL" and "S3.0" in ev and "NO está" in ev, ev
    # con descarte escrito por hoja y todas las hojas barridas -> PASS
    b = dict(HFT_RFI01["barrido"], hojas=list(st), descartes={"A1.2": "spot elevations at grid lines only, not per bay along the lease line"})
    w = workdir(set_texto=st, rfi=dict(HFT_RFI01, barrido=b))
    assert chk(CE.ce_rfi_barrido, CE.Ctx(w))[0] == "PASS"
    # sin texto del set no se puede probar -> FAIL
    assert chk(CE.ce_rfi_barrido, CE.Ctx(workdir()))[0] == "FAIL"


def markups_pdf(p, depth, label_h):
    doc = pymupdf.open()
    pg = doc.new_page(width=2592, height=1728)
    doc.set_page_labels([{"startpage": 0, "prefix": "A1.1", "style": "", "firstpagenum": 1}])
    pg.insert_text((100, 1650), "FLOOR PLAN   SCALE: 1/8\" = 1'-0\"", fontsize=12)
    a = pg.add_polyline_annot([(100, 200), (100 + 20.0 * 9, 200)])
    a.set_info(content=f"S21 · 20.00 LF · H {label_h} · 296.9 SF · 1/A3.2 · S21-N", subject="S21")
    a.update()
    doc.xref_set_key(a.xref, "Depth", str(depth))
    doc.save(p)


def test_altura_circular_oreilly():
    w = workdir()
    c = CE.Ctx(w)
    pdf = os.path.join(w, "FINAL_FOR_REVIEW", "Planos marcados", "m.pdf")
    markups_pdf(pdf, 14.84375, "14'-10.125\"")              # Depth = H del Excel (lo que validaba la revisión circular)
    c = CE.Ctx(w)
    c.canon = {"walls": [{"id": "S21-N", "height_ft": 14.84375, "height_source": "1/A3.2 'STUDS TO 13'-11 1/2\" A.F.F.'"}]}
    est, ev = chk(CE.ce_altura_impresa, c)
    assert est == "FAIL" and "printed source H 13.958" in ev, ev            # BE-119 reproducido
    c.canon = {"walls": [{"id": "S21-N", "height_ft": 14.84375, "height_source": "[PENDIENTE] assumed 8\" purlin (RFI-01)",
                          "height_status": "PENDIENTE"}]}
    assert chk(CE.ce_altura_impresa, c)[0] == "AMBER"
    c.canon = {"walls": [{"id": "S21-N", "height_ft": 14.84375, "height_source": "1/A3.2 'STUDS TO 14'-10 1/8\" A.F.F.'"}]}
    assert chk(CE.ce_altura_impresa, c)[0] == "PASS", chk(CE.ce_altura_impresa, c)


def test_drive_parent():
    assert chk(CE.ce_drive_parent, CE.Ctx(workdir(drive=CE.DRIVE_PROHIBIDO)))[0] == "FAIL"   # O'Reilly / VS en Projects
    assert chk(CE.ce_drive_parent, CE.Ctx(workdir(drive="otro")))[0] == "FAIL"
    assert chk(CE.ce_drive_parent, CE.Ctx(workdir()))[0] == "PASS"
    w = workdir()
    os.remove(os.path.join(w, "entrega.json"))
    assert chk(CE.ce_drive_parent, CE.Ctx(w))[0] == "FAIL"


def test_tiempos():
    assert chk(CE.ce_tiempos, CE.Ctx(workdir(tiempos=False)))[0] == "FAIL"                  # O'Reilly sin TIEMPOS.md
    w = workdir()
    t = open(os.path.join(w, "TIEMPOS.md")).read().replace("| 4 | comparar | 20:54 | 20:54 |\n", "")
    open(os.path.join(w, "TIEMPOS.md"), "w").write(t)
    est, ev = chk(CE.ce_tiempos, CE.Ctx(w))
    assert est == "FAIL" and "paso 4" in ev, ev
    assert chk(CE.ce_tiempos, CE.Ctx(workdir()))[0] == "PASS"
    w = workdir()
    open(os.path.join(w, "TIEMPOS.md"), "a").write("subida 2026-11-03T05:01Z UTC\n")
    assert chk(CE.ce_horas, CE.Ctx(w))[0] == "FAIL"


def test_excel():
    w = workdir()
    c = CE.Ctx(w)
    assert chk(CE.ce_formato_excel, c)[0] == "PASS", chk(CE.ce_formato_excel, c)
    assert chk(CE.ce_tornilleria, c)[0] == "PASS", chk(CE.ce_tornilleria, c)
    assert chk(CE.ce_track_familias, c)[0] == "PASS", chk(CE.ce_track_familias, c)
    assert chk(CE.ce_fuentes_ms, c)[0] == "PASS"
    assert chk(CE.ce_rfi_formato, c)[0] == "PASS", chk(CE.ce_rfi_formato, c)
    assert chk(CE.ce_seguimiento, c)[0] == "PASS"
    assert chk(CE.ce_atribucion, c)[0] == "PASS", chk(CE.ce_atribucion, c)
    x = os.path.join(w, "FINAL_FOR_REVIEW", "Take-off", "P_Takeoff_FINAL.xlsx")
    libro(x, extra_hoja=True)
    assert chk(CE.ce_formato_excel, CE.Ctx(w))[0] == "FAIL"
    libro(x, extra_col=True)
    assert chk(CE.ce_formato_excel, CE.Ctx(w))[0] == "FAIL"
    libro(x, ms=[["Bottom track 6\"", "LF", 20, 0, 0, 0, "", 0, "N/SHEET: 1/A3.2"],
                 ["Top slip / deflection track 6\"", "LF", 20, 0, 0, 0, "", 0, "N/SHEET: 10/A4.1"],
                 ["Framing screws #8 x 1/2\"", "PCS", 410, 0, 0, 0, "", 0, "N/SHEET: A4.1"]])
    assert chk(CE.ce_tornilleria, CE.Ctx(w))[0] == "FAIL"
    libro(x, ms=[["Top and bottom track + slip track 6\"", "LF", 40, 0, 0, 0, "", 0, "N/SHEET: 1/A3.2"]])
    assert chk(CE.ce_track_familias, CE.Ctx(w))[0] == "FAIL"
    libro(x, ms=[["Bottom track 6\"", "LF", 20, 0, 0, 0, "", 0, "N/SHEET: 1/A3.2"]])
    assert chk(CE.ce_track_familias, CE.Ctx(w))[0] == "FAIL"
    libro(x, ms=[["Bottom track 6\"", "LF", 20, 0, 0, 0, "", 0, "see note"]])
    assert chk(CE.ce_fuentes_ms, CE.Ctx(w))[0] == "FAIL"
    libro(x, pending=[["RFI-01", "q", "(A) Drawings: x - delta 1 | (B) Code: y - delta 0"]])
    assert chk(CE.ce_rfi_formato, CE.Ctx(w))[0] == "FAIL"
    libro(x, pending=[["RFI-02", "Insulation type at demising wall", RFI_OK], ["RFI-03", "Fastener spacing at track", RFI_OK],
                      ["RFI-04", "Kicker length at bulkhead (no screws / bolts printed)", RFI_OK]])
    est, ev = chk(CE.ce_rfi_prohibidos, CE.Ctx(w))
    assert est == "FAIL" and "RFI-02" in ev and "RFI-03" in ev and "RFI-04" not in ev, ev
    libro(x, scope=[["ALC-1", "Note", "x", "EXCLUDED - estimator decision: wood blocking"]])
    assert chk(CE.ce_atribucion, CE.Ctx(w))[0] == "FAIL"


def test_entregables_y_docs():
    w = workdir()
    e = os.path.join(w, "FINAL_FOR_REVIEW")
    assert chk(CE.ce_entregables, CE.Ctx(w))[0] == "FAIL"                     # sin PDF ni PNG de markups
    open(os.path.join(e, "Proposal_v1.docx"), "w").write("x")
    assert chk(CE.ce_sin_proposal, CE.Ctx(w))[0] == "FAIL"
    open(os.path.join(e, "PARA_REVISAR_EN_LA_MANANA.md"), "a").write("Costo de la corrida: $12.40\n")
    assert chk(CE.ce_sin_dolares, CE.Ctx(w))[0] == "FAIL"
    # U-123 (preferencias del día 1, COSTOS): el monto en el EXCEL también cuenta (antes solo se miraban los .md)
    w2 = workdir()
    assert chk(CE.ce_sin_dolares, CE.Ctx(w2))[0] == "PASS", chk(CE.ce_sin_dolares, CE.Ctx(w2))   # fórmulas Inputs!$B$11 no
    x = os.path.join(w2, "FINAL_FOR_REVIEW", "Take-off", "P_Takeoff_FINAL.xlsx")
    libro(x, scope=[["ALC-30", "Fasteners", "EXCLUDED", "All screws EXCLUDED (U-053); framing labor approx. $4,200"]])
    est, ev = chk(CE.ce_sin_dolares, CE.Ctx(w2))
    assert est == "FAIL" and "Scope Checklist" in ev, ev
    assert chk(CE.ce_datos_proyecto, CE.Ctx(w))[0] == "FAIL"                  # takeoff.json sin proyecto_datos


def fake_gdrive(lista_ids):
    d = tempfile.mkdtemp(prefix="fake_gd_")
    p = os.path.join(d, "gd.py")
    log = os.path.join(d, "log.txt")
    open(p, "w").write(
        "import sys, json\n"
        f"open({log!r}, 'a').write(' '.join(sys.argv[1:]) + '\\n')\n"
        "c = sys.argv[1]\n"
        f"if c == 'list':\n    [print(json.dumps({{'id': i, 'name': 'Proyecto X'}})) for i in {list(lista_ids)!r}]\n"
        "elif c == 'mkdir':\n    print('NEW_' + sys.argv[3])\n"
        "elif c == 'put':\n    print('OK uploaded ' + sys.argv[2])\n")
    return p, log


def entrega_ok(w, ok=True, parent=CE.DRIVE_RAIZ):
    c = CE.Ctx(w)
    arch = {os.path.relpath(p, w): CE._sha(p) for p in c.archivos_entrega()}
    json.dump({"ok": ok, "entrega_dir": "FINAL_FOR_REVIEW", "chequeos": [{"id": "CE_X", "estado": "PASS" if ok else "FAIL"}],
               "archivos": arch, "drive": {"parent_id": parent, "carpeta_proyecto": "Proyecto X", "carpeta_proyecto_id": "FOLDER123"}},
              open(os.path.join(w, "ENTREGA_OK.json"), "w"))


def test_subida():
    w = workdir()
    try:
        SE.candados(w)
        raise AssertionError("subió sin ENTREGA_OK.json")
    except SE.Bloqueo as e:
        assert "ENTREGA_OK" in str(e)
    entrega_ok(w, ok=False)
    try:
        SE.candados(w)
        raise AssertionError("subió con compuerta roja")
    except SE.Bloqueo as e:
        assert "verde" in str(e)
    entrega_ok(w)
    open(os.path.join(w, "FINAL_FOR_REVIEW", "README_REVIEW.md"), "a").write("cambio tardío\n")
    try:
        SE.candados(w)
        raise AssertionError("subió un archivo cambiado después de la compuerta")
    except SE.Bloqueo as e:
        assert "cambió" in str(e)
    entrega_ok(w, parent=CE.DRIVE_PROHIBIDO)
    try:
        SE.candados(w)
        raise AssertionError("subió a Projects › Claude outputs")
    except SE.Bloqueo as e:
        assert "parent_id" in str(e)
    entrega_ok(w)
    gd, log = fake_gdrive(["OTRA"])
    env = dict(os.environ, GDRIVE_FETCH=gd)
    r = subprocess.run([sys.executable, "-I", os.path.join(CE.AQUI, "subir_entrega.py"), w], capture_output=True, text=True, env=env)
    assert r.returncode == 1 and "NO es hija" in r.stdout, r.stdout + r.stderr
    gd, log = fake_gdrive(["FOLDER123"])
    env = dict(os.environ, GDRIVE_FETCH=gd)
    r = subprocess.run([sys.executable, "-I", os.path.join(CE.AQUI, "subir_entrega.py"), w], capture_output=True, text=True, env=env)
    assert r.returncode == 0, r.stdout + r.stderr
    L = open(log).read()
    assert f"list {CE.DRIVE_RAIZ}" in L and "mkdir FOLDER123 FINAL_FOR_REVIEW" in L and L.count("put ") == 4 and "mkdir NEW_FINAL_FOR_REVIEW Take-off" in L, L
    assert os.path.isfile(os.path.join(w, "SUBIDA_OK.json"))


def test_materiales_schedule():
    """BE-122 (j): sin lectura independiente del schedule = FAIL; board regular donde el schedule imprime Type X = FAIL."""
    w = workdir()
    c = CE.Ctx(w)
    assert chk(CE.ce_materiales_schedule, c)[0] == "FAIL"                     # sin fichas.json
    json.dump({"types": {"S21": {"stud_designation": "600S162-33", "gauge_ga": 20, "oc_in": 16,
                                 "faces": [{"side": "each side", "layers": 1, "board": "5/8\" Type X"}],
                                 "sources": {"stud": "1/A3.2", "board": "1/A3.2"}}}}, open(os.path.join(w, "fichas.json"), "w"))
    canon = os.path.join(w, "canon.json")
    caras = [{"side": "A", "board": "5/8 type X", "layers": 1, "height_ft": 14.8}, {"side": "B", "board": "5/8 regular", "layers": 1, "height_ft": 14.8}]
    json.dump({"walls": [{"id": "S21-N", "faces": caras}]}, open(canon, "w"))
    e = json.load(open(os.path.join(w, "entrega.json")))
    e["canon"] = "canon.json"
    json.dump(e, open(os.path.join(w, "entrega.json"), "w"))
    x = os.path.join(w, "FINAL_FOR_REVIEW", "Take-off", "P_Takeoff_FINAL.xlsx")
    wb = openpyxl.load_workbook(x)
    wb["Partition Takeoff"]["F6"] = '6" 20 ga (33 mil, 600S162-33)'
    wb.save(x)
    est, ev = chk(CE.ce_materiales_schedule, CE.Ctx(w))
    assert est == "FAIL" and "board type S21-N" in ev, ev
    caras[1]["board"] = "5/8 type X"
    json.dump({"walls": [{"id": "S21-N", "faces": caras}]}, open(canon, "w"))
    est, ev = chk(CE.ce_materiales_schedule, CE.Ctx(w))
    assert est != "FAIL" or "board type" not in ev, ev


def test_revision_materiales():
    """test de la herramienta (sesión O'Reilly, test_revision_materiales.py, unido aquí para quedar < 200 archivos)."""
    import revision_materiales as RV
    ficha = {"stud_designation": "362S162-33", "gauge_ga": 20, "oc_in": 16, "height": "STUDS TO 8'-6\" A.F.F.",
             "faces": [{"side": "each side", "layers": 1, "board": "5/8\" Type X W.R."}],
             "sources": {"stud": "W1/A1.1", "board": "W1/A1.1", "height": "W1/A1.1"}}
    fila = [{"type": "W1", "wall": "W-1", "lf": 10.0, "h": 8.5, "layers": 1, "stud": '3-5/8" 20 ga (33 mil, 362S162-33)',
             "oc": 16, "board_sf": 170, "location": "", "source": "W1/A1.1"}]
    bien = {"W-1": {"faces": [{"side": "A", "board": "5/8 type X WR", "layers": 1, "height_ft": 8.5},
                              {"side": "B", "board": "5/8 type X WR", "layers": 1, "height_ft": 8.5}]}}
    mal = {"W-1": {"faces": [{"side": "A", "board": "5/8 type X WR", "layers": 1, "height_ft": 8.5},
                             {"side": "B", "board": "5/8 regular", "layers": 1, "height_ft": 8.5}]}}
    assert RV.comparar_type("W1", ficha, fila, bien)["verdict"] == "GREEN"
    r = RV.comparar_type("W1", ficha, fila, mal)
    assert r["verdict"] == "RED" and any(c["field"].startswith("board type") and c["status"] == "RED" for c in r["checks"]), r
    fila2 = [dict(fila[0], stud='3-5/8" 25 ga (18 mil, 362S162-18)', h=9.0)]
    r = RV.comparar_type("W1", ficha, fila2, bien)
    assert {c["field"] for c in r["checks"] if c["status"] == "RED"} >= {"stud designation", "gauge", "height"}, r
    assert RV.tipo_board('5/8" TYPE "X" GYPSUM BOARD') == "X" and RV.tipo_board("5/8 type X WR") == "X-WR"
    ms = [{"row": 4, "name": "Bottom track 3-5/8\"", "unit": "LF", "net": 30.0,
           "where": "N/SHEET: W1/A1.1 | Breakdown [DERIVED]: W-1 10 + W-2 20 = 30 LF"},
          {"row": 5, "name": "Top track 3-5/8\"", "unit": "LF", "net": 31.0,
           "where": "N/SHEET: W1/A1.1 | Breakdown [DERIVED]: W-1 10 + W-2 20 = 30 LF"},
          {"row": 6, "name": "Additional head track", "unit": "LF", "net": 7.33, "where": "N/SHEET: default (no sheet) | Door 3"}]
    fil = [{"type": "W1", "wall": "W-1"}, {"type": "W1", "wall": "W-2"}]
    sm = {x["row"]: x for x in RV.sumas(ms, fil, "/nonexistent")}
    assert sm[4]["status"] == "GREEN" and sm[4]["by_type"] == {"W1": 30.0}, sm[4]
    assert sm[5]["status"] == "RED" and sm[6]["status"] == "RED", (sm[5], sm[6])


def test_materiales_cfa_rev5():
    """v81cf25 (CFA #2284 rev5): revision_materiales.sumas daba RED en (a) el driver de compound / tape cuando el board no es
    '5/8" Type X' (1/2" regular + MR + 5/8" ceiling) y (b) el desglose 'ítem: op = a LF + ítem: op = b LF = total LF'."""
    import revision_materiales as RV
    ms = [{"row": 4, "name": '1/2" gypsum board regular', "unit": "SF", "net": 100.0, "where": "N/SHEET: A-1"},
          {"row": 5, "name": '5/8" gypsum ceiling board, SAG-RESISTANT', "unit": "SF", "net": 50.0, "where": "N/SHEET: A-1"},
          {"row": 6, "name": 'Joint compound, all purpose', "unit": "LB", "net": 10.8,
           "where": "[DERIVED] N/SHEET: driver | Inputs!B23 (Joint compound (lb per SF) = 0.072) x 150 SF of board"},
          {"row": 7, "name": '3-5/8" stud, framed soffit', "unit": "LF", "net": 84.32,
           "where": "N/SHEET: C4/A-624 | Breakdown [DERIVED]: Serving soffit: ROUNDUP(18.122/(16/12))+1 = 15 joists x 3.755 = "
                    "56.32 LF 3-5/8\" joists + Dining soffit: ROUNDUP(8/(16/12))+1 = 7 joists x 4.0 = 28.0 LF 3-5/8\" joists = 84.32 LF (joists)"}]
    sm = {x["row"]: x for x in RV.sumas(ms, [], "/nonexistent")}
    assert sm[6]["status"] == "GREEN" and sm[7]["status"] == "GREEN", (sm[6], sm[7])
    ms[3]["net"] = 90.0
    assert {x["row"]: x for x in RV.sumas(ms, [], "/nonexistent")}[7]["status"] == "RED"


def test_texto_hoja_rotada():
    """v81cf24 (CFA #2284 rev5): en las hojas con /Rotate 270 (M / P / E del set) el número de hoja del title block salía
    p76.. porque las coordenadas de las palabras vienen sin rotar; el barrido BE-120 no podía casar 'M-201' con su hoja."""
    d = tempfile.mkdtemp(prefix="ce_rot_")
    pdf = os.path.join(d, "rot.pdf")
    doc = pymupdf.open()
    for rot, lab in ((0, "A-101"), (270, "M-201"), (90, "F-201")):
        pg = doc.new_page(width=1000, height=700)
        pg.set_rotation(rot)
        r = pg.rect                                          # rect visto (rotado)
        pt = pymupdf.Point(r.width * 0.9, r.height * 0.95) * pg.derotation_matrix
        pg.insert_text(pt, lab, fontsize=30, rotate=(360 - rot) % 360)
        pg.insert_text(pymupdf.Point(50, 50) * pg.derotation_matrix, "PLAN NOTES S06C", fontsize=8, rotate=(360 - rot) % 360)
    doc.new_page(width=1000, height=700)                     # title block vectorizado: hoja marcada (BE-CF05)
    doc.save(pdf)
    h = CE.texto_set([pdf], os.path.join(d, "set_texto.json"))
    assert list(h) == ["A-101", "M-201", "F-201", "p4-vector"], list(h)


def test_correr_rojo():
    w = workdir(tiempos=False)
    out = CE.correr(w)
    assert not out["ok"] and any(r["id"] == "CE_TIEMPOS" and r["estado"] == "FAIL" for r in out["chequeos"])
    assert any("U-094" in r["reglas"] for r in out["chequeos"] if r["id"] == "CE_TIEMPOS")
    out = CE.correr(w, solo={"CE_DRIVE_PARENT"})
    assert not out["ok"], "una corrida parcial nunca es verde"


# R80e.151–R80e.150 (O'Reilly rev5, 3-nov): tests de los arreglos de tool, como bloques (límite de 200 archivos del skill)
BLOQUES_OREILLY = []
BLOQUES_OREILLY.append(('test_texto_set_ocr', '#!/usr/bin/env python3\n"""test_texto_set_ocr.py — R80e.151 (O\'Reilly rev5, 3-nov): el set de O\'Reilly es RASTER (A1.1-A6.1 / S1.1 sin capa de\ntexto) y `compuerta_entrega.py texto` sacaba 1 carácter por hoja: el barrido BE-120 de los RFI quedaba ciego y pasaba.\nArma un PDF de 1 hoja que es SOLO imagen con \'PROVIDE ADDITIONAL HEAD TRACK\' impreso: con tesseract la frase sale en\nset_texto.json (ocr = [hoja]); sin OCR la hoja queda en sin_texto y CE_RFI_BARRIDO_IMPRESO falla con un RFI abierto."""\nimport json\nimport os\nimport shutil\nimport sys\nimport tempfile\n\nimport pymupdf\n\nAQUI = os.path.dirname(os.path.abspath(__file__))\nsys.path.insert(0, AQUI)\nimport compuerta_entrega as CE  # noqa: E402\n\nd = tempfile.mkdtemp()\nsrc = pymupdf.open()\npg = src.new_page(width=1224, height=792)\npg.insert_text((80, 300), "PROVIDE ADDITIONAL HEAD TRACK AT OPENINGS", fontsize=28)\npg.insert_text((1080, 760), "S1.1", fontsize=22)\npix = pg.get_pixmap(dpi=150)\ndoc = pymupdf.open()\np2 = doc.new_page(width=1224, height=792)\np2.insert_image(p2.rect, pixmap=pix)                    # hoja raster: sin capa de texto\ndoc.new_page(width=612, height=792)                     # página en blanco (separador del set)\npdf = os.path.join(d, "raster.pdf")\ndoc.save(pdf)\nassert len(pymupdf.open(pdf)[0].get_text("text").strip()) < CE.MIN_TEXTO\nsal = os.path.join(d, "set_texto.json")\nif CE._tessdata() and shutil.which("tesseract"):\n    CE.texto_set([pdf], sal)\n    st = json.load(open(sal))\n    txt = " ".join(st["hojas"].values()).upper()\n    assert "HEAD TRACK" in txt, txt[:300]\n    assert st["ocr"] and not st["sin_texto"] and len(st["en_blanco"]) == 1, st\nelse:\n    print("(sin tesseract: solo se prueba la rama sin_texto)")\n# rama sin OCR: barrido ciego -> FAIL con RFI abierto\njson.dump({"fuentes": [], "hojas": {"S1.1": " "}, "ocr": [], "sin_texto": ["S1.1"]}, open(sal, "w"))\n\n\nclass C:\n    set_p = sal\n\n    def rfis_abiertos(self):\n        return [("RFI-01", "head track?")]\n\n    def rfi(self, rid):\n        return {"id": rid, "barrido": {"terminos": ["HEAD TRACK"], "hojas": "ALL"}}\n\n\nr = CE.ce_rfi_barrido(C())\nassert r[0] == "FAIL" and "sin texto" in r[1][0], r\nprint("OK test_texto_set_ocr")\n'))
BLOQUES_OREILLY.append(('test_altura_el_sin_punto', '#!/usr/bin/env python3\n"""test_altura_el_sin_punto.py — R80e.142 (O\'Reilly rev4 → rev5, 3-nov): la fuente de EXT-HEAD-8 dice\n\'3/A3.1 B.O. SHEATHING EL 111\'-4" to T.O. METAL STUD EL 120\'-8" (4\'-3 1/4" + 5\'-0 3/4" printed) = 9.333 ft\'.\naltura_impresa solo reconocía \'EL.\' con punto, tomaba la primera cota (4\'-3 1/4" = 4.271) y la compuerta daba RED\ncontra el Depth 9.333 que SÍ es el impreso (120\'-8" - 111\'-4"). Falla con v81cf23."""\nimport os\nimport sys\n\nsys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))\nimport revision_markups as RM  # noqa: E402\n\nsrc = ("3/A3.1 B.O. SHEATHING EL 111\'-4\\" to T.O. METAL STUD EL 120\'-8\\" (4\'-3 1/4\\" + 5\'-0 3/4\\" printed) = 9.333 ft")\nh, regla, hojas = RM.altura_impresa(src)\nassert regla == "printed elevations" and abs(h - 9.3333) < 0.001, (h, regla)\nh2, regla2, _ = RM.altura_impresa("B.O. SHEATHING EL. 111\'-4\\" to T.O. METAL STUD EL. 120\'-8\\"")\nassert abs(h2 - 9.3333) < 0.001 and regla2 == "printed elevations"\n# una palabra que contiene \'EL\' (PANEL, LEVEL) no es una elevación\nh3, regla3, _ = RM.altura_impresa("PANEL 8\'-0\\" high, LEVEL 2")\nassert regla3 == "printed dimension" and abs(h3 - 8.0) < 0.001, (h3, regla3)\nprint("OK test_altura_el_sin_punto")\n'))
BLOQUES_OREILLY.append(('test_revision_markups_be117', '#!/usr/bin/env python3\n"""test_revision_markups_be117.py — R80e.143 (O\'Reilly rev5, 3-nov): con markups v81cf23 (SF = board SF del Excel, BE-117)\nrevision_markups exigía SF = LF x H y daba RED en todo wall con 2 caras; y daba RED a un LF medido con causa escrita\nen el canon (length_cause) que verificar_markups_excel sí acepta. Las dos compuertas se contradecían.\nW-1: SF = board 2 caras -> GREEN · W-2: línea 2 % larga con length_cause -> AMBER · W-3: igual sin causa -> RED.\nFalla con v81cf23."""\nimport os\nimport sys\nimport tempfile\n\nimport openpyxl\nimport pymupdf\n\nsys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))\nimport revision_markups as RM  # noqa: E402\n\nd = tempfile.mkdtemp()\npdf, xlsx = os.path.join(d, "m.pdf"), os.path.join(d, "t.xlsx")\ndoc = pymupdf.open()\np = doc.new_page(width=2592, height=1728)\ndoc.set_page_labels([{"startpage": 0, "prefix": "A1.1", "style": "", "firstpagenum": 1}])\nfor wid, y, drawn, board in (("W-1", 200, 20.0, 400.0), ("W-2", 300, 20.4, 400.0), ("W-3", 400, 20.4, 400.0)):\n    a = p.add_polyline_annot([(100, y), (100 + drawn * 9, y)])\n    a.set_info(content=f"A1 · 20.00 LF · H 10\'-0\\" · {board:,.2f} SF board · S1/A1.1 · {wid}", subject="A1")\n    a.update()\n    doc.xref_set_key(a.xref, "Depth", "10.0")\ndoc.save(pdf)\nwb = openpyxl.Workbook()\nws = wb.active\nws.title = "Partition Takeoff"\nfor _ in range(4):\n    ws.append([None])\nws.append(["TYPE A1"])\nfor wid in ("W-1", "W-2", "W-3"):\n    ws.append([f"A1 #{wid}", wid, 20.0, 10.0, 1, "3-5/8\\"", 16, 400.0, "x", "S1/A1.1", "[CONFIRMED]"])\nwb.save(xlsx)\ncanon = {"walls": [{"id": w, "length_ft": 20.0, "height_ft": 10.0, "height_source": "S1/A1.1 \'STUDS TO 10\'-0\\" A.F.F.\'"}\n                   for w in ("W-1", "W-2", "W-3")]}\ncanon["walls"][1]["length_cause"] = "line follows the drawn ink to the pier faces; printed 20\'-0\\" governs"\n_d, _m, res = RM.revisar(pdf, xlsx, {"A1.1": 9.0}, canon)\nv = {r["wall"]: r for r in res}\nassert v["W-1"]["verdict"] == "GREEN", v["W-1"]\nassert v["W-2"]["verdict"] == "AMBER" and "cause written" in " ".join(v["W-2"]["amber"]), v["W-2"]\nassert v["W-3"]["verdict"] == "RED" and any("LF measured" in f for f in v["W-3"]["fallas"]), v["W-3"]\nprint("OK test_revision_markups_be117")\n'))
BLOQUES_OREILLY.append(('test_head_track_furring', '#!/usr/bin/env python3\n"""test_head_track_furring.py — R80e.144 (O\'Reilly rev5, 3-nov): additional head track contaba las aberturas > 4\'-0" de\nwalls S21 (1-1/2" Z-furring 150ZF125-18 sobre CMU, sin studs: Door 3 6\'-0", Windows D1 / D2 11\'-4 3/8") = 32.73 LF con\n"N/SHEET: default (no sheet)". Un wall de furring no tiene head de studs (lleva el lintel de mampostería, S4.1); el plano\nno imprime head track (7/A5.1 solo box header). Falla con v81cf24."""\nimport os\nimport sys\n\nsys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))\nimport accesorios as A  # noqa: E402\n\ndata = {"constants": {"addl_head_track_none_source": {"value": True, "source": "7/A5.1; S4.1 lintel schedule"}},\n        "walls": [{"id": "S21-N", "stud_size": "1-1/2 in Z-furring (150ZF125-18)", "element": "wall",\n                   "openings": [{"ref": "Door 3", "kind": "door", "ro_w_ft": 6.0}]},\n                  {"id": "S43-OF-S", "stud_size": "3-5/8 in", "element": "wall",\n                   "openings": [{"ref": "Door 4", "kind": "door", "ro_w_ft": 3.333}]}]}\no = A.Out() if hasattr(A, "Out") else None\no = A.Out()\nA.additional_head_track(data, o)\nassert abs(o.fam[A.F_AHT]) < 1e-9, o.filas\nfila = o.filas[-1]\nassert "default (no sheet)" not in fila["source"] and "7/A5.1" in fila["source"], fila\nassert "Door 3 (S21-N)" in fila["operacion"], fila\n# un wall de studs con abertura > 4\'-0" sí la lleva\ndata["walls"][1]["openings"][0]["ro_w_ft"] = 6.0\no = A.Out()\nA.additional_head_track(data, o)\nassert o.fam[A.F_AHT] > 6.0, o.filas\nprint("OK test_head_track_furring")\n'))
BLOQUES_OREILLY.append(('test_chequeos_ocr_oreilly', '#!/usr/bin/env python3\n"""test_chequeos_ocr_oreilly.py — R80e.145 (O\'Reilly rev5, 3-nov): falsos positivos de la biblioteca v81cf24 sobre un set\nRASTER leído por OCR. Cada caso: el falso positivo de O\'Reilly ya no falla y el error de verdad SIGUE fallando.\nU-057 \'no longer deducted\' · BE-12 cita con \'...\' · BE-15 tag en hexágono que el OCR no lee (AMBER) · BE-21 \'5/8" EXTERIOR\nFIBERGLASS REINFORCED SHEATHING\' = glass mat · BE-102 \'S21/S24\' (types) no es N/HOJA · BE-CF05 páginas en blanco."""\nimport os\nimport sys\n\nsys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))\nimport chequeos_biblioteca as CB  # noqa: E402\n\nB = CB.B\n# U-057\nf_ok = {"side": "A", "deduct_info": "door R.O. 23.89 SF no longer deducted",\n        "board_note": "windows NOT deducted (estimator rule: board per face never deducts openings)"}\nf_mal = {"side": "A", "board_note": "board net of door openings"}\nassert CB.u_057(B(canon={"walls": [{"id": "W1", "faces": [f_ok]}]}))[0] == "PASS"\nassert CB.u_057(B(canon={"walls": [{"id": "W1", "faces": [f_mal]}]}))[0] == "FAIL"\n# BE-12\nhojas = {"S5.3": "16. SIMPSON FCB43.5 FRAMING CLIP AT EACH STUD TO PEMB WIND BEAM (TYP)"}\ncel_ok = [("Material Summary", "I38", "3/S5.3 key note 16 \'SIMPSON FCB43.5 FRAMING CLIP ... TO PEMB WIND BEAM\' drawn")]\ncel_mal = [("Material Summary", "I38", "note \'SIMPSON FCB43.5 FRAMING CLIP AT EVERY STUD TO DECK\' drawn")]\nassert CB.be_12(B(hojas=hojas, celdas=cel_ok))[0] == "PASS"\nassert CB.be_12(B(hojas=hojas, celdas=cel_mal))[0] == "FAIL"\n# BE-15\nms = [{"fila": 10, "material": "Bottom track", "net": 10, "fuente": "N/SHEET: S43/A1.1"}]\nassert CB.be_15(B(canon={}, ms=ms, hojas={"A1.1": "FLOOR PLAN"}, set_meta={"ocr": ["A1.1"]}))[0] == "AMBER"\nassert CB.be_15(B(canon={}, ms=ms, hojas={"A1.1": "FLOOR PLAN"}, set_meta={"ocr": []}))[0] == "FAIL"\n# BE-21\nms_g = [{"fila": 30, "material": \'5/8" glass mat sheathing\', "net": 534.88, "fuente": "N/SHEET: 1/A3.1"}]\nr_ok = CB.be_21(B(ms=ms_g, hojas={"A3.1": \'19. 5/8" EXTERIOR FIBERGLASS REINFORCED SHEATHING\'}, celdas=[]))\nr_mal = CB.be_21(B(ms=ms_g, hojas={"A3.1": \'19. 5/8" EXTERIOR GYPSUM SHEATHING\'}, celdas=[]))\nassert r_ok[0] != "FAIL" and r_mal[0] == "FAIL", (r_ok, r_mal)\n# BE-102\ncanon = {"walls": [{"id": "S21-N", "tag": "S21"}, {"id": "S24-OF", "tag": "S24"}], "type_order": ["S21", "S24"]}\nhj = {"A1.1": "x", "A5.1": "y"}\nassert CB.be_102(B(canon=canon, hojas=hj, celdas=[("Scope Checklist", "D3", "types S21/S24 per 7/A5.1")]))[0] == "PASS"\nassert CB.be_102(B(canon=canon, hojas=hj, celdas=[("Scope Checklist", "D3", "see 7/A9.9")]))[0] == "FAIL"\n# BE-CF05\nhb = {"p1": " ", "p2": " ", "p3": " ", "A1.1": "x", "A1.2": "y", "S1.1": "z", "T1.1": "w", "G1.1": "v", "A2.1": "u"}\nassert CB.be_cf05(B(hojas=hb, set_meta={"en_blanco": ["p1", "p2", "p3"]}))[0] == "PASS"\nassert CB.be_cf05(B(hojas=hb, set_meta={}))[0] == "FAIL"\nprint("OK test_chequeos_ocr_oreilly (1)")\n# BE-63: largo resuelto en la resolución dirigida (tabla de resolucion.md) = decisión citada\nA_ = {"walls": [{"id": "S43-OF-W", "length_ft": 7.43}]}\nB_ = {"walls": [{"id": "S43-OF-W", "length_ft": 7.88}]}\nAB = {"walls": [{"id": "S43-OF-W", "length_ft": 8.0, "length_source": "A1.1 printed 8 ft"}]}\nres = {"resolucion.md": "| 11 | S43-OF-W length | 7.43 | 7.88 | **8.0** CONFIRMADO | A1.1 printed 8 ft |"}\nassert CB.be_63(B(canon_a=A_, canon_b=B_, canon_ab=AB, textos=res))[0] == "PASS"\nassert CB.be_63(B(canon_a=A_, canon_b=B_, canon_ab=AB, textos={}))[0] == "FAIL"\nprint("OK test_chequeos_ocr_oreilly BE-63")\n# BE-50: cableado eléctrico no es traslape de framing; un blocking por otro contratista sí\nm_ok = {"M2": "EXHAUST FAN SHALL BE WIRED BY THE ELECTRICAL CONTRACTOR TO OPERATE WITH THE LIGHT SWITCH"}\nm_mal = {"M2": "BLOCKING FOR UNIT HEATER BY MECHANICAL CONTRACTOR"}\nassert CB.be_50(B(hojas=m_ok, celdas=[]))[0] != "FAIL"\nassert CB.be_50(B(hojas=m_mal, celdas=[]))[0] == "FAIL"\n# BE-63: la resolución nombra el type cuando el wall es el único de ese type\nAB2 = {"walls": [{"id": "S61-RR", "tag": "S61", "length_ft": 8.5, "length_source": "A1.1 8 ft 6 in"}]}\nr2 = {"resolucion.md": "| 14 | S61 length | 8.1 | 8.4 | **8.5** DERIVADO | A1.1 |"}\nassert CB.be_63(B(canon_a={"walls": [{"id": "S61-RR", "length_ft": 8.1}]}, canon_b={"walls": [{"id": "S61-RR", "length_ft": 8.4}]},\n                  canon_ab=AB2, textos=r2))[0] == "PASS"\nprint("OK test_chequeos_ocr_oreilly BE-50 / BE-63 type")\n'))
BLOQUES_OREILLY.append(('test_reconcile_ext', '#!/usr/bin/env python3\n"""test_reconcile_ext.py — R80e.146 (O\'Reilly rev5, 3-nov): las lecturas A / B traían el MISMO framing exterior sin tag\ncon nombres distintos (A: tag \'EXT-CFS\', element \'storefront_cripples\'; B: tag \'EXT\', element \'wall\'): completitud daba\n\'falta vs la otra\' en las dos (U-034) y reconcile emparejaba 25 de 32 (BE-62). Falla con v81cf24."""\nimport os\nimport sys\n\nsys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "runner"))\nimport completitud as C  # noqa: E402\nimport reconcile as R  # noqa: E402\n\nband = {"ori": "H", "c0": 100.0, "c1": 104.0, "lo": 200.0, "hi": 548.0, "sheet": "A1.1"}\na = {"constants": {"plan_scale_pt_per_ft": {"value": 9.0, "source": "x"}},\n     "walls": [{"id": "SF-A-8", "tag": "EXT-CFS", "element": "storefront_cripples", "sheet": "A1.1", "length_ft": 38.67, "band": band},\n               {"id": "S21-N", "tag": "S21", "element": "wall", "sheet": "A1.1", "length_ft": 10, "band": dict(band, c0=300, c1=302)}]}\nb = {"constants": {"plan_scale_pt_per_ft": {"value": 9.0, "source": "x"}},\n     "walls": [{"id": "HEAD-A-8", "tag": "EXT", "element": "wall", "sheet": "A1.1", "length_ft": 38.667, "band": band},\n               {"id": "S21-N", "tag": "S21", "element": "wall", "sheet": "A1.1", "length_ft": 10, "band": dict(band, c0=300, c1=302)}]}\nassert C.revisar(a, ["A1.1"], b)["faltan_vs_otra"] == [] and C.revisar(b, ["A1.1"], a)["faltan_vs_otra"] == []\nm = R.emparejar(b, a)\nassert m.get("HEAD-A-8") == "SF-A-8" and m.get("S21-N") == "S21-N", m\n# un type de partition distinto sigue sin emparejar\nb["walls"][1]["tag"] = "S24"\nassert "S21-N" not in R.emparejar(b, a)\nprint("OK test_reconcile_ext")\n'))
BLOQUES_OREILLY.append(('test_runner_comparar_extra', '#!/usr/bin/env python3\n"""test_runner_comparar_extra.py — R80e.147 (O\'Reilly rev5, 3-nov): el runner corría comparar.py pero nunca\ncomparar_extra.py; la compuerta U-081 / BE-CF06 fallaba (\'las lecturas traen misc_items y no hay revision_extra.md\').\nR80e.148: v81cf24 importaba chequeos_biblioteca (tools/) sin tools/ en el path: el runner no arrancaba\n(ModuleNotFoundError); este test importa el runner SOLO con runner/ en el path. Comprueba también que Runner.comparar lo llama por bitácora en la misma carpeta, después de comparar.py. Falla con v81cf24."""\nimport inspect\nimport os\nimport sys\n\nsys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "runner"))\nimport run_takeoff as RT  # noqa: E402\n\nsrc = inspect.getsource(RT.Runner.comparar)\ni, j = src.find(\'self.tool("comparar.py"\'), src.find(\'self.tool("comparar_extra.py", A, B, inv, out\')\nassert i >= 0 and j > i, src[:400]\nassert os.path.exists(os.path.join(os.path.dirname(os.path.abspath(__file__)), "comparar_extra.py"))\nprint("OK test_runner_comparar_extra")\n'))
BLOQUES_OREILLY.append(('test_auditoria_raster', '#!/usr/bin/env python3\n"""test_auditoria_raster.py — R80e.150 (O\'Reilly rev5, 3-nov): A1.1 es un escaneo sin capa de texto; auditoria_entrega\nexigía /Measure = rótulo SCALE leído del texto de la página -> \'printed on the sheet: none\' en los 32 markups. Vale la\ncalibración del canon que cita el rótulo impreso (1/8" = 9.00 pt/ft) y la medición contra cotas impresas (9.04 pt/ft),\nsi difiere <= 1 % del rótulo; una calibración lejos del rótulo o sin fuente sigue fallando. Falla con v81cf24."""\nimport os\nimport sys\nfrom fractions import Fraction\n\nsys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))\nimport auditoria_entrega as A  # noqa: E402\n\nsrc = "A1.1 1/8\\" = 1\'-0\\" printed (9.0 pt/ft nominal); measured on the raster: grid 1-4 85\'-0\\" = 766.9 pt"\ncan = {"constants": {"plan_scale_pt_per_ft": {"value": 9.04, "source": src}}}\nassert A.calibracion_raster(can, "A1.1", Fraction(113, 900))[0]                     # /Measure = calibración\nassert not A.calibracion_raster(dict(can, constants={"plan_scale_pt_per_ft": {"value": 9.5, "source": src}}),\n                                "A1.1", Fraction(95, 720))[0]                          # 5.5 % del rótulo impreso\nassert not A.calibracion_raster({"constants": {"plan_scale_pt_per_ft": {"value": 9.04, "source": "estimated"}}},\n                                "A1.1", Fraction(113, 900))[0]                         # sin rótulo + medición\nprint("OK test_auditoria_raster")\n'))


def test_oreilly_rev5():
    aq = os.path.dirname(os.path.abspath(__file__))
    for n, src in BLOQUES_OREILLY:
        g = {"__name__": "__main__", "__file__": os.path.join(aq, n + ".py")}
        exec(compile(src, n + ".py", "exec"), g)


if __name__ == "__main__":
    for f in (test_hft_rfi01_impreso, test_altura_circular_oreilly, test_drive_parent, test_tiempos, test_excel,
              test_entregables_y_docs, test_subida, test_materiales_schedule, test_revision_materiales, test_texto_hoja_rotada, test_materiales_cfa_rev5, test_correr_rojo, test_oreilly_rev5):
        f()
        print("ok", f.__name__)
    print("test_compuerta_entrega OK")
