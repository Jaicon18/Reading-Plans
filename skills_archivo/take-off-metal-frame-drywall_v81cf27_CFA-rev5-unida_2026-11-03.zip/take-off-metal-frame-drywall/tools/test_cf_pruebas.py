#!/usr/bin/env python3
"""test_cf_pruebas.py — pruebas de CFA #2284 unidas (BE-CF14 driver de finishing, BE-CF16 barrido de RFI, BE-CF19 hoja de la demo). Cada bloque corre aislado."""
import os, sys, runpy, tempfile
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
BLOQUES = {}
BLOQUES['test_board_driver'] = r'''
#!/usr/bin/env python3
"""test_board_driver.py — BE-CF14: toda familia de gypsum board de canon entra al driver de finishing (compound / tape),
salvo cement board, ballistic panel y sheathing exterior."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import canon, accesorios
fuera = ("cement", "ballistic", "EXTERIOR", "glass mat", "FRT", "1/4")
gyp = [f for f in canon.BOARD_FAM.values() if "gyp" in f.lower() and not any(x in f for x in fuera)]
falta = [f for f in gyp if f not in accesorios.BOARD_DRIVER]
assert not falta, f"familias de gypsum board fuera del driver de finishing: {falta}"
print("test_board_driver OK")
'''
BLOQUES['test_rfi_barrido'] = r'''
#!/usr/bin/env python3
"""test_rfi_barrido.py — R80f.6 / BE-CF16: RFI abierto sin barrido completo = falla."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reglas as R
malo = {"rfis": [{"id": "RFI-01", "pregunta": "height?", "delta": "x"}]}
assert R.rfi_barrido_fallas(malo)
bueno = {"rfis": [{"id": "RFI-01", "pregunta": "height?", "delta": "x",
                   "barrido": {"hojas": "ALL", "terminos": ["B.O.", "DECK", "JOIST"], "grep": "set_text.txt: 0 hits"}}]}
assert not R.rfi_barrido_fallas(bueno), R.rfi_barrido_fallas(bueno)
cerrado = {"rfis": [{"id": "RFI-02", "estado": "CLOSED - estimator decision (option A)"}]}
assert not R.rfi_barrido_fallas(cerrado)
print("test_rfi_barrido OK")
'''
BLOQUES['test_demo_hoja_geom'] = r'''
#!/usr/bin/env python3
"""test_demo_hoja_geom.py — BE-CF19: la hoja de un renglón de demolición sale de su demo_geom, no de la hoja que cita
la fuente de su altura (S-201 / A4/S-601 / "TJI/L65")."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import verificar_markups_excel as V
canon = {"misc_items": [{"ref": "DEMO-02", "familia": "demolition - gypsum board and metal framing", "qty": 100,
                         "source": "KN3 A-050; height:: B.O. 16 in TJI/L65 joists (S-201) = 12.17 ft"},
                        {"ref": "DEMO-04", "familia": "demolition - gypsum board and metal framing", "qty": 50,
                         "source": "KN3 A-050; height: PSL 12.25 ft (A4/S-601)"}],
         "demo_geom": [{"id": "DEMO-02", "sheet": "A-050", "page": 6}, {"id": "DEMO-04", "sheet": "A-050", "page": 6}]}
_, hojas, _ = V.indice_canon(canon)
assert set(hojas) == {"A-050"}, hojas
canon2 = {"misc_items": [{"ref": "DEMO-09", "familia": "demolition - gypsum board and metal framing", "qty": 10,
                          "source": "KN3 A-050; height: B.O. (A4/S-601)"}]}
_, h2, _ = V.indice_canon(canon2)
assert "S-601" not in h2, h2
print("test_demo_hoja_geom OK")
'''
for nombre, codigo in BLOQUES.items():
    ns = {"__name__": "__main__", "__file__": os.path.join(AQUI, nombre + ".py")}
    exec(compile(codigo, nombre, "exec"), ns)
print("test_cf_pruebas OK")
