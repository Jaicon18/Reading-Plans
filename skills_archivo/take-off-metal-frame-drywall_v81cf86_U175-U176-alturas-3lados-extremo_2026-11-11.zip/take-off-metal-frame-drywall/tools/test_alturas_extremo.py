"""U-176 REGLA DE ORO #2 (usuario 11-nov): los 6 controles de alturas_extremo.py. Obligatorios: un wall de 12'-6" en un cuarto de
C.H. 13'-0" = FAIL y un wall más alto que el deck = FAIL. Además: 'above ceiling' que no toma el MAYOR C.H., 'to deck' sin slip track,
board más alto que el wall, cierre dimensional que no cuadra, diferencia A / B sin resolver, muestreo sin una altura = FAIL;
los casos correctos = PASS; la compuerta CE_ALTURAS_EXTREMO existe y el CHECKLIST lleva la muestra."""
import os, sys
AQUI = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, AQUI)
import alturas_extremo as AE


def W(i, h, rooms, regla="above_ceiling", ext=0.5, board=None, top="standard", tipo="X1"):
    return {"id": i, "tipo": tipo, "h": h, "regla": regla, "ext": ext, "rooms": rooms, "board": board or [("A", h)], "top": top, "motivo": None}


def test_u176_alturas_extremo():
    # (3) reglas físicas — los dos obligatorios
    n, f = AE.reglas_fisicas([W("X1-01", 12.5, ["901"], regla="fixed")], {"901": 13.0}, 20.0)
    assert any("< C.H. 13.000" in x for x in f), f                                   # 12'-6" en cuarto de 13'-0"
    n, f = AE.reglas_fisicas([W("X1-02", 15.0, ["901"], regla="fixed")], {"901": 9.0}, 14.0)
    assert any("> B.O. estructura" in x for x in f), f                               # más alto que el deck
    n, f = AE.reglas_fisicas([W("X1-03", 10.5, ["901", "902"])], {"901": 10.0, "902": 12.0}, 20.0)
    assert any("MAYOR C.H." in x for x in f), f                                      # 6" sobre el cielo BAJO = mal
    n, f = AE.reglas_fisicas([W("X1-04", 14.0, ["901"], regla="to_deck", ext=0)], {"901": 9.0}, 14.0)
    assert any("slip" in x for x in f), f
    n, f = AE.reglas_fisicas([W("X1-05", 12.5, ["901"], board=[("A", 13.0)])], {"901": 12.0}, 20.0)
    assert any("board de la cara" in x for x in f), f
    n, f = AE.reglas_fisicas([W("X1-06", 12.5, ["901", "902"]), W("X1-07", 14.0, ["903"], regla="to_deck", ext=0, top="slip track")],
                             {"901": 12.0, "902": 10.0, "903": 9.0}, 14.0, [{"id": "Z-01", "h": 14.0}])
    assert n == 3 and f == [], f
    n, f = AE.reglas_fisicas([], {}, 14.0, [{"id": "Z-02", "h": 26.0}])
    assert f, "demolición más alta que la estructura"
    # (4) cruce por cuarto
    n, f, _ = AE.cruce_cuartos([W("X1-08", 12.5, ["901"]), W("X1-09", 10.5, ["901"])], {"901": 12.0})
    assert any("por debajo del cielo" in x for x in f) and any("alturas distintas" in x for x in f), f
    n, f, filas = AE.cruce_cuartos([W("X1-10", 12.5, ["901"]), W("X1-11", 12.5, ["901", "902"])], {"901": 12.0, "902": 10.0})
    assert n == 2 and f == [] and len(filas) == 3, f
    # (2) cierre dimensional
    assert AE.cierre("12'-0\" (A9.9 ceiling) + 0'-6\" (type legend) = 12.5", 12.5)[0]
    assert AE.cierre("North (room 901) (10'-0\" + 0'-6\") - 8'-6\" = 2.000; Underside (scaled) 7.32 pt / 18 pt/ft = 0.407; Total 2.000 + 0.407 = 2.407", 2.407)[0]
    assert AE.cierre("structure height not printed (rule U-174): 26 FT = 26.0", 26.0)[0]
    assert not AE.cierre("12'-0\" + 0'-6\" = 12.75", 12.75)[0]                         # suma que no cuadra
    assert not AE.cierre("12'-0\" + 0'-6\" = 12.5", 13.0)[0]                           # termina en otra altura
    assert not AE.cierre("", 12.5)[0]
    # (1) doble lectura
    a = [{"Wall ID": "X1-01", "Printed H": "12.5"}, {"Wall ID": "X1-02", "Printed H": "10.5"}]
    b = [{"Wall ID": "X1-01", "Printed H": "12'-6\""}, {"Wall ID": "X1-02", "Printed H": "12.5"}]
    filas, f = AE.comparar_ab(a, b)
    assert len(f) == 1 and "X1-02" in f[0], f
    filas, f = AE.comparar_ab(a, b, {"X1-02": {"Resolution": "A9.9 tag read on directed crop: 10'-0\" + 6\"", "Image": "x.png"}})
    assert f == [] and [r["Result"] for r in filas] == ["MATCH", "RESOLVED"]
    # (6) muestreo
    fin = [{"Wall ID": f"X1-{k:02d}", "Printed H": h} for k, h in enumerate(["12.5"] * 6 + ["9.5", "26"], 1)]
    m = AE.muestra(fin, {12.5: 1, 9.5: 2, 26.0: 3})
    assert len(m) >= 5 and {x["H (ft)"] for x in m} == {12.5, 9.5, 26.0} and AE.muestra_fallas(m, fin) == []
    assert AE.muestra_fallas(m[:2], fin)
    import compuerta_entrega as CE
    assert "CE_ALTURAS_EXTREMO" in {cid for cid, *_x in CE.CHEQUEOS}
    assert "Random sample (U-176)" in open(os.path.join(AQUI, "checklist_revision.py"), encoding="utf-8").read()
    print("test_u176_alturas_extremo OK")


if __name__ == "__main__":
    test_u176_alturas_extremo()
