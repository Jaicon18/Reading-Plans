"""U-175 (usuario 11-nov, Xfinity Interquest rev1): comparación de ALTURAS a tres lados (Depth de Bluebeam / Height del Excel /
ALTURAS_IMPRESAS.csv de una lectura independiente). Con las alturas impresas correctas = 0 fallas (20/20 OK); con W2-02 cambiada
a 9'-6" = FAIL; fila sin Source / Image o DERIVED sin Operation = FAIL; 0 markups comparados = FAIL. Y la compuerta CE_ALTURAS_3LADOS
y la línea del CHECKLIST B2 existen."""
import csv, io, os, sys, tempfile, contextlib
AQUI = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, AQUI)
import comparar_alturas as CA
D = os.path.join(AQUI, "datos_test", "comparar_alturas")
V, X = os.path.join(D, "xf_vista_bluebeam.csv"), os.path.join(D, "xf_takeoff_rev1.xlsx")


def corre(alt):
    t = tempfile.mkdtemp(prefix="u175_"); out = os.path.join(t, "c.csv"); buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = CA.main([V, X, alt, out])
    return rc, buf.getvalue(), out


def test_u175_comparar_alturas():
    rc, txt, out = corre(os.path.join(D, "xf_alturas_ok.csv"))
    assert rc == 0 and "20/20 markups OK" in txt, txt
    assert all(r["Result"] == "OK" for r in csv.DictReader(open(out, encoding="utf-8-sig")))
    rc, txt, _ = corre(os.path.join(D, "xf_alturas_mal.csv"))
    assert rc == 1 and "MISMATCH" in txt, txt
    t = tempfile.mkdtemp(prefix="u175b_")
    filas = list(csv.DictReader(open(os.path.join(D, "xf_alturas_ok.csv"), encoding="utf-8-sig")))
    filas[0]["Image"] = ""; filas[1]["Status"] = "DERIVED"; filas[1]["Operation"] = ""
    p = os.path.join(t, "malo.csv")
    with open(p, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(filas[0])); w.writeheader(); w.writerows(filas)
    rc, txt, _ = corre(p)
    assert rc == 1 and "without value / Source / Image" in txt and "DERIVED without Operation" in txt, txt
    vacio = os.path.join(t, "vista_vacia.csv"); open(vacio, "w").write(open(V, encoding="utf-8-sig").readline())
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = CA.main([vacio, X, os.path.join(D, "xf_alturas_ok.csv"), os.path.join(t, "v.csv")])
    assert rc == 1 and "0 markups" in buf.getvalue()
    import compuerta_entrega as CE
    assert "CE_ALTURAS_3LADOS" in {cid for cid, *_x in CE.CHEQUEOS}
    assert "Three-way height check (U-175)" in open(os.path.join(AQUI, "checklist_revision.py"), encoding="utf-8").read()
    print("test_u175_comparar_alturas OK")


if __name__ == "__main__":
    test_u175_comparar_alturas()
