#!/usr/bin/env python3
"""test_compuerta_entrega.py — BE-121: cada chequeo de compuerta_entrega.py / subir_entrega.py REPRODUCE el error original.
  - BE-120 (Harbor Freight rev2): RFI-01 abierto con la respuesta IMPRESA en A1.2 (B.O. DECK por zona) -> FAIL.
  - BE-119 (O'Reilly 3-nov): Depth del markup = H del Excel (comparación circular) pero la altura IMPRESA es otra -> FAIL.
  - Drive: carpeta bajo Projects › Claude outputs (O'Reilly / VS) -> FAIL; sin ENTREGA_OK verde -> subida bloqueada.
  - O'Reilly sin TIEMPOS.md -> FAIL. + formato Excel, tornillería, tracks, RFI A/B/C, RFI prohibidos.
Tokens que verificar_version.py busca en este archivo: ce_tiempos ce_drive_parent ce_rfi_barrido ce_altura_impresa
ce_formato_excel ce_tornilleria ce_track_familias ce_rfi_formato ce_rfi_prohibidos ce_entregables ce_sin_proposal
ce_sin_dolares ce_horas ce_seguimiento ce_atribucion ce_decisiones ce_fuentes_ms ce_datos_proyecto candados
ce_materiales_schedule revision_materiales
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import openpyxl  # noqa: E402
import pymupdf  # noqa: E402
import compuerta_entrega as CE  # noqa: E402
import subir_entrega as SE  # noqa: E402

RFI_OK = ("(A) Drawings (A2.0): printed B.O. deck per bay - delta -380 SF | (B) Code (ASTM C754): high point (loaded) - "
          "delta 0 (loaded) | (C) Other: ____")


def libro(p, pending=(("RFI-01", "Demising wall D-01 height basis per bay", RFI_OK),), ms=None, extra_hoja=False,
          extra_col=False, scope=None):
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    for h in CE.HOJAS6:
        ws = wb.create_sheet(h)
        fila, cab = CE.CABECERAS[h]
        for _ in range(fila - 1):
            ws.append(["x"])
        ws.append(cab + (["Extra"] if extra_col and h == "Material Summary" else []))
    ws = wb["Partition Takeoff"]
    ws.append(["TYPE S21"])
    ws.append(["S21 #S21-N", "S21-N", 20.0, 14.84375, 1, '6"', 16, 296.9, "Sales", "1/A3.2", "[CONFIRMED]"])
    for r in ms if ms is not None else (
            ["Bottom track 6\"", "LF", 20, 0.15, 0, 0, "run", 1, "N/SHEET: 1/A3.2"],
            ["Top slip / deflection track 6\" (2\" leg)", "LF", 20, 0.15, 0, 0, "run", 1, "N/SHEET: 10/A4.1"],
            ["Drywall screws #6 x 1-1/4\" Type S", "PCS", 0, 0, 0, 0, "each", 0, "N/SHEET: GA-216 | EXCLUDED - estimator decision 2026-10-31 (U-053)"]):
        wb["Material Summary"].append(list(r))
    for r in pending:
        wb["Pending Items"].append(list(r))
    for r in scope if scope is not None else (["ALC-30", "Fasteners", "EXCLUDED", "All screws / anchors EXCLUDED (U-053)"],):
        wb["Scope Checklist"].append(list(r))
    if extra_hoja:
        wb.create_sheet("Notas")
    wb.save(p)
    return p


def workdir(tiempos=True, drive=CE.DRIVE_RAIZ, set_texto=None, rfi=None):
    w = tempfile.mkdtemp(prefix="ce_test_")
    e = os.path.join(w, "FINAL_FOR_REVIEW")
    os.makedirs(os.path.join(e, "Take-off"))
    os.makedirs(os.path.join(e, "Planos marcados"))
    libro(os.path.join(e, "Take-off", "P_Takeoff_FINAL.xlsx"))
    for n in ("README_REVIEW.md", "PARA_REVISAR_EN_LA_MANANA.md"):
        open(os.path.join(e, n), "w").write("# PROJECT DATA\nHoras en PST.\n")
    open(os.path.join(e, "SEGUIMIENTO.md"), "w").write("| RFI-01 | A1.2 | ... |\n")
    if tiempos:
        open(os.path.join(w, "TIEMPOS.md"), "w").write(
            "START 2026-11-02 20:26 PST\n| 1 | arranque | 20:26 | 20:32 |\n| 2-3 | lecturas | 20:33 | 20:53 |\n"
            "| 4 | comparar | 20:54 | 20:54 |\n| 5 | resolver | 20:54 | 21:05 |\n| 6-9 | calc+excel+markups+gates | 20:55 | 21:31 |\n"
            "| **TOTAL** | | 20:26 | 21:31 |\n")
    json.dump({"drive": {"parent_id": drive, "carpeta_proyecto": "Proyecto X", "carpeta_proyecto_id": "FOLDER123"}},
              open(os.path.join(w, "entrega.json"), "w"))
    json.dump({"rfis": [rfi or HFT_RFI01]}, open(os.path.join(w, "takeoff.json"), "w"))
    if set_texto is not None:
        json.dump({"hojas": set_texto}, open(os.path.join(w, "set_texto.json"), "w"))
    return w


# RFI-01 de HFT Loveland rev2 (barrido real, takeoff_canon_FINAL_rev2.json): A1.2 SÍ estaba en la lista y aun así la
# respuesta impresa (B.O. DECK por zona) se quedó como RFI.
HFT_RFI01 = {"id": "RFI-01", "pregunta": "Demising wall D-01 (+-209'-1\", A1.1) runs under a sloped deck. Loaded 18.17 ft "
             "full length (conservative value loaded)", "barrido": {
                 "hojas": ["A0.0", "A1.1", "A1.2", "A2.0", "A4.1", "S2.1"], "terminos": ["DECK", "B.O.", "SLIP"],
                 "grep": "full set text: 'DECK' 93 hits ..."}}
SET_HFT = {"A1.1": "WALL LEGEND ALL WALLS BRACED TO STRUCTURE", "A1.2": "ZONE 1 B.O. DECK +-16'-9\" ZONE 2 B.O. DECK +-17'-5 1/2\"",
           "A2.0": "ROOF PLAN", "S2.1": "JOIST BEARING"}


def chk(fn, c):
    est, ev = fn(c)
    return est, " ".join(ev)


def test_hft_rfi01_impreso():
    w = workdir(set_texto=SET_HFT)
    est, ev = chk(CE.ce_rfi_barrido, CE.Ctx(w))
    assert est == "FAIL" and "A1.2" in ev and "IMPRESA" in ev, ev            # BE-120 reproducido
    # la vieja compuerta A_RFI_BARRIDO solo pedía la lista: con 6 hojas falla por cantidad, con 'ALL' pasaba
    r = dict(HFT_RFI01, barrido=dict(HFT_RFI01["barrido"], hojas="ALL"))
    w = workdir(set_texto=SET_HFT, rfi=r)
    assert chk(CE.ce_rfi_barrido, CE.Ctx(w))[0] == "FAIL"
    # hoja con el término fuera del barrido
    st = dict(SET_HFT, **{"S3.0": "DECK BEARING"})
    w = workdir(set_texto=st, rfi=dict(HFT_RFI01, barrido=dict(HFT_RFI01["barrido"], descartes={"A1.2": "x"})))
    est, ev = chk(CE.ce_rfi_barrido, CE.Ctx(w))
    assert est == "FAIL" and "S3.0" in ev and "NO está" in ev, ev
    # con descarte escrito por hoja y todas las hojas barridas -> PASS
    b = dict(HFT_RFI01["barrido"], hojas=list(st), descartes={"A1.2": "spot elevations at grid lines only, not per bay along the lease line"})
    w = workdir(set_texto=st, rfi=dict(HFT_RFI01, barrido=b))
    assert chk(CE.ce_rfi_barrido, CE.Ctx(w))[0] == "PASS"
    # sin texto del set no se puede probar -> FAIL
    assert chk(CE.ce_rfi_barrido, CE.Ctx(workdir()))[0] == "FAIL"


def markups_pdf(p, depth, label_h):
    doc = pymupdf.open()
    pg = doc.new_page(width=2592, height=1728)
    doc.set_page_labels([{"startpage": 0, "prefix": "A1.1", "style": "", "firstpagenum": 1}])
    pg.insert_text((100, 1650), "FLOOR PLAN   SCALE: 1/8\" = 1'-0\"", fontsize=12)
    a = pg.add_polyline_annot([(100, 200), (100 + 20.0 * 9, 200)])
    a.set_info(content=f"S21 · 20.00 LF · H {label_h} · 296.9 SF · 1/A3.2 · S21-N", subject="S21")
    a.update()
    doc.xref_set_key(a.xref, "Depth", str(depth))
    doc.save(p)


def test_altura_circular_oreilly():
    w = workdir()
    c = CE.Ctx(w)
    pdf = os.path.join(w, "FINAL_FOR_REVIEW", "Planos marcados", "m.pdf")
    markups_pdf(pdf, 14.84375, "14'-10.125\"")              # Depth = H del Excel (lo que validaba la revisión circular)
    c = CE.Ctx(w)
    c.canon = {"walls": [{"id": "S21-N", "height_ft": 14.84375, "height_source": "1/A3.2 'STUDS TO 13'-11 1/2\" A.F.F.'"}]}
    est, ev = chk(CE.ce_altura_impresa, c)
    assert est == "FAIL" and "printed source H 13.958" in ev, ev            # BE-119 reproducido
    c.canon = {"walls": [{"id": "S21-N", "height_ft": 14.84375, "height_source": "[PENDIENTE] assumed 8\" purlin (RFI-01)",
                          "height_status": "PENDIENTE"}]}
    assert chk(CE.ce_altura_impresa, c)[0] == "AMBER"
    c.canon = {"walls": [{"id": "S21-N", "height_ft": 14.84375, "height_source": "1/A3.2 'STUDS TO 14'-10 1/8\" A.F.F.'"}]}
    assert chk(CE.ce_altura_impresa, c)[0] == "PASS", chk(CE.ce_altura_impresa, c)


def test_drive_parent():
    assert chk(CE.ce_drive_parent, CE.Ctx(workdir(drive=CE.DRIVE_PROHIBIDO)))[0] == "FAIL"   # O'Reilly / VS en Projects
    assert chk(CE.ce_drive_parent, CE.Ctx(workdir(drive="otro")))[0] == "FAIL"
    assert chk(CE.ce_drive_parent, CE.Ctx(workdir()))[0] == "PASS"
    w = workdir()
    os.remove(os.path.join(w, "entrega.json"))
    assert chk(CE.ce_drive_parent, CE.Ctx(w))[0] == "FAIL"


def test_tiempos():
    assert chk(CE.ce_tiempos, CE.Ctx(workdir(tiempos=False)))[0] == "FAIL"                  # O'Reilly sin TIEMPOS.md
    w = workdir()
    t = open(os.path.join(w, "TIEMPOS.md")).read().replace("| 4 | comparar | 20:54 | 20:54 |\n", "")
    open(os.path.join(w, "TIEMPOS.md"), "w").write(t)
    est, ev = chk(CE.ce_tiempos, CE.Ctx(w))
    assert est == "FAIL" and "paso 4" in ev, ev
    assert chk(CE.ce_tiempos, CE.Ctx(workdir()))[0] == "PASS"
    w = workdir()
    open(os.path.join(w, "TIEMPOS.md"), "a").write("subida 2026-11-03T05:01Z UTC\n")
    assert chk(CE.ce_horas, CE.Ctx(w))[0] == "FAIL"


def test_excel():
    w = workdir()
    c = CE.Ctx(w)
    assert chk(CE.ce_formato_excel, c)[0] == "PASS", chk(CE.ce_formato_excel, c)
    assert chk(CE.ce_tornilleria, c)[0] == "PASS", chk(CE.ce_tornilleria, c)
    assert chk(CE.ce_track_familias, c)[0] == "PASS", chk(CE.ce_track_familias, c)
    assert chk(CE.ce_fuentes_ms, c)[0] == "PASS"
    assert chk(CE.ce_rfi_formato, c)[0] == "PASS", chk(CE.ce_rfi_formato, c)
    assert chk(CE.ce_seguimiento, c)[0] == "PASS"
    assert chk(CE.ce_atribucion, c)[0] == "PASS", chk(CE.ce_atribucion, c)
    x = os.path.join(w, "FINAL_FOR_REVIEW", "Take-off", "P_Takeoff_FINAL.xlsx")
    libro(x, extra_hoja=True)
    assert chk(CE.ce_formato_excel, CE.Ctx(w))[0] == "FAIL"
    libro(x, extra_col=True)
    assert chk(CE.ce_formato_excel, CE.Ctx(w))[0] == "FAIL"
    libro(x, ms=[["Bottom track 6\"", "LF", 20, 0, 0, 0, "", 0, "N/SHEET: 1/A3.2"],
                 ["Top slip / deflection track 6\"", "LF", 20, 0, 0, 0, "", 0, "N/SHEET: 10/A4.1"],
                 ["Framing screws #8 x 1/2\"", "PCS", 410, 0, 0, 0, "", 0, "N/SHEET: A4.1"]])
    assert chk(CE.ce_tornilleria, CE.Ctx(w))[0] == "FAIL"
    libro(x, ms=[["Top and bottom track + slip track 6\"", "LF", 40, 0, 0, 0, "", 0, "N/SHEET: 1/A3.2"]])
    assert chk(CE.ce_track_familias, CE.Ctx(w))[0] == "FAIL"
    libro(x, ms=[["Bottom track 6\"", "LF", 20, 0, 0, 0, "", 0, "N/SHEET: 1/A3.2"]])
    assert chk(CE.ce_track_familias, CE.Ctx(w))[0] == "FAIL"
    libro(x, ms=[["Bottom track 6\"", "LF", 20, 0, 0, 0, "", 0, "see note"]])
    assert chk(CE.ce_fuentes_ms, CE.Ctx(w))[0] == "FAIL"
    libro(x, pending=[["RFI-01", "q", "(A) Drawings: x - delta 1 | (B) Code: y - delta 0"]])
    assert chk(CE.ce_rfi_formato, CE.Ctx(w))[0] == "FAIL"
    libro(x, pending=[["RFI-02", "Insulation type at demising wall", RFI_OK], ["RFI-03", "Fastener spacing at track", RFI_OK],
                      ["RFI-04", "Kicker length at bulkhead (no screws / bolts printed)", RFI_OK]])
    est, ev = chk(CE.ce_rfi_prohibidos, CE.Ctx(w))
    assert est == "FAIL" and "RFI-02" in ev and "RFI-03" in ev and "RFI-04" not in ev, ev
    libro(x, scope=[["ALC-1", "Note", "x", "EXCLUDED - estimator decision: wood blocking"]])
    assert chk(CE.ce_atribucion, CE.Ctx(w))[0] == "FAIL"


def test_entregables_y_docs():
    w = workdir()
    e = os.path.join(w, "FINAL_FOR_REVIEW")
    assert chk(CE.ce_entregables, CE.Ctx(w))[0] == "FAIL"                     # sin PDF ni PNG de markups
    open(os.path.join(e, "Proposal_v1.docx"), "w").write("x")
    assert chk(CE.ce_sin_proposal, CE.Ctx(w))[0] == "FAIL"
    open(os.path.join(e, "PARA_REVISAR_EN_LA_MANANA.md"), "a").write("Costo de la corrida: $12.40\n")
    assert chk(CE.ce_sin_dolares, CE.Ctx(w))[0] == "FAIL"
    assert chk(CE.ce_datos_proyecto, CE.Ctx(w))[0] == "FAIL"                  # takeoff.json sin proyecto_datos


def fake_gdrive(lista_ids):
    d = tempfile.mkdtemp(prefix="fake_gd_")
    p = os.path.join(d, "gd.py")
    log = os.path.join(d, "log.txt")
    open(p, "w").write(
        "import sys, json\n"
        f"open({log!r}, 'a').write(' '.join(sys.argv[1:]) + '\\n')\n"
        "c = sys.argv[1]\n"
        f"if c == 'list':\n    [print(json.dumps({{'id': i, 'name': 'Proyecto X'}})) for i in {list(lista_ids)!r}]\n"
        "elif c == 'mkdir':\n    print('NEW_' + sys.argv[3])\n"
        "elif c == 'put':\n    print('OK uploaded ' + sys.argv[2])\n")
    return p, log


def entrega_ok(w, ok=True, parent=CE.DRIVE_RAIZ):
    c = CE.Ctx(w)
    arch = {os.path.relpath(p, w): CE._sha(p) for p in c.archivos_entrega()}
    json.dump({"ok": ok, "entrega_dir": "FINAL_FOR_REVIEW", "chequeos": [{"id": "CE_X", "estado": "PASS" if ok else "FAIL"}],
               "archivos": arch, "drive": {"parent_id": parent, "carpeta_proyecto": "Proyecto X", "carpeta_proyecto_id": "FOLDER123"}},
              open(os.path.join(w, "ENTREGA_OK.json"), "w"))


def test_subida():
    w = workdir()
    try:
        SE.candados(w)
        raise AssertionError("subió sin ENTREGA_OK.json")
    except SE.Bloqueo as e:
        assert "ENTREGA_OK" in str(e)
    entrega_ok(w, ok=False)
    try:
        SE.candados(w)
        raise AssertionError("subió con compuerta roja")
    except SE.Bloqueo as e:
        assert "verde" in str(e)
    entrega_ok(w)
    open(os.path.join(w, "FINAL_FOR_REVIEW", "README_REVIEW.md"), "a").write("cambio tardío\n")
    try:
        SE.candados(w)
        raise AssertionError("subió un archivo cambiado después de la compuerta")
    except SE.Bloqueo as e:
        assert "cambió" in str(e)
    entrega_ok(w, parent=CE.DRIVE_PROHIBIDO)
    try:
        SE.candados(w)
        raise AssertionError("subió a Projects › Claude outputs")
    except SE.Bloqueo as e:
        assert "parent_id" in str(e)
    entrega_ok(w)
    gd, log = fake_gdrive(["OTRA"])
    env = dict(os.environ, GDRIVE_FETCH=gd)
    r = subprocess.run([sys.executable, "-I", os.path.join(CE.AQUI, "subir_entrega.py"), w], capture_output=True, text=True, env=env)
    assert r.returncode == 1 and "NO es hija" in r.stdout, r.stdout + r.stderr
    gd, log = fake_gdrive(["FOLDER123"])
    env = dict(os.environ, GDRIVE_FETCH=gd)
    r = subprocess.run([sys.executable, "-I", os.path.join(CE.AQUI, "subir_entrega.py"), w], capture_output=True, text=True, env=env)
    assert r.returncode == 0, r.stdout + r.stderr
    L = open(log).read()
    assert f"list {CE.DRIVE_RAIZ}" in L and "mkdir FOLDER123 FINAL_FOR_REVIEW" in L and L.count("put ") == 4 and "mkdir NEW_FINAL_FOR_REVIEW Take-off" in L, L
    assert os.path.isfile(os.path.join(w, "SUBIDA_OK.json"))


def test_materiales_schedule():
    """BE-122 (j): sin lectura independiente del schedule = FAIL; board regular donde el schedule imprime Type X = FAIL."""
    w = workdir()
    c = CE.Ctx(w)
    assert chk(CE.ce_materiales_schedule, c)[0] == "FAIL"                     # sin fichas.json
    json.dump({"types": {"S21": {"stud_designation": "600S162-33", "gauge_ga": 20, "oc_in": 16,
                                 "faces": [{"side": "each side", "layers": 1, "board": "5/8\" Type X"}],
                                 "sources": {"stud": "1/A3.2", "board": "1/A3.2"}}}}, open(os.path.join(w, "fichas.json"), "w"))
    canon = os.path.join(w, "canon.json")
    caras = [{"side": "A", "board": "5/8 type X", "layers": 1, "height_ft": 14.8}, {"side": "B", "board": "5/8 regular", "layers": 1, "height_ft": 14.8}]
    json.dump({"walls": [{"id": "S21-N", "faces": caras}]}, open(canon, "w"))
    e = json.load(open(os.path.join(w, "entrega.json")))
    e["canon"] = "canon.json"
    json.dump(e, open(os.path.join(w, "entrega.json"), "w"))
    x = os.path.join(w, "FINAL_FOR_REVIEW", "Take-off", "P_Takeoff_FINAL.xlsx")
    wb = openpyxl.load_workbook(x)
    wb["Partition Takeoff"]["F6"] = '6" 20 ga (33 mil, 600S162-33)'
    wb.save(x)
    est, ev = chk(CE.ce_materiales_schedule, CE.Ctx(w))
    assert est == "FAIL" and "board type S21-N" in ev, ev
    caras[1]["board"] = "5/8 type X"
    json.dump({"walls": [{"id": "S21-N", "faces": caras}]}, open(canon, "w"))
    est, ev = chk(CE.ce_materiales_schedule, CE.Ctx(w))
    assert est != "FAIL" or "board type" not in ev, ev


def test_revision_materiales():
    """test de la herramienta (sesión O'Reilly, test_revision_materiales.py, unido aquí para quedar < 200 archivos)."""
    import revision_materiales as RV
    ficha = {"stud_designation": "362S162-33", "gauge_ga": 20, "oc_in": 16, "height": "STUDS TO 8'-6\" A.F.F.",
             "faces": [{"side": "each side", "layers": 1, "board": "5/8\" Type X W.R."}],
             "sources": {"stud": "W1/A1.1", "board": "W1/A1.1", "height": "W1/A1.1"}}
    fila = [{"type": "W1", "wall": "W-1", "lf": 10.0, "h": 8.5, "layers": 1, "stud": '3-5/8" 20 ga (33 mil, 362S162-33)',
             "oc": 16, "board_sf": 170, "location": "", "source": "W1/A1.1"}]
    bien = {"W-1": {"faces": [{"side": "A", "board": "5/8 type X WR", "layers": 1, "height_ft": 8.5},
                              {"side": "B", "board": "5/8 type X WR", "layers": 1, "height_ft": 8.5}]}}
    mal = {"W-1": {"faces": [{"side": "A", "board": "5/8 type X WR", "layers": 1, "height_ft": 8.5},
                             {"side": "B", "board": "5/8 regular", "layers": 1, "height_ft": 8.5}]}}
    assert RV.comparar_type("W1", ficha, fila, bien)["verdict"] == "GREEN"
    r = RV.comparar_type("W1", ficha, fila, mal)
    assert r["verdict"] == "RED" and any(c["field"].startswith("board type") and c["status"] == "RED" for c in r["checks"]), r
    fila2 = [dict(fila[0], stud='3-5/8" 25 ga (18 mil, 362S162-18)', h=9.0)]
    r = RV.comparar_type("W1", ficha, fila2, bien)
    assert {c["field"] for c in r["checks"] if c["status"] == "RED"} >= {"stud designation", "gauge", "height"}, r
    assert RV.tipo_board('5/8" TYPE "X" GYPSUM BOARD') == "X" and RV.tipo_board("5/8 type X WR") == "X-WR"
    ms = [{"row": 4, "name": "Bottom track 3-5/8\"", "unit": "LF", "net": 30.0,
           "where": "N/SHEET: W1/A1.1 | Breakdown [DERIVED]: W-1 10 + W-2 20 = 30 LF"},
          {"row": 5, "name": "Top track 3-5/8\"", "unit": "LF", "net": 31.0,
           "where": "N/SHEET: W1/A1.1 | Breakdown [DERIVED]: W-1 10 + W-2 20 = 30 LF"},
          {"row": 6, "name": "Additional head track", "unit": "LF", "net": 7.33, "where": "N/SHEET: default (no sheet) | Door 3"}]
    fil = [{"type": "W1", "wall": "W-1"}, {"type": "W1", "wall": "W-2"}]
    sm = {x["row"]: x for x in RV.sumas(ms, fil, "/nonexistent")}
    assert sm[4]["status"] == "GREEN" and sm[4]["by_type"] == {"W1": 30.0}, sm[4]
    assert sm[5]["status"] == "RED" and sm[6]["status"] == "RED", (sm[5], sm[6])


def test_correr_rojo():
    w = workdir(tiempos=False)
    out = CE.correr(w)
    assert not out["ok"] and any(r["id"] == "CE_TIEMPOS" and r["estado"] == "FAIL" for r in out["chequeos"])
    assert any("U-094" in r["reglas"] for r in out["chequeos"] if r["id"] == "CE_TIEMPOS")
    out = CE.correr(w, solo={"CE_DRIVE_PARENT"})
    assert not out["ok"], "una corrida parcial nunca es verde"


if __name__ == "__main__":
    for f in (test_hft_rfi01_impreso, test_altura_circular_oreilly, test_drive_parent, test_tiempos, test_excel,
              test_entregables_y_docs, test_subida, test_materiales_schedule, test_revision_materiales, test_correr_rojo):
        f()
        print("ok", f.__name__)
    print("test_compuerta_entrega OK")
