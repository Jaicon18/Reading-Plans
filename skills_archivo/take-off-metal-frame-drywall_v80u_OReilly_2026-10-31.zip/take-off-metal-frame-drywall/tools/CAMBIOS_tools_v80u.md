# CAMBIOS v80u (2026-10-31, corrida O'Reilly Evans #1) — sobre v80t

Errores encontrados en la corrida y su solución (regla para todos los proyectos; suite 5/5 OK después de cada cambio):

| Regla | Error | Solución | Tools |
|---|---|---|---|
| R80e.63 | Hojas numeradas "A4.2" / "A2.1" (un decimal) no se reconocían en el runner ni en las compuertas | regex de hoja acepta `[A-Z]{1,2}\d{1,2}\.\d{1,2}`; cita N/HOJA acepta type + hoja ("S21/A1.1") | runner/evidencia.py, completitud.py, cobertura.py, overlay.py; accesorios.py, alcances.py, closer.py |
| R80e.64 | El estimador excluye MEP: canon.py exigía hoja M, accesorios.py exigía barrido P/M, framed_openings / alcance_filtro exigían ítems | `opening_schedule.sources_none.M`, `mep_sweep.excluded_by_estimator {why, source}`, `fo_in.items_none_reason`, `alcance_in.rows_none_reason` | canon.py, accesorios.py, framed_openings.py, alcance_filtro.py |
| R80e.65 | Z-furring (150ZF125-18) sin familia | familia "1-1/2\" Z-furring" (stud_size con ZF / Z-furring); sin renglón de track por tamaño | canon.py, familias.py, plantilla_excel.py, accesorios.py |
| R80e.66 | contar_tags.py fallaba en hoja raster | `HOJA@pN` en página sin texto = NO INVENTARIABLE con rc 0 y JSON con motivo | contar_tags.py |
| R80e.67 | Renglón de track "roof step and heads": el desglose sumaba todos los walls | filtro por elemento (TRACK_HEADS / parapet) | trazabilidad.py |
| R80e.68 | FRT plywood 5/8 ext no entraba al desglose del renglón 5/8 | material `frt_5_8_ext` cae en el renglón 5/8 in. | trazabilidad.py |
| R80e.69 | El runner tomó TAKEOFF_API_KEY del entorno en corrección / cobertura aunque la corrida era por suscripción (31 llamadas) | flag `--sin-api`: claude() nunca llama; correr además con `env -u TAKEOFF_API_KEY` | runner/run_takeoff.py |
| R80e.70 | Tags de hojas raster no tienen tag_ids del inventario | `tag_manual {source "TAG/HOJA", sheet_raster}` cuenta como tag barrido a mano | reglas.py |
| R80e.71 | markups_bluebeam.py no encontraba la hoja raster (sin texto) y no marcaba ningún wall | página declarada en una hoja sin texto se acepta | markups_bluebeam.py |
| R80e.72 | Citas fijas de B&N (A-410 / A-001A / DM-101) se escribían en el Excel de otro proyecto | textos genéricos "default (no sheet)" o la cita del canon; verificación: 0 citas ajenas en el Excel | trazabilidad.py, accesorios.py |

Órdenes del estimador de esta corrida (todas las corridas):
- Solo hojas del trade (las que tengan framing o gypsum board); excluir eléctrico, civil, cabinets, MEP.
- Si el bid set trae markups de otro estimador: copia limpia (copia_limpia.py) y seguir; declarar lo visto.
- Lo que la sesión puede corregir sola, se corrige sin avisar ni pedir nada al estimador.
- Corridas por suscripción: nunca API (R80e.69).
- Comparaciones de calidad solo contra el mejor skill vigente (v80s / B&N rev13).

## rev2 (2026-10-31, misma corrida)
| Regla | Error | Solución | Tools |
|---|---|---|---|
| R80e.73 | Los defaults de accesorios citaban textos impresos de otro set ("SILL TRACK ANCHORAGE…", "Handoff - Approved") y "estimator decision" de otro proyecto como si fueran de este | todo default sale como "default (no sheet): skill standing criterion / precedent of a previous project, not printed in this set [texto original]" | accesorios.py k(), plantilla_excel.py (Inputs lumber) |
| R80e.74 | Framing screws stud-to-track contados en el Z-furring sin track | walls sin bottom ni top track no cuentan tornillos stud-to-track | accesorios.py framing_screws |
| R80e.75 | Productos impresos (anchors, #10 screws, deep-leg track, sheathing screws, clips) quedaban como RFI por falta de familia | familias "printed" (misc_items) + `acc_nombres` conserva el nombre de plantilla y agrega "-> printed product: …"; spacing impreso en constants | canon.py, familias.py, plantilla_excel.py |
| R80e.76 | ORDEN DE FUENTES: lo impreso se carga; el RFI queda solo por la dimensión o el producto en conflicto | lectura dirigida de notas S (S1.1 nota 7, S5.x key notes, secciones) antes de cerrar accesorios | proceso (lectura) |
| R80e.77 | Orden del estimador "excluye toda la tornillería" (O'Reilly, 2026-10-31) | canon `fasteners_excluded {why, source}` → drywall / framing / heavy-gauge screws, slab pins / PAF, expansion anchors en 0 con nota EXCLUDED y la cantidad calculada en la operación; misc de sheathing screws en 0; RFIs solo de tornillería cerrados; clips, angles, track y blocking se quedan. Solo cuando el estimador lo ordena en ese proyecto | accesorios.py, trazabilidad.py |
