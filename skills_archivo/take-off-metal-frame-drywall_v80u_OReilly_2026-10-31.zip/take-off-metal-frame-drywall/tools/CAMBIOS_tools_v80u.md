# CAMBIOS v80u (2026-10-31, corrida O'Reilly Evans #1) — sobre v80t

Errores encontrados en la corrida y su solución (regla para todos los proyectos; suite 5/5 OK después de cada cambio):

| Regla | Error | Solución | Tools |
|---|---|---|---|
| R80e.63 | Hojas numeradas "A4.2" / "A2.1" (un decimal) no se reconocían en el runner ni en las compuertas | regex de hoja acepta `[A-Z]{1,2}\d{1,2}\.\d{1,2}`; cita N/HOJA acepta type + hoja ("S21/A1.1") | runner/evidencia.py, completitud.py, cobertura.py, overlay.py; accesorios.py, alcances.py, closer.py |
| R80e.64 | El estimador excluye MEP: canon.py exigía hoja M, accesorios.py exigía barrido P/M, framed_openings / alcance_filtro exigían ítems | `opening_schedule.sources_none.M`, `mep_sweep.excluded_by_estimator {why, source}`, `fo_in.items_none_reason`, `alcance_in.rows_none_reason` | canon.py, accesorios.py, framed_openings.py, alcance_filtro.py |
| R80e.65 | Z-furring (150ZF125-18) sin familia | familia "1-1/2\" Z-furring" (stud_size con ZF / Z-furring); sin renglón de track por tamaño | canon.py, familias.py, plantilla_excel.py, accesorios.py |
| R80e.66 | contar_tags.py fallaba en hoja raster | `HOJA@pN` en página sin texto = NO INVENTARIABLE con rc 0 y JSON con motivo | contar_tags.py |
| R80e.67 | Renglón de track "roof step and heads": el desglose sumaba todos los walls | filtro por elemento (TRACK_HEADS / parapet) | trazabilidad.py |
| R80e.68 | FRT plywood 5/8 ext no entraba al desglose del renglón 5/8 | material `frt_5_8_ext` cae en el renglón 5/8 in. | trazabilidad.py |
| R80e.69 | El runner tomó TAKEOFF_API_KEY del entorno en corrección / cobertura aunque la corrida era por suscripción (31 llamadas) | flag `--sin-api`: claude() nunca llama; correr además con `env -u TAKEOFF_API_KEY` | runner/run_takeoff.py |
| R80e.70 | Tags de hojas raster no tienen tag_ids del inventario | `tag_manual {source "TAG/HOJA", sheet_raster}` cuenta como tag barrido a mano | reglas.py |
| R80e.71 | markups_bluebeam.py no encontraba la hoja raster (sin texto) y no marcaba ningún wall | página declarada en una hoja sin texto se acepta | markups_bluebeam.py |
| R80e.72 | Citas fijas de B&N (A-410 / A-001A / DM-101) se escribían en el Excel de otro proyecto | textos genéricos "default (no sheet)" o la cita del canon; verificación: 0 citas ajenas en el Excel | trazabilidad.py, accesorios.py |

Órdenes del estimador de esta corrida (todas las corridas):
- Solo hojas del trade (las que tengan framing o gypsum board); excluir eléctrico, civil, cabinets, MEP.
- Si el bid set trae markups de otro estimador: copia limpia (copia_limpia.py) y seguir; declarar lo visto.
- Lo que la sesión puede corregir sola, se corrige sin avisar ni pedir nada al estimador.
- Corridas por suscripción: nunca API (R80e.69).
- Comparaciones de calidad solo contra el mejor skill vigente (v80s / B&N rev13).
