# CAMBIOS de tools v80x, v81cf8, v81cf11 y v81cf21 (unidos en v81cf21 para quedar < 200 archivos; texto original sin cambios)

<!-- archivo original: tools/CAMBIOS_tools_v80x.md -->
# CAMBIOS tools v80x — VS #679 Downey rev2 (paso 11 auditor + paso 12 biblioteca)
| Regla | Error (paso 12) | Solución | Tool |
|---|---|---|---|
| R80e.109 | BE-102 citas truncadas (C/A12) y ids de wall leídos como hojas | RX_NH: punto primero; sin guion 3 dígitos | trazabilidad.py |
| R80e.110 | BE-46 storefront y clips mezclaban productos | split por miembro / designación de clip | trazabilidad.py |
| R80e.111 | BE-46 foil-backed como "regular", 1/2" MR como "exterior sheathing" | boards "5/8 foil-backed" y "1/2 MR" con familia / renglón | canon, familias, plantilla, trazabilidad, inventario |
| R80e.112 | BE-15 blocking como stud 3-5/8"; split duplicaba familia | split backing track / plate + guard NET | trazabilidad, plantilla |
| R80e.113 | track de soffits por tamaño no sumaba sus ítems | + items_filas | trazabilidad |
| compra | BE-51 reveal: piezas = LF | trim stick 10 ft | plantilla_excel |
Suite 5/5 OK.

<!-- archivo original: tools/CAMBIOS_tools_v81cf8.md -->
# CAMBIOS tools v81cf8 (02-nov-2026, CFA #2284 River Point back-check rev2) — generic, all projects

| Id | Tool | Problem | Fix | Test (fails with v81cf7) |
|---|---|---|---|---|
| T1 / BE-CF16 | canon.py `nombres_contexto.z_size`; plantilla_excel.py `nombre_plantilla` | The Z-furring row was always labelled "1-1/2\" Z-furring channel" even when the set prints a 2" Z channel | z size from `constants.z_furring_size {value, source}` or from the stud_size of the walls in the Z-furring family; the row label shows it; absent / 1-1/2" = old label | `test_z_size_label.py` |
| T2 / BE-CF15 | canon.py (F_SAG, BOARD_FAM, FAMS, optional); familias.py; plantilla_excel.py name; accesorios.BOARD_DRIVER; trazabilidad.py board key; alcances.py ALC-11 (+ 1/2" families in ALC-07) | A spec "Ceiling Type" (sag-resistant) board had no board key: carried as "5/8 regular" with a note | board key "5/8 ceiling sag-resistant" -> family '5/8" gyp ceiling board SAG-RESISTANT', row "5/8\" gypsum ceiling board, SAG-RESISTANT (ceiling type)", in the finishing driver and in ALC-11 | `test_sag_board.py` |
| T3 / BE-CF17 | canon.py F_PRINTED; familias.py; plantilla_excel.py name / NO_METAL_CANON | Setting-type compound at cement board joints had no LB family (note only, not bought) | printed family "setting-type joint compound at cement board (printed)" in LB (misc_items, yield x cement board SF) | `test_setting_compound_yield.py` |
| T4 / BE-CF17 | plantilla_excel.py `YIELD_CANON` in `familias_faltantes` | Yield-based canon rows (mesh tape) got the 6 % non-metal waste against the Inputs rule "yields carry no waste" | mesh tape and setting compound rows: waste none (0 %), roll (LF) / lb | `test_setting_compound_yield.py` |
| T5 | plantilla_excel.py `_escribir` | OTHER FRAMING block of the Partition Takeoff had no SUBTOTAL | "SUBTOTAL OTHER FRAMING" row (LF and board SF), text in col. B | `test_other_framing_subtotal_seal.py` |
| T6 / BE-CF18 | reglas.py `sello_path` / `sellar_sidecar` / `leer_sello`; plantilla_excel.py `_escribir` | The seal was a 7th hidden sheet `_reglas` (in Spanish) inside the delivered workbook | the workbook has exactly the 6 fixed sheets; the seal (huella + sha256 of the saved workbook) goes to `<excel>.sello.json`, read by reglas.A_EXCEL / bitacora; an Excel with the old hidden sheet is still read (backward compatible); a workbook edited after the seal is no longer sealed | `test_other_framing_subtotal_seal.py` |

<!-- archivo original: tools/CAMBIOS_tools_v81cf11.md -->
# CAMBIOS tools v81cf11 (03-nov-2026, CFA #2284 River Point rev4)

| Id | Tool | Problem | Fix | Test |
|---|---|---|---|---|
| BE-117 | markups_bluebeam.py `contenido` / `board_sf` (verificar uses the same function) | The SF in each wall markup was LF x H (framing area) and did not equal the Board (SF) of its Excel row | SF = sum of the wall faces (length x height x layers) - openings, written "X SF board"; walls without faces keep LF x H | `test_markups_board_sf.py` (fails with v81cf10 as delivered) |
| BE-117b | markups_bluebeam.py `contenido` (board-only walls) | board-only SF written with 1 decimal (16.1) vs the Excel 16.14 | 2 decimals, identical to the Excel row (test_existing_walls.py updated: 300.00 SF) | `test_existing_walls.py` |
| BE-117c | canon.py TRACK_NOMBRES["slip"] / track_by_element | The slip / deflection top track row always said "2\" deflection leg" even when the head detail prints a 3" long-legged slotted track | leg from walls[].top_track_leg or parsed from top_track_kind_source ("3\" LONG LEGGED"); default 2" | `test_slip_leg_label.py` |
| BE-117d | trazabilidad.py `aplicar` (N/SHEET of every Material Summary row) | A row with any N/SHEET dropped the bare sheets of its items (gyp ceiling row cited C3/S-241, A2/S-241 but not A-221 where the ceilings are drawn): verificar_markups_excel found DETAIL A-221 not in the row | the bare sheets of the item sources not covered by an N/SHEET are added (same rule as the per-product split) | `test_be117_excel_ids.py` |
| BE-117e | accesorios.py `level5` | op "<ref>: L x (h - base) = SF": the markup checker read <ref> = L (59.69) instead of the SF | op "<ref> <SF> SF = L x (h - base)" | `test_be117_excel_ids.py` |
| BE-117f | trazabilidad.py board rows | 1/2" regular board row had no per-ID breakdown (op text cut at 566 chars), so soffit bottoms / walls of that board could not be matched; ceilings were named "ceiling <room>" | 1/2" gyp board joins the per-board branch (faces + ceilings + items); a ceiling with `id` is listed by its id | `test_be117_excel_ids.py` |


# CAMBIOS tools v81cf13 (03-nov-2026, merge of Chuze FINAL4 patch PARCHE_BE117g_para_v81cf13) — generic, all projects

On top of v81cf12 (BE-115: one cumulative line). Chuze-branch ids R80f.7–R80f.10 renumbered to R80f.8–R80f.11 (R80f.7 = A_MARKUPS_EXCEL in the main line). Chuze files were merged as 3-way diffs (base v81cf10 archive, ours v81cf12); BE-117b–f kept (markup SF = board SF from the canon faces, 2 decimals).

| Id | Tool | Problem | Fix | Test |
|---|---|---|---|---|
| BE-117g | verificar_markups_excel.py `leer_excel` / union | A joined Partition Takeoff row "A+B" (PT2: wall + return): each piece was looked up alone (row "without annotation", TYPE vs a Material Summary row, duplicate Wall ID) — Chuze FINAL4 16 FAIL | `union` {piece -> row}; each piece checked for TYPE / H against its row; LF / SF of the pieces summed and squared against the row (±0.5 %); pieces are not duplicates | `test_markups_excel_union.py` |
| R80f.8 | plantilla_excel.py `verificar_excel`; markups_bluebeam.py `resumen_vigente` | language check failed on a quoted proper name in the R80e.121 "PROJECT DATA" block; with two summaries of the same canon the oldest was verified | exemption for any "PROJECT DATA" block; most recent summary verified | `test_chuze_r80f8_11.py` |
| R80f.9 | markups_bluebeam.py `ajustar_a_lf`, `cargar_board`, `NHOJA_RX` | Bluebeam Length vs printed LF up to 1 %; DETAIL "3D/A301" for A2-3D/A301 | run with diff < TOL_PT drawn at LF length; board_out.json SF only for walls without faces (BE-117b first); hyphenated types whole | `test_chuze_r80f8_11.py` |
| R80f.10 | markups_bluebeam.py `leyendas_por_hoja`, `orden_types` | legend only on a last page | legend box on every marked sheet in schedule order | `test_chuze_r80f8_11.py` |
| R80f.11 | auditoria_entrega.py (new) | delivery audit by eye | delivery audit by program, rc 1 = not deliverable | `test_chuze_r80f8_11.py` |


# CAMBIOS tools v81cf18 (03-nov-2026, Chuze Fitness Austin Bluffs FINAL5) — generic, all projects

On top of v81cf17 (BE-115). Origin: Chuze FINAL5 (RCP ceilings with no markups; orchestrator decision #0: drawn geometry wins over hatch-stroke extents).

| Id | Tool | Problem | Fix | Test (fails with v81cf17) |
|---|---|---|---|---|
| R80f.13 | markups_rcp.py `escribir`, `_pagina`, `_bracing_on`, `_label` | One RCP sheet per project (constants.rcp_sheet): a set with ceilings / soffits on several enlarged RCP sheets (Chuze: A421.A ... A426) got no ceiling markups; ID = room text; lateral-bracing clusters drawn even when the set has none; project-specific legend text (J/A12.02); legend at a fixed corner | every ceiling on ITS sheet (ceilings[].sheet, else rcp_sheet; page by Page Label, title block or rcp_page); polygon found by ceilings[].id or room; NM / ID = id; Contents carries "GWB CEILING <ceiling_tag>"; clusters only unless constants.ceiling_lateral_bracing = false; legend per sheet in the corner with the least ink; one PNG per sheet (<sheet>_rcp_markups.png) | `test_rcp_multihoja.py` |
| R80f.14 | verificar_markups_excel.py `buscar_pdf` | The delivery PDF next to the Excel was looked up with the case-sensitive glob "*markup*": "Proj_Markups_X.pdf" was missed and the older walls-only PDF of 6_markups was verified (A_MARKUPS_EXCEL false failures) | any PDF next to the Excel whose name contains "markup" (case-insensitive) | `test_rcp_multihoja.py` |
| R80f.15 | auditoria_entrega.py | Area annotations (RCP polygons) were reported as "annot without Partition Takeoff row"; ceiling sheets were not in the marked-sheets check | an area annot is squared against the "ID SF" breakdown of the Material Summary and its drawn area vs SF (<= 0.5 %); ceilings[].sheet counted as sheets with elements | `test_rcp_multihoja.py` |
| R80f.16 | markups_rcp.py `sin_hatch`, `_color_hatch` | Rule (Chuze FINAL5 audit): the GWB ceiling = the HATCHED area only, bounded by the faces. A ceiling polygon taken from the room region included parts with no C-5 hatch (white display boxes of the storefront soffit, the corner beyond an L-shaped wall in the shower) | every ceiling polygon is checked against the hatch strokes of its sheet (constants.rcp_hatch_color or the commonest thin stroke color): a part without hatch that touches the polygon boundary (>= 1 SF) is reported and markups_rcp exits rc 1 (polygon must follow the hatch boundary; a closed white sub-region without hatch is a hole); a small interior hole (< 4 SF, device / fan) is an opening and is not deducted; `hatch_check_cause` / polygon `cause` documents an exception | `test_rcp_hatch.py` |

Note (v81cf18 merge): test_rcp_multihoja.py and test_rcp_hatch.py are carried as blocks inside `test_chuze_r80f8_11.py` (package limit of 200 files); every assertion is kept.


<!-- v81cf21 -->
## v81cf21 (HFT Loveland, 03-nov-2026) — R80f.17–R80f.28

Tool fixes de la corrida Harbor Freight Loveland (TOOL_LIMITS_CALC / BACKCHECK_rev2_cierre):
- BE-HF1 / BE-HF1b: hat channel vertical -> familia vertical furring, rótulo impreso, familias.py (R80f.17)
- BE-HF2: canon.MISC_ALIAS 'FRP panels' (R80f.18)
- BE-HF3: furring sin C.R. bracing (R80f.19)
- BE-HF4: vigas_sobre_walls --min-size (R80f.20)
- BE-HF5: A_BRACING con spacing impreso (R80f.19)
- BE-HF6 / BE-HF6b: box beams de misc en A_HEADER_LF y desglose (R80f.21)
- BE-HF7: tamano_stud con designación (R80f.22)
- BE-HF8: cita de hoja suelta (R80f.22)
- BE-HF9: 0 SF en markup de wall sin board (R80f.23)
- BE-HF10: auditoria_entrega --rfis-abiertos + causas (R80f.24)
- BE-HF11: head de Partition Takeoff por tamaño / tipo (R80f.26)
- BE-HF12: braces to structure + spacing bar (R80f.25)
- BE-HF13: bracing solo > altura mínima impresa (R80f.19)
- BE-HF14: una fila por Wall ID + BULKHEAD-<tag> (R80f.27)
- BE-HF15: demo 'faces x layer' (R80f.23)
- BE-HF16: desglose de sill + nota de redondeo (R80f.22)
- BE-HF17: leyenda en orden del schedule (R80f.23)
