#!/usr/bin/env python3
"""markups_rcp.py — R80e.135 / BE-VS-15 (03-nov-2026, TODOS): toda hoja con renglones del take-off lleva markups.

Agrega al PDF de markups (salida de markups_bluebeam.py + markups_demo.py) un POLÍGONO por cada ceiling / soffit /
bulkhead del canon en la hoja del RCP (constants.rcp_sheet), con el formato que verificar_markups_excel cuadra contra
el Excel:
  Subject  = el board del renglón del Excel (ej. '5/8 GYPSUM BOARD TYPE X')
  Contents = '<Subject> · CEILING <room> · <SF> SF · CLG <altura> · <detalle N/HOJA> · <room>'
  /NM      = 'TO-<room>'  (el room es el ID del desglose 'ceiling <room> <SF>' del Material Summary)
  /Measure = escala impresa de la hoja (pt/ft), /IT /PolygonDimension (Bluebeam muestra el Area en SF).
Además dibuja (contenido de página, no annot) los clusters de lateral bracing (4 splay wires + compression strut)
@12'-0" O.C. en cada dirección y a no más de 6'-0" del perímetro, como los cuenta el take-off, y la leyenda del RCP.
Escribe un PNG por hoja.

Entrada: polys.json = [{room, polygon [[x, y], ...] (coordenadas de la página TAL COMO SE VE, page.rect)}].
Uso:  python3 markups_rcp.py <markups.pdf> <takeoff_canon.json> <polys.json> <salida.pdf> <dir_png>
rc 0 = todos los ceilings con área del take-off tienen polígono; rc 1 = falta alguno (lista en stdout).
"""
import json
import math
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import markups_bluebeam as mb  # noqa: E402

RGB = (0.0, 0.55, 0.85)
BRACE_RGB = (0.85, 0.1, 0.55)
MT_AREA = 129            # /MeasurementTypes de un área de Bluebeam Revu
BOARD_TXT = {"5/8 type X": "5/8 GYPSUM BOARD TYPE X", "5/8 regular": "5/8 GYPSUM BOARD",
             "1/2 MR": "1/2 GYPSUM BOARD MOISTURE RESISTANT", "5/8 MR": "5/8 GYPSUM MOISTURE RESISTANT"}


def _area(p):
    return abs(sum(p[i][0] * p[(i + 1) % len(p)][1] - p[(i + 1) % len(p)][0] * p[i][1] for i in range(len(p)))) / 2


def _clusters(c):
    """Centros de los clusters de bracing (J/A12.02): ROUNDUP(ns/12) x ROUNDUP(ew/12) en ceilings usg_grid."""
    if c.get("system") != "usg_grid" or not c.get("ns_ft") or not c.get("ew_ft"):
        return 0, 0
    return math.ceil(float(c["ns_ft"]) / 12 - 1e-9), math.ceil(float(c["ew_ft"]) / 12 - 1e-9)


def escribir(pdf_in, canon_p, polys_p, pdf_out, dir_png):
    import pymupdf as fitz
    canon = json.load(open(canon_p, encoding="utf-8"))
    _pl = json.load(open(polys_p, encoding="utf-8"))
    polys = {p["room"]: p["polygon"] for p in _pl}
    causas = {p["room"]: p["cause"] for p in _pl if p.get("cause")}   # área dibujada != SF: causa escrita
    k = canon.get("constants") or {}
    hoja = k.get("rcp_sheet")
    hoja = hoja.get("value") if isinstance(hoja, dict) else hoja
    esc = mb.escala(canon, hoja)
    doc = fitz.open(pdf_in)
    pg = None
    for i in range(doc.page_count):
        if doc[i].get_label() == hoja:
            pg = i
    if pg is None:
        sm = k.get("rcp_page")
        pg = int(sm.get("value") if isinstance(sm, dict) else sm) - 1 if sm else None
    if pg is None:
        print(json.dumps({"error": f"no encuentro la página de la hoja {hoja} (constants.rcp_page)"}))
        return 1
    page = doc[pg]
    M = page.derotation_matrix
    falta, n, sf_tot, cl_tot = [], 0, 0.0, 0
    for c in canon.get("ceilings") or []:
        room, sf = c.get("room"), float(c.get("area_sf") or 0)
        if not sf:
            continue
        pts = polys.get(room)
        if not pts:
            falta.append(room)
            continue
        sub = BOARD_TXT.get(str(c.get("board") or ""), str(c.get("board") or "GYPSUM BOARD").upper())
        det = c.get("detail") or (c.get("system_callout") or {}).get("detail") or ""
        h = float(c.get("height_ft") or 0)
        cz = f" · cause: {causas[room]}" if room in causas else ""
        txt = f"{sub} · CEILING {room} · {sf:,.2f} SF · CLG {mb.ftin(h)}{cz} · {det} · {room}"
        a = page.add_polygon_annot([fitz.Point(x, y) * M for x, y in pts])
        a.set_info(title="take-off", subject=sub, content=txt)
        a.set_colors(stroke=RGB, fill=RGB)
        a.set_border(width=1.5)
        a.set_opacity(0.35)
        a.update()
        mb._nm(doc, a, "TO-" + room)
        if esc:
            mb._measure(doc, a, esc)
            doc.xref_set_key(a.xref, "IT", "/PolygonDimension")
            doc.xref_set_key(a.xref, "MeasurementTypes", str(MT_AREA))
        n += 1
        sf_tot += sf
        # clusters de bracing: rejilla regular dentro del rectángulo envolvente, a <= 6'-0" del perímetro
        nx, ny = _clusters(c)
        if nx and ny and float(c.get("area_sf") or 0) > 0:
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
            for i in range(nx):
                for j in range(ny):
                    cx = x0 + (x1 - x0) * (i + 0.5) / nx
                    cy = y0 + (y1 - y0) * (j + 0.5) / ny
                    page.draw_polyline([fitz.Point(cx, cy - 5) * M, fitz.Point(cx - 5, cy + 4) * M,
                                        fitz.Point(cx + 5, cy + 4) * M, fitz.Point(cx, cy - 5) * M],
                                       color=BRACE_RGB, fill=BRACE_RGB, width=0.8)
                    cl_tot += 1
    # leyenda del RCP
    box = fitz.Rect(40, 40, 470, 112)
    page.draw_rect(box * M, color=(0, 0, 0), fill=(1, 1, 1), width=0.8)
    lin = [f"TAKE-OFF LEGEND - {hoja} (gypsum board ceilings / soffits)",
           f"blue area = gyp bd ceiling / soffit: {n} areas, {sf_tot:,.2f} SF (Contents: board · room · SF · ceiling height · detail)",
           f"magenta triangle = lateral bracing cluster, (4) 12 GA splay wires + 3-5/8\" stud compression strut (J/A12.02): {cl_tot}",
           "measure: /Measure at the printed scale of the sheet; SF = Excel row 'ceiling <room>'"]
    for i_, t_ in enumerate(lin):
        page.insert_text(fitz.Point(box.x0 + 6, box.y0 + 14 + 14 * i_) * M, t_, fontsize=7.5 if i_ else 8.5,
                         fontname="hebo" if i_ == 0 else "helv", rotate=page.rotation)
    try:                                               # Page Label = hoja (columna Page Label de Bluebeam)
        reglas = list(doc.get_page_labels() or [])
        viejo = next((r for r in reglas if r["startpage"] == pg and r.get("style")), None)
        if viejo:                                      # la página arrancaba una numeración: la corre a pg + 1
            reglas.remove(viejo)
            if pg + 1 < doc.page_count and (pg + 1) not in {r["startpage"] for r in reglas}:
                reglas.append({"startpage": pg + 1, "prefix": viejo.get("prefix", ""), "style": viejo["style"],
                               "firstpagenum": viejo.get("firstpagenum", 1) + 1})
        if pg not in {r["startpage"] for r in reglas}:
            prev = max((r for r in reglas if r["startpage"] < pg), key=lambda r: r["startpage"], default=None)
            reglas.append({"startpage": pg, "prefix": str(hoja), "style": "", "firstpagenum": 1})
            if pg + 1 < doc.page_count and (pg + 1) not in {r["startpage"] for r in reglas} and prev and prev.get("style"):
                reglas.append({"startpage": pg + 1, "prefix": prev.get("prefix", ""), "style": prev["style"],
                               "firstpagenum": prev.get("firstpagenum", 1) + (pg + 1 - prev["startpage"])})
            doc.set_page_labels(sorted(reglas, key=lambda r: r["startpage"]))
    except Exception:                                  # noqa: BLE001
        pass
    doc.save(pdf_out, garbage=3, deflate=True)
    os.makedirs(dir_png, exist_ok=True)
    d2 = fitz.open(pdf_out)
    d2[pg].get_pixmap(dpi=110).save(os.path.join(dir_png, f"{hoja}_markups.png"))
    print(json.dumps({"hoja": hoja, "page": pg + 1, "areas": n, "sf_total": round(sf_tot, 2), "clusters": cl_tot,
                      "sin_poligono": falta}, ensure_ascii=False))
    return 1 if falta else 0


if __name__ == "__main__":
    if len(sys.argv) != 6:
        print(__doc__)
        sys.exit(2)
    sys.exit(escribir(*sys.argv[1:]))
