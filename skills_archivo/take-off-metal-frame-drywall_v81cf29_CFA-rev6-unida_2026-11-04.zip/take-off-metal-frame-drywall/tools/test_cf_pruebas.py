#!/usr/bin/env python3
"""test_cf_pruebas.py — pruebas de CFA #2284 unidas (BE-CF14 driver de finishing, BE-CF16 barrido de RFI, BE-CF19 hoja de la demo). Cada bloque corre aislado."""
import os, sys, runpy, tempfile
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
BLOQUES = {}
BLOQUES['test_board_driver'] = r'''
#!/usr/bin/env python3
"""test_board_driver.py — BE-CF14: toda familia de gypsum board de canon entra al driver de finishing (compound / tape),
salvo cement board, ballistic panel y sheathing exterior."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import canon, accesorios
fuera = ("cement", "ballistic", "EXTERIOR", "glass mat", "FRT", "1/4")
gyp = [f for f in canon.BOARD_FAM.values() if "gyp" in f.lower() and not any(x in f for x in fuera)]
falta = [f for f in gyp if f not in accesorios.BOARD_DRIVER]
assert not falta, f"familias de gypsum board fuera del driver de finishing: {falta}"
print("test_board_driver OK")
'''
BLOQUES['test_rfi_barrido'] = r'''
#!/usr/bin/env python3
"""test_rfi_barrido.py — R80f.6 / BE-CF16: RFI abierto sin barrido completo = falla."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reglas as R
malo = {"rfis": [{"id": "RFI-01", "pregunta": "height?", "delta": "x"}]}
assert R.rfi_barrido_fallas(malo)
bueno = {"rfis": [{"id": "RFI-01", "pregunta": "height?", "delta": "x",
                   "barrido": {"hojas": "ALL", "terminos": ["B.O.", "DECK", "JOIST"], "grep": "set_text.txt: 0 hits"}}]}
assert not R.rfi_barrido_fallas(bueno), R.rfi_barrido_fallas(bueno)
cerrado = {"rfis": [{"id": "RFI-02", "estado": "CLOSED - estimator decision (option A)"}]}
assert not R.rfi_barrido_fallas(cerrado)
print("test_rfi_barrido OK")
'''
BLOQUES['test_demo_hoja_geom'] = r'''
#!/usr/bin/env python3
"""test_demo_hoja_geom.py — BE-CF19: la hoja de un renglón de demolición sale de su demo_geom, no de la hoja que cita
la fuente de su altura (S-201 / A4/S-601 / "TJI/L65")."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import verificar_markups_excel as V
canon = {"misc_items": [{"ref": "DEMO-02", "familia": "demolition - gypsum board and metal framing", "qty": 100,
                         "source": "KN3 A-050; height:: B.O. 16 in TJI/L65 joists (S-201) = 12.17 ft"},
                        {"ref": "DEMO-04", "familia": "demolition - gypsum board and metal framing", "qty": 50,
                         "source": "KN3 A-050; height: PSL 12.25 ft (A4/S-601)"}],
         "demo_geom": [{"id": "DEMO-02", "sheet": "A-050", "page": 6}, {"id": "DEMO-04", "sheet": "A-050", "page": 6}]}
_, hojas, _ = V.indice_canon(canon)
assert set(hojas) == {"A-050"}, hojas
canon2 = {"misc_items": [{"ref": "DEMO-09", "familia": "demolition - gypsum board and metal framing", "qty": 10,
                          "source": "KN3 A-050; height: B.O. (A4/S-601)"}]}
_, h2, _ = V.indice_canon(canon2)
assert "S-601" not in h2, h2
print("test_demo_hoja_geom OK")
'''
BLOQUES['test_cf_rev6_dia1'] = '#!/usr/bin/env python3\n"""test_cf_rev6_dia1 - BE-CF21 (CFA #2284 rev6, 3-nov): false positives / gaps the day-1 gate (U-114..U-125) found in CFA rev5.\nEach case: the real error still fails; the false positive no longer does. U-117 reads existing_walls[] tag_ids and the canon\ntags_descartados; U-120 looks only at the markup Wall ID (not keynotes / sheets of the source); markups_demo: area = Polygon,\na bent polyline = one piece per axis; R80e.84 allows the DELIVERED image (proceso/review_img) in Review Items."""\nimport os, sys, tempfile\nsys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))\nimport chequeos_biblioteca as CB\nimport markups_demo as MD\nimport plantilla_excel as PE\nfrom PIL import Image\nd = tempfile.mkdtemp()\npng = os.path.join(d, "PT0001.png")\nImage.new("RGB", (40, 40), (255, 0, 0)).save(png)\noc = [{"id": "PT0001", "type": "W6", "sheet": "A-202", "png": png, "png_verificado": True, "kind": "partition_tag"},\n      {"id": "PT0002", "type": "W6", "sheet": "A-202", "png": png, "png_verificado": True, "kind": "partition_tag"}]\ninv = {"ocurrencias": {"partition_tag": oc}}\nwalls = [{"id": "M1", "element": "wall", "tag_ids": []}]\nok = {"walls": walls, "existing_walls": [{"id": "W6-01-CB", "tag_ids": ["PT0001"]}],\n      "tags_descartados": [{"id": "PT0002", "motivo": "legend text of the WALL TYPE SCHEDULE (not a plan tag)"}]}\nr = CB.u_117(CB.B(canon=ok, inv_full=inv))\nassert r[0] == "PASS", r\nmal = {"walls": walls, "existing_walls": [{"id": "W6-01-CB", "tag_ids": ["PT0001"]}]}\nassert CB.u_117(CB.B(canon=mal, inv_full=inv))[0] == "FAIL"\na_ok = [{"label": "A-202", "subject": "BOARD ONLY", "tipo": "PolyLine", "verts": [(0, 0), (50, 0)],\n         "contents": "BOARD ONLY - NO FRAMING \\u00b7 7.90 LF \\u00b7 H 14 ft \\u00b7 G.2/A-202 + A-622 D3/D4 \\u00b7 KN3 + KN4 \\u00b7 W6-01S-SRV"}]\nr = CB.u_120(CB.B(annots=a_ok))\nassert r[0] == "PASS", r\na_mal = [dict(a_ok[0], contents="BOARD ONLY \\u00b7 7.90 LF \\u00b7 A-202 \\u00b7 W6-01 & W6-02")]\nassert CB.u_120(CB.B(annots=a_mal))[0] == "FAIL"\na_l = [dict(a_ok[0], verts=[(0, 0), (50, 0), (50, 50)])]\nassert CB.u_120(CB.B(annots=a_l))[0] == "FAIL"\nassert MD.es_area({"polyline": [[0, 0], [10, 0], [10, 10], [0, 10], [0, 0]], "h_ft": 0, "group": "ceilings"})\nassert not MD.es_area({"polyline": [[0, 0], [10, 0]], "h_ft": 12})\npz = MD.piezas_por_eje([(0, 0), (80, 0), (80, 150)])\nassert len(pz) == 2 and pz[0][-1] == pz[1][0], pz\nassert len(MD.piezas_por_eje([(0, 0), (80, 0), (160, 0)])) == 1\nimport openpyxl\nwb = openpyxl.Workbook()\nws = wb.active\nws.title = "Review Items"\nws["F3"] = "proceso/review_img/r02_S241_A2.png"\nassert not PE.verificar_texto_cliente(wb), PE.verificar_texto_cliente(wb)\nws["F4"] = "img_rev4/r02.png"\nassert PE.verificar_texto_cliente(wb)\ndel ws["F4"]\nws2 = wb.create_sheet("Scope Checklist")\nws2["B2"] = "proceso/review_img/r02.png"\nassert PE.verificar_texto_cliente(wb)\nprint("test_cf_rev6_dia1 OK")\n'
for nombre, codigo in BLOQUES.items():
    ns = {"__name__": "__main__", "__file__": os.path.join(AQUI, nombre + ".py")}
    exec(compile(codigo, nombre, "exec"), ns)
print("test_cf_pruebas OK")
