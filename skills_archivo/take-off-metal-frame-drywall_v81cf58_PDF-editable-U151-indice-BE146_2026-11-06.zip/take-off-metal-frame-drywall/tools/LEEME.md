# Herramientas v61 candidatas (2026-10-16)

Cinco herramientas deterministas para el skill take-off metal frame / drywall. Implementan las reglas 60.3–60.10 de ADENDA_v60 / ARBITRAJE_10.
Son **genéricas**: no llevan datos de ningún proyecto. Los tests usan datos inventados.

Se usan igual que `studs_nodos.py` y `board_caras.py`. **El agente solo declara datos leídos del plano. La tool hace el cálculo.**

## Contrato común (las 5)

- **Uso:** `python3 <tool>.py <entrada.json> <salida.json>`. Solo stdlib.
- **Códigos de salida:**
  - rc 0 = OK. Escribe la salida y muestra los totales en stdout.
  - rc 1 = la entrada viola el contrato. Muestra `ERROR <tool>: <motivo>` en stderr y **no escribe la salida**.
  - rc 2 = uso incorrecto.
- **`source`:** todo renglón lleva `source` con forma N/HOJA. Ejemplos: `6/A12.01`, `D/A9.22`, `F/1/S5.20`, o la hoja sola (`E00.01`). Se aceptan varias fuentes separadas por `,` `;` o `·`. Si falta o está mal → rc 1. La salida copia la `source` tal como vino.
- **Formato de la salida:** totales por familia, más un renglón por elemento con `source` y `operacion` (la fórmula escrita con sus números).
- **Repetidos:** un id o elemento repetido → rc 1. Cada cosa se cuenta una vez.

## 1. headers.py — reglas 60.5 y 60.10

**Entrada:**
- `openings[]`:
  - `ref`, `wall`
  - `kind`: door | window | storefront | opening | duct | recessed_accessory
  - `location`
  - `ro_w_ft`
  - `qty` (entero, aberturas iguales)
  - `with_sill`
  - `header_type` + `header_type_source` (opcionales)
  - `source`
- `header_schedule{source, rows[{max_span_ft, type}]}` — opcional
- `stud_bay_in` — default 14.375; si se cambia, exige `stud_bay_source` <!-- [ciego-ok] criterio genérico -->

**Fórmula:**
- header LF = (R.O. + 1'-4") × 1 × qty
- sill track LF = (R.O. + 1'-4") × qty, solo si `with_sill`

**Tipo de header:**
- Sale de `header_type` o de la primera fila del schedule con `max_span_ft` ≥ R.O.
- **Va solo en la descripción.**
- Si no hay tipo → `TYPE PENDING` + RFI en `avisos`. El LF no cambia.

**Rechazos (rc 1):**
- Campo `members`, `multiplier`, `plies` o `x_members` (los members no multiplican el LF).
- `kind` = `recessed_accessory` (va a framed_openings.py).

**60.10:** si R.O. ≤ stud bay → `FITS_MODULE`, 0 LF. <!-- [ciego-ok] criterio genérico -->

**Salida:** `totales_lf{header, sill track}`, `renglones[]`, `avisos[]`.

## 2. corridas.py — reglas 60.6, 60.7, 60.8 y 53.4

**Entrada:**
- `runs[]`:
  - `id`, `element`
  - `orientation`: vertical | horizontal
  - `length_ft`
  - `height_ft` (en vertical)
  - `rows`
  - `track_lines` (solo en horizontal)
  - `bottom_track` / `top_track` + `track_source`
  - `bracing_rows` + `bracing_rows_source` (opcional)
  - `source`
- `bracing{spacing_in, source}`
- `section_details[{source, runs}]`

**Elementos permitidos por orientación (60.8):**
- Solo vertical: wall, parapet, column_wrap, canopy_framing, vestibule_head, grille_head, grille_box, door_bulkhead, soffit_drop, chase.
- Solo horizontal: ceiling, soffit_bottom, joist, fascia_box, canopy_soffit.
- Los dos: bulkhead, other.
- Un elemento con la orientación equivocada → rc 1.

**Fórmulas:**
- Vertical:
  - bottom/top track = L × rows × 2
  - bracing rows = `bracing_rows` declarado, o si no ROUNDUP(H × 12 / spacing_in) − 1, mínimo 0
  - bracing C.R. channel = bracing rows × L × rows
- Horizontal:
  - ceiling/soffit track = L × track_lines
  - sin bracing

**60.6:** el número de corridas que citan un `section_details.source` debe ser igual a `runs`. Si no → rc 1.

**60.7:** una corrida vertical sin `bracing.spacing_in` y sin `bracing_rows` con fuente → rc 1. Así, ninguna corrida queda sin bracing por olvido.

**Salida:** `totales_lf{bottom/top track, ceiling/soffit track, bracing C.R. channel}`, `renglones[]`.

## 3. altura_stud.py — reglas 60.3 y 59.13

**Formato de los números:** todo número va como `{"value", "source"}`. Si no → rc 1.

**Entrada:**
- `bod_table{source, points[{y_ft, bod_ft}]}`
- `beams{nombre: {d_in{value, source}}}`. La fuente del peralte puede ser texto libre, por ejemplo `AISC W12X26`.
- `walls[]`:
  - `id`
  - `type`: exterior | interior
  - `y_ft`, y opcional `y_to_ft` (wall con pendiente), **o** `bod_ft`
  - `stops_under_beam{value: bool, source}` — obligatorio en exterior
  - `beam`

**Fórmula:**
- B.O.D.(y) = interpolación lineal en la tabla. No extrapola.
- H = B.O.D. − d/12, si `stops_under_beam`.
- H = B.O.D., si no.
- Wall con pendiente: `height_ft` = lado alto (53.2) y `height_avg_ft` = promedio.

**Salida:** `resumen_por_tipo{exterior|interior: walls, min_ft, max_ft}`, `renglones[]` (con todas las fuentes usadas). El `height_ft` de la salida es el que se le pasa a studs_nodos.py.

## 4. framed_openings.py — reglas 60.9, 60.10 y 58.4

**Entrada:**
- `modules`:
  - `wall_stud_bay_in` — default 14.375 <!-- [ciego-ok] criterio genérico -->
  - `ceiling_furring_oc_in{value, source}` — obligatorio si hay items de ceiling
- `items[]`:
  - `tag`, `category`
  - `location`: ceiling | wall
  - `shape`: rect | round
  - `qty`
  - `width_in`
  - `length_ft{desc, catalog, drawn}`
  - `length_override{value, source, rfi}`
  - `source`

**Largo (60.9):**
- Si desc ≠ catalog, se carga el que coincide con drawn.
- Se agrega un RFI con delta = 2 × (otro − cargado) × qty.
- Si el dibujo no lo resuelve → rc 1, salvo que venga `length_override` con fuente y texto de RFI.

**Módulo (60.10):** si max(ancho, largo) ≤ módulo → `FITS_MODULE`, 0 LF. <!-- [ciego-ok] criterio genérico -->

**Wall que no cabe en el stud bay:** queda en `TO_HEADER_SILL` (58.4) con 0 LF aquí, y aparece en la lista `to_header_sill` para pasarla a headers.py. <!-- [ciego-ok] criterio genérico -->

**Fórmula:**
- rect: LF = 2 × (L + W) × qty
- round: LF = 4 × d × qty

**Salida:** `totales_lf{framed openings MEP}`, `renglones[]`, `rfis[]`, `to_header_sill[]`.

## 5. alcance_filtro.py — regla 60.4

**Entrada:**
- `rows[]`:
  - `id`, `family`, `description`, `qty`, `unit`, `source`
  - `substrate_of` (drywall | cladding) + `substrate_source` — opcionales

**Clasificación:**
- **Siempre cladding:** Z-girt, girt, lath. Va a EXCLUDED.
- **Cladding por contexto:** hat channel / furring / channel + metal panel / ACM / stucco / EIFS / EPS-n / cladding / rainscreen / siding / fiber cement. Va a EXCLUDED.
- **hat channel sin contexto:** rc 1. El agente tiene que declarar `substrate_of` con fuente, porque el furring channel 7/8" de drywall también es un hat channel.
- **Declaración que contradice:** `substrate_of: drywall` en un Z-girt o lath → rc 1.

**EXCLUDED:**
- La qty sale de los totales de su familia, así que nunca queda en furring channel.
- Lleva un RFI en inglés con delta = qty.

**Salida:** `totales_incluidos{"family [unit]"}`, `excluidos[]`, `rfis[]`, `renglones[]`.

## Resultado de tests (2026-10-16)

| Tool | Tests | Resultado |
|---|---|---|
| headers.py | 12 | OK |
| corridas.py | 13 | OK |
| altura_stud.py | 11 | OK |
| framed_openings.py | 11 | OK |
| alcance_filtro.py | 8 | OK |

**Total: 55/55 OK.** El detalle está en `tests.log`.

**Cómo prueban los tests:**
- Cada suite tiene casos con datos buenos, casos de borde y casos con datos malos.
- Casos de borde: R.O. exactamente igual al stud bay, H múltiplo exacto de 48", y y en el extremo de la tabla.
- Los casos con datos malos tienen que dar ValueError y rc ≠ 0 por CLI.

**Mutaciones (`mutaciones.log`):** rompí cada regla clave de cada tool y la suite falló las 10 veces de 10:
- header × 2 members
- sin 60.10
- sin 60.6
- bracing sin el −1
- sin 60.8
- stud a B.O.D.
- exterior sin declarar viga
- framed sin 60.10
- framed carga el catálogo
- cladding sin contexto

## Puntos de ARBITRAJE_10 que no son fórmula exacta

1. **Purlin "0.75 × L si track paralelo al flute"** (tabla de herramientas, corridas.py). Ni ARBITRAJE_10 ni la adenda definen de dónde sale el 0.75, en qué unidad está, ni a qué familia va. **No se implementó.** Hace falta que lo defina la regla.
2. **"bottom+top = L × rows".** Se tomó así: cada corrida lleva bottom **y** top, y cada uno vale L × rows, o sea 2 × L × rows (60.6: "cada una lleva su bottom y top track"). Si la referencia quería decir L × rows en total, el número de la familia sale a la mitad. Hay que confirmarlo con una corrida conocida.
3. **Ceiling/soffit track de framing horizontal.** El ARBITRAJE no da fórmula. La tool exige `track_lines`, declarado por el agente con su fuente.
4. **53.4 bracing.** Se usó la fórmula de la tabla del ARBITRAJE: ROUNDUP(H/4) − 1. El espaciado (48") no se fija en la tool: viene de `bracing.spacing_in` con su fuente, porque cambia según el proyecto. La adenda no trae un umbral aparte para el "parapet ≥ 4 ft": con H = 4 ft la fórmula ya da 0 rows.
5. **60.10 en ceiling.** "Cabe en el módulo" se tomó como max(largo, ancho) ≤ espaciado del furring. Por eso un slot largo y angosto sí lleva framed opening. Esto coincide con el veredicto del arbitraje: slots contados, downlights de 3.5" no.

## v72b — compuerta de reglas inviolables

`reglas.py compuerta <work_dir> [--excel <final.xlsx>]` revisa TODAS las reglas del skill (catálogo de
`reglas_catalogo.py`, tipo en `reglas_clasificacion.py`). `plantilla_excel.py armar` la corre y no escribe el Excel
sin OK; `etapas.py compuerta` y `bitacora.py compuerta` también. Tests: `test_reglas.py` (un test por regla),
`test_ciego_tools.py` (E24 en las tools). `fixture_reglas.py` = proyecto sintético mínimo que pasa la compuerta.

- revision_markups.py (R80e.136, 3-nov-2026, O'Reilly): revisión rápida de markups vs Excel (VERDE/ROJA + recortes + mapa de alturas). Uso: revision_markups.py markups.pdf takeoff.xlsx out --scale A1.1=1/8 --canon takeoff_canon.json --order <schedule>. Test: --selftest (llamado por test_markups_excel.py).

- R80e.137 (BE-113, 3-nov-2026): studs_nodos.py jambs = 0 en walls de furring (FURRING_RX); closer.py acepta el conteo (Wall.furring o 'R80e.137' en la operación del STUD). Test: test_project_data.py.

- R80f.17–R80f.28 (HFT Loveland, 3-nov-2026, v81cf21): tool fixes BE-HF1..BE-HF17 en canon.py (hat channel z_kind, MISC_ALIAS, furring_sin_bracing, bracing_min_altura, braces_to_structure, track_by_element de heads), familias.py, plantilla_excel.py, reglas.py (A_BRACING spacing impreso, A_HEADER_LF con misc box beams), trazabilidad.py, partition_types.py (partition_row_rule wall_id, BULKHEAD-<tag>), markups_bluebeam.py, markups_demo.py, auditoria_entrega.py (--rfis-abiertos), vigas_sobre_walls.py (--min-size). Tests: test_hft_loveland.py (11 bloques).

- R80e.138 (BE-119, 3-nov-2026): revision_markups.py — columna 'Printed source H' (altura impresa de la cita de la fuente) vs Depth; ROJO si difiere, ÁMBAR si no hay altura impresa o depende de un supuesto (RFI).


---

# README_etapas.md (unido aquí en v81cf58 para quedar < 200 archivos al agregar quitar_firmas_labels.py; texto literal del archivo original)

# Etapas 1 y 3 — inventario por script y doble lectura comparada

Herramientas nuevas, aparte de las tools v68 (no las modifican). Python 3 + pymupdf (+ numpy).

**v70 — nombre de la Etapa 1:** el inventario de tags por script es `inventario_tags.py` (+ `test_inventario_tags.py`).
En v69 se llamaba `inventario.py` y, al copiarlo encima de las tools, tapaba a **`inventario.py` = inventario cerrado
de WALLS** (bandas, solapes, apilados, MR, purlin, zonas; v63) que `canon.py` importa (`inventario.verificar`,
`inventario.PURLIN_ELEMS`) y que `bitacora.py` exige. Los dos conviven: `inventario_tags.py` = Etapa 1 (tags del
PDF), `inventario.py` = verificación de walls dentro de `canon.py`. `test_sin_colisiones.py` falla si vuelven a
chocar. Las salidas de la Etapa 1 siguen siendo `1_inventario/inventario.json` + `inventario.md` + `recortes/`.
Son GENÉRICAS: ningún tag, hoja, coordenada ni nombre de proyecto vive en el código; todo sale del PDF.

## Por qué

En pruebas ciegas la misma versión del skill dio resultados distintos entre corridas (partition types con
conteos de walls distintos para el mismo type). La causa: el inventario de tags y la partición de walls
los hacía el modelo a ojo. Estas herramientas sacan esa parte del ojo y hacen visible cualquier diferencia.

## Cadena

```
plano.pdf
   │
   ▼
1. inventario_tags.py plano.pdf inv/       → inv/inventario.json + inventario.md + recortes/
   │   (índice de hojas, types del schedule, cada tag con hoja + coordenadas + PNG circulado y verificado)
   │
   ├──────────────────────────────┐
   ▼                              ▼
2A. lectura A (independiente)   2B. lectura B (independiente)
    takeoff_canon_A.json            takeoff_canon_B.json
   │   (cada lectura parte del MISMO inventario; ninguna ve a la otra)
   └──────────────┬───────────────┘
                  ▼
3. comparar.py canon_A.json canon_B.json inv/inventario.json rev/   → rev/revision.md + revision.json + img/
                  │   (usa particion.py con la misma regla para las dos)
                  ▼
   el estimador resuelve cada renglón de revision.md → UN canon final
                  ▼
4. canon.py takeoff_canon.json out/   (tools v68, sin cambios)
                  ▼
5. plantilla_excel.py → Excel
```

## Qué revisa el estimador (y solo eso)

`revision.md` (en inglés) trae:

1. **Matching walls** — una línea por type: walls que coinciden (|ΔLF| ≤ 2 %), walls y LF de A y de B, y
   cuántos tags encontró el inventario. No hay que revisarlas.
2. **Items to review** — lista numerada, cada uno con hoja y su imagen (A = azul, B = naranja):
   - *LF differs*: mismo wall en las dos lecturas con más de 2 % de diferencia (delta en LF y %).
   - *only in reading A / only in reading B*: un wall que una lectura vio y la otra no.
   - "matched by LF only (no geometry)": el wall no trae `band`; el emparejamiento es más débil.
3. **Alerts** (cruce con el inventario):
   - *TAG SIN WALL*: tag del plano que ninguna lectura tomó → falta un wall.
   - *TYPE NO INVENTARIADO*: una lectura usa un type que no está en el schedule (o el tag está en el plano
     pero no en el schedule → RFI).
   - *WALL SIN TAG EN LA HOJA*: wall de un type en una hoja donde el inventario no encontró ese tag.

En el inventario, además: `inventario.md` → tabla type × hoja, lista numerada de cada tag contado con su
recorte, vista de la hoja con todos los tags circulados y numerados, la lista de **ambiguos (NO contados)** con
su motivo, los tags en símbolo que **no están en el schedule**, y las hojas **NO INVENTARIABLES POR SCRIPT**
(raster). Lo ambiguo nunca se cuenta en silencio: se lista para que el estimador decida.

## Herramientas

| Archivo | Qué hace | Test |
|---|---|---|
| `inventario_tags.py <pdf> <out_dir> [--dpi 150] [--sin-recortes]` | Etapa 1: índice de hojas (title block), types del schedule (títulos "PARTITION TYPE …" + columnas de la hoja de schedule), ocurrencias (partition tags, ambiguos, candidatos fuera de schedule, door / window tags, detail bubbles N/HOJA, referencias N/HOJA en texto, keynotes, cotas), conteo por type y hoja, recorte PNG por ocurrencia con el tag circulado y **verificado al reabrirlo** (anillo rojo en su lugar, tinta del tag en el centro, texto bajo la marca = el tag) y una vista por hoja de planta. Coordenadas en pt de la página ROTADA (como el PNG). Ids únicos en todas las listas (v70): `PT` tag contado, `PA` ambiguo, `PC` candidato fuera del schedule (con su propio recorte verificado), `PX` texto fuera de planta, `DW` door / window, `DB` / `DR` detail bubble / referencia en texto, `KN` keynote, `CO` cota. Sale con código 1 si algún PNG no verifica. | `test_inventario_tags.py`, `test_inventario_tags_v70.py` |
| `particion.py canon.json [--modo run\|tramo] [salida.json]` | Regla de partición de walls como parámetro: **tramo** = un wall por tramo recto (colineales ≤ 3" y contiguos ≤ 6" se unen; jog ≤ 1'-0" se suma al vecino); **run** = un wall por run continuo aunque tenga quiebres (los tramos se encadenan extremo con extremo; una T no encadena). Nunca une hojas ni types distintos. v70: default **run**; `door_bulkhead` = type `BULKHEAD-<familia>` (G1 → G; nunca se une con sus walls G / G1); unión por componentes conexas (no depende del orden). v70c: Excepción: walls exteriores y parapets se cortan por fachada/eje (nunca juntar dos ejes o fachadas). | `test_particion.py`, `test_particion_v70.py` |
| `comparar.py A.json B.json inventario.json out_dir [--modo] [--pdf] [--radio-ft 5]` | Etapa 3 (arriba). v70: los candidatos `PC####` entran al cruce (sin wall → alerta "tag sin wall"); rechaza (rc 1) una lectura con `page` 0-based. | `test_comparar.py`, `test_etapas_v70.py` |
| `etapas.py estado\|compuerta <dir>` · `etapas.py unir <carpeta> <canon.json> [--inventario inv.json]` (v69, v70) | Dónde quedó la corrida (reanudar); compuerta de etapas (falla si falta inventario / canon A / canon B / revisión, si la revisión está vencida o no cubre el inventario, o si un tag —incluidos los candidatos `PC`— queda sin wall y sin alerta); unión de los fragmentos de una lectura. v70 `unir`: tipo distinto entre fragmentos = ERROR (sin crash); `notes` distintas → `{fragmento: texto}` + aviso; convención de `band` (caras ≤ 2 ft, largo ±3 % / 1 ft o `band_length_ok_reason`, "banda traspuesta"); `page` 1-based contra el inventario; refs de openings contra `opening_schedule` (la tarea de openings fija las refs primero, Etapa 2a). | `test_etapas.py`, `test_etapas_v70.py` |
| `test_ciego_v69.py <SKILL.md\|carpeta>` (v69) | E24 genérico sobre el skill. | autoprueba |
| `test_sin_colisiones.py [carpeta]` (v70) | Falla si `canon.inventario` no es el inventario de walls (`verificar`, `PURLIN_ELEMS`), si `inventario_tags` no expone `inventario()`, o si un módulo de la carpeta no expone los nombres que otros módulos leen de él. | autoprueba |

### La regla de partición: una sola constante

`particion.py`: `MODO_DEFAULT = "eje"` (v71, E28: un wall = una línea recta de un type; esquina / jog / T entre dos
líneas con tag corta; segmento sin tag se suma al wall con tag que toca; grupo sin tag = un wall; exteriores y
parapets por eje / fachada). Cada wall del canon lleva `tag_ids`. "run" (v70) y "tramo" quedan como opciones
(`--modo run|tramo` en `particion.py` / `comparar.py`). Las dos lecturas SIEMPRE se parten con la misma regla dentro de `comparar.py`.

## Campos del canon que usan estas herramientas

Del `takeoff_canon.json` v68, en `walls[]`: `id`, `tag`, `length_ft`, `element` (los no-partition van a
"other framing"), `band {ori, c0, c1, lo, hi}` en pt de la hoja, `constants.plan_scale_pt_per_ft`.
Campos opcionales que conviene escribir en cada lectura:

- `sheet` (sheet number de la planta donde está el wall). Si falta, se toma el primer sheet number de `source`.
- `page` (página del PDF, **1-based** como el visor) cuando el set repite un sheet number en varias páginas.
  `etapas.py unir` y `comparar.py` rechazan `page` = página del inventario − 1 (0-based).
- `band` con la convención `{ori, c0, c1 (caras, perpendicular), lo, hi (extensión)}` en pt de la hoja.
- `tag_ids`: los ids del inventario (`PT0012` …) del tag que la lectura usó para ese wall. Con eso el cruce
  tag ↔ wall es exacto; sin eso se hace por distancia (`--radio-ft`, default 5 ft).

`canon.py` los reconoce como campos del esquema (`canon.WALL_KEYS`). v70: una clave de wall fuera del esquema
CON números = error en `canon.py` (nombra el campo correcto, p. ej. plywood → plywood_strips); sin números = aviso;
los sufijos `_info`, `_note`, `_check`, `_source`, `_status`… marcan traza que ninguna tool lee.

## Límites conocidos

- Solo lee texto vectorial. Hojas raster (escaneadas) = "NO INVENTARIABLE POR SCRIPT"; un tag dibujado como
  líneas (texto vectorizado) no se ve.
- El sheet number se busca en el cuadrante inferior derecho; title blocks en otra posición (p. ej. civiles con
  el número vectorizado) quedan "sheet number NO IDENTIFICADO" (se citan por página).
- Types del schedule: hace falta un título "PARTITION [TYPE] …" / "WALL TYPE …" o una hoja de schedule cuyo
  título diga PARTITION / WALL TYPE. Si el schedule es raster o no tiene esos rótulos, no hay types y el
  inventario lo avisa.
- Tags de una sola letra (X, Y, Z…) se parecen a grid bubbles y letras de sellos: solo cuentan si el tamaño de
  letra y el radio del símbolo coinciden con los tags de varios caracteres de ESA hoja; si no, van a ambiguos.
- Dos tags iguales encimados (dos tags del mismo type a menos de un símbolo) se cuentan los dos y se marcan "SUPERPUESTO":
  ¿duplicado o dos walls? lo decide el estimador.
- Door / window tags, keynotes y cotas son candidatos por patrón (no se cruzan con su schedule salvo doors).
- `comparar.py` empareja por solape de bbox; dos walls distintos del mismo type pegados pueden emparejarse
  cruzados. El delta queda visible en la imagen.
- Sin `band` en un wall: emparejamiento solo por LF (≤ 10 %) y no se puede cruzar contra la posición del tag.
