#!/usr/bin/env python3
"""compuerta_entrega.py — BE-121 (usuario 3-nov, INVIOLABLE): COMPUERTA DE ENTREGA por programa.

Toda regla inviolable de categoría "programa" (REGLAS_REGISTRO.json, cuando = "entrega") se revisa AQUÍ, por el FONDO,
antes de entregar. Ninguna entrega sale sin este programa en verde y sin subir_entrega.py (que se niega a subir sin
ENTREGA_OK.json verde y vigente). No hay flag de override.

Uso:
  python3 compuerta_entrega.py <project_workdir> [--entrega entrega.json]
      Busca en <project_workdir> (o lo que diga entrega.json): la carpeta de entrega FINAL_FOR_REVIEW* (Take-off/*.xlsx,
      Planos marcados/*.pdf + *.png, README_REVIEW.md, PARA_REVISAR_EN_LA_MANANA.md, SEGUIMIENTO.md), takeoff_canon.json,
      takeoff.json, TIEMPOS.md, set_texto.json (texto completo del set incl. AutoCAD SHX) y entrega.json
      ({"drive": {"parent_id", "carpeta_proyecto", "carpeta_proyecto_id"}, "escalas": {"A1.1": "1/8"}, ...}).
      Escribe <project_workdir>/ENTREGA_OK.json (PASS / FAIL / AMBER por chequeo con sus reglas y evidencia + sha256 de
      cada archivo entregable). rc 0 = sin FAIL; rc 1 = al menos un FAIL.
  python3 compuerta_entrega.py texto <bidset.pdf> [<otro.pdf> ...] --out <set_texto.json>
      Extrae por PROGRAMA el texto de cada hoja (texto + contenido de anotaciones, p. ej. "AutoCAD SHX Text") con su
      número de hoja (title block). Lo usa el chequeo BE-120.

Chequeos (id → reglas): ver CHEQUEOS abajo y REGLAS_REGISTRO.json. AMBER no bloquea pero se reporta.
"""
import datetime
import glob
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

VERSION = "compuerta_entrega v2 (BE-121 + biblioteca + CE_CALLOUTS, 3-nov-2026)"
DRIVE_RAIZ = "1UReOABlgJPIkGLe8-nRO6U-6i7xpKoIc"          # Shared drives › JC HUNTER PROJECTS › Claude outputs (raíz)
DRIVE_PROHIBIDO = "1rUgu9cFt59LWzuoCUbFPrEjyNXB6ot5h"      # Projects › Claude outputs (PROHIBIDO)
HOJAS6 = ["Inputs", "Partition Takeoff", "Material Summary", "Pending Items", "Review Items", "Scope Checklist"]
CABECERAS = {   # (fila, encabezados) del formato fijo de plantilla_excel.py (idéntico en todas las entregas)
    "Inputs": (4, ["PARAMETER", "VALUE", "NOTE / SOURCE"]),
    "Partition Takeoff": (4, ["Partition / Scope", "Wall #", "Length (LF)", "Height (FT)", "Layers", "Stud Size",
                              "Stud O.C. (in)", "Board (SF)", "Location", "Source (DETAIL/SHEET)", "Status"]),
    "Material Summary": (3, ["Material", "Unit", "Net", "Waste %", "Waste", "Purchase", "Selling unit", "Pieces to buy",
                             "Where it comes from", "Yield check (live formula)"]),
    "Pending Items": (1, ["RFI", "Question / condition", "Delta of each alternative"]),
    "Review Items": (2, ["#", "Phase", "Type / order", "Item", "Sheet + detail", "Image"]),
    "Scope Checklist": (1, ["Scope ID", "Scope", "Status", "Note (quantity, NOT APPLICABLE + sheet, or RFI)"]),
}
PASOS_TIEMPOS = list(range(1, 10))      # pasos 1–9 con hora (10 = subida, ocurre después de esta compuerta)
RX_FT = re.compile(r"\d+\s*'\s*-?\s*\d+(?:\s+\d+/\d+)?\s*\"?|\bEL\.?\s*\d|\d+(?:\.\d+)?\s*(?:ft|FT)\b")
RX_HOJA = re.compile(r"^[A-Z]{1,3}-?\d{1,3}(?:\.\d{1,2})?[A-Z]?$")
RX_FASTENER = re.compile(r"(?i)\bscrews?\b|\banchors?\b|titen|tapcon|\bbolts?\b|slab pins?|\bP\.?A\.?F\.?\b|"
                         r"power[- ]driven|\bfasteners?\b|kwik|x-?edni|\bpins?\b")
RX_SLIP = re.compile(r"(?i)slip|deflection|deep[- ]leg|slotted")
RX_TRACK = re.compile(r"(?i)\btrack\b")
RX_CERRADO = re.compile(r"(?i)closed|cerrad|estimator decision|resuelt")
# BE-121 / R-ALC-01/03/05/07 / U-053 / U-061: temas que por orden del usuario NUNCA son RFI
RFI_PROHIBIDOS = [
    ("tornillería (U-053: EXCLUDED sin RFI)", RX_FASTENER),
    ("trade que no hacemos (U-061 / R-ALC-01)", re.compile(
        r"(?i)\bACT\b|acoustical (?:ceiling|tile)|insulation|stucco|roofing|cabinet|casework|millwork|\bwood\b|"
        r"\bFRT\b|plywood|Div\.?\s*0?6\b")),
    ("ductos (R-ALC-03)", re.compile(r"(?i)duct (?:penetration|opening|sleeve)s?|(?:framed )?openings? (?:for|at) ducts?")),
    ("demolición de cielo existente sin tipo (R-ALC-05)", re.compile(r"(?i)existing\s+(?:\w+\s+){0,3}ceilings?.{0,60}(?:demo|remov)|(?:demo|remov)\w*.{0,60}existing\s+(?:\w+\s+){0,3}ceilings?")),
    ("altura de partition existente a demoler (R-ALC-07)", re.compile(r"(?i)(?:demo|remov|existing)\w*[^.]{0,80}\bheights?\b|\bheights?\b[^.]{0,80}(?:demo|to be removed)")),
]


# ----------------------------------------------------------------------------------------------- utilidades
def _sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _leer(p):
    try:
        return open(p, encoding="utf-8").read() if p and os.path.isfile(p) else ""
    except (OSError, UnicodeDecodeError):
        return ""


def _json(p):
    try:
        return json.load(open(p, encoding="utf-8")) if p and os.path.isfile(p) else None
    except (OSError, ValueError):
        return None


def _ultimo(patrones, raiz):
    for pat in patrones:
        xs = sorted(glob.glob(os.path.join(raiz, pat), recursive=True))
        if xs:
            return xs[-1]
    return None


def registro():
    """REGLAS_REGISTRO.json del skill (raíz del skill o $TAKEOFF_SKILL)."""
    for c in (os.environ.get("TAKEOFF_SKILL"), os.path.join(AQUI, ".."),
              os.path.join(AQUI, "..", "take-off-metal-frame-drywall")):
        p = os.path.join(c or "", "REGLAS_REGISTRO.json")
        if c and os.path.isfile(p):
            return _json(p)
    return None


class Ctx:
    def __init__(self, workdir, entrega_json=None):
        self.w = os.path.abspath(workdir)
        self.cfg = _json(entrega_json or os.path.join(self.w, "entrega.json")) or {}
        g = lambda k: (os.path.join(self.w, self.cfg[k]) if self.cfg.get(k) else None)   # noqa: E731
        ed = g("entrega_dir")
        if not ed:
            ds = sorted(d for d in glob.glob(os.path.join(self.w, "FINAL_FOR_REVIEW*")) if os.path.isdir(d))
            ed = ds[-1] if ds else None
        self.entrega = ed
        e = ed or self.w
        self.excel = g("excel") or _ultimo(["Take-off/*.xlsx"], e)
        self.markups = g("markups") or _ultimo(["Planos marcados/*.pdf"], e)
        self.planos = os.path.join(e, "Planos marcados")
        self.readme = os.path.join(e, "README_REVIEW.md")
        self.para = os.path.join(e, "PARA_REVISAR_EN_LA_MANANA.md")
        self.seg = os.path.join(e, "SEGUIMIENTO.md")
        self.canon_p = g("canon") or _ultimo(["etapas/4_canon/takeoff_canon.json", "takeoff_work/etapas/4_canon/takeoff_canon.json",
                                             "**/4_canon/takeoff_canon.json", "**/takeoff_canon_FINAL*.json"], self.w)
        self.tk_p = g("takeoff") or _ultimo(["proceso_calc/takeoff.json", "**/takeoff.json"], self.w)
        self.tiempos = g("tiempos") or _ultimo(["TIEMPOS.md", "*/TIEMPOS.md"], self.w)
        self.set_p = g("set_texto") or _ultimo(["set_texto.json", "**/set_texto.json"], self.w)
        self.canon = _json(self.canon_p) or {}
        self.tk = _json(self.tk_p) or {}
        self._wb = None

    def wb(self):
        if self._wb is None and self.excel:
            import openpyxl
            self._wb = openpyxl.load_workbook(self.excel, data_only=False)
        return self._wb

    def rfis_abiertos(self):
        """ids de RFI abiertos = renglones de Pending Items (lo que se le entrega al usuario); sin Excel, takeoff.json."""
        wb = self.wb()
        if wb is not None and "Pending Items" in wb.sheetnames:
            out = []
            for r in wb["Pending Items"].iter_rows(min_row=2, values_only=True):
                fila = " | ".join(str(x or "") for x in r[1:])
                if r and r[0] and re.match(r"(?i)\s*[A-Z\-]*RFI", str(r[0])) and not re.search(r"\bCLOSED\b", fila[:300]):
                    out.append((str(r[0]).strip(), fila))
            return out
        return [(str(r.get("id")), str(r.get("pregunta") or "")) for r in self.rfis()
                if not RX_CERRADO.search(str(r.get("estado") or r.get("status") or ""))]

    def rfis(self):
        xs = list(self.tk.get("rfis") or [])
        ids = {str(r.get("id")) for r in xs}
        xs += [r for r in (self.canon.get("rfis") or []) if str(r.get("id")) not in ids]
        return xs

    def rfi(self, rid):
        return next((r for r in self.rfis() if str(r.get("id")) == rid), None)

    def archivos_entrega(self):
        if not self.entrega or not os.path.isdir(self.entrega):
            return []
        return sorted(os.path.join(r, f) for r, _, fs in os.walk(self.entrega) for f in fs)


CHEQUEOS = []


def chequeo(cid, reglas, desc):
    def deco(fn):
        CHEQUEOS.append((cid, reglas, desc, fn))
        return fn
    return deco


def R(estado, *ev):
    return estado, [str(x) for x in ev if x]


# ----------------------------------------------------------------------------------------------- chequeos
@chequeo("CE_ENTREGABLES", ["U-011", "U-048"], "carpeta de entrega completa: Take-off/*.xlsx, Planos marcados/ (PDF + PNG), "
         "README_REVIEW.md, PARA_REVISAR_EN_LA_MANANA.md, SEGUIMIENTO.md")
def ce_entregables(c):
    if not c.entrega:
        return R("FAIL", "no hay carpeta FINAL_FOR_REVIEW* (ni entrega_dir en entrega.json)")
    falta = []
    if not c.excel:
        falta.append("Take-off/*.xlsx")
    if not c.markups:
        falta.append("Planos marcados/*.pdf (markups Bluebeam)")
    if not glob.glob(os.path.join(c.planos, "*.png")):
        falta.append("Planos marcados/*.png (imagen por hoja)")
    for p in (c.readme, c.para, c.seg):
        if not os.path.isfile(p):
            falta.append(os.path.basename(p))
    return R("FAIL", *["falta " + x for x in falta]) if falta else R("PASS", f"{len(c.archivos_entrega())} archivos en {os.path.basename(c.entrega)}")


@chequeo("CE_SIN_PROPOSAL", ["U-015"], "sin proposal en la entrega")
def ce_sin_proposal(c):
    xs = [p for p in c.archivos_entrega() if re.search(r"(?i)proposal", os.path.relpath(p, c.entrega))]
    return R("FAIL", *xs) if xs else R("PASS", "sin archivos de proposal")


@chequeo("CE_FORMATO_EXCEL", ["U-003", "U-016", "BE-43"], "Excel de formato fijo: exactamente las 6 hojas visibles en orden "
         "y los encabezados fijos de plantilla_excel.py (sin hojas ni columnas agregadas)")
def ce_formato_excel(c):
    wb = c.wb()
    if wb is None:
        return R("FAIL", "no hay Excel")
    ev, est = [], "PASS"
    vis = [ws.title for ws in wb.worksheets if ws.sheet_state == "visible"]
    ocultas = [ws.title for ws in wb.worksheets if ws.sheet_state != "visible"]
    if vis != HOJAS6:
        est = "FAIL"
        ev.append(f"hojas visibles {vis} != {HOJAS6}")
    for o in ocultas:
        if o == "_reglas":
            est = "AMBER" if est == "PASS" else est
            ev.append("hoja oculta _reglas (sello viejo; desde R80f.5 va en <excel>.sello.json)")
        else:
            est = "FAIL"
            ev.append(f"hoja oculta extra '{o}'")
    for h, (fila, cab) in CABECERAS.items():
        if h not in wb.sheetnames:
            continue
        ws = wb[h]
        real = [str(x).strip() for x in next(ws.iter_rows(min_row=fila, max_row=fila, values_only=True)) if x is not None]
        if real != cab:
            est = "FAIL"
            ev.append(f"{h} fila {fila}: encabezados {real} != {cab}")
    return R(est, *(ev or ["6 hojas + encabezados fijos OK"]))


def _ms_filas(c):
    wb = c.wb()
    if wb is None or "Material Summary" not in wb.sheetnames:
        return []
    out = []
    for i, r in enumerate(wb["Material Summary"].iter_rows(min_row=4, values_only=True), start=4):
        if not r or not r[0] or str(r[0]).upper().startswith(("SUBTOTAL", "TOTAL")):
            continue
        net = r[2] if len(r) > 2 else None
        out.append({"fila": i, "material": str(r[0]), "net": net if isinstance(net, (int, float)) else None,
                    "fuente": str(r[8] or "") if len(r) > 8 else ""})
    return out


@chequeo("CE_TORNILLERIA", ["U-053"], "toda la tornillería (screws, anchors, Titen, pins/PAF, Tapcon, bolts) = 0 con EXCLUDED "
         "en Material Summary y una línea EXCLUDED en Scope Checklist")
def ce_tornilleria(c):
    fs = [f for f in _ms_filas(c) if RX_FASTENER.search(f["material"]) and not re.search(r"(?i)\bclips?\b|angle", f["material"])]
    malos = [f"fila {f['fila']} '{f['material'][:60]}' net {f['net']}" + ("" if "EXCLUDED" in f["fuente"].upper() else " sin EXCLUDED")
             for f in fs if (f["net"] or 0) != 0 or "EXCLUDED" not in f["fuente"].upper()]
    wb = c.wb()
    sc = " ".join(" ".join(str(x or "") for x in r) for r in wb["Scope Checklist"].iter_rows(values_only=True)) \
        if wb is not None and "Scope Checklist" in wb.sheetnames else ""
    if not re.search(r"(?i)(screw|fastener|anchor|tornill)[^|]{0,200}EXCLUDED|EXCLUDED[^|]{0,200}(screw|fastener|anchor)", sc):
        malos.append("Scope Checklist sin la línea EXCLUDED de tornillería")
    return R("FAIL", *malos) if malos else R("PASS", f"{len(fs)} renglones de tornillería en 0 con EXCLUDED")


@chequeo("CE_TRACK_FAMILIAS", ["U-056", "BE-24"], "dos familias de track en renglones separados: estándar (bottom / top) y "
         "slip / deflection; ningún renglón las mezcla; si no hay slip track, Scope Checklist lo declara NOT APPLICABLE")
def ce_track_familias(c):
    fs = [f for f in _ms_filas(c) if RX_TRACK.search(f["material"])]
    est = [f for f in fs if re.search(r"(?i)bottom|top", f["material"]) and not RX_SLIP.search(f["material"])]
    slip = [f for f in fs if RX_SLIP.search(f["material"])]
    mezcla = [f for f in slip if re.search(r"(?i)bottom|standard|top and bottom|&", f["material"])]
    ev = []
    if not est:
        ev.append("sin renglón de track estándar (bottom / top)")
    if mezcla:
        ev += [f"fila {f['fila']} mezcla familias: '{f['material'][:70]}'" for f in mezcla]
    if not [f for f in slip if (f["net"] or 0) > 0]:
        wb = c.wb()
        sc = " ".join(" ".join(str(x or "") for x in r) for r in wb["Scope Checklist"].iter_rows(values_only=True)) if wb else ""
        if not re.search(r"(?i)(slip|deflection)[^|]{0,160}(NOT APPLICABLE|no wall reaches|none reach)", sc):
            ev.append("sin renglón de slip / deflection track > 0 y sin NOT APPLICABLE en Scope Checklist")
    return R("FAIL", *ev) if ev else R("PASS", f"{len(est)} renglones estándar / {len(slip)} slip-deflection, separados")


@chequeo("CE_FUENTES_MS", ["U-025", "BE-40"], "todo renglón del Material Summary con cantidad cita su fuente (N/SHEET, "
         "sección de spec o código del trade)")
def ce_fuentes_ms(c):
    rx = re.compile(r"N/SHEET|[A-Z]{1,3}-?\d{1,3}(?:\.\d{1,2})?\b|\b0[5-9]\s?\d{2}\s?\d{2}\b|ASTM|GA-\d|AISI|UL\b|IBC|SSMA|USG")
    malos = [f"fila {f['fila']} '{f['material'][:60]}'" for f in _ms_filas(c) if (f["net"] or 0) > 0 and not rx.search(f["fuente"])]
    if not _ms_filas(c):
        return R("FAIL", "Material Summary vacío o sin Excel")
    return R("FAIL", *malos) if malos else R("PASS", "todos los renglones con fuente")


@chequeo("CE_DATOS_PROYECTO", ["U-077", "R-ALC-09", "BE-114"], "hoja de datos del proyecto + hojas obligatorias en takeoff.json, "
         "Inputs del Excel, README_REVIEW y PARA_REVISAR (reglas.datos_proyecto_fallas)")
def ce_datos_proyecto(c):
    import reglas
    if not c.tk:
        return R("FAIL", "no hay takeoff.json con proyecto_datos / hojas_revisadas")
    fs = reglas.datos_proyecto_fallas(c.tk, c.excel, [c.readme, c.para])
    for p in (c.readme, c.para):
        if not os.path.isfile(p):
            fs.append((os.path.basename(p), "no existe", "doc con PROJECT DATA arriba"))
    return R("FAIL", *[" · ".join(map(str, f)) for f in fs]) if fs else R("PASS", "datos del proyecto en las 4 fuentes")


def _pasos_tiempos(txt):
    """{paso: [horas]} de las filas '| 2-3 | ... | 20:33 | 20:53 |' de TIEMPOS.md."""
    out = {}
    for ln in txt.splitlines():
        cs = [x.strip(" *") for x in ln.strip().strip("|").split("|")]
        if len(cs) < 3:
            continue
        m = re.match(r"^(\d{1,2})(?:[a-z])?(?:\s*[-–]\s*(\d{1,2}))?[a-z]?$", cs[0])
        if not m:
            continue
        horas = re.findall(r"\b\d{1,2}:\d{2}\b", " ".join(cs[1:]))
        a, b = int(m.group(1)), int(m.group(2) or m.group(1))
        for k in range(a, b + 1):
            out.setdefault(k, []).extend(horas)
    return out


@chequeo("CE_TIEMPOS", ["U-094"], "TIEMPOS.md con hora de inicio / fin (hora de California) de cada paso 1–9 y TOTAL")
def ce_tiempos(c):
    t = _leer(c.tiempos)
    if not t:
        return R("FAIL", "no existe TIEMPOS.md en la carpeta del proyecto (cache_proyectos/<proyecto>/TIEMPOS.md)")
    p = _pasos_tiempos(t)
    falta = [k for k in PASOS_TIEMPOS if not p.get(k)]
    ev = [f"paso {k} sin fila con hora" for k in falta]
    if not re.search(r"(?i)\bTOTAL\b", t):
        ev.append("sin fila TOTAL")
    if not re.search(r"(?i)\bPST\b|\bPDT\b|california|los_angeles", t):
        ev.append("sin zona horaria de California (PST/PDT)")
    return R("FAIL", *ev) if ev else R("PASS", f"pasos 1–9 con hora; {os.path.relpath(c.tiempos, c.w)}")


@chequeo("CE_HORAS_CALIFORNIA", ["U-045"], "horas al usuario en hora de California: sin UTC en TIEMPOS / README / PARA_REVISAR")
def ce_horas(c):
    ev = []
    for p in (c.tiempos, c.readme, c.para):
        t = _leer(p)
        for m in re.finditer(r"\bUTC\b|\d{2}:\d{2}(?::\d{2})?Z\b|\bGMT\b", t):
            ev.append(f"{os.path.basename(p)}: '{t[max(0, m.start() - 30):m.end() + 10]}'")
    return R("FAIL", *ev[:10]) if ev else R("PASS", "sin horas en UTC")


RX_DOLAR = re.compile(r"\$\s?\d|\bUSD\b|\b\d[\d,.]*\s?(?:dollars|d[oó]lares)\b", re.I)


@chequeo("CE_SIN_DOLARES", ["U-018", "U-123"], "sin costos en dólares en lo entregado: README / PARA_REVISAR / SEGUIMIENTO, "
         "celdas visibles del Excel (no fórmulas) y texto de los markups (U-123, preferencias del día 1)")
def ce_sin_dolares(c):
    ev = []
    for p in (c.readme, c.para, c.seg):
        t = _leer(p)
        for m in RX_DOLAR.finditer(t):
            ev.append(f"{os.path.basename(p)}: '{t[max(0, m.start() - 30):m.end() + 15]}'")
    wb = c.wb()
    for ws in (wb.worksheets if wb is not None else []):
        if ws.sheet_state != "visible":
            continue
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if isinstance(v, str) and not v.startswith("=") and RX_DOLAR.search(v):
                    ev.append(f"{ws.title}!{cell.coordinate}: '{v[:60]}'")
                elif cell.number_format and "$" in str(cell.number_format) and isinstance(v, (int, float)):
                    ev.append(f"{ws.title}!{cell.coordinate}: formato de moneda '{cell.number_format}'")
    if c.markups and os.path.isfile(c.markups):
        import pymupdf
        for pg in pymupdf.open(c.markups):
            for a in pg.annots() or []:
                t = (a.info or {}).get("content") or ""
                if RX_DOLAR.search(t):
                    ev.append(f"markup {pg.get_label() or pg.number + 1}: '{t[:60]}'")
    return R("FAIL", *ev[:10]) if ev else R("PASS", "sin montos en dólares")


@chequeo("CE_DRIVE_PARENT", ["U-090", "U-004", "U-001"], "la carpeta del proyecto en Drive cuelga de Claude outputs de la RAÍZ "
         f"({DRIVE_RAIZ}); nunca de Projects › Claude outputs")
def ce_drive_parent(c):
    d = c.cfg.get("drive") or {}
    pid, nombre = str(d.get("parent_id") or ""), str(d.get("carpeta_proyecto") or "")
    if not pid:
        return R("FAIL", "entrega.json sin drive.parent_id (no se puede verificar el folder de entrega)")
    if pid == DRIVE_PROHIBIDO:
        return R("FAIL", f"parent_id {pid} = Projects › Claude outputs (PROHIBIDO)")
    if pid != DRIVE_RAIZ:
        return R("FAIL", f"parent_id {pid} != {DRIVE_RAIZ} (Claude outputs de la raíz)")
    if not nombre.strip():
        return R("FAIL", "entrega.json sin drive.carpeta_proyecto (un folder por proyecto, nombre = proyecto)")
    return R("PASS", f"parent {pid} › '{nombre}' (subir_entrega.py lo verifica en vivo con gdrive_fetch list)")


def _rfi_texto(c, rid, fila):
    r = c.rfi(rid) or {}
    return fila + " " + json.dumps(r, ensure_ascii=False)


@chequeo("CE_RFI_FORMATO", ["U-042", "U-048", "U-052"], "cada RFI abierto: (A) planos con N/HOJA y delta · (B) código con "
         "cita y delta · (C) otro, en ese orden, y el valor conservador CARGADO declarado")
def ce_rfi_formato(c):
    ev = []
    for rid, fila in c.rfis_abiertos():
        ia, ib, ic = (fila.find(x) for x in ("(A)", "(B)", "(C)"))
        if min(ia, ib, ic) < 0 or not ia < ib < ic:
            ev.append(f"{rid}: opciones (A)/(B)/(C) faltan o fuera de orden")
        if len(re.findall(r"(?i)delta", fila)) < 2:
            ev.append(f"{rid}: delta en (A) y (B)")
        if not re.search(r"(?i)loaded|carried|cargad", _rfi_texto(c, rid, fila)):
            ev.append(f"{rid}: sin valor conservador cargado declarado (loaded / carried)")
    return R("FAIL", *ev) if ev else R("PASS", f"{len(c.rfis_abiertos())} RFI abiertos con A/B/C + delta + valor cargado")


@chequeo("CE_RFI_PROHIBIDOS", ["U-053", "U-061", "U-064", "U-071", "U-075", "R-ALC-01", "R-ALC-03", "R-ALC-05", "R-ALC-07"],
         "ningún RFI abierto sobre lo que el usuario ordenó resolver sin RFI (tornillería, trades ajenos, ductos, cielo "
         "existente sin tipo, altura de partition a demoler)")
def ce_rfi_prohibidos(c):
    ev = []
    for rid, fila in c.rfis_abiertos():
        r = c.rfi(rid) or {}
        tema = str(r.get("pregunta") or fila)
        tema = re.split(r"(?<=[a-z0-9\)\"])\.\s|\s\|\s|:\s", tema, maxsplit=1)[0][:300]   # el tema = antes del 1er '. ' / ' | ' / ': '
        for nombre, rx in RFI_PROHIBIDOS:
            m = rx.search(tema)
            if m and m.start() <= 80 and not re.search(r"(?i)\b(?:no|not|without|sin)\b[^,;]{0,12}$", tema[:m.start()]):
                ev.append(f"{rid}: {nombre} — '{tema[max(0, m.start() - 40):m.end() + 40]}'")
    return R("FAIL", *ev) if ev else R("PASS", "ningún RFI sobre temas con orden fija")


def _terminos(r):
    b = r.get("barrido") if isinstance(r.get("barrido"), dict) else {}
    ts = [str(t) for t in (b.get("terminos") or []) if str(t).strip()]
    for q in re.findall(r"'([^']{4,40})'|\"([^\"]{4,40})\"", str(r.get("pregunta") or "")):
        q = (q[0] or q[1]).strip()
        if q.upper() == q and re.search(r"[A-Z]{2}", q) and not RX_FT.fullmatch(q):
            ts.append(q)
    return sorted(set(ts), key=str.lower)


def barrido_impreso(rid, r, hojas_txt):
    """BE-120: -> lista de fallas. (1) un término del RFI aparece en una hoja que NO está en su barrido.hojas;
    (2) un término aparece junto a un valor IMPRESO (cota ft-in / EL.) en una hoja y el RFI no registra por qué esa hoja
    no lo contesta (barrido.descartes {hoja: motivo}) — posible respuesta impresa."""
    b = r.get("barrido") if isinstance(r.get("barrido"), dict) else {}
    hojas = b.get("hojas")
    todas = hojas == "ALL"
    lista = set(hojas or []) if isinstance(hojas, list) else set()
    desc = b.get("descartes") if isinstance(b.get("descartes"), dict) else {}
    out = []
    ts = _terminos(r)
    if not ts:
        return [f"{rid}: sin términos de barrido (barrido.terminos)"]
    for hoja, txt in sorted(hojas_txt.items()):
        for t in ts:
            rx = re.compile(r"(?<![A-Za-z0-9])" + re.escape(t) + r"(?![A-Za-z0-9])", re.I)
            ms = list(rx.finditer(txt))
            if not ms:
                continue
            if not todas and hoja not in lista:
                out.append(f"{rid}: '{t}' aparece {len(ms)} vez/veces en {hoja}, que NO está en su barrido.hojas")
                break
            con_valor = [txt[max(0, m.start() - 40):m.end() + 60] for m in ms if RX_FT.search(txt[max(0, m.start() - 40):m.end() + 60])]
            if con_valor and not str(desc.get(hoja) or "").strip():
                out.append(f"{rid}: posible respuesta IMPRESA en {hoja}: '{' '.join(con_valor[0].split())}' — se aplica "
                           f"con N/HOJA o se registra en barrido.descartes['{hoja}'] por qué no contesta")
                break
    return out


@chequeo("CE_RFI_BARRIDO_IMPRESO", ["U-100", "U-086", "U-052", "BE-120", "BE-CF16", "U-019"], "BE-120: por cada RFI abierto se "
         "buscan sus términos en el TEXTO COMPLETO del set (incl. SHX); falla si aparecen en una hoja fuera de su barrido o "
         "junto a un valor impreso sin descarte escrito")
def ce_rfi_barrido(c):
    abiertos = c.rfis_abiertos()
    if not abiertos:
        return R("PASS", "0 RFI abiertos")
    st = _json(c.set_p)
    hojas_txt = (st or {}).get("hojas") if isinstance(st, dict) else None
    if not hojas_txt:
        return R("FAIL", "no hay set_texto.json (texto completo del set): correr `compuerta_entrega.py texto <bidset.pdf> "
                         "--out <workdir>/set_texto.json`; sin él no se puede probar que la respuesta no está impresa")
    ev = []
    sin = (st or {}).get("sin_texto") or []
    if sin:                                    # R80e.151: barrido ciego en hojas raster sin OCR
        ev.append(f"{len(sin)} hojas sin texto (raster sin OCR): {', '.join(sin[:12])} — instalar tesseract y repetir `texto`")
    for rid, _ in abiertos:
        r = c.rfi(rid)
        if not r:
            ev.append(f"{rid}: sin registro en takeoff.json (barrido no documentado)")
            continue
        ev += barrido_impreso(rid, r, hojas_txt)
    return R("FAIL", *ev) if ev else R("PASS", f"{len(abiertos)} RFI: ningún término en hojas sin barrer ni junto a valores impresos sin descarte")


@chequeo("CE_ATRIBUCION_ESTIMADOR", ["U-052"], "toda 'estimator decision' del Excel cita su respuesta escrita o precedente "
         "(R-ALC-NN, R80e.34, U-NNN, respuesta del usuario, standing rule)")
def ce_atribucion(c):
    wb = c.wb()
    if wb is None:
        return R("FAIL", "no hay Excel")
    rx_cita = re.compile(r"(?i)R-ALC-\d+|R80[a-z]\.\d+|U-\d{3}|BE-[A-Z0-9-]+|precedent|standing (?:rule|order)|user answer|"
                         r"respuesta|answered|recommended option|option \(?A\)?|20\d\d-\d\d-\d\d|\b\d{1,2}-(?:oct|nov|dec)\b")
    ev = []
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if isinstance(v, str) and re.search(r"(?i)estimator(?:'s)? decision|decisi[oó]n del estimador", v) and not rx_cita.search(v):
                    ev.append(f"{ws.title}!{cell.coordinate}: '{v[:90]}'")
    return R("FAIL", *ev[:15]) if ev else R("PASS", "toda decisión del estimador con cita")


@chequeo("CE_DECISIONES_EN_EXCEL", ["U-016", "U-050"], "todo RFI cerrado (por plano o por el estimador) queda escrito en el Excel")
def ce_decisiones(c):
    wb = c.wb()
    if wb is None:
        return R("FAIL", "no hay Excel")
    txt = " ".join(str(x) for ws in wb.worksheets for r in ws.iter_rows(values_only=True) for x in r if x)
    cerrados = [str(r.get("id")) for r in c.rfis() if RX_CERRADO.search(str(r.get("estado") or r.get("status") or ""))]
    cerrados += [str(k) for k in (c.tk.get("rfi_cierre") or {})]
    falta = []
    for k in cerrados:
        partes = [p.strip() for p in re.split(r"/", k) if p.strip()]
        if not any(re.search(r"(?<![\w-])" + re.escape(p) + r"(?![\w-])", txt) or
                   re.search(r"(?<![\w-])" + re.escape(re.sub(r"^[AB]-", "", p)) + r"(?![\w-])", txt) for p in partes):
            falta.append(k)
    return R("FAIL", *[f"{k}: cerrado pero no citado en el Excel" for k in falta]) if falta else \
        R("PASS", f"{len(cerrados)} cierres citados")


@chequeo("CE_SEGUIMIENTO", ["U-048"], "SEGUIMIENTO.md lista cada RFI abierto")
def ce_seguimiento(c):
    t = _leer(c.seg)
    if not t:
        return R("FAIL", "no hay SEGUIMIENTO.md en la entrega")
    falta = [rid for rid, _ in c.rfis_abiertos() if rid not in t]
    return R("FAIL", *[f"{x} no está en SEGUIMIENTO.md" for x in falta]) if falta else R("PASS", "RFI abiertos en SEGUIMIENTO")


def _escalas_pdf(pdf, canon):
    """{hoja: pt/ft} desde el rótulo SCALE IMPRESO de cada hoja marcada (si hay varios, el que coincide con el canon)."""
    import pymupdf
    import verificar_markups_excel as VME
    out, amb = {}, []
    doc = pymupdf.open(pdf)
    for p in doc:
        if not list(p.annots() or []):
            continue
        lab = p.get_label() or f"p{p.number + 1}"
        imp = VME.escalas_impresas(p.get_text("text").replace("’", "'").replace("”", '"'))
        can, _ = VME.escala_canon(canon, lab)
        if len(imp) == 1:
            out[lab] = imp[0]
        elif can and any(abs(can - x) < 0.01 for x in imp):
            out[lab] = can
        elif can and not imp:
            out[lab] = can
            amb.append(f"{lab}: la hoja del PDF de markups no tiene capa de texto; escala tomada del canon ({can:.3f} pt/ft)")
        else:
            amb.append(f"{lab}: escalas impresas {imp}, canon {can}")
    return out, amb


@chequeo("CE_ALTURA_IMPRESA", ["U-099", "BE-119", "U-010", "U-088"], "BE-119: cada markup re-medido a la escala IMPRESA y su "
         "Depth comparado contra la altura IMPRESA de su fuente (N/HOJA), no contra el Excel. RED = FAIL; sin altura impresa = AMBER")
def ce_altura_impresa(c):
    if not (c.markups and c.excel):
        return R("FAIL", "falta el PDF de markups o el Excel")
    import revision_markups as RM
    sc_cfg = {k: RM.escala_pt_per_ft(v) for k, v in (c.cfg.get("escalas") or {}).items()}
    sc, amb = _escalas_pdf(c.markups, c.canon)
    sc.update(sc_cfg)
    _doc, _mk, res = RM.revisar(c.markups, c.excel, sc, c.canon)
    rojo = [f"{r['wall']}: {'; '.join(r['fallas'])}" for r in res if r["verdict"] == "RED"]
    amb_w = [f"{r['wall']}: {'; '.join(r['amber'])}" for r in res if r["verdict"] == "AMBER"]
    if rojo:
        return R("FAIL", f"{len(rojo)} RED / {len(amb_w)} AMBER de {len(res)}", *rojo, *amb)
    if amb_w or amb:
        return R("AMBER", f"0 RED / {len(amb_w)} AMBER de {len(res)}", *amb_w, *amb)
    return R("PASS", f"{len(res)} filas GREEN contra la altura impresa")


@chequeo("CE_MATERIALES_SCHEDULE", ["U-111", "BE-122"], "BE-122 (j): lectura INDEPENDIENTE del Partition Type Schedule "
         "(fichas.json, subagente que no vio el Excel) vs lo cargado por wall / type (revision_materiales.comparar_type) + cada "
         "renglón del Material Summary = suma de walls por type con origen impreso (revision_materiales.sumas). RED = FAIL")
def ce_materiales_schedule(c):
    import revision_materiales as RV
    fp = (os.path.join(c.w, c.cfg["fichas"]) if c.cfg.get("fichas") else None) or _ultimo(["fichas.json", "**/fichas.json"], c.w)
    fj = _json(fp)
    if not (fj and fj.get("types")):
        return R("FAIL", "no hay fichas.json (lectura independiente del Partition Type Schedule por un subagente que no vio "
                         "el Excel): sin ella no hay revisión de materiales no circular (BE-122)")
    if not (c.excel and c.canon_p):
        return R("FAIL", "falta Excel o canon")
    filas, ms = RV.leer_excel(c.excel)
    cw = {w["id"]: w for w in c.canon.get("walls") or []}
    misc = c.canon.get("misc_items") or []
    mapa = {k: (v if isinstance(v, list) else str(v).split(",")) for k, v in (c.cfg.get("mapa_materiales") or {}).items()}
    sel = lambda t: [f for f in filas if f["type"] in mapa.get(t, [t]) or f["wall"] in mapa.get(t, [])]  # noqa: E731
    res = [RV.comparar_type(t, fj["types"][t], sel(t), cw, misc) for t in fj["types"]]
    cub = {id(f) for t in fj["types"] for f in sel(t)}
    calc = c.cfg.get("calc_dir") and os.path.join(c.w, c.cfg["calc_dir"]) or os.path.join(os.path.dirname(c.canon_p), "out")
    sm = RV.sumas(ms, filas, calc)
    rojo = [f"type {r['type']}: " + "; ".join(f"{x['field']} schedule {x['schedule']} / Excel {x['excel']}" for x in r["checks"]
                                               if x["status"] == "RED") for r in res if r["verdict"] == "RED"]
    rojo += [f"Material Summary fila {s['row']} '{s['material'][:50]}': {s['note'][:120]}" for s in sm if s["status"] == "RED"]
    amb = [f"type {r['type']}: AMBER (el schedule no lo dice)" for r in res if r["verdict"] == "AMBER"]
    amb += [f"walls fuera del schedule: {f['type']} {f['wall']}" for f in filas if id(f) not in cub]
    amb += [f"Material Summary fila {s['row']} AMBER: {s['note'][:100]}" for s in sm if s["status"] == "AMBER"]
    if rojo:
        return R("FAIL", f"{len(rojo)} RED", *rojo[:25], *amb[:10])
    return R("AMBER", *amb[:25]) if amb else R("PASS", f"{len(res)} types y {len(sm)} renglones del Material Summary en verde")


@chequeo("CE_MARKUPS_EXCEL", ["U-010", "BE-117", "BE-44"], "verificar_markups_excel.py: TYPE·LF·H·SF·DETAIL·Wall ID = Excel, "
         "/Measure = escala impresa, Length vs LF <= 0.5 %")
def ce_markups_excel(c):
    if not (c.markups and c.excel and c.canon_p):
        return R("FAIL", "falta PDF de markups, Excel o canon")
    import verificar_markups_excel as VME
    fallas, _l, _r = VME.verificar(c.markups, c.excel, c.canon_p)
    return R("FAIL", f"{len(fallas)} fallas", *fallas[:25]) if fallas else R("PASS", "markups = Excel = escala impresa")


@chequeo("CE_AUDITORIA", ["U-005", "U-007", "U-011", "BE-42"], "auditoria_entrega.py: orden del schedule, SUBTOTAL por type, "
         "GRAND TOTAL, PNG por hoja marcada, PROJECT DATA, RFI abiertos con (A)/(B)/(C)")
def ce_auditoria(c):
    if not (c.markups and c.excel and c.canon_p):
        return R("FAIL", "falta PDF de markups, Excel o canon")
    import auditoria_entrega as AE
    res = AE.auditar(c.excel, c.markups, c.canon_p, imagenes=c.planos, docs=[c.readme, c.para], rfis_abiertos=True)
    malos = [f"{a} · {b} · {d}" for a, b, ok, d in res if not ok]
    return R("FAIL", f"{len(malos)} de {len(res)}", *malos[:25]) if malos else R("PASS", f"{len(res)} revisiones OK")


@chequeo("CE_REGLAS", ["U-009", "U-031", "U-083", "U-085", "R-ALC-11", "R-ALC-12", "BE-116"], "reglas.py compuerta en modo final "
         "(--excel): todas las compuertas A_* del catálogo (etapas, bitácora, no dibujado, strut, barrido, markups, ...)")
def ce_reglas(c):
    if not c.canon_p:
        return R("FAIL", "no hay takeoff_canon.json")
    d = os.path.dirname(os.path.dirname(c.canon_p)) if os.path.basename(os.path.dirname(c.canon_p)) == "4_canon" else os.path.dirname(c.canon_p)
    out = tempfile.mkdtemp(prefix="ce_reglas_")
    env = dict(os.environ)
    bit = _ultimo(["**/bitacora.jsonl"], c.w)
    if bit and not env.get("BITACORA"):
        env["BITACORA"] = bit
    cmd = [sys.executable, os.path.join(AQUI, "reglas.py"), "compuerta", d, "--out", out] + (["--excel", c.excel] if c.excel else [])
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=1800, env=env)
    ro = _json(os.path.join(out, "reglas_out.json")) or {}
    if p.returncode == 0 and ro.get("ok"):
        return R("PASS", f"reglas.py OK ({ro.get('reglas')} reglas)")
    fs = [f"{f.get('regla')} · {f.get('elemento')} · {f.get('valor')}" for f in (ro.get("fallas") or [])[:20]]
    return R("FAIL", f"reglas.py rc {p.returncode}, {ro.get('n_fallas', '?')} fallas", *(fs or [(p.stdout + p.stderr)[-400:]]))


# ----------------------------------------------------------------------------------------------- biblioteca de errores
# Orden del usuario 3-nov ("haz los programas"): las reglas que eran "programa-pendiente" (127 BE-* + U-017 / U-026 /
# U-034 / U-035 / U-037 / U-043 / U-051 / U-057 / U-058 / U-079 / U-081 / U-082 / R-ALC-02 / R-ALC-04 / R-ALC-10) y
# CE_CALLOUTS (U-113 / BE-124, cadena de burbujas N/HOJA hasta el final) corren aquí, una línea por regla en ENTREGA_OK.json.
import chequeos_biblioteca as CB  # noqa: E402


def _cb(fn):
    def w(c):
        return fn(CB.B.desde_ctx(c))
    w.__name__ = fn.__name__
    return w


for _ids, _fn, _desc in CB.CHEQUEOS:
    CHEQUEOS.append(("CE_CALLOUTS" if _fn.__name__ == "ce_callouts" else "CB_" + _fn.__name__.upper(), _ids, _desc, _cb(_fn)))


# ----------------------------------------------------------------------------------------------- correr
def correr(workdir, entrega_json=None, solo=None):
    c = Ctx(workdir, entrega_json)
    reg = registro() or {}
    por_chequeo = {}
    for e in reg.get("reglas") or []:
        if e.get("categoria") == "programa" and e.get("cuando") == "entrega":
            for ch in e.get("chequeos") or []:
                nm = ch.split("::")[-1]
                por_chequeo.setdefault("ce_reglas" if nm.startswith("A_") else nm, []).append(e["id"])
    res = []
    for cid, reglas_, desc, fn in CHEQUEOS:
        if solo and cid not in solo:
            continue
        try:
            est, ev = fn(c)
        except Exception as e:                                          # noqa: BLE001 — un chequeo roto = FAIL
            est, ev = "FAIL", [f"el chequeo no corrió: {type(e).__name__}: {e}"]
        ids = sorted(set(reglas_) | set(por_chequeo.get(fn.__name__, [])) | set(por_chequeo.get(cid, [])))
        res.append({"id": cid, "reglas": ids, "descripcion": desc, "estado": est, "evidencia": ev})
    archivos = {os.path.relpath(p, c.w): _sha(p) for p in c.archivos_entrega()}
    n = {k: sum(r["estado"] == k for r in res) for k in ("PASS", "AMBER", "FAIL")}
    ahora = datetime.datetime.now(datetime.timezone.utc)
    try:
        from zoneinfo import ZoneInfo
        ca = ahora.astimezone(ZoneInfo("America/Los_Angeles")).strftime("%Y-%m-%d %H:%M %Z")
    except Exception:                                                   # noqa: BLE001
        ca = ""
    out = {"version": VERSION, "fecha_california": ca, "fecha_iso": ahora.isoformat(), "workdir": c.w,
           "entrega_dir": os.path.relpath(c.entrega, c.w) if c.entrega else None, "ok": n["FAIL"] == 0 and not solo,
           "resumen": n, "chequeos": res, "archivos": archivos, "drive": c.cfg.get("drive") or {},
           "registro": (reg.get("version") if reg else None)}
    return out


MIN_TEXTO = 200          # R80e.151 (O'Reilly rev5): una hoja con menos caracteres = raster sin capa de texto -> OCR


def _tessdata():
    for d in (os.environ.get("TESSDATA_PREFIX"), "/usr/share/tesseract-ocr/5/tessdata", "/usr/share/tesseract-ocr/4.00/tessdata",
              "/usr/share/tessdata", "/usr/local/share/tessdata"):
        if d and os.path.isfile(os.path.join(d, "eng.traineddata")):
            return d
    return None


def _en_blanco(p):
    """página sin tinta: < 0.05 % de píxeles oscuros a 20 dpi en gris."""
    import pymupdf
    px = p.get_pixmap(dpi=20, colorspace=pymupdf.csGRAY)
    s_ = px.samples
    return sum(1 for b in s_ if b < 200) < 0.0005 * max(len(s_), 1)


RX_DE_N = re.compile(r"\b([A-Z]{1,3}-?\d{1,3}(?:\.\d{1,2})?[A-Z]?)\s+(?:of|OF)\s+\d{1,3}\b")


def _rotulo_esquina(p, td):
    """R80e.151: número de hoja del title block por OCR de la esquina inferior derecha ('E4 of 4', 'M1 of 3', 'A1.1');
    dos recortes (el title block cambia de proporción entre disciplinas), el primero que lee gana."""
    import pymupdf
    os.environ.setdefault("TESSDATA_PREFIX", td)
    r = p.rect
    for x0, y0, dpi in ((0.90, 0.86, 150), (0.93, 0.88, 150), (0.86, 0.80, 200), (0.93, 0.88, 300)):
        try:
            pix = p.get_pixmap(dpi=dpi, clip=pymupdf.Rect(r.width * x0, r.height * y0, r.width * 0.985, r.height))
            t = pymupdf.open("pdf", pix.pdfocr_tobytes(tessdata=td))[0].get_text("text")
        except Exception:                               # noqa: BLE001
            continue
        m = RX_DE_N.findall(t) or re.findall(r"\b[A-Z]{1,3}-?\d{1,3}\.\d{1,2}[A-Z]?\b", t)
        if m:
            return m[-1]
    return None


def texto_set(pdfs, salida, dpi=200):
    """Texto de cada hoja del set (texto + anotaciones, p. ej. AutoCAD SHX Text) con su número de hoja.
    R80e.151 (O'Reilly rev5): las hojas RASTER (sin capa de texto: < MIN_TEXTO caracteres) se pasan por OCR (tesseract vía
    pymupdf); si no hay OCR quedan en 'sin_texto' y el chequeo BE-120 FALLA con RFI abiertos (barrido ciego)."""
    import pymupdf
    hojas, fuentes, ocr, sin, blanco = {}, [], [], [], []
    td = _tessdata()
    for pdf in pdfs:
        doc = pymupdf.open(pdf)
        fuentes.append({"pdf": os.path.basename(pdf), "paginas": doc.page_count})
        for p in doc:
            t = p.get_text("text")
            raster = len(t.strip()) < MIN_TEXTO
            leido = False
            if raster and td:
                try:
                    o = p.get_textpage_ocr(dpi=dpi, full=True, tessdata=td).extractText()
                    t += "\n" + o
                    leido = len(o.strip()) >= 20
                except Exception:                      # noqa: BLE001 — una hoja que no se puede leer queda sin texto
                    pass
            t += "\n" + "\n".join((a.info or {}).get("content") or "" for a in (p.annots() or []))
            lab = p.get_label() or ""
            if not RX_HOJA.match(lab):
                W, H = p.rect.width, p.rect.height
                cands = [(w[3] - w[1], w[4]) for w in p.get_text("words") if w[0] > 0.75 * W and w[1] > 0.7 * H and RX_HOJA.match(w[4])]
                lab = max(cands)[1] if cands else f"p{p.number + 1}"
            if lab.startswith("p") and raster:          # rótulo de hoja de la capa OCR (title block, esquina inf. der.)
                m = [x for x in re.findall(r"\b[A-Z]{1,3}-?\d{1,3}\.\d{1,2}[A-Z]?\b", t[-600:])]
                if m:
                    lab = m[-1]
                elif td:
                    lab = _rotulo_esquina(p, td) or lab
            k, n = lab, 2
            while k in hojas:
                k, n = f"{lab}#{n}", n + 1
            hojas[k] = t
            if raster:
                if leido:
                    ocr.append(k)
                elif _en_blanco(p):                   # página sin tinta (separador): no hay nada que barrer
                    blanco.append(k)
                else:
                    sin.append(k)
    json.dump({"fuentes": fuentes, "hojas": hojas, "ocr": ocr, "sin_texto": sin, "en_blanco": blanco}, open(salida, "w", encoding="utf-8"),
              ensure_ascii=False)
    return hojas


def main(argv):
    if len(argv) > 1 and argv[1] == "texto":
        a = argv[2:]
        if "--out" not in a:
            print(__doc__)
            return 2
        i = a.index("--out")
        sal, pdfs = a[i + 1], a[:i] + a[i + 2:]
        h = texto_set(pdfs, sal)
        st = _json(sal) or {}
        print(f"set_texto: {len(h)} hojas -> {sal} (OCR {len(st.get('ocr') or [])}, sin texto {len(st.get('sin_texto') or [])})")
        return 0
    if len(argv) < 2:
        print(__doc__)
        return 2
    ej = argv[argv.index("--entrega") + 1] if "--entrega" in argv else None
    out = correr(argv[1], ej)
    p = os.path.join(out["workdir"], "ENTREGA_OK.json")
    json.dump(out, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for r in out["chequeos"]:
        print(f"{r['estado']:5} {r['id']:24} {', '.join(r['reglas'])[:60]}")
        if r["estado"] != "PASS":
            for e in r["evidencia"][:6]:
                print("        - " + e[:220])
    n = out["resumen"]
    print(f"COMPUERTA DE ENTREGA: PASS {n['PASS']} / AMBER {n['AMBER']} / FAIL {n['FAIL']} -> "
          + ("VERDE (se puede subir con subir_entrega.py)" if out["ok"] else "ROJA: NO SE ENTREGA") + f"\n{p}")
    return 0 if out["ok"] else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
