"""BE-117g: un renglón "A+B" del Partition Takeoff (PT2: wall + return) se cuadra contra la SUMA de las anotaciones A y B.
Falla con la v81cf12 (cada pieza buscada sola -> 'renglón sin anotación' / TYPE contra un renglón del Material Summary)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import verificar_markups_excel as V
ex = {"pt": {"W1+W1r": [{"fila": 7, "lf": 6.72, "h": 12.58, "sf": 141.7, "grupo": "TYPE A3C", "a": "A3C  #W1+W1r", "sf_col": "Board", "texto": "A3C/A301"}]}, "ms": [], "errores": []}
ex["union"] = {"W1": "W1+W1r", "W1r": "W1+W1r"}
# la lógica de unión: cada pieza resuelve a su renglón y las sumas cuadran
assert ex["union"]["W1"] == ex["union"]["W1r"] == "W1+W1r"
src = open(V.__file__).read()
for frag in ('out["union"]', 'uniones.setdefault(union', 'wid not in uniones', 'suma LF de las piezas'):
    assert frag in src, f"falta la lógica BE-117g: {frag}"
print("test_markups_excel_union OK")


# --- test_markups_board_sf (unido aquí en v81cf87, BE-XF08: el skill debe quedar en 199 archivos) ---
# test_markups_board_sf.py — BE-117 (user 3-nov): the SF in the Contents of a wall markup is the BOARD SF of its
# Excel row (faces x height x layers), not LF x H (the old Contents showed LF x H instead of the board SF of the row).
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import markups_bluebeam as MB
w = {"id": "W1", "tag": "A1", "element": "wall", "length_ft": 14.167, "height_ft": 10.667, "detail": "1/A-501", "sheet": "A-101",
     "faces": [{"side": "A", "room": "K", "board": "1/2 cement board", "layers": 1, "height_ft": 10.5}]}
ct = MB.contenido(w)
assert "148.75 SF board" in ct, ct
w2 = dict(w, faces=[])
assert "151.12 SF wall" in MB.contenido(w2), MB.contenido(w2)   # U-153: sin board, SF wall = LF x H
print("test_markups_board_sf OK")
