#!/usr/bin/env python3
"""test_excluidas_texto.py — R80w.20: el texto de exclusión que canon.py escribe (familias_out.excluidas -> Scope
Checklist) no trae nombres de archivo internos: plantilla_excel.TEXTO_INTERNO (R80e.84) lo rechazaba y el Excel
no pasaba verificar en NINGÚN proyecto. Sintético; falla con canon.py v80v."""
import os, re, sys
AQ = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQ)
import plantilla_excel as P
src = open(os.path.join(AQ, "canon.py"), encoding="utf-8").read()
m = re.search(r'out\["excluidas"\]\s*=\s*\{(.+?)\}', src, re.S)
assert m, "no se encontró out['excluidas'] en canon.py"
for txt in re.findall(r'"([^"]+)"', m.group(1)):
    assert not P.TEXTO_INTERNO.search(txt), f"texto interno en excluidas: {P.TEXTO_INTERNO.search(txt).group(0)}"
print("test_excluidas_texto OK")


# --- test_fastener_sheet (unido aquí en v81cf87, BE-XF08: el skill debe quedar en 199 archivos) ---
# test_fastener_sheet.py — R80w.40: con fasteners_excluded (R80e.77) la fila en 0 de cada familia de tornillería
# conserva la hoja de donde salía el item (fuente del cálculo o del none-reason) además de la regla del estimador, en vez
# de quedar solo con la regla ("N/SHEET: default (no sheet)" en el Excel). Sintético; falla con accesorios v80w.39.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import accesorios as A
d = {"fasteners_excluded": {"why": "fasteners", "source": "estimator standing rule"},
     "accesorios_none": [{"familia": "expansion anchors", "why": "no exterior wall on slab", "source": "A201"}]}
r = A.calcular({"familias": {}}, d)
src = [x["source"] for x in r["filas"] if x["familia"] == "expansion anchors"]
assert src == ["A201; estimator standing rule"], src
assert r["familias"]["expansion anchors"] == 0.0
print("test_fastener_sheet OK")
