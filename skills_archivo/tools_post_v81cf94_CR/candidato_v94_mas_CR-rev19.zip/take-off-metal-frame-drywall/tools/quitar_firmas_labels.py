#!/usr/bin/env python3
"""quitar_firmas_labels.py — U-151 / BE-147 (6-nov, CR City Hotel rev3b): copia del PDF de markups SIN firmas digitales
(el sello visible del campo /Sig se aplana en la hoja) y con Page Label = hoja en TODAS las páginas.

Un PDF con campos /FT /Sig (y /SigFlags 3) bloquea en Bluebeam Page Labels e insertar / quitar páginas aunque no muestre
candado. Origen: cache_proyectos/herramientas/quitar_firmas_labels.py (CR City Hotel rev3b), copiada al skill en v81cf58.

Uso: python3 -I quitar_firmas_labels.py <markups.pdf> <salida.pdf> <inventario.json> ['{"pagina":"HOJA",...}']
     inventario.json = {"sheets": [{"page": 1, "sheet": "A0.01"}, ...]} (páginas base 1); el JSON opcional corrige / completa
     hojas leídas a ojo en el title block (hojas escaneadas sin texto).
Chequeo: compuerta_entrega.py CE_PDF_EDITABLE (o `compuerta_entrega.py pdf_editable <pdf>`): 0 campos /Sig, sin /SigFlags ni
/Perms, Page Labels únicos = páginas, ninguno puramente numérico salvo hoja impresa así.
"""
import json
import sys


def es_firma(a):
    from pikepdf import Name
    ft = a.get('/FT') or (a.get('/Parent') or {}).get('/FT')
    return ft == Name.Sig


def quitar(src, dst, sheets):
    """sheets {pagina base 1: hoja}. -> número de campos de firma quitados."""
    import pikepdf
    from pikepdf import Dictionary, Array
    pdf = pikepdf.open(src)
    quitadas = 0
    for page in pdf.pages:
        annots = page.obj.get('/Annots')
        if not annots:
            continue
        keep = Array()
        for a in annots:
            if es_firma(a):
                ap = a.get('/AP')
                n = ap.get('/N') if ap else None
                if n is not None and isinstance(n, pikepdf.Stream):
                    r = [float(v) for v in a.Rect]
                    page.add_overlay(n, pikepdf.Rectangle(*r))     # sello visible conservado (aplanado)
                quitadas += 1
            else:
                keep.append(a)
        page.obj.Annots = keep
    af = pdf.Root.get('/AcroForm')
    if af is not None:
        f = Array([x for x in af.get('/Fields', []) if not es_firma(x)])
        if len(f):
            af.Fields = f
        else:
            del pdf.Root['/AcroForm']
        if '/AcroForm' in pdf.Root and '/SigFlags' in pdf.Root.AcroForm:
            del pdf.Root.AcroForm['/SigFlags']
    if '/Perms' in pdf.Root:
        del pdf.Root['/Perms']
    nums = Array()
    for i in range(len(pdf.pages)):
        lab = sheets.get(i + 1) or ('LEGEND' if i == len(pdf.pages) - 1 else str(i + 1))
        nums.append(i)
        nums.append(Dictionary(P=pikepdf.String(lab)))
    pdf.Root.PageLabels = Dictionary(Nums=nums)
    pdf.save(dst)
    return quitadas


def main(argv):
    if len(argv) < 4:
        print(__doc__)
        return 2
    src, dst, inv = argv[1], argv[2], argv[3]
    extra = json.loads(argv[4]) if len(argv) > 4 else {}
    sheets = {x['page']: x['sheet'] for x in json.load(open(inv, encoding='utf-8'))['sheets']}
    sheets.update({int(k): v for k, v in extra.items()})
    print('firmas quitadas', quitar(src, dst, sheets))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
