#!/usr/bin/env python3
"""test_traza_hojas.py — R80w.28: trazabilidad cita hojas de 3 dígitos sin guion (X101), con sufijo de letra (10/X505.B) y
el grid de drywall cita la hoja de sus ceilings (antes: "default (no sheet)" en renglones con fuente). Sintético; falla
con trazabilidad v80v."""
import json, os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import trazabilidad as T
assert T.RX_NH.search("10/X505.B").group(0) == "10/X505.B"
assert T.RX_HOJA.search("A101, A102 sheets").group(0) == "A101"
d = tempfile.mkdtemp()
F = "USG drywall main tee (DGLW26)"
json.dump({"familias": {F: 10.0}, "partition_types": {"types": {}}, "accesorios": {},
           "filas": [{"familia": "ceilings", "room": "R1", "source": "C-5/X121; X421.A", "operacion": "usg_grid: main tee 10"}]},
          open(os.path.join(d, "familias_out.json"), "w"))
for n, v in (("studs_out.json", {"walls": []}), ("board_out.json", {"caras": []}), ("corridas_out.json", {"renglones": []})):
    json.dump(v, open(os.path.join(d, n), "w"))
cp = os.path.join(d, "canon.json"); json.dump({"walls": []}, open(cp, "w"))
out = T.aplicar({"materials": [{"material": "X main tee", "unit": "LF", "net": 10.0, "familia": F, "source": "x"}], "walls": []}, d, cp)
assert "default (no sheet)" not in out["materials"][0]["cita"] and "5/X121" in out["materials"][0]["cita"], out["materials"][0]["cita"]
print("test_traza_hojas OK")

# BE-CR07 (regresión): Type C con su desglose por caras + ceiling resilient channel x capas (antes no cuadraba con el renglón)
# BE-GK34 (regresión): 1/2" EXTERIOR gyp sheathing lista las caras de walls además de las filas misc (la suma = NET)
import canon as _C
FC, FE = _C.BOARD_FAM["5/8 type C"], _C.BOARD_FAM["1/2 exterior gyp sheathing"]
d2 = tempfile.mkdtemp()
json.dump({"familias": {FC: 190.0, FE: 100.0}, "partition_types": {"types": {}}, "accesorios": {},
           "filas": [{"familia": FE, "ref": "X9-EXT-01 misc", "source": "5/X9.07", "operacion": "6.0 x 10.0 = 60.0 SF"}]},
          open(os.path.join(d2, "familias_out.json"), "w"))
for n, v in (("studs_out.json", {"walls": []}), ("corridas_out.json", {"renglones": []}),
             ("board_out.json", {"caras": [{"wall": "Z9-01", "board": "5/8 type C", "sf": 90.0, "room": "x"},
                                           {"wall": "Z9-03", "board": "1/2 exterior gyp sheathing", "sf": 40.0, "room": "exterior"}]})):
    json.dump(v, open(os.path.join(d2, n), "w"))
cp2 = os.path.join(d2, "canon.json")
json.dump({"walls": [{"id": "Z9-01", "detail": "1/X9.05"}, {"id": "Z9-03", "detail": "2/X9.05"}],
           "misc_items": [{"ref": "X9-EXT-01 misc", "qty": 60.0}],
           "ceilings": [{"room": "CLG-X9-01", "board": "5/8 type C", "system": "resilient_channel", "area_sf": 50.0,
                         "layers": {"value": 2}, "detail": "3/X9.06"}]}, open(cp2, "w"))
o2 = T.aplicar({"materials": [{"material": "5/8 Type C", "unit": "SF", "net": 190.0, "familia": FC, "source": "x"},
                              {"material": "1/2 ext sheathing", "unit": "SF", "net": 100.0, "familia": FE, "source": "x"}], "walls": []}, d2, cp2)
c_c, c_e = o2["materials"][0]["cita"], o2["materials"][1]["cita"]
assert "Z9-01 90" in c_c and "ceiling CLG-X9-01 100" in c_c and "= 190 SF" in c_c, c_c          # BE-CR07
assert "Z9-03 40" in c_e and "X9-EXT-01 misc 60" in c_e and "= 100 SF" in c_e, c_e              # BE-GK34
print("test_traza_hojas BE-CR07 / BE-GK34 OK")

# BE-CR07 (v81cf96, hallado por el post-mortem): la familia 5/8" EXTERIOR gyp sheathing Type X no entraba a la rama de board
# (no empieza con '5/8" gyp'): sin desglose por caras y cita 'default (no sheet)'
FX = _C.BOARD_FAM["5/8 exterior gyp sheathing type X"]
d3 = tempfile.mkdtemp()
json.dump({"familias": {FX: 80.0}, "partition_types": {"types": {}}, "accesorios": {}, "filas": []}, open(os.path.join(d3, "familias_out.json"), "w"))
for n, v in (("studs_out.json", {"walls": []}), ("corridas_out.json", {"renglones": []}),
             ("board_out.json", {"caras": [{"wall": "Z9-05", "board": "5/8 exterior gyp sheathing type X", "sf": 80.0, "room": "exterior"}]})):
    json.dump(v, open(os.path.join(d3, n), "w"))
cp3 = os.path.join(d3, "canon.json")
json.dump({"walls": [{"id": "Z9-05", "detail": "4/X9.05"}]}, open(cp3, "w"))
o3 = T.aplicar({"materials": [{"material": "5/8 ext sheathing type X", "unit": "SF", "net": 80.0, "familia": FX, "source": "x"}], "walls": []}, d3, cp3)
c_x = o3["materials"][0]["cita"]
assert "Z9-05 80" in c_x and "= 80 SF" in c_x and "default" not in c_x, c_x
print("test_traza_hojas BE-CR07 5/8 exterior OK")
