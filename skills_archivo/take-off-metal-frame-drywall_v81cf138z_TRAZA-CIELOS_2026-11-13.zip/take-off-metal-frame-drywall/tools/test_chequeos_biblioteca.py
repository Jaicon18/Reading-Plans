#!/usr/bin/env python3
"""test_chequeos_biblioteca.py — orden del usuario 3-nov ("haz los programas"): cada chequeo de chequeos_biblioteca.py
REPRODUCE su error original (caso MALO -> FAIL) y pasa con el arreglo (caso BUENO -> PASS). Un caso por regla que estaba
"programa-pendiente" + CE_CALLOUTS (U-113 / BE-124: burbuja 7/A9.26 de la marquesina sin seguir) + env_api (BE-91) +
A_CATALOGO (BE-CF08: archivo nuevo en referencias/ sin clasificar) + cableado en compuerta_entrega.py.
Uso: python3 -I test_chequeos_biblioteca.py"""
import copy
import json
import os
import shutil
import subprocess
import sys
import tempfile

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import chequeos_biblioteca as CB  # noqa: E402

B = CB.B


def W(i, tag="2", sheet="A-101", L=20.0, H=10.0, faces=None, **kw):
    w = {"id": i, "tag": tag, "element": "wall", "sheet": sheet, "length_ft": L, "height_ft": H,
         "length_source": f"{sheet} vector [DERIVED]", "height_source": "1/A-401 B.O. DECK 10'-0\" [CONFIRMED]",
         "band": {"ori": "H", "c0": 100, "c1": 104, "lo": 100, "hi": 100 + L * 9, "sheet": sheet},
         "faces": faces if faces is not None else [F("A", "OFFICE 901"), F("B", "OFFICE 902")]}
    w.update(kw)
    return w


def F(side, room, board="5/8 type X", layers=1, h=10.0, **kw):
    f = {"side": side, "room": room, "board": board, "layers": layers, "height_ft": h,
         "height_source": "A-401 [CONFIRMED]", "board_source": "1/A-501 '(1) LAYER 5/8\" TYPE X'"}
    f.update(kw)
    return f


def M(material, net=10.0, fuente="N/SHEET: 1/A-501", unit="LF", waste="=Inputs!$B$6", selling="run 10 ft", pieces=None, fila=4):
    return {"fila": fila, "material": material, "unit": unit, "net": net, "waste": waste, "purchase": None,
            "selling": selling, "pieces": pieces if pieces is not None else "=ROUNDUP(F4/Inputs!$B$11,0)", "fuente": fuente}


K = {"constants": {"plan_scale_pt_per_ft": {"value": 9.0, "source": "A-101 1/8\""}}}


def C(walls=None, **kw):
    c = copy.deepcopy(K)
    c["walls"] = walls if walls is not None else [W("W1")]
    c.update(kw)
    return c


RFI_OK = "(A) Drawings: x - delta 0 | (B) Code: y - delta 0 (loaded) | (C) Other"
INPUTS = [(5, "Waste - ALL METAL, any type", 0.15, ""), (6, "Waste - EVERYTHING THAT IS NOT METAL", 0.06, "")]

# ---------------------------------------------------------------- preferencias del día 1 (U-114..U-125, BE-131)
from PIL import Image as _Im, ImageDraw as _Dr  # noqa: E402
IMGD = tempfile.mkdtemp(prefix="pref_img_")


def _png(nombre, aro):
    im = _Im.new("RGB", (200, 120), (255, 255, 255))
    d = _Dr.Draw(im)
    d.text((70, 50), "B.O. DECK", fill=(0, 0, 0))
    if aro:
        d.ellipse([50, 35, 150, 80], outline=(255, 0, 0), width=3)
    im.save(os.path.join(IMGD, nombre))
    return nombre


ARO, SIN_ARO = _png("wall_W1.png", True), _png("sheet_A1.2.png", False)
open(os.path.join(IMGD, "vacia.png"), "wb").close()
OCC = [{"kind": "partition_tag", "type": "D", "sheet": "A1.1", "id": f"PT000{i}", "png": ARO, "png_verificado": True} for i in (1, 2, 3)]
W_OK = dict(length_source="A1.1 vector 1411.4 pt / 6.75 = 209.1 ft [DERIVED]", img=ARO, height_img=ARO)


# caso: función -> (kwargs MALO = error original, kwargs BUENO = arreglo)
CASOS = {
    # ---- preferencias del día 1 (usuario 3-nov, BE-131)
    # U-114 #0: demising cara vecina "[DERIVED]" sin operación + "same as" sin wall + escalado sin PENDING
    "u_114": ({"canon": C([W("W1", length_source="A1.1 vector [DERIVED]", faces=[F("A", "HFT", height_source="D/A4.1 '1 LAYER 5/8\" "
                                "TYPE X GYP. BD. @ EACH SIDE' to 1\" below deck [DERIVED]")]),
                              W("RE-01", length_source="S2.1 opening widths measured at scale [DERIVED] 1411 / 6.75 = 10 ft")])},
              {"canon": C([W("W1", length_source="A1.1 vector 1411.4 pt / 6.75 = 209.1 ft [DERIVED]",
                             faces=[F("A", "HFT", height_source="B.O. deck 18.25 (3/A-301) - 0.08 slip = 18.17 ft [DERIVED]")]),
                           W("W3", length_source="A1.1 printed '20'-0\"' [CONFIRMED]", height_source="same as W1")])}),
    # U-115: O'Reilly rev4 Material Summary 'N/SHEET: not applicable (see note)' (CE_FUENTES_MS lo dejaba pasar)
    "u_115": ({"ms": [M("FRT plywood substrate (5/8 in.)", 420.25, unit="SF", fuente="N/SHEET: not applicable (see note)")],
               "pt": [{"fila": 6, "wall": "EX-DIN-01", "lf": 12.0, "source": "A.3 interior elevation general notes"}]},
              {"ms": [M("FRT plywood substrate (5/8 in.)", 420.25, unit="SF", fuente="N/SHEET: 7/A4.2")],
               "pt": [{"fila": 6, "wall": "EX-DIN-01", "lf": 12.0, "source": "A.3/A-202"}]}),
    # U-116: HFT 'metal hat channel ... (not printed)' y espaciado 'assumed' sin RFI = elección en silencio
    "u_116": ({"ms": [M("Bracing 1-1/2\" CRC", 40, fuente="N/SHEET: A1.1 | spacing not printed: 4'-0\" O.C. assumed")],
               "pend": [("RFI-05", "Braces to structure", RFI_OK)]},
              {"ms": [M("Bracing 1-1/2\" CRC", 40, fuente="N/SHEET: A1.1 | spacing not printed: 4'-0\" O.C. assumed, see RFI-05")],
               "pend": [("RFI-05", "Braces to structure", RFI_OK)]}),
    # U-117: tags D del plano que el canon no cuenta (ubicaciones sin wall); sin inventario = barrido no hecho
    "u_117": ({"canon": C([W("W1", tag="D", tag_ids=["PT0001"])]), "inv_full": {"ocurrencias": {"partition_tag": OCC}}, "inv_dir": IMGD},
              {"canon": C([W("W1", tag="D", tag_ids=["PT0001", "PT0002"]), W("W2", tag="D", tag_ids=["PT0003"])]),
               "inv_full": {"ocurrencias": {"partition_tag": OCC}}, "inv_dir": IMGD}),
    # U-118: O'Reilly — height_img = página entera sin marca (0 px rojos); RFI y Review Item sin imagen
    "u_118": ({"canon": C([W("S21-N", img=ARO, height_img=SIN_ARO)]), "raiz": IMGD,
               "pend": [("RFI-01", "Height basis per bay", RFI_OK)], "review": [("1/7", "Floor plan", "C", "W5", "A1.1", "plan crop of A1.1")]},
              {"canon": C([W("S21-N", img=ARO, height_img=ARO)], rfis=[{"id": "RFI-01", "img": ARO}]), "raiz": IMGD,
               "pend": [("RFI-01", "Height basis per bay", RFI_OK)], "review": [("1/7", "Floor plan", "C", "W5", "A1.1", "wall_W1.png")]}),
    # U-119: README_REVIEW con prosa en español (el entregable va íntegro en inglés)
    "u_119": ({"docs": {"README_REVIEW.md": "# ESTA ES LA VERSIÓN FINAL PARA REVISAR\nLa altura de los muros sale de la hoja A-401.\n| 5 | 3/A2.1 | A1.1 | 3/A2.1 | fuera de alcance: East exterior elevation |"}},
              {"docs": {"README_REVIEW.md": "# ESTA ES LA VERSIÓN FINAL PARA REVISAR\nWall heights come from 1/A-401 (B.O. DECK EL. 18'-3\").\nType X wraps to B.O. framing EL 108'-6\" | studs to EL 120'-8\".",
                        "PARA_REVISAR_EN_LA_MANANA.md": "La altura de los walls sale de la hoja A-401."}}),
    # U-120: O'Reilly rev4 'S42-H1+S42-H2' en un renglón + polilínea en L (dos ejes en un markup)
    "u_120": ({"pt": [{"fila": 25, "wall": "S42-H1+S42-H2", "lf": 30.0}],
               "annots": [{"label": "A1.1", "subject": "S42", "contents": "S42 | LF 30 | S42-H1", "tipo": "PolyLine",
                           "verts": [(0, 0), (100, 0), (100, 80)]}]},
              {"pt": [{"fila": 25, "wall": "S42-H1", "lf": 15.0}],
               "annots": [{"label": "A1.1", "subject": "S42", "contents": "S42 | LF 15 | S42-H1", "tipo": "PolyLine",
                           "verts": [(0, 0), (60, 0), (100, 1)]}]}),
    # U-121: markup sin /Depth (Bluebeam no da Wall Area) y sin Subject
    "u_121": ({"annots": [{"label": "A1.1", "subject": "", "contents": "A-01 | LF 11.54", "measure": True, "tipo": "PolyLine", "depth": None}]},
              {"annots": [{"label": "A1.1", "subject": "TYPE A", "contents": "A-01 | LF 11.54", "measure": True, "tipo": "PolyLine", "depth": 18.04}]}),
    # U-125: PARA_REVISAR con 'tablaroca' / 'postes metálicos' (términos del trade traducidos)
    "u_125": ({"docs": {"PARA_REVISAR_EN_LA_MANANA.md": "Se cargó tablaroca 5/8 tipo X y postes metálicos de 6\"."}},
              {"docs": {"PARA_REVISAR_EN_LA_MANANA.md": "Se cargó 5/8 Type X gypsum board y studs 6\" 20 GA."}}),
    # U-017 (B&N §0.F): A leyó la cota impresa 12'-4"; la resolución tomó B (12.9)
    "u_017": ({"canon_a": C([W("W1", L=12.333, length_source="A-101 printed '12'-4\"' [CONFIRMED]")]), "canon_b": C([W("W1", L=12.9)]),
               "canon_ab": C([W("W1", L=12.9)])},
              {"canon_a": C([W("W1", L=12.333, length_source="A-101 printed '12'-4\"' [CONFIRMED]")]), "canon_b": C([W("W1", L=12.9)]),
               "canon_ab": C([W("W1", L=12.333)])}),
    "be_08": ({"canon": C([W("W1", L=11.9, length_source="A-101 printed '12'-4\"' [CONFIRMED]")])},
              {"canon": C([W("W1", L=12.333, length_source="A-101 printed '12'-4\"' [CONFIRMED]")])}),
    # U-026 / BE-108: RFI de control joints, ya decidido por R80e.34 #8
    "u_026": ({"pend": [("RFI-05", "Control joints not detailed: spacing?", RFI_OK)]},
              {"pend": [("RFI-05", "Control joints per R80e.34 #8 precedent", RFI_OK)]}),
    # U-034 / BE-59: lectura A sin la hoja ampliada que B sí trae
    "u_034": ({"canon_a": C([W("W1")]), "canon_b": C([W("W1"), W("W9", sheet="A-221")])},
              {"canon_a": C([W("W1"), W("W9", sheet="A-221")]), "canon_b": C([W("W1"), W("W9", sheet="A-221")])}),
    # U-035 / BE-65: canon sin plan_scale_pt_per_ft (W2-01 band 50.0 vs 48'-4")
    "u_035": ({"canon": {"walls": [W("W1")]}}, {"canon": C()}),
    # U-037 / BE-72: tags de un type en el inventario y ningún wall de ese type
    "u_037": ({"canon": C([W("W1", tag="2")]), "inventario": [{"type": "4", "sheet": "A-101"}, {"type": "2", "sheet": "A-101"}]},
              {"canon": C([W("W1", tag="2"), W("W2", tag="4")]), "inventario": [{"type": "4", "sheet": "A-101"}, {"type": "2", "sheet": "A-101"}]}),
    # U-043 / BE-94: R80e.43 validado con una sola corrida
    "u_043": ({"textos": {"INDICE.md": "**03-nov: v9 = VERSIÓN VIGENTE PARA EL PRÓXIMO PROYECTO** = arreglo, probado con la #4"}},
              {"textos": {"INDICE.md": "**03-nov: v9 = VERSIÓN VIGENTE PARA EL PRÓXIMO PROYECTO** = arreglo. Banco #3 #4 #5 = 0 familias distintas"}}),
    # U-051 / BE-100: bid set de O'Reilly con 79 markups de Bluebeam de otro estimador
    "u_051": ({"bidset_annots": [{"title": "jsmith", "subject": "Length Measurement"}, {"title": "AutoCAD SHX Text", "subject": ""}]},
              {"bidset_annots": [{"title": "AutoCAD SHX Text", "subject": ""}]}),
    # U-057 / BE-110: altura del purlin medida a escala; board con aberturas descontadas
    "u_057": ({"canon": C([W("W1", height_source="purlin height scaled from 1/A3.2 [DERIVED]",
                             faces=[F("A", "X", note="less openings deducted"), F("B", "Y")])])}, {"canon": C()}),
    # U-058 / BE-111: head interior del storefront tomado de la cota exterior T.O. high eave
    "u_058": ({"canon": C([W("W1", faces=[F("A", "SALES 101", height_source="5'-0 3/4\" from 1/A3.1 to T.O. high eave")])])},
              {"canon": C([W("W1", faces=[F("A", "SALES 101", height_source="11'-4\" R.O. A5.2 -> 12'-0\" 1/A5.2 interior face")])])}),
    # U-079 / BE-CF01: la copia limpia borró los 519 'AutoCAD SHX Text': M/P/E sin texto
    "be_cf01": ({"hojas": {"A-101": "FLOOR PLAN", "M-101": "", "P-101": " ", "E-101": ""}},
                {"hojas": {"A-101": "FLOOR PLAN", "M-101": " ".join(["SUPPLY DUCT 12x10 TO DIFFUSER"] * 5),
                           "P-101": " ".join(["SANITARY WASTE LINE VENT"] * 5), "E-101": " ".join(["PANEL LP CIRCUIT HOMERUN"] * 5)}}),
    # U-081 / BE-CF06: comparar.py solo walls: sin revision_extra con cielos / demo
    "u_081": ({"canon_a": C(ceilings=[{"room": "901"}]), "canon_b": C(ceilings=[{"room": "901"}])},
              {"canon_a": C(ceilings=[{"room": "901"}]), "canon_b": C(ceilings=[{"room": "901"}]),
               "textos": {"etapas/2_lectura/revision_extra.md": "| ceilings | A 2 | B 2 |"}}),
    # U-082 / R-ALC-10: conflicto plano vs spec sin hoja / sección / delta
    "u_082": ({"ms": [M("Track 3-5/8\"", fuente="N/SHEET: drawings conflict with spec, plan carried")]},
              {"ms": [M("Track 3-5/8\"", fuente="N/SHEET: 1/A-501 conflict with spec 09 22 16 2.2.B (20 GA): plan 25 GA carried, delta +3%")]}),
    # R-ALC-02: blocking de grab bar sin medida impresa cargado 1 fila x 2 ft
    "r_alc_02": ({"canon": C(blocking_items=[{"ref": "GB-1", "rows": 1, "lf_each": 2, "source": "grab bar, size not printed"}])},
                 {"canon": C(blocking_items=[{"ref": "GB-1", "rows": 2, "lf_each": 3, "source": "grab bar, size not printed (R-ALC-02)"}])}),
    # R-ALC-04: demo plan quita partitions de gyp y no hay renglón de demolición
    "r_alc_04": ({"hojas": {"D-101": "DEMOLITION PLAN  REMOVE EXISTING GYP. BD. PARTITION"}, "ms": [M("Bottom track 3-5/8\"")]},
                 {"hojas": {"D-101": "DEMOLITION PLAN  REMOVE EXISTING GYP. BD. PARTITION"}, "ms": [M("Bottom track 3-5/8\""),
                                                                                                  M("Demolition gyp board partition", 200, unit="SF")]}),
    # BE-01: 8/A-410 'METAL STUD/TRACK FIRE STOP AT CEILING LINE, TYP.' sin cuantificar
    "be_01": ({"hojas": {"A-410": "8 METAL STUD/TRACK FIRE STOP AT CEILING LINE, TYP."}, "ms": [M("Bottom track")]},
              {"hojas": {"A-410": "8 METAL STUD/TRACK FIRE STOP AT CEILING LINE, TYP."}, "ms": [M("Fire stop track 3-5/8\"")]}),
    "be_02": ({"hojas": {"A-001": "W.R. GYP BD FOR WALL AND CEILING CONSTRUCTION AT WET AREAS"},
               "canon": C(ceilings=[{"room": "WOMEN'S 910", "system": "suspended gyp", "board": "5/8 type X"}])},
              {"hojas": {"A-001": "W.R. GYP BD FOR WALL AND CEILING CONSTRUCTION AT WET AREAS"},
               "canon": C(ceilings=[{"room": "WOMEN'S 910", "system": "suspended gyp", "board": "5/8 W.R."}])}),
    "be_03": ({"hojas": {"A-001": "W.R. GYP BD AT WET AREAS"}, "canon": C([W("W1", faces=[F("A", "RESTROOM 910", "5/8 type X")])])},
              {"hojas": {"A-001": "W.R. GYP BD AT WET AREAS"}, "canon": C([W("W1", faces=[F("A", "RESTROOM 910", "5/8 W.R.")])])}),
    "be_04": ({"canon": C([W("W1", faces=[F("A", "CAFE WORK ROOM", "5/8 W.R.", board_source="E/A-221 5/8\" FRT PLYWOOD only + FRP")])])},
              {"canon": C([W("W1", faces=[F("A", "CAFE WORK ROOM", "none", layers=0, board_source="E/A-221 5/8\" FRT PLYWOOD only + FRP")])])}),
    "be_05": ({"canon": C([W("W1", faces=[F("A", "SALES", layers=2)])])}, {"canon": C()}),
    "be_06": ({"canon": C([W("S1", tag="SOFFIT", element="soffit", faces=[F("N", "SALES")])])},
              {"canon": C([W("S1", tag="SOFFIT", element="soffit", faces=[F("N", "SALES"), F("bottom", "SALES")])])}),
    "be_07": ({"canon": C(partition_schedule=[{"type": "3", "source": "A-501"}]), "hojas": {"A-101": "3 SIM. 3 2"}},
              {"canon": C([W("W1"), W("W1-SIM", tag="3", length_source="A-101 SIM. tag end face 0.4 ft")],
                          partition_schedule=[{"type": "3", "source": "A-501"}]), "hojas": {"A-101": "3 SIM. 3 2"}}),
    "be_09": ({"canon": C([W("W1", length_source="A-101 existing partition to remain")])}, {"canon": C()}),
    "be_10": ({"scope": [("ALC-20", "Soffit", "RFI", "soffit with HOLD dimension, not priced")]},
              {"scope": [("ALC-20", "Soffit", "QUANTIFIED", "soffit HOLD dimension quantified + RFI-04")]}),
    "be_11": ({"hojas": {"A-221": "AREA OF 3/4\" FIRE RESISTANT PLYWOOD"}, "ms": [M("Bottom track")]},
              {"hojas": {"A-221": "AREA OF 3/4\" FIRE RESISTANT PLYWOOD"}, "ms": [M("3/4\" FRT plywood", 40, unit="SF")]}),
    "be_12": ({"hojas": {"A-501": "1 PARTITION TYPES"}, "ms": [M("Head track", fuente="N/SHEET: 1/A-501 'ADD FULL LENGTH ADDL HEAD TRACK AT OPENINGS'")]},
              {"hojas": {"A-501": "1 PARTITION TYPES ADD FULL LENGTH ADDL HEAD TRACK AT OPENINGS"},
               "ms": [M("Head track", fuente="N/SHEET: 1/A-501 'ADD FULL LENGTH ADDL HEAD TRACK AT OPENINGS'")]}),
    "be_13": ({"hojas": {"E-103": "2 SERVER ROOM 3/4\" PLYWOOD BACKBOARD BY GC"}, "ms": [M("Bottom track")]},
              {"hojas": {"E-103": "2 SERVER ROOM 3/4\" PLYWOOD BACKBOARD BY GC"}, "ms": [M("Bottom track")],
               "scope": [("ALC-30", "Backboard", "EXCLUDED", "plywood backboard 2/E-103 BY GC (R80e.34 #11)")]}),
    "be_14": ({"hojas": {"A-401": "T.O. WD-1 15'-0\" A.F.F."}, "pend": [("RFI-03", "T.O. WD-1 not printed; assumed 16'", RFI_OK)]},
              {"hojas": {"A-401": "SECTION"}, "pend": [("RFI-03", "T.O. WD-1 not printed; assumed 16'", RFI_OK)]}),
    "be_15": ({"canon": C(misc_items=[{"ref": "J-1", "familia": "1-5/8\" post vertical", "source": "3/A-410 '1 5/8\" x 16 GA. METAL JOIST FRAMING @ 48\" O.C.'"}])},
              {"canon": C(misc_items=[{"ref": "J-1", "familia": "1-5/8\" joist horizontal", "source": "3/A-410 '1 5/8\" x 16 GA. METAL JOIST FRAMING @ 48\" O.C.'"}])}),
    "be_16": ({"hojas": {"A-410": "CLIP ANGLE AT EACH STUD"}, "ms": [M("Bottom track")]},
              {"hojas": {"A-410": "CLIP ANGLE AT EACH STUD"}, "ms": [M("Clip angle 2x2", 20, unit="EA")]}),
    "be_17": ({"canon": C([W("W1", gauge="20 GA"), W("W2", gauge="16 GA")]), "ms": [M("Framing screws #8", 500, unit="EA")]},
              {"canon": C([W("W1", gauge="20 GA"), W("W2", gauge="16 GA")]), "ms": [M("Framing screws #8 (EXCLUDED)", 0, unit="EA")]}),
    "be_18": ({"textos": {"PASO12_cobertura.md": "| BE-13 | backboard | GAP |"}}, {"textos": {"PASO12_cobertura.md": "| BE-13 | backboard | OK |"}}),
    "be_19": ({"hojas": {"A-410": "SLAB PINS @ 24\" O.C."}, "ms": [M("Slab pins @ 12\"", 300, unit="EA")]},
              {"hojas": {"A-410": "SLAB PINS @ 24\" O.C."}, "ms": [M("Slab pins @ 24\"", 300, unit="EA")]}),
    "be_20": ({"canon": C([W("S1", tag="SOFFIT", element="soffit", faces=[F("N", "X"), F("bottom", "X")])]), "ms": [M("Track 3-5/8\"", fuente="1/A-501 soffit perimeter")]},
              {"canon": C([W("S1", tag="SOFFIT", element="soffit", faces=[F("N", "X"), F("bottom", "X")])]),
               "ms": [M("Track 3-5/8\"", fuente="1/A-501 soffit 2 tracks"), M("Stud 3-5/8\"", fuente="1/A-501 soffit studs @ 16")]}),
    "be_21": ({"hojas": {"A-501": "5/8 TYPE X"}, "ms": [M("5/8\" glass mat sheathing", 100, unit="SF")]},
              {"hojas": {"A-501": "5/8\" GLASS MAT SHEATHING"}, "ms": [M("5/8\" glass mat sheathing", 100, unit="SF")]}),
    "be_22": ({"hojas": {"A-501": "JAMB"}, "ms": [M("Jamb return gypsum", 30)]}, {"hojas": {"A-501": "GYP BD RETURN AT JAMB"}, "ms": [M("Jamb return gypsum", 30)]}),
    "be_23": ({"ms": [M("Acoustical sealant", 20, unit="TUBE")]}, {"ms": [M("Acoustical sealant (EXCLUDED)", 0, unit="TUBE")]}),
    "be_25": ({"canon": C(ceilings=[{"room": "901", "system": "suspended gypsum furring", "board": "5/8 type X"}])},
              {"canon": C(ceilings=[{"room": "901", "system": "suspended gypsum furring", "board": "5/8 type X", "system_callout": "5/A-601"}])}),
    "be_26": ({"canon": C([W("K1", tag="K", length_source="A-101 node to node N3-N4")])},
              {"canon": C([W("K1", tag="K", length_source="A-101 hatch extent printed 8'-0\"")])}),
    "be_27": ({"hojas": {"A-101": "ATM RECESS"}, "canon": C()}, {"hojas": {"A-101": "ATM RECESS"}, "canon": C(atm_recess_none_reason="ATM by vendor 3/A-101")}),
    "be_28": ({"hojas": {"A-301": "CANOPY FRAMING 6\" STUDS"}, "ms": [M("Bottom track")]},
              {"hojas": {"A-301": "CANOPY FRAMING 6\" STUDS"}, "ms": [M("Bottom track")], "scope": [("ALC-03", "Canopy / parapet", "QUANTIFIED", "canopy studs")]}),
    "be_29": ({"ms": [M("Header track", 40, fuente="1/A-501 assumed 2 pcs per door")]},
              {"ms": [M("Header track", 40, fuente="1/A-501 R80e.34 #4 precedent 2 pcs per door")]}),
    "be_41": ({"scope": [("ALC-05", "Headers", "QUANTIFIED", "by headers.py from takeoff_canon.json")]},
              {"scope": [("ALC-05", "Headers", "QUANTIFIED", "door schedule A-601")]}),
    "be_45": ({"pt": [{"fila": 5, "wall": "W1", "board": 400.0}], "ms": [M("5/8\" Type X gypsum board", 1200, unit="SF")]},
              {"pt": [{"fila": 5, "wall": "W1", "board": 400.0}], "ms": [M("5/8\" Type X gypsum board", 420, unit="SF")]}),
    "be_46": ({"ms": [M("Cement board 1/2\" / 5/8\" backer", 100, unit="SF")]}, {"ms": [M("Cement board 1/2\" backer", 100, unit="SF")]}),
    "be_47": ({"scope": [("ALC-26", "X", "RFI", "see RFI-40")], "pend": [("RFI-01", "q", RFI_OK)]},
              {"scope": [("ALC-26", "X", "RFI", "see RFI-01")], "pend": [("RFI-01", "q", RFI_OK)]}),
    "be_48": ({"annots": [{"label": "A-101", "subject": "Legend", "contents": "Source: takeoff_canon.json", "measure": False}]},
              {"annots": [{"label": "A-101", "subject": "2", "contents": "TYPE 2 LF 20", "measure": True}]}),
    "be_49": ({"canon": C([W("LWT-01", L=46.0, length_source="A-101 printed '46'-0\"' [CONFIRMED]",
                            band={"ori": "H", "c0": 1, "c1": 2, "lo": 0, "hi": 48.83 * 9 + 100, "sheet": "A-101"})])},
              {"canon": C([W("LWT-01", L=46.0, length_source="A-101 printed '46'-0\"' [CONFIRMED]",
                            band={"ori": "H", "c0": 1, "c1": 2, "lo": 0, "hi": 46.0 * 9, "sheet": "A-101"})])}),
    "be_50": ({"hojas": {"E-301": "LIGHT FIXTURE SUPPORT WIRES BY THE EC"}, "pend": [("RFI-01", "q", RFI_OK)]},
              {"hojas": {"E-301": "LIGHT FIXTURE SUPPORT WIRES BY THE EC"}, "pend": [("RFI-07", "E-301 support wires by the EC vs 5/A-121", RFI_OK)]}),
    "be_51": ({"ms": [M("2x blocking", 37.5, selling="piece", pieces="=ROUNDUP(F4,0)")]},
              {"ms": [M("2x blocking", 37.5, selling="piece", pieces="=ROUNDUP(F4/Inputs!$B$11,0)")]}),
    "be_52": ({"ms": [M("Bottom track", fila=4), M("Framing screws", 0, fila=5)], "scope": [("ALC-40", "#8 screws", "QUANTIFIED", "covered by row 5")]},
              {"ms": [M("Bottom track", fila=4), M("Framing screws", 10, fila=5)], "scope": [("ALC-40", "#8 screws", "QUANTIFIED", "covered by row 5")]}),
    "be_53": ({"pend": [("RFI-28", "A/A-410 prints '(1) #10-16 SCREW @ EACH FLANGE' and clip", "(A) Drawings: clip angle delta +20 EA | (B) Code delta 0 (loaded) | (C)")]},
              {"pend": [("RFI-28", "A/A-410 prints '(1) #10-16 SCREW @ EACH FLANGE' and clip", "(A) Drawings: clip angle + screws (EXCLUDED U-053) delta | (B) delta (loaded) | (C)")]}),
    "be_54": ({"ms": [M("Drywall screws Type S", 10, fuente="board total minus cement board base")]}, {"ms": [M("Drywall screws Type S", 10, fuente="per face")]}),
    "be_55": ({"pend": [("RFI-02", "per C7-03 rev7 plan check", RFI_OK)]}, {"pend": [("RFI-02", "per 3/A-410", RFI_OK)]}),
    "be_57": ({"inputs": INPUTS, "ms": [M("2x6 FRT wood blocking", 30, waste="=Inputs!$B$5")]},
              {"inputs": INPUTS, "ms": [M("2x6 FRT wood blocking", 30, waste="=Inputs!$B$6")]}),
    "be_58": ({"bitacora": [{"paso": "excel a mano"}]}, {"bitacora": [{"paso": "canon.py"}, {"paso": "reglas.py ok"}, {"paso": "plantilla_excel.py"}]}),
    "be_60": ({"canon_a": {"walls": [], "HG1": {}}, "canon_b": C()}, {"canon_a": C(), "canon_b": C()}),
    "be_61": ({"canon_a": C([W("W1")]), "canon_b": C([W("W1"), W("W2"), W("W3")]), "canon_ab": C([W("W1")])},
              {"canon_a": C([W("W1")]), "canon_b": C([W("W1"), W("W2"), W("W3")]), "canon_ab": C([W("W1"), W("W2"), W("W3")])}),
    "be_62": ({"canon": C([W("C25", tag="C25", band={"ori": "BOX", "x0": 1, "y0": 1, "x1": 9, "y1": 9, "sheet": "A-101"})])},
              {"canon": C([W("C25", tag="C25", element="column_wrap", band={"ori": "BOX", "x0": 1, "y0": 1, "x1": 9, "y1": 9, "sheet": "A-101"})])}),
    "be_63": ({"canon_a": C([W("W1", L=20)]), "canon_b": C([W("W1", L=20.1)]), "canon_ab": C([W("W1", L=24.5)])},
              {"canon_a": C([W("W1", L=20)]), "canon_b": C([W("W1", L=20.1)]), "canon_ab": C([W("W1", L=20)])}),
    "be_64": ({"canon_a": C([W("W1", length_source="from FINAL_FOR_REVIEW rev13")]), "canon_b": C()}, {"canon_a": C(), "canon_b": C()}),
    "be_66": ({"costos": [{"paso": "lectura_B", "usd": "", "tope": "4"}]}, {"costos": [{"paso": "lectura_B", "usd": "3.9", "tope": "4"}]}),
    "be_67": ({"canon": C(nodes=[{"id": "NP3", "kind": "L", "walls": ["W1", "EXT-07"]}])}, {"canon": C(nodes=[{"id": "NP3", "kind": "L", "walls": ["W1"]}])}),
    "be_68": ({"canon": C([W("W1", height_source="20 ft", length_source="vector")])}, {"canon": C()}),
    "be_69": ({"ms": [M("5/8\" Type X gypsum board", 100, unit="SF", fuente="A-501 | 5/8\" regular faces 40 + X 60")]},
              {"ms": [M("5/8\" Type X gypsum board", 100, unit="SF", fuente="A-501 | X faces 100")]}),
    "be_70": ({"hojas": {"A-121": "GYP. BD. CEILING @ 9'-0\""}, "canon": C()},
              {"hojas": {"A-121": "GYP. BD. CEILING @ 9'-0\""}, "canon": C(ceilings=[{"room": "910", "board": "5/8 type X"}])}),
    "be_71": ({"canon_a": C(), "canon_b": C()},
              {"canon_a": C(), "canon_b": C(), "textos": {"3_revision/resolucion.md": "x", "PASO12_cobertura.md": "| ok |"}}),
    "be_73": ({"pt": [{"fila": 9, "partition": None, "wall": "2-11", "lf": 3.0}]}, {"pt": [{"fila": 9, "partition": "TYPE 2", "wall": "2-11", "lf": 3.0}]}),
    "be_76": ({"canon": C([W("W1", faces=[F("A", "X", "5/8 regular")])], generales={"board": "5/8 type X", "board_reemplaza": "5/8 regular"})},
              {"canon": C([W("W1")], generales={"board": "5/8 type X", "board_reemplaza": "5/8 regular"})}),
    "be_77": ({"canon_a": C([W("C-E2", faces=[F("A", "WORKROOM", "1/2 cement board")])]), "canon_b": C([W("C-E2")]), "revision": {}},
              {"canon_a": C([W("C-E2", faces=[F("A", "WORKROOM", "1/2 cement board")])]), "canon_b": C([W("C-E2")]),
               "revision": {"difieren_atributos": [{"wall": "C-E2"}]}}),
    "be_78": ({"canon": C([W("W1", height_source="placeholder 20 ft [PENDIENTE]")])}, {"canon": C()}),
    "be_79": ({"canon": C([W("W1", faces=[{"board": "5/8 type X"}])])}, {"canon": C()}),
    "be_80": ({"canon_a": C(columns_none_reason="existing columns C23"), "canon_b": C(misc_items=[{"ref": "COL-1"}]), "revision": {}},
              {"canon_a": C(columns_none_reason="existing columns C23"), "canon_b": C(misc_items=[{"ref": "COL-1"}]),
               "revision": {"nones": "columns: A none / B COL-1"}}),
    "be_81": ({"canon": C([W("W1", tag="F")], partition_schedule=[{"type": "2", "source": "A-501"}])},
              {"canon": C([W("W1", tag="2")], partition_schedule=[{"type": "2", "source": "A-501"}])}),
    "be_82": ({"canon": C([W("W2-04", L=30, faces=[F("A", "CAFE WORKROOM 904")]), W("C-H1-N", sheet="A-221", L=29, faces=[F("A", "CAFE WORKROOM 904")])])},
              {"canon": C([W("W2-04", L=12, faces=[F("A", "SALES 101")]), W("C-H1-N", sheet="A-221", L=29, faces=[F("A", "CAFE WORKROOM 904")])])}),
    "be_83": ({"canon": C([W("W1", H=25, faces=[F("A", "WOMEN 910", "5/8 W.R.", h=25, height_source="A-400A")])], ceilings=[{"room": "WOMEN 910", "height_ft": 9.0}])},
              {"canon": C([W("W1", H=25, faces=[F("A", "WOMEN 910", "5/8 W.R.", h=9.5, height_source="A-121 + 6\"")])], ceilings=[{"room": "WOMEN 910", "height_ft": 9.0}])}),
    "be_84": ({"canon": C([W("CW1", element="column_wrap")]), "ms": [M("Bottom track")]},
              {"canon": C([W("CW1", element="column_wrap")]), "ms": [M("Bottom track"), M("Corner bead", 40)]}),
    "be_85": ({"canon": C(accesorios_none="PAFs and duct sleeves"), "ms": [M("Duct sleeve", 4, unit="EA")]},
              {"canon": C(accesorios_none="PAFs and duct sleeves"), "ms": [M("Bottom track")]}),
    "be_88": ({"pend": [("RFI-01", "q", "delta", "(A) planos", "(B) código")]}, {"pend": [("RFI-01", "q", RFI_OK)]}),
    "be_89": ({"canon": C(nodes=[{"id": f"N{i}", "kind": "free", "walls": ["W1"]} for i in range(8)])},
              {"canon": C(nodes=[{"id": f"N{i}", "kind": "L", "walls": ["W1"]} for i in range(8)])}),
    "be_90": ({"hojas": {"A-500": "DOOR SCHEDULE"}, "canon": C()},
              {"hojas": {"A-500": "DOOR SCHEDULE"}, "canon": C(opening_schedule={"items": [{"ref": "101"}]})}),
    "be_91": ({"env": {"ANTHROPIC_BASE_URL": "http://x", "CLAUDE_CODE_SESSION": "s", "ANTHROPIC_API_KEY": "k"}},
              {"env": CB.env_api({"ANTHROPIC_BASE_URL": "http://x", "CLAUDE_CODE_SESSION": "s", "ANTHROPIC_API_KEY": "k"})}),
    "be_92": ({"canon": C(decisiones_sin_objeto=["cross members", "nested bracing"])}, {"canon": C()}),
    "be_95": ({"canon": C([W("HG2", length_source="A-101 curved wall measured by chord")])}, {"canon": C([W("HG2", length_source="A-101 curved wall arc length")])}),
    "be_97": ({"canon": C([W("E1", faces=[F("A", "SALES", h=12), F("A", "SALES", h=25)])])}, {"canon": C([W("E1", faces=[F("A", "SALES", h=12), F("A2", "SALES", h=25)])])}),
    "be_98": ({"canon": C([W("W1", tag="1A")], excluded_types={"1A": "existing (RFI-01)"})}, {"canon": C([W("W1", tag="2")], excluded_types={"1A": "existing (RFI-01)"})}),
    "be_102": ({"hojas": {"A1.1": "PLAN"}, "ms": [M("Bottom track", fuente="8/A-410")]}, {"hojas": {"A1.1": "PLAN", "A4.1": "8"}, "ms": [M("Bottom track", fuente="8/A4.1")]}),
    "be_103": ({"canon": C([{k: v for k, v in W("W1").items() if k != "band"}])}, {"canon": C()}),
    "be_104": ({"canon": C(partition_schedule=[{"type": "S24", "source": "S24/A1.1 7/8\" Z-FURRING over CMU + 6\" STUDS"}]), "ms": [M("Stud 6\"")]},
               {"canon": C(partition_schedule=[{"type": "S24", "source": "S24/A1.1 7/8\" Z-FURRING over CMU + 6\" STUDS"}]), "ms": [M("Stud 6\""), M("Z-furring 7/8\"")]}),
    "be_105": ({"pend": [("RFI-21", "S1.1 note 7 printed Titen HD @ 48\"; default spacing loaded", RFI_OK)]},
               {"pend": [("RFI-21", "Opening width not dimensioned", RFI_OK)]}),
    "be_106": ({"scope": [("ALC-1", "x", "QUANTIFIED", "Estimator criterion / Handoff - Approved")]},
               {"scope": [("ALC-1", "x", "QUANTIFIED", "estimator criterion per R80e.34 #8")]}),
    "be_107": ({"canon": C(), "ms": [M("Framing screws", 500, unit="EA")]},
               {"canon": C(fasteners_excluded=True), "ms": [M("Framing screws", 0, unit="EA", fuente="EXCLUDED (U-053)")]}),
    "be_112": ({"canon": C([W("W1", top_track="standard track, framing hung from structure")])},
               {"canon": C([W("W1", top_track="deep-leg slip track, framing hung from structure")])}),
    "be_cf02": ({"canon": C([W("W1", tag="2")], partition_schedule=[{"type": "W4.1", "source": "A-202"}])},
                {"canon": C([W("W1", tag="W4.1")], partition_schedule=[{"type": "W4.1", "source": "A-202"}])}),
    "be_cf03": ({"canon": C([W("W1", faces=[F("A", "X", "1/2 regular")])]), "ms": [M("5/8\" Type X gypsum board", 100, unit="SF")]},
                {"canon": C([W("W1", faces=[F("A", "X", "1/2 regular")])]), "ms": [M("1/2\" gypsum board regular", 100, unit="SF")]}),
    "be_cf04": ({"canon": C([W("WD1", stud_size="2x6 wood")])}, {"canon": C(existing_walls=[{"id": "WD1", "note": "wood-framed, board only"}])}),
    "be_cf05": ({"hojas": {"p1": "x", "p2": "y", "A-101": "z"}}, {"hojas": {"G-001": "x", "A-100": "y", "A-101": "z"}}),
    "be_cf07": ({"canon": C(misc_items=[{"ref": "J1", "familia": "3-5/8\" stud", "source": "S-241 LGS CEILING JOIST SCHEDULE 6\" 600S162-43"}])},
                {"canon": C(misc_items=[{"ref": "J1", "familia": "6\" joist", "source": "S-241 LGS CEILING JOIST SCHEDULE 6\" 600S162-43"}])}),
    "be_cf09": ({"canon": C([W("ZF1", stud_size="7/8\" Z-furring", bracing_rows=2, bracing_rows_source="skill default C.R.")])},
                {"canon": C([W("ZF1", stud_size="7/8\" Z-furring", bracing_rows=0)])}),
    "be_cf10": ({"hojas": {"A-001": "SECTION 09 29 00 GYPSUM BOARD"}, "ms": [M("5/8\" Type X gypsum board", 100, unit="SF", fuente="1/A-501")]},
                {"hojas": {"A-001": "SECTION 09 29 00 GYPSUM BOARD"}, "ms": [M("5/8\" Type X gypsum board", 100, unit="SF", fuente="1/A-501 + 09 29 00 2.1.A")]}),
    "cr_r8_c": ({"canon": C(ceilings=[{"room": "R1", "area_sf": 124.0, "height_ft": None}])},
                {"canon": C(ceilings=[{"room": "R1", "area_sf": 124.0, "height_ft": 8.9375}])}),
    "cr_r6_o1": ({"canon": C(misc_items=[{"ref": "CLG-L1-07 angle molding", "familia": "USG angle molding", "qty": 33.3, "op": "4 x sqrt(69.45) = 33.33"}])},
                 {"canon": C(misc_items=[{"ref": "CLG-L1-07 angle molding", "familia": "USG angle molding", "qty": 33.9, "op": "perimeter of the measured room polygon = 33.89 LF"}])}),
    "cr_r6_o2": ({"canon": C(framed_soffits=[{"id": "S2", "floor": "L2", "detail": "7/A7.23", "faces": [{"side": "bottom", "width_ft": 1.0}]},
                                             {"id": "S3", "floor": "L3", "detail": "7/A7.23", "faces": [{"side": "bottom", "width_ft": 0.375}]}])},
                 {"canon": C(framed_soffits=[{"id": "S2", "floor": "L2", "detail": "7/A7.23", "faces": [{"side": "bottom", "width_ft": 0.375}]},
                                             {"id": "S3", "floor": "L3", "detail": "7/A7.23", "faces": [{"side": "bottom", "width_ft": 0.375}]}])}),
    "cr_r6_e1": ({"canon": C(ceilings=[{"room": "L1 FS-1 membrane under the LEVEL 2 floor", "height_ft": 12.0}],
                             misc_items=[{"ref": "CLG-L1-11 board", "source": "coffers | [CONFIRMED] height 12.063"}])},
                 {"canon": C(ceilings=[{"room": "L1 FS-1 membrane under the LEVEL 2 floor", "height_ft": 12.0}],
                             misc_items=[{"ref": "CLG-L1-12 board", "source": "field | [CONFIRMED] height 11.0"}])}),
    "be_cf11": ({"pend": [("RFI-09", "D3/A-624 blocking 2x6 wood OR 6\" metal: which?", RFI_OK)]}, {"pend": [("RFI-09", "Opening width", RFI_OK)]}),
    "be_cf13": ({"annots": [{"label": "6", "subject": "2", "contents": "TYPE 2 DERIVADO", "measure": True}]},
                {"annots": [{"label": "A-101", "subject": "2", "contents": "TYPE 2 DERIVED", "measure": True}]}),
    "be_ch03": ({"hojas": {"A-102": "ENLARGED PLAN SCALE: 3/16\" = 1'-0\""}, "canon": C(constants={"plan_scale_by_sheet": {"A-102": 18.0}})},
                {"hojas": {"A-102": "ENLARGED PLAN SCALE: 3/16\" = 1'-0\""}, "canon": C(constants={"plan_scale_by_sheet": {"A-102": 13.5}})}),
    "be_hf02": ({"review": [("1/7", "Detail", "B", "Braces to structure printed A1.1 note 1 — qty 0", "A1.1", "")]},
                {"review": [("1/7", "Detail", "B", "Braces to structure printed A1.1 note 1 — 240 LF loaded", "A1.1", "")]}),
    "be_hf03": ({"ms": [M("Head track 3-5/8\"", 40, fuente="3/A5.3 bulkhead top track")]}, {"ms": [M("Top slip track 3-5/8\"", 40, fuente="3/A5.3 bulkhead")]}),
    "be_hf04": ({"canon": C([W("W1", H=8.5, bracing_rows=1, bracing_rows_source="A4.1 note 7: partitions higher than 12'-0\"")])},
                {"canon": C([W("W1", H=8.5, bracing_rows=0, bracing_rows_source="A4.1 note 7: partitions higher than 12'-0\"")])}),
    "be_hf05": ({"pt": [{"fila": 5, "wall": "Q-14+Q-12+Q-13", "lf": 30.0}]}, {"pt": [{"fila": 5, "wall": "Q-14", "lf": 10.0}]}),
    "be_vs_01": ({"hojas": {"A01.01": "LOWEST POINT OF DECK 17'-0\"", "A02.01": "PLAN"},
                  "pend": [("RFI-02", "Height of structure not printed", RFI_OK)], "canon": C(rfis=[{"id": "RFI-02", "barrido": {"hojas": ["A02.01"]}}])},
                 {"hojas": {"A01.01": "LOWEST POINT OF DECK 17'-0\"", "A02.01": "PLAN"},
                  "pend": [("RFI-02", "Height of structure per bay", RFI_OK)], "canon": C(rfis=[{"id": "RFI-02", "barrido": {"hojas": ["A02.01", "A01.01"]}}])}),
    "be_vs_02": ({"hojas": {"A15.04": "UL LISTED FIRE RESISTANT GYPSUM BOARD THROUGHOUT"}, "canon": C(ceilings=[{"room": "MGR", "board": "5/8 regular"}])},
                 {"hojas": {"A15.04": "UL LISTED FIRE RESISTANT GYPSUM BOARD THROUGHOUT"}, "canon": C(ceilings=[{"room": "MGR", "board": "5/8 type X"}])}),
    "be_vs_04": ({"ms": [M("Blocking 6\" backing track", 50, fila=4), M("Blocking 6\" backing track", 50, fila=9)]},
                 {"ms": [M("Blocking 6\" backing track", 100, fila=4)]}),
    "be_vs_06": ({"canon": C(blocking_items=[{"ref": "B1", "label": "6\" X 18 GA BACKING TRACK", "familia": "3-5/8\" stud"}])},
                 {"canon": C(blocking_items=[{"ref": "B1", "label": "6\" X 18 GA BACKING TRACK", "familia": "6\" 18 GA backing track"}])}),
    "be_vs_07": ({"hojas": {"S03.01": "BRIDGING NOT REQUIRED WHERE BOARD BOTH SIDES"}, "canon": C([W("W1", bridging_rows=2)])},
                 {"hojas": {"S03.01": "BRIDGING NOT REQUIRED WHERE BOARD BOTH SIDES"}, "canon": C([W("W1", bridging_rows=0)])}),
    "be_vs_08": ({"demo": {"items": [{"id": "D1", "height_source": "assumed 12'"}]}, "annots": []},
                 {"demo": {"items": [{"id": "D1", "height_source": "A01.01 LOWEST POINT 17'-0\""}]}, "textos": {"demo_cruce.md": "x"},
                  "annots": [{"label": "A01.01", "subject": "DEMO", "contents": "DEMO D1", "measure": True}]}),
    "be_vs_10": ({"scope": [("ALC-9", "Ceiling bracing", "NOT APPLICABLE", "not carried: RCP shows no bracing, not drawn")]},
                 {"scope": [("ALC-9", "Ceiling bracing", "QUANTIFIED", "S-001 note 12 + ASTM C754")]}),
    "be_vs_13": ({"pt": [{"fila": 5, "wall": "W026", "lf": 10.0, "h": 10.0, "board": 300.0}],
                  "annots": [{"label": "A02.01", "subject": "2", "contents": "W026 TYPE 2 LF 10 SF 250", "measure": True}]},
                 {"pt": [{"fila": 5, "wall": "W026", "lf": 10.0, "h": 10.0, "board": 300.0}],
                  "annots": [{"label": "A02.01", "subject": "2", "contents": "W026 TYPE 2 LF 10 SF 300", "measure": True}]}),
    "be_vs_14": ({"hojas": {"A12.01": "ADDITIONAL STUD REQ'D AT EQ. STUDS"}, "pend": [("RFI-12", "Is 'ADDITIONAL STUD REQ D AT EQ STUDS' required?", "(A) delta")]},
                 {"hojas": {"A12.01": "ADDITIONAL STUD REQ'D AT EQ. STUDS"}, "pend": [("RFI-12", "Opening width not dimensioned", "(A) delta")]}),
    "be_vs_15": ({"canon": C([W("W1")], ceilings=[{"room": "1", "rcp_sheet": "A03.01"}]), "annots": [{"label": "A-101", "subject": "2", "contents": "", "measure": True}]},
                 {"canon": C([W("W1")], ceilings=[{"room": "1", "rcp_sheet": "A03.01"}]),
                  "annots": [{"label": "A-101", "subject": "2", "contents": "", "measure": True}, {"label": "A03.01", "subject": "CLG", "contents": "", "measure": True}]}),
    # R80f.43 / BE-141 (Chuze FINAL7 audit U-138): cifra tecleada vieja en el Scope Checklist
    "cifras_texto": ({"ms": [M('5/8" gypsum board, Type X', net=57241.6)], "celdas": [("Scope Checklist", "D8", '5/8" Type X 58,393.09 SF')]},
                     {"ms": [M('5/8" gypsum board, Type X', net=57241.6)], "celdas": [("Scope Checklist", "D8", '5/8" Type X 57,241.60 SF')]}),
    # U-143 (usuario 5-nov, HFT RFI-02 '1 vs 2 layers' del wall a demoler): demo solo en SF, sin capas ni RFI de composición
    # (unida con el caso de CFA: canon con LF x H x 2 layers y RFI de capas de la demo)
    "u_143": ({"ms": [M("Demolition - existing gypsum board 2 layers per face", 120.0, unit="SF", fuente="D1.1")],
               "pend": [("RFI-02", "Existing wall to be demolished: 1 or 2 layers of board?", "(A) delta 0 (B) delta +SF")],
               "canon": {"misc_items": [{"ref": "DEMO-X1", "familia": "demolition - gypsum board and metal framing", "unit": "SF", "qty": 200.0,
                                         "op": "10.0 LF x 10.0 ft x 2 layer(s) = 200.0 SF"}],
                         "rfis": [{"id": "RFI-X", "question": "Walls to demolish: how many layers of gypsum board?"}]}},
              {"ms": [M("Demolition of existing partitions (SF of wall)", 120.0, unit="SF", fuente="D1.1")], "pend": [],
               "canon": {"misc_items": [{"ref": "DEMO-X1", "familia": "demolition - gypsum board and metal framing", "unit": "SF", "qty": 100.0,
                                         "op": "10.0 LF x 10.0 ft = 100.0 SF (wall area)"}],
                         "rfis": [{"id": "RFI-X", "question": "Walls to demolish: height not printed."}]}}),
    # U-139 (usuario 5-nov): una decisión vieja cargaba FRT 2X blocking y FRT plywood: wood > 0 = FAIL
    "u_139": ({"ms": [M("Blocking FRT / 2X FRT wood", 100.0, fuente="N/SHEET: 6/A4.2"),
                      M("FRT plywood (5/8 in.)", 50.0, unit="SF", fuente="N/SHEET: 2/A3.1")]},
              {"ms": [M("Blocking FRT / 2X FRT wood", 0.0, fuente="EXCLUDED - wood blocking by others (Div. 06), user decision 2026-11-05, R-ALC-01"),
                      M("Metal stud blocking", 120.0, fuente="N/SHEET: 6/A4.2")]}),
    # U-127 / BE-138 CB_BOTH_SIDES: el type imprime board en las dos caras y el wall trae una sola (error de Chuze FINAL5)
    "both_sides": ({"canon": C([{"id": "W1", "tag": "A3C", "element": "wall", "faces": [{"side": "A", "board": "5/8 type X", "layers": 1, "height_ft": 10}]}]),
                    "fichas": {"types": {"A3C": {"faces": [{"side": "each side", "board": '5/8" GYP BD - BOTH SIDES'}]}}}},
                   {"canon": C([{"id": "W1", "tag": "A3C", "element": "wall", "faces": [{"side": "A", "board": "5/8 type X", "layers": 1, "height_ft": 10},
                                                                                         {"side": "B", "board": "5/8 type X", "layers": 1, "height_ft": 10}]}]),
                    "fichas": {"types": {"A3C": {"faces": [{"side": "each side", "board": '5/8" GYP BD - BOTH SIDES'}]}}}}),
    # U-113 / BE-124 CE_CALLOUTS: la planta señala D/A9.22, que llama 7/A9.26 (marquesina): la cadena se cortó en D/A9.22
    "ce_callouts": ({"hojas": {"A2.01": "FLOOR PLAN D/A9.22 1/A12.01", "A9.22": "D SECTION SEE 7/A9.26", "A9.26": "7 SIDE CANOPY", "A12.01": "1 PARTITION TYPES"},
                     "canon": C([W("W1", sheet="A2.01")]), "ms": [M("Stud 6\"", fuente="1/A12.01 + D/A9.22")], "set_meta": {"burbujas": {}}},
                    {"hojas": {"A2.01": "FLOOR PLAN D/A9.22 1/A12.01", "A9.22": "D SECTION SEE 7/A9.26", "A9.26": "7 SIDE CANOPY", "A12.01": "1 PARTITION TYPES"},
                     "canon": C([W("W1", sheet="A2.01")]), "ms": [M("Stud 6\"", fuente="1/A12.01 + D/A9.22 -> 7/A9.26")], "set_meta": {"burbujas": {}}}),
    # BE-CF24 (CFA rev9): la Source de un board-only con la altura VIEJA (1'-0" G.3) en un renglón cargado a 1.25 (C3/A-604)
    "be_cf24": ({"canon": {"existing_walls": [{"id": "X-1", "height_ft": 1.25, "source": "W6/A-202 | height: G.3/A-202 to 1'-0\" = 1.0 ft [CONFIRMED]"}]}},
                {"canon": {"existing_walls": [{"id": "X-1", "height_ft": 1.25, "source": "W6/A-202 | height: [CONFIRMED] C3/A-604 1' - 3\" = 1.25 ft"}]}}),
    # R-ALC-06 (CFA rev9): DEMO-14 marcado en la planta nueva A-202 en vez del demolition plan A-050
    # BE-CF25 (CFA rev9): RFI-11 / 12 / 20 'printed nowhere' con un barrido de 8 términos, un solo GC, sin medida vectorial
    "be_cf25": ({"canon": {"rfis": [{"id": "RFI-11", "status": "open - conservative value loaded", "question": "Dining half walls: height printed nowhere.",
                                     "barrido": {"hojas": "ALL", "terminos": ["HALF WALL", "HALF WALLS", "PONY", "KNEE", "LOW WALL", "42\"", "3'-6\"", "PARTIAL HEIGHT"]}}]}},
                {"canon": {"rfis": [{"id": "RFI-11", "status": "open - conservative value loaded", "question": "Dining half walls: height printed nowhere.",
                                     "barrido": {"hojas": "ALL", "terminos": ["HALF WALL", "HALF WALLS", "PONY", "KNEE", "LOW WALL", "42\"", "3'-6\"", "PARTIAL HEIGHT",
                                                                               "BOOTH", "BANQUETTE", "KN8", "CAP", "OUTLET", "J-BOX"],
                                                 "sets": ["CDM Bid Set.pdf", "Empower Riverpoint Updated 10.29.26.pdf"],
                                                 "medida_vectorial": "no elevation / section draws the wall: nothing to measure at a printed scale",
                                                 "lugares": [{"sheet": "X-100", "what": "KN8", "img": "a.png"}, {"sheet": "X-200", "what": "booths", "img": "b.png"},
                                                             {"sheet": "X-300", "what": "outlets", "img": "c.png"}]}}]}}),
    # BE-CF26 (CFA rev10): RFI resuelto con la opción A todavía en el valor viejo y el valor resuelto como alternativa
    "be_cf26": ({"canon": {"rfis": [{"id": "RFI-28", "status": "resolved - from drawings", "resolved": {"answer": "4.244 x 8.144 ft = 34.57 SF [DERIVED]"},
                                     "opciones": {"A": {"texto": "Plans: 38.35 SF loaded", "delta": "0 (loaded); 34.57 SF hatch outline: -3.78 SF demolition"}}}]}},
                {"canon": {"rfis": [{"id": "RFI-28", "status": "resolved - from drawings", "resolved": {"answer": "4.244 x 8.144 ft = 34.57 SF [DERIVED]"},
                                     "opciones": {"A": {"texto": "Plans: 34.57 SF loaded", "delta": "0 (loaded); outer outline 38.35 SF +3.78 SF demolition"}}}]}}),
    # CC-R1 / CC-R5 / CC-R7 / CC-R12 (Consumer Cellular rev3, auditoría U-138): renglón duplicado sin IDs, residuo de redondeo que
    # compra piezas, Scope EXCLUDED sobre el FRP cargado, wall con cota impresa en [DERIVED]
    "cc_r1": ({"ms": [M("Stud blocking at edge of gypboard", 176.4, fuente="N/SHEET: 2/A104 | 77.0 LF; 37.5 LF; 19.5 LF", fila=5),
                      M("Metal stud blocking - strapping", 134.0, fuente="Breakdown: BLK-SLAT-N 77 LF + BLK-LOGO-S 37.5 LF + BLK-LOGO-W 19.5 LF", fila=6)]},
              {"ms": [M("Metal stud blocking - strapping", 134.0, fuente="Breakdown: BLK-SLAT-N 77 LF + BLK-LOGO-S 37.5 LF + BLK-LOGO-W 19.5 LF", fila=6)]}),
    "cc_r5": ({"ms": [M("Top / deflection track - other", 0.01, fuente="N/SHEET: A100 | = 0 LF (rounding)")]},
              {"ms": [M("Top track 3-5/8\"", 57.44, fuente="N/SHEET: 1/A500 | E3-01 7.25 LF")]}),
    "cc_r7": ({"ms": [M("FRP panels", 148.33, unit="SF")], "scope": [("ALC-20", "NO APLICA", "EXCLUDED - FRP B-3 is a finish product")]},
              {"ms": [M("FRP panels", 148.33, unit="SF")], "scope": [("ALC-20", "CUANTIFICADO", "FRP B-3 carried with its PVC trim")]}),
    "cc_r12": ({"canon": C([dict(W("<w1>"), length_status="CONFIRMADO")]), "pt": [{"fila": 6, "wall": "<w1>", "status": "[DERIVED]"}]},
               {"canon": C([dict(W("<w1>"), length_status="CONFIRMADO")]), "pt": [{"fila": 6, "wall": "<w1>", "status": "[CONFIRMED]"}]}),
    # U-146 / U-147 (usuario 5-nov, Consumer Cellular RFI-01 / RFI-04 -> A): corte de deck no dibujado / level of finish sin especificar
    "u_146": ({"pend": [("RFI-01", "The deck break between PLY DECK @ 16'-4\" and @ 17'-1 9/16\" is not drawn", RFI_OK)]},
              {"pend": [("RFI-05", "Control joints per R80e.34 #8 precedent", RFI_OK)]}),
    "u_147": ({"pend": [("RFI-04", "Gypsum board finish level and trims are not specified", RFI_OK)]},
              {"pend": []}),
    "r_alc_06": ({"annots": [{"label": "A-202", "subject": "DEMO", "contents": "DEMO"}], "hojas": {"A-202": "DIMENSIONAL FLOOR PLAN", "A-050": "DEMOLITION PLAN"}},
                 {"annots": [{"label": "A-050", "subject": "DEMO", "contents": "DEMO"}], "hojas": {"A-202": "DIMENSIONAL FLOOR PLAN", "A-050": "DEMOLITION PLAN"}}),
    # BE-CR25 (CR City Hotel rev1): canon con walls = 0 y Partition Takeoff con filas = la compuerta en vacío
    "canon_no_vacio": ({"canon": {"walls": [], "existing_walls": []}, "pt": [{"fila": 6, "wall": "W.4-L2-01 A", "partition": "W.4-0"}]},
                       {"canon": C([W("<w1>")]), "pt": [{"fila": 6, "wall": "<w1>", "partition": "W.4-0"}]}),    # BE-CR30 (CR City Hotel rev3): tags GYP-n del RCP sin renglón (BAR 107 / franja del lobby / Cleaning 215)
    "rcp_tags": ({"canon": C([W("<w1>")], misc_items=[{"ref": "CLG-L1-01 board", "qty": 10}]),
                  "hojas": {"A3.01": "REFLECTED CEILING PLAN GYP-1 9' - 0\" GYP-1 11' - 0\" GYP-1: GYPSUM BOARD ON METAL SUSPENSION"}},
                 {"canon": C([W("<w1>")], misc_items=[{"ref": "CLG-L1-01 board", "qty": 10}],
                             rcp_tags=[{"sheet": "A3.01", "tag": "GYP-1", "rows": ["CLG-L1-01 board"]},
                                       {"sheet": "A3.01", "tag": "GYP-1", "none_reason": "inside the tenant space: note on 1/A2.01"}]),
                  "hojas": {"A3.01": "REFLECTED CEILING PLAN GYP-1 9' - 0\" GYP-1 11' - 0\" GYP-1: GYPSUM BOARD ON METAL SUSPENSION"}}),
    # U-155 (usuario 8-nov): opción B 'per code' sin sección / tabla
    "u_155": ({"ms": [M("Type X 5/8\"", 10, fuente="N/SHEET: A2.01 | head to deck per code"),
                      M("Type X 5/8\" ceiling", 10, fuente="N/SHEET: A3.04 | CODE: GA-216 / ASTM C1396 allow 5/8\" Type X"),
                      M("Ceiling grid", 10, fuente="N/SHEET: A3.01 | CODE: none applies - scope question")]},
              {"ms": [M("Type X 5/8\"", 10, fuente="N/SHEET: A2.01 | head to deck per code: IBC 2018 Section 707.5")]}),
    # U-161 / U-163 (usuario 11-nov)
    "u_161": ({"pend": [("RFI-04", "ELEC 221: A0.00 'ELECTRICAL AND IT ROOMS' 2 HR vs code plan 1HR FP: which one?")]},
              {"pend": [("RFI-17", "WATER ENTRY 128 ceiling not labeled")]}),
    # U-174 (usuario 11-nov, Xfinity RFI-01): altura de estructura no impresa = altura del edificio del code analysis, sin RFI
    # U-178 (usuario 11-nov): wall más alto que la tabla de limiting heights sin miembro = gauge SFIA conservador, sin RFI
    "u_178": ({"pend": [("RFI-01", "Wall X1-01 is 18 ft: the limiting height table has no member for that height (exceeds the table)")]},
              {"pend": [("RFI-02", "[PENDING - user manual verification] extent of the patch and repair not printed")]}),
    # U-184 (4): altura de elevación sin comprobación en planta (CR rev19 east eave) / exclusión F&B sin revisar el rating (U-159)
    "u_184_elev": ({"canon": {"walls": [{"id": "X1-01", "height_ft": 21.0, "height_source": "8/X9.9 EAST ELEVATION eave line"}]}},
                   {"canon": {"walls": [{"id": "X1-01", "height_ft": 21.0, "height_source": "8/X9.9 EAST ELEVATION eave line",
                                         "height_plan_check": "X9.1 plan: X1-01 lies on the east frontal plane of 8/X9.9"}]}}),
    "u_184_excl": ({"canon": {"excluded_items": [{"refs": ["CLG-X9-01"], "reason": "room 901 F&B by tenant (3/X9.9)"}]}},
                   {"canon": {"excluded_items": [{"refs": ["CLG-X9-01"], "reason": "room 901 F&B by tenant (3/X9.9), non-rated; the rated RS-1 membrane above is carried"}]}}),
    "u_174": ({"pend": [("RFI-01", "Height of the existing structure (underside of roof structure) is not printed on any sheet", "(A) A0.1 'HEIGHT IN STORIES: 1 STORY - 26 FT'")],
               "hojas": {"A0.1": "BUILDING DATA HEIGHT IN STORIES: 1 STORY - 26 FT"}},
              {"pend": [("RFI-01", "Height of the existing structure - CLOSED: user decision 11-nov (U-174)", "26'-0\" loaded")],
               "hojas": {"A0.1": "BUILDING DATA HEIGHT IN STORIES: 1 STORY - 26 FT"}}),
    "u_163": ({"canon": {"misc_items": [{"ref": "CLG-L1-SHN fireproofing", "familia": "spray fireproofing", "qty": 9.68}]}},
              {"canon": {"misc_items": [{"ref": "CLG-L1-SHN board", "familia": '5/8" gyp board Type X', "qty": 29.04}]}}),
    # post-mortem 11-nov (fondo): BE-CR20 membrana del piso N en el cielo de N-1 (LEVEL 8 sin membrana en L7)
    "be_cr20_membrana": ({"canon": {"rated_floor_assemblies": [{"id": "FS-9", "levels": ["LEVEL 8", "LEVEL 9"], "source": "X0.9 FS-9 'LEVEL 8, 9 THROUGHOUT'"}],
                                    "ceilings": [{"room": "L8 FS-9 membrane under the LEVEL 9 floor", "floor": "L8", "area_sf": 50, "assembly": {"id": "FS-9"}}]}},
                         {"canon": {"rated_floor_assemblies": [{"id": "FS-9", "levels": ["LEVEL 8", "LEVEL 9"], "source": "X0.9 FS-9 'LEVEL 8, 9 THROUGHOUT'"}],
                                    "ceilings": [{"room": "L8 FS-9 membrane under the LEVEL 9 floor", "floor": "L8", "area_sf": 50, "assembly": {"id": "FS-9"}},
                                                 {"room": "L7 FS-9 membrane under the LEVEL 8 floor", "floor": "L7", "area_sf": 50}]}}),
    # BE-CR22: wall que es solo el vano de una puerta (fantasma) / puerta dentro del LF sin citarla
    "be_cr22_vanos": ({"canon": C([W("X9-L9-01", sheet="X9.1", band={"ori": "H", "c0": 100, "c1": 104, "lo": 290, "hi": 312, "sheet": "X9.1"})],
                                  opening_schedule={"items": [{"ref": "901.1", "kind": "door", "sheet": "X9.1", "center_pt": [300, 102], "ro_w_ft": 3.0}]})},
                      {"canon": C([W("X9-L9-01", sheet="X9.1", band={"ori": "H", "c0": 100, "c1": 104, "lo": 100, "hi": 400, "sheet": "X9.1"},
                                     openings=[{"ref": "901.1", "kind": "door", "ro_w_ft": 3.0}])],
                                  opening_schedule={"items": [{"ref": "901.1", "kind": "door", "sheet": "X9.1", "center_pt": [300, 102], "ro_w_ft": 3.0}]})}),
    # BE-CR27: pisos típicos (8xx / 9xx) con el cement board del shower distinto (> 10 %) sin stack_reasons
    "be_cr27_stack": ({"canon": C([W(f"X9-L8-0{i}", L=10.0, faces=[F("A", f"SHOWER 80{i}", board="1/2 cement board", h=8.0), F("B", f"ROOM 80{i}")]) for i in (1, 2, 3)]
                                  + [W(f"X9-L9-0{i}", L=10.0 if i > 1 else 4.0, faces=[F("A", f"SHOWER 90{i}", board="1/2 cement board", h=8.0 if i > 1 else 2.0), F("B", f"ROOM 90{i}")]) for i in (1, 2, 3)], typical_floors=["L8", "L9"])},
                      {"canon": C([W(f"X9-L8-0{i}", L=10.0, faces=[F("A", f"SHOWER 80{i}", board="1/2 cement board", h=8.0), F("B", f"ROOM 80{i}")]) for i in (1, 2, 3)]
                                  + [W(f"X9-L9-0{i}", L=10.0, faces=[F("A", f"SHOWER 90{i}", board="1/2 cement board", h=8.0), F("B", f"ROOM 90{i}")]) for i in (1, 2, 3)])}),
    # U-189 (1) / BE-CR39: corredor 216 de CR — FS-1 rated cargado y el GYP-1 8'-11" colgado debajo cubierto por el MISMO renglón
    "faltantes_auditoria": ({"canon": {"walls": [], "ceilings": [{"room": "Z9 901", "area_sf": 50.0}],
                                       "rcp_tags": [{"sheet": "X9.01", "tag": "GYP-9", "height": "8'-11\"", "rows": ["ceilings[0]"]}]},
                             "textos": {"Auditoria/AUDITORIA_U181_rev9.md": "| 1 | X9.01 GYP-9 8'-11\" missing in corridor 901 | add |"}},
                            {"canon": {"walls": [], "ceilings": [{"room": "Z9 901", "area_sf": 50.0}],
                                       "rcp_tags": [{"sheet": "X9.01", "tag": "GYP-9", "height": "8'-11\"", "rows": []}]},
                             "textos": {"Auditoria/AUDITORIA_U181_rev9.md": "| 1 | X9.01 GYP-9 8'-11\" missing in corridor 901 | add |"}}),
    "rcp_apilados": ({"canon": {"walls": [], "ceilings": [{"room": "L9 Corridor 916", "assembly": {"id": "FS-1"}, "area_sf": 450.0}],
                                "rcp_tags": [{"sheet": "X9.2", "tag": "FS-1", "height": "", "rows": ["ceilings[0]"]},
                                             {"sheet": "X9.2", "tag": "GYP-1", "height": "8' - 11\"", "rows": ["ceilings[0]"]}]}},
                     {"canon": {"walls": [], "ceilings": [{"room": "L9 Corridor 916", "assembly": {"id": "FS-1"}, "area_sf": 450.0},
                                                          {"room": "L9 Corridor 916", "board": "5/8 type X", "area_sf": 450.0}],
                                "rcp_tags": [{"sheet": "X9.2", "tag": "FS-1", "height": "", "rows": ["ceilings[0]"]},
                                             {"sheet": "X9.2", "tag": "GYP-1", "height": "8' - 11\"", "rows": ["ceilings[1]"]}]}}),
    # U-189 (2) / BE-CR39: banda 7/X9.23 con la caja de la derecha en plenum sin cargar; 12/X9.03 sin revisión cara por cara
    "detalle_caras": ({"canon": {"walls": [], "misc_items": [{"ref": "SOF-L9-01 board", "qty": 100, "source": "7/X9.23 band"},
                                                             {"ref": "BW-L9-02 board", "qty": 40, "source": "12/X9.03 smoke curtain"}],
                                 "detail_faces": [{"detail": "7/X9.23", "faces": [
                                     {"face": "bottom", "dim": "4 1/2\"", "loaded": "SOF-L9-01 board"},
                                     {"face": "right box (plenum)", "dim": "2'-0\""}]}]}},
                      {"canon": {"walls": [], "misc_items": [{"ref": "SOF-L9-01 board", "qty": 100, "source": "7/X9.23 band"},
                                                             {"ref": "SOF-L9-01b board", "qty": 50, "source": "7/X9.23 right box"},
                                                             {"ref": "BW-L9-02 board", "qty": 40, "source": "12/X9.03 smoke curtain"}],
                                 "detail_faces": [{"detail": "7/X9.23", "faces": [
                                     {"face": "bottom", "dim": "4 1/2\"", "loaded": "SOF-L9-01 board"},
                                     {"face": "right box (plenum)", "dim": "2'-0\"", "loaded": "SOF-L9-01b board"}]},
                                     {"detail": "12/X9.03", "faces": [{"face": "shaft side", "dim": "2'-0\"", "loaded": "BW-L9-02 board"},
                                                                     {"face": "wall side", "dim": "", "none_reason": "12/X9.03: no board on the wall side"}]}]}}),
    # U-191 / BE-CR41: RFI de RC '16 in. o.c. per assembly (UL X546)' sin el ítem del listing = FAIL; con 'X546 Item 6' = PASS
    "u_191_ref": ({"canon": {"walls": [], "ceilings": [{"room": "L9 Corridor 916", "rc_oc_in": {"value": 16, "source": "RS-9 'SPACING PER ASSEMBLY' (UL L946): 16 in. loaded"}}],
                             "rfis": [{"id": "RFI-91", "question": "RC spacing per assembly not printed (UL L946)"}]}},
                  {"canon": {"walls": [], "ceilings": [{"room": "L9 Corridor 916", "rc_oc_in": {"value": 12, "source": "RS-9 'SPACING PER ASSEMBLY': UL L946 Item 6 = 12 in. o.c."}}],
                             "rfis": []}}),
    # BE-GK32: cara exterior bajo EIFS cargada como Dens Shield tile backer
    "be_gk32_sheathing_exterior": ({"canon": C([W("Z9-L9-01", sheet="X9.3", faces=[F("A", "EXTERIOR (EIFS)", board="5/8 Dens Shield tile backer"), F("B", "OFFICE 901")])])},
                                   {"canon": C([W("Z9-L9-01", sheet="X9.3", faces=[F("A", "EXTERIOR (EIFS)", board="1/2 exterior glass mat sheathing"), F("B", "OFFICE 901")])])}),
    # BE-GK33 / 33b: '(open)' de un RFI cerrado en un wall hermano, '[scale check]', RFI cerrado con '+x %'
    "be_gk33_textos_viejos": ({"canon": C([W("Z9-L9-02", height_source="X9.5 B.O. 12'-0\" RFI-07 (open)"),
                                           W("Z9-L9-03", length_source="X9.2 vector [scale check]")],
                                          rfis=[{"id": "RFI-07", "status": "closed - user decision"},
                                                {"id": "RFI-09", "status": "closed", "loaded": "+10 % allowance", "opciones": {"A": {"texto": "≈ 40 SF"}}}])},
                              {"canon": C([W("Z9-L9-02", height_source="X9.5 B.O. 12'-0\" (RFI-07 closed: user decision)"),
                                           W("Z9-L9-03", length_source="X9.2 vector 90.0 pt / 9.0 = 10.0 ft [DERIVED]")],
                                          rfis=[{"id": "RFI-07", "status": "closed - user decision"},
                                                {"id": "RFI-09", "status": "closed", "loaded": "measured delta -5.50 SF", "opciones": {"A": {"texto": "delta -5.50 SF"}}},
                                                {"id": "RFI-11", "status": "open", "loaded": "X9.6 note RFI-11 (open)"}])}),
    # BE-GK37: bottom track en una fila que el detalle no dibuja + clip citado como motivo sin renglón
    "be_gk37_fila_detalle": ({"canon": {"misc_items": [{"ref": "X9-EXT-01 bottom track", "familia": "6\" track", "qty": 20, "source": "9/X9.4 exterior stud row"},
                                                       {"ref": "X9-EXT-02 bottom track", "familia": "6\" track", "qty": 0, "reason": "9/X9.4 row bears on the joists with a clip at each stud"}]},
                              "hojas": {"X9.4": "EXTERIOR STUD ROW BEARS ON JOISTS. CLIP L2X2X18 GA AT EACH STUD"}},
                             {"canon": {"misc_items": [{"ref": "X9-EXT-01 clip", "familia": "clip L2x2x18 GA", "qty": 20, "source": "9/X9.4 kn 18"},
                                                       {"ref": "X9-EXT-02 bottom track", "familia": "6\" track", "qty": 0, "reason": "9/X9.4 row bears on the joists with a clip at each stud"},
                                                       {"ref": "X9-INT-01 bottom track", "familia": "6\" track", "qty": 20, "source": "3/X9.7 interior row"}]},
                              "hojas": {"X9.4": "EXTERIOR STUD ROW BEARS ON JOISTS. CLIP L2X2X18 GA AT EACH STUD", "X9.7": "BOTTOM TRACK 600T125-43 AT SLAB"}}),
    # post-mortem #8: U-161 / U-174 / U-178 revisan el VALOR cargado, no solo el RFI abierto
    "u_161_valor": ({"canon": C([W("Z9-L9-04", faces=[F("A", "ELEC 921"), F("B", "CORRIDOR 922")], rating_hr=1)]),
                     "hojas": {"X0.0": "ELECTRICAL AND IT ROOMS 2 HR", "X0.1": "CODE PLAN ELEC 921 1HR FIRE PARTITION"}},
                    {"canon": C([W("Z9-L9-04", faces=[F("A", "ELEC 921"), F("B", "CORRIDOR 922")], rating_hr=2)]),
                     "hojas": {"X0.0": "ELECTRICAL AND IT ROOMS 2 HR", "X0.1": "CODE PLAN ELEC 921 1HR FIRE PARTITION"}}),
    "u_174_valor": ({"canon": {"walls": [{"id": "Z9-L9-05", "height_ft": 28.0, "height_source": "structure height not printed (sweep X9.1-X9.6)"}]},
                     "hojas": {"X0.1": "BUILDING DATA HEIGHT IN STORIES: 1 STORY - 31 FT"}},
                    {"canon": {"walls": [{"id": "Z9-L9-05", "height_ft": 31.0, "height_source": "structure height not printed (sweep X9.1-X9.6): X0.1 building height (U-174)"}]},
                     "hojas": {"X0.1": "BUILDING DATA HEIGHT IN STORIES: 1 STORY - 31 FT"}}),
    "u_178_largo": ({"canon": {"walls": [{"id": "Z9-L9-06", "length_ft": 12.5, "length_source": "X9.2 sloped wall at the ramp, length VARIES"}]}},
                    {"canon": {"walls": [{"id": "Z9-L9-06", "length_ft": 12.5, "length_source": "X9.2 sloped wall at the ramp, length VARIES",
                                          "length_op": "sqrt(12.0^2 + 3.5^2) = 12.5 ft (inclined length)"}]}}),
    # CR-R17-SILENCIO (revisión dirigida de rev16 F5): CLG-L4-412WS conservador sin RFI / Review / Scope
    "cr_r17_silencio": ({"canon": {"misc_items": [{"ref": "CLG-L4-412WS board", "qty": 34.52, "source": "WS-1 area: conservative (U-048): RS-1 continuous"}]},
                         "celdas": [("Pending Items", "B2", "RFI-04 untagged walls")]},
                        {"canon": {"misc_items": [{"ref": "CLG-L1-SHN board", "qty": 29.04, "source": "assembly NOT printed -> conservative assumption LOADED (U-048, RFI-29)"}]},
                         "celdas": [("Pending Items", "B9", "RFI-29 2HR SHAFT CEILING ... CLG-L1-SHN")]}),
    # CR-R16 (revisión dirigida de rev15)
    "cr_r16_ri": ({"celdas": [("Pending Items", "B10", "RFI-22 BAR ... -125.98 SF board"), ("Review Items", "F9", "BAR 107 121.6 SF; RFI-22 asks to confirm (delta -121.6 SF).")]},
                  {"celdas": [("Pending Items", "B10", "RFI-22 BAR ... -125.98 SF board"), ("Review Items", "F9", "BAR 107 125.98 SF; RFI-22 option B delta -125.98 SF board.")]}),
    "cr_r16_t509": ({"celdas": [("Pending Items", "B5", "CODE: IBC 2018 Table 509 does not list electrical / IT rooms and ...")]},
                    {"celdas": [("Pending Items", "B5", "CODE: IBC 2018 Table 509 row 'Electrical installations and transformers' gives no hourly rating")]}),
    "cr_r16_madera": ({"canon": {"misc_items": [{"ref": "SOF-L2-01 cripples", "familia": '2-1/2" stud', "qty": 62.87, "source": "7/A7.23 draws the cove pieces with the wood 'X' symbol"}]}},
                      {"canon": {"misc_items": [{"ref": "SOF-L1-01 cripples", "familia": '2-1/2" stud', "qty": 237.05, "source": "5/A7.31 no wood drawn"}]}}),
    # CR-R15-BARRIDO (CR City Hotel rev14 F02): A5.08 '2HR SHAFT CEILING' cortado del barrido de RFI-13
    "cr_r15_barrido": ({"canon": {"rfis": [{"id": "RFI-13", "barrido": {"terminos": ["SHAFT CEILING"], "encontrado_en": []}}]},
                        "hojas": {"A5.08": "2HR SHAFT CEILING", "A0.06": "NOTES"}},
                       {"canon": {"rfis": [{"id": "RFI-13", "barrido": {"terminos": ["SHAFT CEILING"], "encontrado_en": ["A5.08:SHAFT CEILING"]}}]},
                        "hojas": {"A5.08": "2HR SHAFT CEILING", "A0.06": "NOTES"}}),
    # CR-R13-E1 (CR City Hotel rev13): XW.6.4-L2-01 A sheathing con la H 5.915 de la línea interior de 2/A5.04
    "cr_r13_e1": ({"canon": {"walls": [], "existing_walls": [
                      {"id": "XW-01 A", "height_ft": 5.915, "board": "5/8 exterior gyp sheathing", "height_source": "2/A5.04 interior board line x=627.4"},
                      {"id": "XW-01 B", "height_ft": 5.915, "board": "5/8 type X", "height_source": "2/A5.04 interior board line x=627.4"}]}},
                  {"canon": {"walls": [], "existing_walls": [
                      {"id": "XW-01 A", "height_ft": 6.64, "board": "5/8 exterior gyp sheathing", "height_source": "2/A5.04 sheathing line x=610.68"},
                      {"id": "XW-01 B", "height_ft": 5.915, "board": "5/8 type X", "height_source": "2/A5.04 interior board line x=627.4"}]}}),
    # CR-R12-E1 (CR City Hotel rev12): delta del Review Item con la altura vieja 12.0 (la fila ya está a 13.7917)
    "cr_r12_e1": ({"canon": {"walls": [], "existing_walls": [{"id": "W.6-L1-17 A", "length_ft": 7.45, "height_ft": 13.7917}]},
                   "review": [("1/7", "Floor plan", "W.6.1", "W.6-L1-17", "1/A7.50", "delta -178.80 SF [DERIVED 7.45 x 12.0 x 2 faces x 1 layer] W.6-L1-17 A")]},
                  {"canon": {"walls": [], "existing_walls": [{"id": "W.6-L1-17 A", "length_ft": 7.45, "height_ft": 13.7917}]},
                   "review": [("1/7", "Floor plan", "W.6.1", "W.6-L1-17", "1/A7.50", "delta -205.50 SF [DERIVED 7.45 x 13.7917 x 2 faces x 1 layer] W.6-L1-17 A")]}),
    # CR-R11-F12 (CR City Hotel rev11): cara interior de F&B 410 a 11'-4 3/4" (corte del deck bar) con el sheathing a 10.24
    "cr_r11_f12": ({"canon": {"walls": [], "existing_walls": [{"id": "XW-17 A", "height_ft": 10.24, "board": "5/8 exterior gyp sheathing"},
                                                              {"id": "XW-17 B", "height_ft": 11.3958, "board": "5/8 type X"}]}},
                   {"canon": {"walls": [], "existing_walls": [{"id": "XW-17 A", "height_ft": 10.24, "board": "5/8 exterior gyp sheathing"},
                                                              {"id": "XW-17 B", "height_ft": 8.9375, "board": "5/8 type X"}]}}),
    # BE-CR45 (CR rev20d): board NON-rated sobre el tramo del shower + cement board = doble conteo; rated (-1) = capas quedan
    "ducha_cbu": ({"canon": {"showers": [{"floor": "L2", "room": "214", "box": [100, 130, 50, 80], "cbu": [{"side": "W", "id": "CBU-1"}]}],
                             "existing_walls": [{"id": "CBU-1", "floor": "L2", "board": "1/2 cement board", "height_ft": 9.0, "type_id": "W.4-0", "path": [[100, 50], [100, 80]]},
                                                {"id": "W-1", "floor": "L2", "board": "5/8 type X", "height_ft": 9.24, "type_id": "W.4-0", "location": "| faces: shower 214", "path": [[100, 40], [100, 90]]}]}},
                  {"canon": {"showers": [{"floor": "L2", "room": "214", "box": [100, 130, 50, 80], "cbu": [{"side": "W", "id": "CBU-1"}]}],
                             "existing_walls": [{"id": "CBU-1", "floor": "L2", "board": "1/2 cement board", "height_ft": 9.0, "type_id": "W.4-0", "path": [[100, 50], [100, 80]]},
                                                {"id": "W-1", "floor": "L2", "board": "5/8 type X", "height_ft": 9.24, "type_id": "W.4-1", "location": "| faces: shower 214", "path": [[100, 40], [100, 90]]}]}}),
    # BE-XF20 (Xfinity rev1c E-1): 16 ga backing studs (8/A2.0) en los bays de W2 sumados a los 20 ga del wall sin deducción
    "stud_zona_reemplaza": ({"canon": {"walls": [{"id": "W2-01", "type_id": "W2", "stud_size": "3-5/8\" 20 ga (362S125-33)"}],
                                       "misc_items": [{"ref": "STUD16", "qty": 125.0, "unit": "LF", "source": "8/A2.0 backing studs on W2 | 362S162-54: 8/A2.0", "op": "W2-01 10 studs"}]}},
                            {"canon": {"walls": [{"id": "W2-01", "type_id": "W2", "stud_size": "3-5/8\" 20 ga (362S125-33)"}],
                                       "misc_items": [{"ref": "STUD16", "qty": 125.0, "unit": "LF", "source": "8/A2.0 backing studs on W2 | 362S162-54: 8/A2.0", "op": "W2-01 10 studs"},
                                                      {"ref": "STUD20-OUT", "qty": -125.0, "unit": "LF", "source": "2/A2.0 W2 stud 362S125-33; 8/A2.0", "op": "deduction"}]}}),
    # BE-XF21 (Xfinity rev1c E-2): 7/A2.0 'METAL TRACK' + 'METAL STUD NESTED IN METAL TRACK' cargado como 2 piezas de track
    "head_piezas": ({"canon": {"walls": [{"id": "W2-01", "openings": [{"ref": "Door 101", "pieces": 2, "piece": "track",
                                          "header_type_source": "7/A2.0: '3-5/8\" METAL TRACK' + '3-5/8\" METAL STUD NESTED IN METAL TRACK'"}]}], "misc_items": []}},
                    {"canon": {"walls": [{"id": "W2-01", "openings": [{"ref": "Door 101", "pieces": 1, "piece": "track",
                                          "header_type_source": "7/A2.0: '3-5/8\" METAL TRACK' + '3-5/8\" METAL STUD NESTED IN METAL TRACK'"}]}],
                               "misc_items": [{"ref": "HDR-101-NESTED", "qty": 4.333, "designation": "362S125-33", "source": "7/A2.0 nested stud; door 101"}]}}),
    # U-201 (usuario 13-nov): RFI abierto sobre un tema ya decidido (rating code plan vs tag) = FAIL; cerrado con su DEDUCT = PASS
    "u201_decisiones": ({"canon": {"walls": [], "rfis": [{"id": "RFI-9", "status": "open", "question": "Rating conflict: the code plan draws 2 HR while the tag reads 1"}]}},
                        {"canon": {"walls": [], "rfis": [{"id": "RFI-9", "status": "closed", "question": "Rating conflict: the code plan draws 2 HR while the tag reads 1"}],
                                   "deduct_alternates": [{"id": "DA-9", "rfi": "RFI-9", "delta_sf": -100.0}]}}),
}


def test_casos():
    nombres = {fn.__name__: fn for _, fn, _ in CB.CHEQUEOS}
    sin = sorted(set(nombres) - set(CASOS))
    assert not sin, f"chequeos sin caso que reproduzca el error: {sin}"
    for nm, (malo, bueno) in CASOS.items():
        fn = nombres[nm]
        e1, ev1 = fn(B(**malo))
        assert e1 == "FAIL", (nm, "MALO", e1, ev1)
        e2, ev2 = fn(B(**bueno))
        assert e2 == "PASS", (nm, "BUENO", e2, ev2)


def test_v119_be_cr40_verificacion():
    """verificación independiente 12b (BE-CR40 STILL-WEAK): (1) 'faltante_por_tag: CARGADO' escrito en el renglón no es prueba — se llama
    la función y lo cargado = FAIL; (2) hallazgo sin tag ('corridor 901 ceiling missing') se resuelve por cuarto: cargado = FAIL, sin
    cielo = PASS; sin tag ni cuarto = FAIL (no N/A); (3) se lee cualquier .md de Auditoria/, no solo AUDITORIA / INFORME. Sintético."""
    fn = CB.faltantes_auditoria
    can = {"walls": [], "ceilings": [{"room": "Z9 Corridor 901", "area_sf": 50.0}],
           "rcp_tags": [{"sheet": "X9.01", "tag": "GYP-9", "height": "8'-11\"", "rows": ["ceilings[0]"]}]}
    t = lambda ln, nom="Auditoria/notas_rev9.md": {nom: "| 1 | " + ln + " | add |"}     # noqa: E731
    e, ev = fn(B(canon=can, textos=t("X9.01 GYP-9 8'-11\" missing in corridor 901 — faltante_por_tag: FALTA")))
    assert e == "FAIL" and "CARGADO" in ev[0], (e, ev)                    # (1) auto-declaración ignorada; (3) notas_rev9.md se lee
    e, ev = fn(B(canon=can, textos=t("corridor 901 ceiling missing")))
    assert e == "FAIL" and "901" in ev[0], (e, ev)                        # (2) por cuarto: cargado
    e, ev = fn(B(canon=can, textos=t("corridor 902 ceiling missing")))
    assert e == "PASS", (e, ev)                                           # cuarto sin cielo en el canon: falta de verdad
    e, ev = fn(B(canon=can, textos=t("corridor ceiling missing")))
    assert "sin hallazgos" in str(ev), (e, ev)                           # v121 (CR): sin cuarto / tag / ref no es hallazgo (definición)
    can2 = dict(can, rcp_tags=can["rcp_tags"] + [{"sheet": "X9.02", "tag": "GYP-9", "height": "9'-0\"", "rows": []}])
    e, ev = fn(B(canon=can2, textos=t("GYP-9 missing")))
    assert e == "FAIL" and "no se puede resolver" in ev[0], (e, ev)       # tag ambiguo (una cargada, otra no) = FAIL
    can3 = dict(can, misc_items=[{"ref": "CLG-Z9-901 board", "qty": 50.0}])                      # cierre con la ref que lo cargó
    e, ev = fn(B(canon=can3, textos=t("corridor 901 ceiling missing", nom="Auditoria/AUDITORIA_U181_rev9.md") | {"x": ""}))
    assert e == "FAIL", (e, ev)                                           # sin cierre en el renglón: cargado = FAIL
    e, ev = fn(B(canon=can3, textos={"Auditoria/AUDITORIA_U181_rev9.md": "| 1 | corridor 901 ceiling missing | CERRADO: CLG-Z9-901 (1/X9.31) |"}))
    assert e == "PASS", (e, ev)
    e, ev = fn(B(canon=can3, textos={"Auditoria/AUDITORIA_U181_rev9.md": "| 1 | corridor 901 ceiling missing | CERRADO: CLG-Z9-999 (1/X9.31) |"}))
    assert e == "FAIL" and "CLG-Z9-999" in ev[0], (e, ev)                 # cierre con una ref que no existe
    # v120 (GK #8 / H-04, ids sintéticos): cierre con CUALQUIER ref cargada del canon; 'hoja faltante' no es cielo; DOBLE_CIELO.csv resuelve
    can4 = dict(can, misc_items=[{"ref": "EXT-Z9-901 board", "qty": 30.0}])
    e, ev = fn(B(canon=can4, textos={"Auditoria/AUDITORIA_U181_rev9.md": "| 3 | corridor 901 ceiling missing | CLOSED: EXT-Z9-901 (1/X9.31) |"}))
    assert e == "PASS", (e, ev)                                          # EXT- (no solo CLG / SOF / BW / CW)
    e, ev = fn(B(canon=can, textos={"Auditoria/AUDITORIA_U181_rev9.md": "| 8 | FS-9 band 30/X9.20 (missing) | n/a |"}))
    assert "sin hallazgos" in str(ev), (e, ev)                           # GK #8: falta una HOJA, no un cielo (sin palabra de cielo)
    e, ev = fn(B(canon=can, textos={"Auditoria/AUDITORIA_U181_rev9.md": "| 8 | soffit 30/X9.20 (missing) for the ceiling band | n/a |"}))
    assert e == "FAIL", (e, ev)                                          # v121: con palabra de cielo ya no se salta
    dcsv = ("Room,Level,Type,Upper ceiling,Lower ceiling,Heights,N/SHEET,Framing,Row / reason\n"
            "Z9 911 Lobby,Z9,double,FS-9,GYP,9',1/X9.31,x,upper: FS-9 [0]; lower: CLG-Z9-911\n"
            "Z9 912 Bar,Z9,double,FS-9,GYP,9',1/X9.31,x,upper: FS-9 [1]; lower: CLG-Z9-912\n")
    tx = {"Auditoria/AUDITORIA_U181_rev9.md": "| H-04 | upper ceiling missing in rooms 911 and 912 | see DOBLE_CIELO |", "Auditoria/DOBLE_CIELO.csv": dcsv}
    canl = dict(can, ceilings=can["ceilings"] + [{"room": "Z9 Bar 912", "area_sf": 30.0}],
                misc_items=[{"ref": "CLG-Z9-911 board", "qty": 20.0}, {"ref": "CLG-Z9-912 board", "qty": 20.0}])
    e, ev = fn(B(canon=canl, textos=tx))
    assert e == "PASS", (e, ev)                                          # H-04: resuelto por DOBLE_CIELO.csv (refs cargadas)
    tx["Auditoria/AUDITORIA_U181_rev9.md"] = "| H-04 | upper ceiling missing in rooms 911 and 913 | see DOBLE_CIELO |"
    e, ev = fn(B(canon=canl, textos=tx))
    assert e == "PASS" or "913" in str(ev), (e, ev)                      # 913 no está en la tabla: se resuelve contra el canon
    print("test_v119_be_cr40_verificacion OK")


def test_v121_be_cr40_cierre_explicito():
    """v121 (verificación 5, adv5_faltantes): (1) una ref cargada suelta en el texto NO cierra; solo 'CERRADO: <ref> (<N/HOJA>)' con la ref
    en el canon con cantidad > 0; (2) 'N/HOJA (missing)' se salta solo sin palabra de cielo; (3) DOBLE_CIELO.csv resuelve solo con refs
    upper / lower cargadas; (4) un soffit cargado no es el cielo del cuarto; (5) 'not included' es hallazgo. Sintético."""
    fn = CB.faltantes_auditoria
    can = {"walls": [{"id": "X9-216-01"}], "ceilings": [{"room": "Z9 Lobby 801", "area_sf": 80.0}],
           "misc_items": [{"ref": "SOF-Z9-216 board", "qty": 40.0}, {"ref": "EXT-Z9-2 board", "qty": 30.0}],
           "rcp_tags": [{"sheet": "X9.01", "tag": "GYP-9", "height": "8'-11\"", "rows": []}]}
    A = "Auditoria/AUDITORIA_U181_rev9.md"
    run = lambda ln, c=can, x=None: fn(B(canon=c, textos=dict({A: "| 1 | " + ln + " |"}, **(x or {}))))      # noqa: E731
    for ln in ("corridor 216 ceiling missing", "Corridor 216: soffit SOF-Z9-216 loaded but X9.01 GYP-9 8'-11\" ceiling missing | OPEN",
               "corridor 216 ceiling missing along wall X9-216-01 | OPEN", "Corridor 216 GYP-9 8'-11\" missing per 7/X9.23 (not in canon) | OPEN",
               "Room 216 ceiling band 7/X9.23 not included in take-off | OPEN"):
        e, ev = run(ln)
        assert e == "PASS" and "1 hallazgo" in ev[0], (ln, e, ev)        # falta de verdad: contado, la ref de contexto no lo cierra
    e, ev = run("corridor 216 ceiling missing | CERRADO: EXT-Z9-2 (1/X9.31)")
    assert e == "PASS", (e, ev)                                          # cierre explícito con ref cargada
    e, ev = run("corridor 216 ceiling missing | CERRADO: EXT-Z9-2")
    assert e == "FAIL" and "N/HOJA" in ev[0], (e, ev)
    e, ev = run("corridor 216 ceiling missing | CERRADO: X9-216-01 (1/X9.31)")
    assert e == "FAIL" and "cantidad > 0" in ev[0], (e, ev)              # muro sin cantidad
    dc = ("Room,Level,Type,Upper ceiling,Lower ceiling,Heights,N/SHEET,Framing,Row / reason\n"
          "Z9 216 Corridor,Z9,double,RS-9,GYP-9,8'-11\",7/X9.23,x,upper: RS-9 [0]; lower: GYP-9 MISSING (H-04)\n")
    assert CB.cuartos_doble_cielo(B(canon=can, textos={"Auditoria/DOBLE_CIELO.csv": dc})) == set()
    dc2 = dc.replace("lower: GYP-9 MISSING (H-04)", "lower: CLG-Z9-216")
    assert CB.cuartos_doble_cielo(B(canon=can, textos={"Auditoria/DOBLE_CIELO.csv": dc2})) == set()
    canl = dict(can, misc_items=can["misc_items"] + [{"ref": "CLG-Z9-216 board", "qty": 12.0}])
    assert CB.cuartos_doble_cielo(B(canon=canl, textos={"Auditoria/DOBLE_CIELO.csv": dc2})) == {"216"}
    can2 = {"walls": [{"id": "X9-901-01"}], "ceilings": [{"room": "Z9 Corridor 901", "area_sf": 50.0}],
            "rcp_tags": [{"sheet": "X9.01", "tag": "GYP-9", "height": "8'-11\"", "rows": ["ceilings[0]"]}]}
    for ln in ("X9.01 GYP-9 8'-11\" missing in corridor 901 along wall X9-901-01 | OPEN",
               "X9.01 GYP-9 8'-11\" missing in corridor 901 per 7/X9.23 (not in canon) | OPEN",
               "corridor 901 ceiling per 7/X9.23 not included in take-off | OPEN"):
        e, ev = run(ln, can2)
        assert e == "FAIL" and "CARGADO" in ev[0], (ln, e, ev)           # cargado declarado faltante
    dc3 = ("Room,Level,Type,Upper ceiling,Lower ceiling,Heights,N/SHEET,Framing,Row / reason\n"
           "Z9 901 Corridor,Z9,double,RS-9,GYP-9,8'-11\",7/X9.23,x,upper: RS-9 (none); lower: GYP-9 ceilings[0]\n")
    e, ev = run("corridor 901 lower ceiling missing | OPEN", can2, {"Auditoria/DOBLE_CIELO.csv": dc3})
    assert e == "FAIL" and "CARGADO" in ev[0], (e, ev)                   # upper '(none)': la tabla no resuelve
    print("test_v121_be_cr40_cierre_explicito OK")


def test_v121_excluded_y_brief():
    """v121 (COORDINACIÓN 12-nov 22:15 / 22:30, casos GK H-04 y CR, sintético): (a) 'CERRADO: EXCLUDED - <motivo impreso> (<N/HOJA>)'
    cierra; una fila EXCLUDED + N/HOJA de DOBLE_CIELO.csv resuelve el cuarto (cualquier fila); cuarto por cuarto, el SOF de otro elemento
    con el mismo número no vuelve 'cargado' un cuarto EXCLUDED; (b) BRIEF*.md / LEEME* y los renglones de definición no son hallazgos."""
    fn = CB.faltantes_auditoria
    can = {"walls": [], "ceilings": [{"room": "Z9 Bar 912", "area_sf": 30.0}],
           "misc_items": [{"ref": "SOF-Z9-911 board", "qty": 25.0}], "rcp_tags": []}
    A = "Auditoria/AUDITORIA_U181_rev9.md"
    run = lambda ln, x=None: fn(B(canon=can, textos=dict({A: "| H-04 | " + ln + " |"}, **(x or {}))))      # noqa: E731
    assert run("room 913 ceiling missing | CERRADO: EXCLUDED - OPEN TO STRUCTURE PER RCP (1/X9.31)")[0] == "PASS"
    e, ev = run("room 913 ceiling missing | CERRADO: EXCLUDED - OPEN TO STRUCTURE")
    assert e == "FAIL" and "EXCLUDED" in ev[0], (e, ev)                  # sin N/HOJA
    dc = ("Room,Level,Type,Upper ceiling,Lower ceiling,Heights,N/SHEET,Framing,Row / reason\n"
          "Z9 911 Lobby,Z9,single,,,,1/X9.31,,EXCLUDED - OPEN TO STRUCTURE (no ceiling of ours)\n")
    x = {"Auditoria/DOBLE_CIELO.csv": dc}
    assert CB.cuartos_doble_cielo(B(canon=can, textos=x)) == {"911"}
    e, ev = run("ceiling missing in rooms 911 and 913", x)
    assert e == "PASS", (e, ev)                                          # 911 EXCLUDED (su SOF no lo vuelve cargado); 913 falta de verdad
    e, ev = run("ceiling missing in rooms 911 and 912", x)
    assert e == "FAIL" and "912" in ev[0], (e, ev)                       # 912 sí está cargado: cuarto por cuarto
    assert CB.cuartos_doble_cielo(B(canon=can, textos={"Auditoria/DOBLE_CIELO.csv": dc.replace("1/X9.31", "")})) == set()   # sin N/HOJA
    defin = "- FALTA — a wall / ceiling in OUR scope that is not loaded\n- NO ES NUESTRO — existing, by others\n"
    e, ev = fn(B(canon=can, textos={"Auditoria/auditoria_cobertura_rev9/BRIEF.md": defin + "room 912 ceiling missing\n"}))
    assert "sin hallazgos" in str(ev), (e, ev)                           # BRIEF*.md no se lee
    e, ev = fn(B(canon=can, textos={A: defin}))
    assert "sin hallazgos" in str(ev), (e, ev)                           # renglón de definición no es hallazgo
    e, ev = fn(B(canon=can, textos={A: defin + "| 1 | room 912 ceiling missing | OPEN |\n"}))
    assert e == "FAIL" and "912" in ev[0], (e, ev)                       # el hallazgo concreto sí se revisa
    print("test_v121_excluded_y_brief OK")


def test_v126_entregas_previas():
    """v126 (COORDINACIÓN 12-nov 23:13, CR / GK, sintético): CB_FALTANTES no audita carpetas entrega_rev* de otra rev ni symlinks a
    entregas previas."""
    w = tempfile.mkdtemp(prefix="v126cb_")
    for d in ("entrega_rev3a/Auditoria", "entrega_rev3b/Auditoria", "FINAL_FOR_REVIEW_rev2/Auditoria"):
        os.makedirs(os.path.join(w, d))
    os.symlink(os.path.join(w, "entrega_rev3a"), os.path.join(w, "anterior"))
    act = os.path.join(w, "entrega_rev3b")
    assert not CB.texto_de_otra_rev(w, os.path.join(act, "Auditoria", "x.md"), act)
    assert CB.texto_de_otra_rev(w, os.path.join(w, "entrega_rev3a", "Auditoria", "x.md"), act)
    assert CB.texto_de_otra_rev(w, os.path.join(w, "FINAL_FOR_REVIEW_rev2", "Auditoria", "x.md"), act)
    assert CB.texto_de_otra_rev(w, os.path.join(w, "anterior", "Auditoria", "x.md"), act)          # symlink a una entrega previa
    assert not CB.texto_de_otra_rev(w, os.path.join(w, "Auditoria", "x.md"), act)
    print("test_v126_entregas_previas OK")


def test_v129_be_vs_13_id_largo():
    """v129 (COORDINACIÓN 13-nov 00:10, caso CR): be_vs_13 toma el id MÁS LARGO: un id y el mismo id con ' S' (sufijo de cara) dan PASS;
    antes el id corto se quedaba con los markups de los dos."""
    fn = CB.be_vs_13
    pt = [{"wall": "XW.6.3-L1-01", "board": 24.37}, {"wall": "XW.6.3-L1-01 S", "board": 35.53}]
    an = [{"contents": "XW.6.3-L1-01 · 24.37 SF board", "label": "p1", "subject": "X9"},
          {"contents": "XW.6.3-L1-01 S · 35.53 SF board", "label": "p1", "subject": "X9"}]
    e, ev = fn(B(pt=pt, annots=an))
    assert e == "PASS", (e, ev)
    an2 = an + [{"contents": "XW.6.3-L1-01 · 10.00 SF board", "label": "p2", "subject": "X9"}]
    e, ev = fn(B(pt=pt, annots=an2))
    assert e == "FAIL" and "XW.6.3-L1-01 " in ev[0] and "34.37" in ev[0], (e, ev)   # el corto sí suma sus propios tramos
    print("test_v129_be_vs_13_id_largo OK")


def test_v130_rcp_apilados_total():
    """v130 (CR): el PASS de CB_RCP_APILADOS escribe primero el TOTAL de cielos evaluados y no escribe '(0 … vía ceilings_misc)'."""
    can = {"ceilings": [{"room": "Z9 Bar 912", "area_sf": 30.0}, {"room": "Z9 Lobby 913", "area_sf": 40.0}],
           "rcp_tags": [{"sheet": "X9.31", "tag": "GYP-9", "height": "9'-0\"", "rows": ["ceilings[0]"]},
                        {"sheet": "X9.31", "tag": "GYP-8", "height": "9'-0\"", "rows": ["ceilings[1]"]}]}
    e, ev = CB.rcp_apilados(B(canon=can))
    assert e == "PASS" and ev[0].startswith("2 cielos evaluados;") and "vía" not in ev[0], (e, ev)
    can["ceilings_misc"] = [{"ref": "CLG-Z9-914", "room": "Z9 914"}]
    can["misc_items"] = [{"ref": "CLG-Z9-914", "qty": 10.0}]
    e, ev = CB.rcp_apilados(B(canon=can))
    assert e == "PASS" and ev[0].startswith("3 cielos evaluados (1 vía ceilings_misc);"), (e, ev)
    print("test_v130_rcp_apilados_total OK")


def test_v96_sin_falsos_positivos_cr():
    """v81cf96 (canon cerrado de CR City Hotel corrido con los chequeos nuevos): (1) BE-GK37 no aplica a track de soffit (SOF-) ni a un
    track cuya fuente cita el texto impreso ('"J" RUNNER CHANNEL') o una hoja que lo dice; (2) U-178 (5): 'sloped ceiling' en la
    fuente de la altura no es un largo inclinado; (3) BE-CR27 con pisos típicos INFERIDOS = AMBER (declarados = FAIL, en CASOS)."""
    hojas = {"X9.4": "SECTION AT MEZZANINE", "X9.5": "PARTITION TYPES CH \"J\" RUNNER CHANNEL"}
    mis = [{"ref": "SOF-L9-01 track", "familia": "track de ceilings / soffits", "qty": 30, "source": "2/X9.4 dropped soffit"},
           {"ref": "J-RUNNER Z9-01", "familia": "J-runner 2-1/2\"", "qty": 8, "source": "3/X9.4; X9.5 CH '\"J\" RUNNER CHANNEL'"},
           {"ref": "J-RUNNER Z9-02", "familia": "J-runner 2-1/2\"", "qty": 8, "source": "3/X9.4 + X9.5"}]
    assert CB.be_gk37_fila_detalle(B(canon={"misc_items": mis}, hojas=hojas))[0] == "PASS"
    w = {"id": "Z9-L9-01 B", "length_ft": 25.5, "source": "X9.2 length 229.4/9 = 25.49 | height: underside of sloped ceiling (1185.8-1026.1)/27"}
    assert CB.u_178_largo(B(canon={"walls": [w]}))[0] == "PASS"
    assert CB.u_178_largo(B(canon={"walls": [dict(w, source="X9.2 sloped wall at the ramp")]}))[0] == "FAIL"
    for txt in ("to deck (X9.3 B.O.D. EL. 15'-4 1/2\" NO SLOPE)", "X9.3 B.O. DECK VARIES - 16'-0\" @ LP; roof SLOPE 1/4\" PER FT down toward this wall",
                "column wrap X9.1 'VARIES - SEE PLAN 14\" MAX' per face"):
        assert CB.u_178_largo(B(canon={"walls": [{"id": "Z9-L9-02", "height_source": txt, "length_source": txt}]}))[0] == "PASS", txt
    malo = CASOS["be_cr27_stack"][0]["canon"]
    inferido = {k: v for k, v in malo.items() if k != "typical_floors"}
    assert CB.be_cr27_stack(B(canon=inferido))[0] == "AMBER"
    print("test_v96_sin_falsos_positivos_cr OK")


def test_be_06_soffit_sides():
    """BE-06: soffit_side = un lado por elemento; un solo lado del soffit = FAIL, varios lados = PASS."""
    uno = C([W("SS-X-N", tag="", element="soffit_side", faces=[F("N", "X")])])
    tres = C([W(f"SS-X-{k}", tag="", element="soffit_side", faces=[F(k, "X")]) for k in ("N", "W", "IV")])
    assert CB.be_06(B(canon=uno))[0] == "FAIL" and CB.be_06(B(canon=tres))[0] == "PASS"


def test_callouts_extra():
    """CE_CALLOUTS: hoja / detalle referido que no existe se reporta; fuera de alcance con motivo = disposición."""
    SM = {"burbujas": {}}
    h = {"A2.01": "FLOOR PLAN 4/A9.30 5/A12.01", "A12.01": "1 PARTITION TYPES"}
    e, ev = CB.ce_callouts(B(hojas=h, canon=C([W("W1", sheet="A2.01")]), set_meta=SM))
    t = " ".join(ev)
    assert e == "FAIL" and "A9.30 no existe" in t and "no tiene el detalle 5" in t, t
    h = {"A2.01": "FLOOR PLAN 3/E1.01", "E1.01": "3 PANEL SCHEDULE"}
    assert CB.ce_callouts(B(hojas=h, canon=C([W("W1", sheet="A2.01")]), set_meta=SM))[0] == "FAIL"
    na = {"E1.01": {"3": "panel schedule: electrical, not our trade"}}
    assert CB.ce_callouts(B(hojas=h, canon=C([W("W1", sheet="A2.01")]), set_meta=SM, no_aplican=na))[0] == "PASS"
    assert CB.ce_callouts(B(hojas=h, canon=C([W("W1", sheet="A2.01")]), set_meta=SM, no_aplican={"3/E1.01": "x"}))[0] == "FAIL"   # sin motivo
    assert CB.ce_callouts(B(hojas=None, canon=C()))[0] == "FAIL"
    assert CB.callouts_de("A2.0/A3.1 01/A09.02 D/A09.22") == [("D", "A9.22")]           # cola de hoja y cero = no es burbuja
    # U-137 / BE-139 (4-nov, "¿y qué pasó con los detail call outs?"): burbujas de DOS líneas (1 arriba / A3.2 abajo)
    h = {"A1.1": "FLOOR PLAN", "A3.2": "WALL SECTIONS 1 2", "A4.2": "INTERIOR SECTIONS & DETAILS 5"}
    cn = C([W("W1", sheet="A1.1")])
    e, ev = CB.ce_callouts(B(hojas=h, canon=cn, set_meta={}))                      # set_texto viejo sin barrido de burbujas
    assert e == "FAIL" and "sin barrido de burbujas" in ev[0], ev
    e, ev = CB.ce_callouts(B(hojas=h, canon=cn, set_meta=SM))                      # 0 burbujas y el set tiene DETAILS: vacío
    assert e == "FAIL" and "PASS en vacío prohibido" in ev[0], ev
    bub = {"A1.1": {"burbujas": [{"x": 933.5, "y": 1124.3, "r": 17, "n": "1", "hoja": "A3.2"}],
                    "sin_leer": [{"x": 450.0, "y": 527.0, "r": 17}], "circulos": 2}}
    e, ev = CB.ce_callouts(B(hojas=h, canon=cn, set_meta={"burbujas": bub}))
    t = " ".join(ev)
    assert e == "FAIL" and "1/A3.2 (burbuja en A1.1" in t and "(450, 527)" in t, t
    ms = [M("Stud 6\"", fuente="1/A3.2 head at PEMB purlin")]
    ver = {"A1.1": [{"x": 450.0, "y": 527.0, "n": "5", "hoja": "A4.2"}]}
    e, ev = CB.ce_callouts(B(hojas=h, canon=cn, ms=ms, set_meta={"burbujas": bub}, verificadas=ver))
    assert e == "FAIL" and "5/A4.2" in " ".join(ev) and "1/A3.2" not in " ".join(ev), ev   # la verificada entra a la cadena
    ms = [M("Stud 6\"", fuente="1/A3.2 head at PEMB purlin; 5/A4.2 soffit")]
    assert CB.ce_callouts(B(hojas=h, canon=cn, ms=ms, set_meta={"burbujas": bub}, verificadas=ver))[0] == "PASS"
    ver = {"A1.1": [{"x": 451.0, "y": 526.0, "no_es_burbuja": "north arrow"}]}
    ms = [M("Stud 6\"", fuente="1/A3.2 head at PEMB purlin")]
    assert CB.ce_callouts(B(hojas=h, canon=cn, ms=ms, set_meta={"burbujas": bub}, verificadas=ver))[0] == "PASS"
    ver = {"A1.1": [{"x": 451.0, "y": 526.0, "no_es_burbuja": "x"}]}                # sin motivo
    assert CB.ce_callouts(B(hojas=h, canon=cn, ms=ms, set_meta={"burbujas": bub}, verificadas=ver))[0] == "FAIL"
    # O'Reilly rev7: 10/A5.2 citado; el OCR de la hoja raster A5.2 no lee el '10' del título (rectángulo, no círculo) -> AMBER;
    # verificado a ojo con imagen en burbujas_verificadas.json -> PASS; sin imagen sigue AMBER
    h2 = {"A1.1": "FLOOR PLAN", "A5.2": "WINDOW SCHEDULE VESTIBULE ENLARGE PLAN", "A3.2": "WALL SECTIONS 1 2"}
    bub2 = {"A1.1": {"burbujas": [{"x": 596.0, "y": 1130.0, "r": 13, "n": "10", "hoja": "A5.2"}], "sin_leer": [], "circulos": 1}}
    ms2 = [M("Stud 6\"", fuente="10/A5.2 vestibule")]
    sm2 = {"burbujas": bub2, "ocr": ["A5.2"]}
    assert CB.ce_callouts(B(hojas=h2, canon=cn, ms=ms2, set_meta=sm2))[0] == "AMBER"
    v2 = {"A5.2": [{"detalle_existe": "10", "img": "burbujas_img/A5.2_detalle_10_existe.png"}]}
    assert CB.ce_callouts(B(hojas=h2, canon=cn, ms=ms2, set_meta=sm2, verificadas=v2))[0] == "PASS"
    assert CB.ce_callouts(B(hojas=h2, canon=cn, ms=ms2, set_meta=sm2, verificadas={"A5.2": [{"detalle_existe": "10"}]}))[0] == "AMBER"


def test_auditoria_u138():
    """U-138 auditoría adversarial 4-nov: PASS que no se sostenían. Cada caso: el error original -> FAIL, corregido -> PASS."""
    import revision_markups as RM
    occ = [{"id": "PT001", "kind": "partition_tag", "type": "S43", "sheet": "A1.1", "png": "PT001.png", "png_verificado": True}]
    inv = {"pages": 68, "ocurrencias": {"partition_tag": occ}}
    cn = C([W("W1", tag="S43", sheet="A1.1")])
    # (a) U-037 sin inventario_tags pero con inventario.json: cuenta contra él (antes AMBER mientras U-117 PASS); sin ninguno = FAIL
    assert CB.u_037(B(canon=cn, inv_full=inv))[0] == "PASS"
    assert CB.u_037(B(canon=C([W("W1", tag="S24", sheet="A1.1")]), inv_full=inv))[0] == "FAIL"
    assert CB.u_037(B(canon=cn))[0] == "FAIL"
    # (a) U-117: inventario de otro set (páginas distintas) = FAIL
    sm = {"fuentes": [{"pdf": "bidset.pdf", "paginas": 172}]}
    r = CB.u_117(B(canon=cn, inv_full=inv, set_meta=sm, hojas={"A1.1": "x"}))
    assert r[0] == "FAIL" and any("otro set" in e for e in r[1]), r
    # (b) altura sin hoja: el regex de hojas de revision_markups veía 'none' en A421 / A435.A (Chuze); cara sin hoja = FAIL
    assert RM.HOJA_RX.findall("head D/A301; B.O. DECK on A422.B / A435.A") and RM.HOJA_RX.search("A421 elev 5")
    w_ok = {"id": "W1", "height_ft": 10, "height_source": "A421 elev 5", "faces": [{"side": "A", "height_ft": 10, "height_source": "A421"}]}
    w_mal = {"id": "W1", "height_ft": 10, "height_source": "A421 elev 5", "faces": [{"side": "A", "height_ft": 10, "height_source": "to deck"}]}
    assert CB.be_78(B(canon={"walls": [w_ok]}))[0] == "PASS" and CB.be_78(B(canon={"walls": [w_mal]}))[0] == "FAIL"
    fs = lambda s: {"walls": [{"id": "W1", "height_ft": 10, "height_source": s, "height_status": "[DERIVED] 10 - 0 = 10"}]}  # noqa: E731
    assert any("sin hoja" in e for e in CB.u_114(B(canon=fs("to the deck (B.O. DECK VARIOUS)"), pt=[]))[1])
    assert not any("sin hoja" in e for e in CB.u_114(B(canon=fs("A422.B B.O. DECK 22'-1\""), pt=[]))[1])
    # (c) BE-25: cielos de gypsum cargados como misc_items (GWB-CLG-*) también se revisan; 'N/A' con el set imprimiéndolos = FAIL
    mi = lambda src: {"walls": [], "misc_items": [{"ref": "GWB-CLG-ROOM-1", "familia": "5/8 type X", "source": src}]}  # noqa: E731
    assert CB.be_25(B(canon=mi("A1.2")))[0] == "FAIL" and CB.be_25(B(canon=mi("7/A4.2")))[0] == "PASS"
    assert CB.be_25(B(canon={"walls": []}, hojas={"A1.2": "5/8\" GYP. BD. CEILING"}))[0] == "FAIL"
    # (e) BE-VS-15: markups DEMO contra elementos de demo (no hojas)
    an = [{"label": "D1.1", "subject": "DEMO", "contents": "DEMO · 10.00 LF · H 9'-0\" · 1 layer(s) · 3 · P01-N · 3/D1.1", "measure": True}]
    dm = [{"id": "P01-N", "sheet": "D1.1"}, {"id": "P02-S", "sheet": "D1.1"}]
    assert CB.be_vs_15(B(canon={"walls": []}, annots=an, demo=dm))[0] == "FAIL"
    assert CB.be_vs_15(B(canon={"walls": []}, annots=an, demo=dm[:1]))[0] == "PASS"
    # (f) BE-15: S43/A1.1 (tag verificado en el inventario) y 13/A5.2 (detalle verificado a ojo) en hoja OCR -> PASS; sin -> AMBER
    ms = [M("Stud", fuente="N/SHEET: S43/A1.1; 13/A5.2 sill")]
    hj = {"A1.1": "FLOOR PLAN", "A5.2": "WINDOW SCHEDULE"}
    sm2 = {"ocr": ["A1.1", "A5.2"]}
    assert CB.be_15(B(canon={"walls": []}, ms=ms, hojas=hj, set_meta=sm2))[0] == "AMBER"
    ver = {"A5.2": [{"detalle_existe": "13", "img": "burbujas_img/A5.2_detalle_13_existe.png"}]}
    assert CB.be_15(B(canon={"walls": []}, ms=ms, hojas=hj, set_meta=sm2, inv_full=inv, verificadas=ver))[0] == "PASS"
    # v81cf38: U-116 / BE-CF23 leía solo 'status'; un RFI con estado 'CLOSED' (O'Reilly RFI-07 "(A) not carried") no es abierto
    rf = lambda **k: {"walls": [{"id": "W1", "height_source": "A1.1 printed 10 ft [CONFIRMED]"}], "rfis": [dict({"id": "RFI-07", "opciones": {"A": {"texto": "Not carried"}}}, **k)]}  # noqa: E731
    assert not any("RFI-07" in e for e in CB.u_116(B(canon=rf(estado="CLOSED")))[1])
    assert any("RFI-07" in e for e in CB.u_116(B(canon=rf(status="open")))[1])


def test_be_cf08_catalogo():
    """BE-CF08: un archivo nuevo en referencias/ sin clasificar en reglas_clasificacion.py -> A_CATALOGO falla."""
    sk = os.path.join(AQUI, "..")
    if not os.path.isfile(os.path.join(sk, "SKILL.md")):
        sk = os.path.join(AQUI, "..", "take-off-metal-frame-drywall")
    d = tempfile.mkdtemp(prefix="cf08_")
    for x in ("SKILL.md", "referencias", "tools"):
        src = os.path.join(sk, x) if x != "tools" else AQUI
        (shutil.copytree if os.path.isdir(src) else shutil.copy)(src, os.path.join(d, x))
    open(os.path.join(d, "referencias", "adenda_v99.md"), "w").write("# Adenda v99\n\n## REGLA 99.1 — regla nueva de prueba\nToda X lleva Y.\n")
    env = dict(os.environ, TAKEOFF_SKILL=d)
    p = subprocess.run([sys.executable, "-c", "import reglas, json; print(json.dumps(reglas.a_catalogo(None)))"],
                       cwd=os.path.join(d, "tools"), capture_output=True, text=True, env=env, timeout=600)
    out = json.loads(p.stdout.strip().splitlines()[-1])
    assert any("99" in str(x[0]) and "sin clasificar" in str(x[1]) for x in out), (out[:5], p.stderr[-300:])


def test_u118_evidencia_circula():
    """U-118: evidencia.py circula lo citado en la hoja; si lo citado no está impreso, la página va sin marca y u_118 falla."""
    import pymupdf
    sys.path.insert(0, os.path.join(AQUI, "..", "runner"))
    sys.path.insert(0, os.path.join(AQUI, "..", "take-off-metal-frame-drywall", "runner"))
    import evidencia
    d = tempfile.mkdtemp(prefix="u118_")
    pdf = os.path.join(d, "set.pdf")
    doc = pymupdf.open()
    pg = doc.new_page(width=600, height=400)
    pg.insert_text((100, 200), "ZONE 2 B.O. DECK +-17'-5 1/2\"", fontsize=14)
    doc.save(pdf)
    ev = evidencia.Evidencia(pdf, {"A1.2": 0}, os.path.join(d, "img"))
    con = ev.hoja("A1.2 'B.O. DECK' zone 2 [CONFIRMED]")
    sin = ev.hoja("A1.2 'T.O. PARAPET' [CONFIRMED]")
    b = B(raiz=d)
    assert CB._img_ok(b, con)[0] is True, CB._img_ok(b, con)
    assert CB._img_ok(b, sin) == (False, "sin marca circulada (0 px rojos)"), CB._img_ok(b, sin)
    assert CB._img_ok(b, "vacia.png") == (False, "no existe") and CB._img_ok(B(raiz=IMGD), "vacia.png")[1].startswith("vacía")
    c = {"walls": [{"id": "W1", "tag": "D", "element": "wall", "tag_ids": ["PT0001"],
                    "band": {"ori": "H", "c0": 100, "c1": 104, "lo": 100, "hi": 300, "sheet": "A1.1"}}]}
    inv = {"ocurrencias": {"partition_tag": [{"id": "PT0001", "type": "D", "sheet": "A1.1", "center_pt": [150, 110]},
                                             {"id": "PT0002", "type": "D", "sheet": "A1.1", "center_pt": [250, 95]}]}}
    evidencia.tags_a_walls(c, inv)
    assert c["walls"][0]["tag_ids"] == ["PT0001", "PT0002"], c["walls"][0]["tag_ids"]     # U-117: se agrega, no se quita


def test_cableado_compuerta():
    import compuerta_entrega as CE
    ids = {cid for cid, _, _, _ in CE.CHEQUEOS}
    assert "CE_CALLOUTS" in ids and "CB_BE_01" in ids and "CB_U_017" in ids, sorted(ids)[:10]
    assert len([x for x in ids if x.startswith("CB_")]) == len(CB.CHEQUEOS) - 1


def test_cfa_rev5_falsos():
    """v81cf25 (CFA #2284 rev5): falsos FAIL de BE-15 / BE-102 / BE-14 con el texto real del Excel de CFA."""
    h = {"A-050": "DEMO PLAN 8 DEMO HALF WALLS", "A-052": "RCP", "A-909": "C09250", "A-201": "PLAN 7 EXISTING", "A-221": "PT-41 C.H.14'-6\""}
    b = B(hojas=h, ms=[M("Demolition", fuente="N/SHEET: A-050/A-052, KN7/A-201, C09250 2.5.B/A-909")])
    assert CB.be_15(b)[0] == "PASS", CB.be_15(b)
    b = B(hojas=h, celdas=[("Partition Takeoff", "J5", "A2/A3 S-241; M2.1/M3.5; 3/CT-73B; KN3/KN7; 01/MB-01")])
    assert CB.be_102(b)[0] == "PASS", CB.be_102(b)
    b = B(hojas=h, celdas=[("Partition Takeoff", "J5", "see 8/A-410")])
    assert CB.be_102(b)[0] == "FAIL"                               # el error original sigue cazado
    t = "Play area (A-221 PT-41 C.H. 14'-6\"): framing printed nowhere. - not printed: No sheet labels the new ceiling framing."
    b = B(hojas=h, celdas=[("Pending Items", "B2", t)])
    assert CB.be_14(b)[0] == "PASS", CB.be_14(b)
    b = B(hojas=h, celdas=[("Pending Items", "B2", "PT-41 height not printed.")])
    assert CB.be_14(b)[0] == "FAIL"
    dm = {"items": [{"id": "DEMO-01", "height_source": "S-201 B.O."}]}
    assert CB.be_vs_08(B(demo=dm, textos={"etapas/DEMO_CRUCE.md": "x"}))[0] == "PASS"     # nombre de demo_cruce.py
    assert CB.be_vs_08(B(demo=dm, textos={}))[0] == "FAIL"
    d = tempfile.mkdtemp()
    os.makedirs(os.path.join(d, "etapas", "2_lectura"))
    for n in ("canon_A.json", "canon_B.json"):
        json.dump({"walls": []}, open(os.path.join(d, "etapas", "2_lectura", n), "w"))
    import compuerta_entrega as CE
    bb = CB.B.desde_ctx(CE.Ctx(d))
    assert bb.canon_a is not None and bb.canon_b is not None             # lecturas A / B guardadas como canon_A / canon_B


if __name__ == "__main__":
    test_casos()
    print("ok casos", len(CASOS))
    test_v96_sin_falsos_positivos_cr()
    test_v119_be_cr40_verificacion()
    test_v121_be_cr40_cierre_explicito()
    test_v121_excluded_y_brief()
    test_v126_entregas_previas()
    test_v129_be_vs_13_id_largo()
    test_v130_rcp_apilados_total()
    test_be_06_soffit_sides()
    test_callouts_extra()
    print("ok callouts")
    test_auditoria_u138()
    print("ok auditoria U-138")
    test_cableado_compuerta()
    print("ok cableado")
    test_u118_evidencia_circula()
    print("ok u_118 evidencia circulada + u_117 tag_ids")
    test_cfa_rev5_falsos()
    print("ok cfa rev5 falsos")
    test_be_cf08_catalogo()
    print("ok be_cf08 A_CATALOGO")
    print("test_chequeos_biblioteca OK")

# ---- bloque test_consumer_cellular (BE-CC01 BE-CC02 BE-CC03 BE-CC04 BE-CC05 BE-CC06 v81cf48; BE-CC07 BE-CC08 BE-CC09 BE-CC10 v81cf49) ----
def test_consumer_cellular():
    import subprocess as _sp
    _code = r'''
import os, re, sys
sys.path.insert(0, os.getcwd())
A = os.getcwd()
src = lambda f: open(os.path.join(A, f), encoding="utf-8").read()
# BE-CC01: the ceiling perimeter track row cites the sheet of its ceilings (trazabilidad)
assert "BE-CC01" in src("trazabilidad.py") and 'filas_de("ceilings")' in src("trazabilidad.py").split("BE-CC01")[0][-400:] + src("trazabilidad.py").split("BE-CC01")[1][:200]
# BE-CC02: no detail of another project in a Material Summary row name
import plantilla_excel as PE
assert not re.search(r"3/A-410", PE.__dict__.get("NOMBRES", {}).get("nested inner runner (deflection head)", "") if isinstance(PE.__dict__.get("NOMBRES"), dict) else ""), "row name cites 3/A-410"
assert '"nested inner runner (deflection head)": "Nested inner runner at the deflection head (3/A-410)"' not in src("plantilla_excel.py")
# BE-CC03: eye-read bubbles without a detector ring count as read bubbles; low count on eye-swept entry sheets = AMBER
import chequeos_biblioteca as CB
class B: pass
b = B(); b.set_meta = {"burbujas": {"A100": {"burbujas": [], "sin_leer": [], "indep_no_detectados": []}}}
b.verificadas = {"A100": [{"x": 1, "y": 1, "n": "3", "hoja": "A600", "img": "x.png"}]}
leidas, pend = CB._burbujas_hoja(b, CB.norm_hoja("A100"))
assert (("3", CB.norm_hoja("A600")) in leidas), leidas
assert "BE-CC03" in src("chequeos_biblioteca.py")
# BE-CC04: an area annot is matched to the Material Summary row whose breakdown value equals its SF
assert "BE-CC04" in src("auditoria_entrega.py")
# BE-CC05: fichas types on 3-digit sheets (A500) get their sheet
assert "BE-CC05" in src("compuerta_entrega.py")
m = re.search(r'HJ_ = r"(.+?)"', src("compuerta_entrega.py")); assert m and re.search(m.group(1), "1/A500")
# BE-CC06: schedule marks of row ids with spaces are recognized
assert re.match(r"#(\d+) (.+?) on ", "#24 BACK OF HOUSE on A101 (FINISH PLAN) reviewed").group(2) == "BACK OF HOUSE"
assert "BE-CC06" in src("compuerta_entrega.py")
# BE-CC07 (rev1 case): bubbles on 5 sheets the chain never reached (A101, A102, A402, A501, A700) must be seeded and a sheet
# with bubbles and no origin circle = FAIL
b = CB.B(canon={"walls": [{"sheet": "A100", "tag": "A3", "faces": []}]}, celdas=[("x", "A1", "per 3/A600")],
         hojas={h: "t" for h in ("A100", "A101", "A102", "A402", "A500", "A501", "A600", "A700")},
         set_meta={"burbujas": {"A100": {"burbujas": [{"n": "3", "hoja": "A600", "x": 10, "y": 10}]}}},
         verificadas={"A101": [{"x": 1, "y": 1, "n": "3", "hoja": "A502", "img": "i"}],
                      "A102": [{"x": 1, "y": 1, "n": "2", "hoja": "A402", "img": "i"}],
                      "A402": [{"x": 1, "y": 1, "n": "6", "hoja": "A502", "img": "i"}],
                      "A501": [{"x": 1, "y": 1, "n": "2B", "hoja": "A501", "img": "i"}],
                      "A700": [{"x": 1, "y": 1, "n": "6", "hoja": "A500", "img": "i"},
                               {"x": 1.5, "y": 1.5, "n": "6", "hoja": "A500", "img": "i"}]},
         cadena_md="1. **A100 3/A600** x\n2. **A101 3/A502** x\n6. **A102 1/A301** x\n13. **A402 6/A502** x\n27. **A501 \"A1\"** x\n39. **A700 nota** x")
regs = CB.cadena_detalles(b)
assert {r["origen"] for r in regs} >= {"A100", "A101", "A102", "A402", "A501", "A700"}, {r["origen"] for r in regs}
assert sum(r["origen"] == "A700" for r in regs) == 1, "duplicate detector / eye bubble counted twice"
ev = CB.faltan_circulos(b, {"A100": 2, "A500": 14, "A600": 16})       # rev1: circles only on A100 / A500 / A600
assert len([e for e in ev if "0 círculos" in e]) == 5, ev
assert CB.faltan_circulos(b, {"A100": 1, "A101": 1, "A102": 1, "A402": 1, "A501": 1, "A700": 1}) == []
assert "BE-CC07" in src("compuerta_entrega.py")
# BE-CC09: detector bubbles of a rotated page are stored in the VISIBLE frame (rev1: every A600 detector circle misplaced)
import pymupdf
_d = pymupdf.open(); _p = _d.new_page(width=1728, height=2592); _p.set_rotation(270)
_q = pymupdf.Point(1507.1, 1442.0) * _p.rotation_matrix
assert abs(_q.x - 1442.0) < 0.2 and abs(_q.y - 220.9) < 0.2, _q
assert "BE-CC09" in src("compuerta_entrega.py") and 'out[k]["frame"] = "visible"' in src("compuerta_entrega.py")
assert "BE-CC10" in src("compuerta_entrega.py")
# CC-R3 / CC-R4 / CC-R4b..e / CC-R5 / CC-R6 / CC-R10 (Consumer Cellular rev3 audit U-138)
assert "CC-R3" in src("accesorios.py") and "outside corner and division bar" in src("accesorios.py")
assert "CC-R4 " in src("trazabilidad.py") and 'get("track_gauge")' in src("trazabilidad.py")
assert "CC-R5" in src("canon.py") and "resto > 0.05" in src("canon.py")
assert "CC-R6" in src("trazabilidad.py") and "METAL\s+STRAPPING" in src("trazabilidad.py")
assert "CC-R10" in src("chequeos_biblioteca.py") and "CC-R4b" in src("chequeos_biblioteca.py") and "CC-R4c" in src("chequeos_biblioteca.py")
assert CB._cota_impresa("A100 dim 7'-3\" (ticks 673.9-804.6 pt)") is not None, "CC-R4d"
assert CB.RX_ACC.search("20 GA. METAL STRAPPING ATTACHED TO NEW") and CB.RX_ACC.search("2\" X 2\" SHEET METAL ANGLE"), "CC-R4e"
class _B3:
    pass
_b3 = _B3(); _b3.canon = {"misc_items": []}; _b3.hojas = None; _b3.walls = lambda: []
_b3.ceilings = lambda: [{"room": "RR", "system": "usg_grid", "board": "5/8 type X WR", "source": "2/A501"}]
assert CB.be_25(_b3)[0] == "PASS", CB.be_25(_b3)
# U-150 (usuario 5-nov, Consumer Cellular): proposal sin NOT INCLUDED = FAIL; con INCLUDED + NOT INCLUDED + FBM = PASS
import openpyxl, tempfile
import compuerta_entrega as CE
def _prop(not_inc=True):
    wb = openpyxl.Workbook(); P = wb.active; P.title = "PROPOSAL"
    P["C21"] = "INCLUDED (quantities):\n• Bottom track 3-5/8\": 10.00 LF"
    if not_inc:
        P["C48"] = "NOT INCLUDED / EXCLUSIONS:"; P["C49"] = "• Insulation: batt"
    F = wb.create_sheet("FBM_PRICES"); F.append(["FBM code", "Product", "Cat", "Price", "Unit", "Min", "Stock", "Lead", "Link", "Read on"])
    F.append(["X-1", "track", "SteelFraming", 18.6, "Piece", 1, "Available", "", "https://myfbm.com/all-products/x/p/X-1", "2026-11-05"])
    B = wb.create_sheet("PRICING"); B.append(["M", "track", 10, "LF", "X-1", 18.6, "Piece", 0.1, "=C1*F1*H1", "2/A500"])
    f = tempfile.mktemp(suffix=".xlsx"); wb.save(f); return f
_ms = [('Bottom track 3-5/8"', 10.0)]; _sc = [("ALC-E06", "Insulation", "NOT APPLICABLE", "EXCLUDED - batt insulation")]
assert any("NOT INCLUDED" in e for e in CE.revisar_proposal(_prop(False), _ms, _sc)), "U-150: proposal without NOT INCLUDED must FAIL"
assert CE.revisar_proposal(_prop(True), _ms, _sc) == [], CE.revisar_proposal(_prop(True), _ms, _sc)
assert "U-150" in src("compuerta_entrega.py") and "Proposal" in src("compuerta_entrega.py")
# U-146 / U-147 (user decisions 5-nov, Consumer Cellular RFI-01 / RFI-04 -> option A)
assert criterios.deck_sin_corte([16.333, 17.130]) == 17.130 if False else abs(__import__("criterios").deck_sin_corte([16.333, 17.130]) - 17.13) < 1e-9
assert __import__("criterios").level_of_finish() == 4 and __import__("criterios").level_of_finish(5) == 5
class _B2:
    def __init__(s, rf): s._rf = rf
    def rfis_abiertos(s): return s._rf
assert CB.u_146(_B2([("RFI-01", "The deck break between PLY DECK @ 16'-4\" and @ 17'-1 9/16\" is not drawn", "")]))[0] == "FAIL"
assert CB.u_147(_B2([("RFI-04", "Gypsum board finish level and trims are not specified", "")]))[0] == "FAIL"
assert CB.u_146(_B2([]))[0] == "PASS" and CB.u_147(_B2([("RFI-09", "door 3C header", "")]))[0] == "PASS"
# BE-CC08: the only printed ceiling system detail governs even without a bubble (why written); no why = not accepted
import criterios
assert criterios.system_callout_ok({"detail": "2/A501", "printed_only": True, "source": "A501", "why": "2/A501 is the only gypsum board ceiling detail printed in the set"})[0]
assert not criterios.system_callout_ok({"detail": "2/A501", "printed_only": True, "source": "A501"})[0]
print("test_consumer_cellular OK")
'''
    _r = _sp.run([sys.executable, '-c', _code], cwd=os.path.dirname(os.path.abspath(__file__)), capture_output=True, text=True)
    assert _r.returncode == 0 and 'test_consumer_cellular OK' in _r.stdout, _r.stdout + _r.stderr
    print('test_consumer_cellular OK')

test_consumer_cellular()


def test_cr_rev6_cf10_specs():
    """E3 (CR City Hotel, auditoría COORDINACIÓN 7-nov): CB_BE_CF10 dio 'N/A: el set no trae specs' mientras la entrega citaba
    05 40 00 / 09 29 00 2.3 B / 09 29 00 3.6.E.4 -> pasó en vacío. Ahora: entrega que cita specs sin Project Manual leído = FAIL;
    con specs_dir leído y renglones con su sección = PASS; sección citada que no está en specs_dir = FAIL."""
    cel = [("Pending RFIs", "B5", "RFI-13: 09 29 00 2.3 B 'Gypsum Ceiling Board' (spec lists it)")]
    ms = [M("5/8\" Type X gypsum board", 100, unit="SF", fuente="A0.06 + 09 29 00 2.1.A")]
    b = CB.B(hojas={"A0.00": "CODE SUMMARY"}, celdas=cel, ms=ms)
    r = CB.be_cf10(b)
    assert r[0] == "FAIL" and "Project Manual" in str(r), r
    b = CB.B(hojas={"A0.00": "CODE SUMMARY"}, celdas=cel, ms=ms, specs={"092900": "SECTION 09 29 00 GYPSUM BOARD"})
    assert CB.be_cf10(b)[0] == "PASS", CB.be_cf10(b)
    b = CB.B(hojas={"A0.00": "x"}, celdas=cel + [("Partition", "C9", "05 40 00 cold-formed framing")], ms=ms,
             specs={"092900": "SECTION 09 29 00"})
    assert CB.be_cf10(b)[0] == "FAIL", CB.be_cf10(b)
    b = CB.B(hojas={"A0.00": "x"}, celdas=[("Partition", "C9", "no spec cited")], ms=[M("track", 10, fuente="1/A-501")])
    assert CB.be_cf10(b)[0] in ("N/A", "NA", "PASS") or "N/A" in str(CB.be_cf10(b)), CB.be_cf10(b)
    print("test_cr_rev6_cf10_specs OK")


test_cr_rev6_cf10_specs()


def test_cr_rev6_auditoria():
    """CR City Hotel rev6 (auditoría COORDINACIÓN 7-nov): E1 coffers = membrana, O1 sqrt, O2 anchos distintos del mismo detalle."""
    ang = {"ref": "CLG-L1-07 angle molding", "familia": "USG angle molding", "qty": 33.3, "op": "4 x sqrt(69.45) = 33.33 (square-equivalent perimeter)"}
    assert CB.cr_r6_o1(CB.B(canon={"misc_items": [ang]}))[0] == "FAIL"
    assert CB.cr_r6_o1(CB.B(canon={"misc_items": [dict(ang, op="perimeter of the measured room polygon = 33.89 LF")]}))[0] == "PASS"
    so = lambda fl, w_: {"id": f"SOF-{fl}", "floor": fl, "detail": "7/A7.23 (typ.)", "faces": [{"side": "bottom", "width_ft": w_}]}
    assert CB.cr_r6_o2(CB.B(canon={"framed_soffits": [so("L2", 1.0), so("L3", 0.375)]}))[0] == "FAIL"
    assert CB.cr_r6_o2(CB.B(canon={"framed_soffits": [so("L2", 0.375), so("L3", 0.375)]}))[0] == "PASS"
    mem = {"room": "L1 FS-1 membrane under the LEVEL 2 floor", "height_ft": 12.0}
    cof = {"ref": "CLG-L1-11 board", "source": "LOBBY coffers | [CONFIRMED] height 12.063 (1/A7.31 'GYP-1 12'-0 3/4\"')"}
    assert CB.cr_r6_e1(CB.B(canon={"ceilings": [mem], "misc_items": [cof]}))[0] == "FAIL"
    assert CB.cr_r6_e1(CB.B(canon={"ceilings": [mem], "misc_items": [dict(cof, source="field | [CONFIRMED] height 11.0")]}))[0] == "PASS"
    print("test_cr_rev6_auditoria OK")


test_cr_rev6_auditoria()


def test_be_cr42_conflicto_con_delta_y_gk47():
    """BE-CR42 (CR rev20, CB_U_082 roja: Review Item de conflicto plano vs plano con 'DEDUCT -X SF' sin la palabra 'delta'):
    plantilla_excel.validar lo detiene al ARMAR; conflict_note escribe siempre 'delta:'. BE-GK47: un entero escrito con '.0' no es 'impreso en 0'.
    Valores sintéticos."""
    import plantilla_excel as PE
    malo = {"revisar": [{"n": 1, "fase": "detalle", "punto": "Conflict Z9-1 1/X9.01 vs WS-9 1/X9.71: DEDUCT -123.45 SF from GYP-9"}]}
    bueno = {"revisar": [{"n": 1, "fase": "detalle",
                          "punto": PE.conflict_note("1/X9.01", "1/X9.71", delta_txt="-123.45 SF", detalle="GYP-9 vs WS-9 over the same area")}]}
    assert PE.conflictos_sin_delta(malo), "conflicto sin delta debía fallar"
    assert not PE.conflictos_sin_delta(bueno), PE.conflictos_sin_delta(bueno)
    assert "delta: -123.45 SF" in bueno["revisar"][0]["punto"]
    assert not PE.conflictos_sin_delta({"rfis": [{"id": "RFI-9", "pregunta": "Plan conflicts with spec 09 99 99", "delta": "+12 LF"}]})
    assert not PE.conflictos_sin_delta({"revisar": [{"punto": "Wall type Z9 per 2/X9.11", "conflict": "none"}]})
    try:
        PE.conflict_note("1/X9.01", "1/X9.71", delta_txt="")
        raise AssertionError("conflict_note sin delta debía fallar")
    except ValueError:
        pass
    fn = {f.__name__: f for _, f, _ in CB.CHEQUEOS}["be_hf02"]
    e, ev = fn(B(review=[("RI-9", "Detail", "B", "printed X9.21 furring: +47.0 LF track / 29.0 LF loaded", "X9.21", "")]))
    assert e == "PASS", ev
    e, ev = fn(B(review=[("RI-9", "Detail", "B", "printed X9.21 furring carried 0.0 LF", "X9.21", "")]))
    assert e == "FAIL", ev


test_be_cr42_conflicto_con_delta_y_gk47()   # post-mortem 2026-11-12b: estaba definido y nunca se llamaba


def test_u192_tasas_decididas():
    """U-192 (usuario 12-nov, Proposal de CR rev20): ceiling / soffit track, trims / corner bead / control joint y sales tax en
    [RATE TO CONFIRM] = FAIL; la labor de resilient channel sí puede quedar [RATE TO CONFIRM]. Valores sintéticos."""
    import openpyxl
    import compuerta_entrega as CE
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "PRICING"
    ws.append(["Labor - resilient channel", 99, "LF", "[RATE TO CONFIRM]"])
    assert CE.u192_fallas(wb) == []
    for t in ("Labor - ceiling track", "Labor - corner bead / control joint", "Sales tax"):
        w2 = openpyxl.Workbook()
        w2.active.append([t, 9, "LF", "[RATE TO CONFIRM]"])
        assert CE.u192_fallas(w2), t
    w3 = openpyxl.Workbook()
    w3.active.append(["Taxes 9.99% (template rate - [RATE TO CONFIRM] for the city)", "=B9*0.0999"])
    assert CE.u192_fallas(w3), "Taxes en [RATE TO CONFIRM] debía fallar"
    ws.append(["Labor - soffit framing incl. track", 9, "LF", 1.5])
    assert CE.u192_fallas(wb) == []


test_u192_tasas_decididas()


def test_be_cr45_ducha_cbu():
    """BE-CR45 (CR rev20d, v81cf138f): CB_DUCHA_CBU. Caso real CR: canon rev20c = 6 dobles conteos (a) + 6 cement board en la línea de
    atrás (b) = FAIL; rev20d = 0 = PASS. Sin cement board = N/A; cement board sin lista de showers = AMBER (no pasa en vacío)."""
    import json as _j
    import chequeos_biblioteca as CB_
    assert CB_.ducha_cbu(CB_.B(canon={"walls": [{"id": "x", "board": "5/8 type X"}]}))[0] == "PASS"
    assert CB_.en_vacio(CB_.B(pt=[{"wall": "x"}]), "ducha_cbu", *CB_.ducha_cbu(CB_.B(canon={"walls": [{"id": "x", "board": "5/8 type X"}]})))[0] == "PASS"
    assert CB_.ducha_cbu(CB_.B(canon={"walls": [{"id": "x", "board": "1/2 cement board"}]}))[0] == "AMBER"
    sh = [{"floor": "L2", "room": "214", "box": [100, 130, 50, 80], "cbu": [{"side": "W", "id": "CBU-1"}]}]
    can = {"existing_walls": [
        {"id": "CBU-1", "floor": "L2", "board": "1/2 cement board", "height_ft": 9.0, "type_id": "W.4-0", "path": [[100, 50], [100, 80]]},
        {"id": "W-1", "floor": "L2", "board": "5/8 type X", "height_ft": 9.24, "type_id": "W.4-0", "type": "W.4",
         "location": "bath | faces: shower 214", "path": [[100, 40], [100, 90]]}], "showers": sh}
    est, ev = CB_.ducha_cbu(CB_.B(canon=can))
    assert est == "FAIL" and any(x.startswith("(a)") for x in ev), ev
    can["existing_walls"][1]["type_id"] = "W.4-1"                    # rated: las capas quedan, no es doble conteo
    assert CB_.ducha_cbu(CB_.B(canon=can))[0] == "PASS"
    D = None
    for raiz in (os.environ.get("TAKEOFF_REPO"), "/home/user/Reading-Plans", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")):
        d = os.path.join(raiz or "", "cache_proyectos", "herramientas", "tests")
        if raiz and os.path.isfile(os.path.join(d, "be_cr45_cr_banos_cbu.json")):
            D = d
            break
    if not D:
        print("AVISO test_be_cr45_ducha_cbu: datos de CR no encontrados (cache_proyectos/herramientas/tests); caso real saltado")
        return
    sh = _j.load(open(os.path.join(D, "be_cr45_cr_banos_cbu.json")))["showers"]
    f = CB_.ducha_cbu_fallas(_j.load(open(os.path.join(D, "be_cr45_cr_canon_rev20c.json"))), sh)
    assert sum(x.startswith("(a)") for x in f) == 6 and sum(x.startswith("(b)") for x in f) == 6, f
    assert CB_.ducha_cbu_fallas(_j.load(open(os.path.join(D, "be_cr45_cr_canon_rev20d.json"))), sh) == []


test_be_cr45_ducha_cbu()


def test_be_xf20_stud_zona():
    """BE-XF20 (Xfinity rev1c -> rev1d, auditoría 13-nov E-1): canon real rev1c (STUD16-GF 362S162-54 sin deducción) = FAIL;
    rev1d (STUD20-GF-REPLACED citando 8/A2.0) = PASS; deducción de otra cantidad = FAIL; 'decision' con N/HOJA = PASS."""
    import json as _j
    import chequeos_biblioteca as CB_
    base = {"walls": [{"id": "W2-01", "type_id": "W2", "stud_size": "362S125-33"}],
            "misc_items": [{"ref": "Z", "qty": 100.0, "unit": "LF", "source": "8/A2.0 zone on W2-01 | 362S162-54"},
                           {"ref": "D", "qty": -60.0, "unit": "LF", "source": "8/A2.0 deduction 362S125-33"}]}
    assert CB_.stud_zona_fallas(base) and "vs deduction" in CB_.stud_zona_fallas(base)[0]
    base["misc_items"][0]["decision"] = "added on top: 8/A2.0 note 'IN ADDITION TO WALL STUDS'"
    assert CB_.stud_zona_fallas(base) == []
    base["misc_items"][0]["decision"] = "see 1/A9.9"                    # verificación g #3: otro N/HOJA no libera
    assert CB_.stud_zona_fallas(base)
    grid = {"walls": [{"id": "Z9-01", "type_id": "A", "stud_size": "362S125-33"}],   # verificación g #1 (Grand Kia): eje 'A' no es el type A
            "misc_items": [{"ref": "Z", "qty": 10.0, "source": "ceiling framing at grid line A (H.1 to B) | 362S162-43"}]}
    assert CB_.stud_zona_fallas(grid) == []
    grid["misc_items"][0]["source"] = "backing zone on type A walls | 362S162-54"
    assert CB_.stud_zona_fallas(grid)
    tam = {"walls": [{"id": "Y9-01", "type_id": "B", "stud_size": "362S162-19"}],     # Grand Kia EXT-03B: el type citado solo por su tamaño
           "misc_items": [{"ref": "EXT", "qty": 50.0, "source": "A200 EXT: stud framing; A220 type B 21'-0\" | 362S162-68"}]}
    assert CB_.stud_zona_fallas(tam) == []
    D = None
    for raiz in (os.environ.get("TAKEOFF_REPO"), "/home/user/Reading-Plans", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")):
        d = os.path.join(raiz or "", "cache_proyectos", "herramientas", "tests")
        if raiz and os.path.isfile(os.path.join(d, "be_xf20_xf_rev1c.json")):
            D = d
            break
    if not D:
        print("AVISO test_be_xf20_stud_zona: datos de Xfinity no encontrados; caso real saltado")
        return
    f = CB_.stud_zona_fallas(_j.load(open(os.path.join(D, "be_xf20_xf_rev1c.json"))))
    assert len(f) == 1 and f[0].startswith("STUD16-GF") and "362S125-33" in f[0], f
    assert CB_.stud_zona_fallas(_j.load(open(os.path.join(D, "be_xf20_xf_rev1d.json")))) == []


test_be_xf20_stud_zona()


def test_be_xf21_head_piezas():
    """BE-XF21 (Xfinity rev1c -> rev1d, auditoría 13-nov E-2): canon real rev1c (Door 101: 2 piezas de track, la 2a impresa como stud) = FAIL;
    rev1d (HDR-101-NESTED 362S125-33) = PASS; una fila de TRACK que cite la puerta no cuenta como stud."""
    import json as _j
    import chequeos_biblioteca as CB_
    can = {"walls": [{"id": "W", "openings": [{"ref": "Door 7", "pieces": 2, "piece": "track", "header": "5/A5 TRACK + NESTED STUD"}]}],
           "misc_items": [{"ref": "HDR-7", "familia": "track header", "qty": 4.0, "source": "5/A5 door 7 | 362T125-33"}]}
    assert CB_.head_piezas_fallas(can), "una fila de track no es la pieza de stud"
    can["misc_items"].append({"ref": "HDR-7-S", "familia": "3-5/8\" stud", "qty": 4.0, "source": "5/A5 door 7 nested stud | 362S125-33"})
    assert CB_.head_piezas_fallas(can) == []
    D = None
    for raiz in (os.environ.get("TAKEOFF_REPO"), "/home/user/Reading-Plans", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")):
        d = os.path.join(raiz or "", "cache_proyectos", "herramientas", "tests")
        if raiz and os.path.isfile(os.path.join(d, "be_xf20_xf_rev1c.json")):
            D = d
            break
    if not D:
        print("AVISO test_be_xf21_head_piezas: datos de Xfinity no encontrados; caso real saltado")
        return
    f = CB_.head_piezas_fallas(_j.load(open(os.path.join(D, "be_xf20_xf_rev1c.json"))))
    assert len(f) == 1 and f[0].startswith("Door 101"), f
    c1 = _j.load(open(os.path.join(D, "be_xf20_xf_rev1c.json")))           # verificación h #1: un jamb que cita la puerta no es la pieza del head
    c1["misc_items"].append({"ref": "JAMB-101", "familia": "3-5/8\" stud", "qty": 14.0, "source": "door 101 jamb studs | 362S125-33"})
    assert CB_.head_piezas_fallas(c1)
    assert CB_.head_piezas_fallas(_j.load(open(os.path.join(D, "be_xf20_xf_rev1d.json")))) == []


test_be_xf21_head_piezas()


def test_u201_decisiones_regla():
    """U-201 (usuario 13-nov, CR, botones 'A'): caso real CR (fixture de CR, commit 474c2f8): rev20c con RFI-32 (rating code plan vs tag),
    RFI-33 (elementos sin tag) y RFI-34 (wrap con solo SFRM) ABIERTOS = 3 fallas; rev20d (cerrados por la regla, DA-7 / DA-8 con delta) = 0;
    (1) cerrado SIN su DEDUCT = FAIL."""
    import json as _j
    import chequeos_biblioteca as CB_
    D = None
    for raiz in (os.environ.get("TAKEOFF_REPO"), "/home/user/Reading-Plans", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")):
        d = os.path.join(raiz or "", "cache_proyectos", "herramientas", "tests")
        if raiz and os.path.isfile(os.path.join(d, "u201_cr_rev20c_rev20d.json")):
            D = d
            break
    sint = {"rfis": [{"id": "RFI-1", "status": "closed", "question": "code plan 2 HR vs plan tag 1 HR"}], "deduct_alternates": []}
    assert CB_.u201_fallas(sint) and "DEDUCT" in CB_.u201_fallas(sint)[0]
    rx = {n: rx for n, (_d, rx) in CB_.U201_TEMAS.items()}                 # verificación k: redacciones y falsos positivos
    for s in ("Wall type not shown at the niche", "No partition type indicated for the chase walls", "the east wall is not tagged"):
        assert rx[2].search(s), s
    for s in ("1 HR vs 2 HR fire rating discrepancy", "Life safety plan shows 2 HR but partition tag shows 1 HR"):
        assert rx[1].search(s), s
    assert rx[3].search("spray-applied fireproofing at the beam vs gypsum enclosure")
    for s in ("SFRM is by others - confirm fireproofing excluded", "Room tag 904 on code plan differs from the finish plan", "Untagged ceiling: ACT or GWB?"):
        assert not any(r.search(s) for r in rx.values()), s
    assert CB_.u201_fallas({"rfis": [{"id": "R1", "status": "closed - code", "question": "the east wall is not tagged"}]}) == []
    assert CB_.u201_fallas({"rfis": [{"id": "R1", "status": "closed", "question": "rating conflict, code plan 2 HR"}],
                            "deduct_alternates": [{"rfi": "R1", "delta_sf": "-448.89 SF"}]}) == []
    if not D:
        print("AVISO test_u201_decisiones_regla: datos de CR no encontrados; caso real saltado")
        return
    fx = _j.load(open(os.path.join(D, "u201_cr_rev20c_rev20d.json")))
    f = CB_.u201_fallas(fx["rev20c"])
    assert sorted(x.split(":")[0] for x in f) == ["RFI-32", "RFI-33", "RFI-34"], f
    assert CB_.u201_fallas(fx["rev20d"]) == []
    sin_da = _j.loads(_j.dumps(fx["rev20d"]))
    sin_da["deduct_alternates"] = [x for x in sin_da["deduct_alternates"] if x.get("rfi") != "RFI-32"]
    assert [x for x in CB_.u201_fallas(sin_da) if x.startswith("RFI-32")]


test_u201_decisiones_regla()


def test_be_cr0_01_inventario_i1():
    """BE-CR0-01 (CR desde cero 13-nov, test del proyecto test_be_cr0_01_inv_I1.py): verificar_png normalizaba 'I' -> '1' solo en el texto
    leído: el tag esperado 'FI.2' contra el texto 'FI.2' (leído F1.2) no coincidía = 'PNG NO VERIFICADO'. Ahora coincide_tag normaliza los
    dos lados; un tag distinto sigue sin coincidir."""
    import re as _re
    import inventario_tags as IT
    for tag in ("FI.2", "FI.6", "XI.2.7"):
        leido = _re.sub(r"\b([A-Z])[lI|i]\b", r"\g<1>1", tag)            # lo que verificar_png deja del texto leído
        assert not (tag in leido or tag in _re.sub(r"\s+", "", leido))    # el error original (v81cf138o)
        assert IT.coincide_tag(tag, tag) and IT.coincide_tag(tag, leido)
    assert IT.coincide_tag("W.6-1", "W.6-1 | 1") and not IT.coincide_tag("W.4", "W.6") and not IT.coincide_tag("FI.2", "FI.6")


test_be_cr0_01_inventario_i1()


def test_be_cr0_02_normalizar_fragmentos():
    """BE-CR0-02 (CR desde cero, test del proyecto test_be_cr0_02_normalizar.py): dos lectores con la MISMA escala y textos de fuente
    distintos = `unir` fallaba; etapas.normalizar_fragmentos los une (fuentes concatenadas, global = escala de A2.x); valores distintos = rc 1."""
    import tempfile
    import etapas as ET
    def run(frags):
        d, o = tempfile.mkdtemp(), tempfile.mkdtemp()
        for n, f in frags.items():
            json.dump(f, open(os.path.join(d, n), "w"))
        rc = ET.normalizar_fragmentos(d, o)
        p = os.path.join(o, "00_comunes.json")
        return rc, (json.load(open(p)) if os.path.exists(p) else None)
    rc, c = run({"a.json": {"constants": {"plan_scale_by_sheet": {"A2.01": {"value": 9.0, "source": "x"}}, "plan_scale_pt_per_ft": {"value": 9.0, "source": "x"}}},
                 "b.json": {"constants": {"plan_scale_by_sheet": {"A2.01": {"value": 9.0, "source": "y"}, "A6.00": {"value": 18.0, "source": "z"}},
                                          "plan_scale_pt_per_ft": {"value": 18.0, "source": "z"}}}})
    assert rc == 0 and c["constants"]["plan_scale_by_sheet"]["A2.01"]["source"] == "x | y" and c["constants"]["plan_scale_pt_per_ft"]["value"] == 9.0, c
    rc, _ = run({"a.json": {"constants": {"plan_scale_by_sheet": {"A2.01": {"value": 9.0, "source": "x"}}}},
                 "b.json": {"constants": {"plan_scale_by_sheet": {"A2.01": {"value": 18.0, "source": "y"}}}}})
    assert rc == 1
    rc, c = run({"a.json": {"details": {"3/A9.01": {"notes": "head per A0.06"}}}, "b.json": {"details": {"3/A9.01": {"notes": "deflection track"}}}})
    assert rc == 0 and c["details"]["3/A9.01"]["readers"] == ["a.json", "b.json"] and "deflection" in c["details"]["3/A9.01"]["notes"]


test_be_cr0_02_normalizar_fragmentos()


def test_be_cr0_03_owner_existing():
    """BE-CR0-03 (CR desde cero, test del proyecto test_be_cr0_03_owner_existing.py): chequeos_v71.ids_canon no incluía existing_walls; en
    un set de wood framing (todo board-only) un tag descartado con owner = wall board-only fallaba R78.15 'owner no existe en el canon'."""
    import chequeos_v71 as C71
    c = {"existing_walls": [{"id": "W.6-L9-01", "tag_ids": ["PT9300"]}],
         "tags_descartados": [{"id": "PT9021", "motivo": "CMU; its room face is counted in W.6-L9-01", "owner": "W.6-L9-01"}]}
    assert C71.r78_15(c) == [], C71.r78_15(c)
    c["tags_descartados"][0]["owner"] = "W.6-L9-99"
    assert C71.r78_15(c), "un owner que no existe sigue fallando"


test_be_cr0_03_owner_existing()


def test_be_cr0_04_ambiguo_type_id():
    """BE-CR0-04 (CR desde cero, test del proyecto test_be_cr0_04_ambiguo_type_id.py): comparar.ambiguos_sin_disposicion comparaba el type
    del tag ambiguo solo con w.tag / w.type; los walls board-only traen la designación en type_id y un texto largo en type -> 'citado en
    tag_ids de un wall de otro type' aunque el tag estaba bien asignado. Un type distinto sigue fallando."""
    import comparar as CP
    inv = {"ocurrencias": {"partition_ambiguo": [{"id": "PA9004", "type": "XW.6.3", "sheet": "A9.01", "page": 17}]}}
    can = {"existing_walls": [{"id": "XW.6.3-L9-01", "type_id": "XW.6.3-0", "type": "XW.6.3 (exterior 2x6 wood stud) non-rated", "tag_ids": ["PA9004"]}]}
    assert CP.ambiguos_sin_disposicion(inv, [can]) == [], CP.ambiguos_sin_disposicion(inv, [can])
    can["existing_walls"][0].update(type_id="XW.6.4-0", type="XW.6.4 (exterior) non-rated")
    assert CP.ambiguos_sin_disposicion(inv, [can]), "otro type sigue fallando"


test_be_cr0_04_ambiguo_type_id()


def test_be_cr0_07_detail_board_only():
    """BE-CR0-07 (CR desde cero 14-nov): markups_bluebeam.contenido de un board-only sin keynote dejaba DETAIL vacío (cientos de 'DETAIL sin
    N/HOJA' en un edificio de wood framing); ahora DETAIL = su N/HOJA (cita del wall)."""
    import markups_bluebeam as MB
    w = {"element": MB.EXIST_EL, "id": "W.9-L9-05 A", "type_id": "W.9-0", "length_ft": 6.46, "height_ft": 9.292, "faces": 1, "layers": 1,
         "source": "1/A9.02 | path", "sheet": "A9.02"}
    c = MB.contenido(w)
    assert "1/A9.02" in c.split("·")[-2], c


test_be_cr0_07_detail_board_only()


def test_be_cr0_08_inventario_multi_pdf():
    """BE-CR0-08 (CR desde cero 14-nov): en un set de varios PDF (A 86 + S 26 páginas) el inventario de tags del PDF de arquitectura (86) se
    marcaba 'inventario de otro set' (86 != 112); ahora vale si sus páginas = las de UNO de los PDF fuente. Un número que no es de ningún
    PDF sigue fallando."""
    import chequeos_biblioteca as CB_
    mk = lambda n: CB_.B(canon={"walls": [{"id": "W1", "element": "wall"}]}, set_meta={"fuentes": [{"paginas": 86}, {"paginas": 26}]},   # noqa: E731
                         inv_full={"pages": n, "ocurrencias": {"partition_tag": [{"id": "P1", "type": "W.9", "sheet": "A9.01"}]}})
    assert not [x for x in CB_.u_117(mk(86))[1] if "inventario de otro set" in x]
    assert not [x for x in CB_.u_117(mk(112))[1] if "inventario de otro set" in x]
    assert [x for x in CB_.u_117(mk(50))[1] if "inventario de otro set" in x]


test_be_cr0_08_inventario_multi_pdf()


def test_be_cr0_09_rcp_capas():
    """BE-CR0-09 (CR desde cero 14-nov): un cielo de 2 capas (RS-6) daba Area dibujada vs el doble de SF en el Excel (CE_VISTA_BLUEBEAM);
    ahora su Contents dice 'board = 2 layer(s) x drawn area'; 1 capa = nada."""
    import markups_rcp as MR
    assert MR.capas_txt({"layers": 2}) == "; board = 2 layer(s) x drawn area"
    assert MR.capas_txt({"layers": {"value": 3}}).startswith("; board = 3")
    assert MR.capas_txt({"layers": 1}) == MR.capas_txt({}) == ""


test_be_cr0_09_rcp_capas()


def test_be_cr0_10_madera_y_membrana():
    """BE-CR0-10 (CR desde cero 14-nov, edificio de wood framing): (a) be_20 pedía track metálico a un soffit armado SOLO en madera (Div. 06
    EXCLUDED) = falso positivo; un soffit metálico sin track / stud sigue fallando. (b) be_02 juzgaba la membrana FS-1 'above GYP-1' (oculta,
    doble cielo) como el cielo expuesto del wet room; el cielo expuesto del toilet en Type C sigue fallando."""
    import chequeos_biblioteca as CB_
    mk = lambda fr: CB_.B(canon={"framed_soffits": [{"id": "S9", "framing": fr}], "walls": [{"id": "W"}]}, ms=[])   # noqa: E731
    assert CB_.be_20(mk("2x6 wood stud (Div. 06 EXCLUDED)"))[0] == "PASS"
    assert CB_.be_20(mk("3-5/8\" metal stud + track"))[0] == "FAIL"
    hj = {"A9.01": "WATER RESISTANT GYPSUM BOARD AT ALL WET LOCATIONS"}
    mk2 = lambda room: CB_.B(canon={"ceilings": [{"room": room, "board": "5/8 Type C"}], "walls": [{"id": "W"}]}, hojas=hj)   # noqa: E731
    assert CB_.be_02(mk2("L9 909 Toilet FS-1 membrane above GYP-1"))[0] == "PASS"
    assert CB_.be_02(mk2("L9 909 Toilet"))[0] == "FAIL"


test_be_cr0_10_madera_y_membrana()


def test_be_cr0_11_traza_cielo():
    """BE-CR0-11 (CR desde cero 14-nov): trazabilidad._item no encontraba los renglones de cielo del desglose ('ceiling <room>' / id / room):
    la fila Type C (solo cielos) salía 'N/SHEET: default (no sheet)'; ahora cita la fuente del cielo."""
    import trazabilidad as TZ
    can = {"ceilings": [{"room": "L9 909 RS-6", "source": "2/A9.00 RS-6 A0.98"}]}
    assert TZ._src_item("ceiling L9 909 RS-6", can) == "2/A9.00 RS-6 A0.98"
    assert TZ._src_item("L9 909 RS-6", can) == "2/A9.00 RS-6 A0.98"
    assert TZ._src_item("nada", can) == ""


test_be_cr0_11_traza_cielo()
