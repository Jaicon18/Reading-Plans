#!/usr/bin/env python3
"""test_board_driver_mr.py — R80e.130 / BE-CF14: el 1/2" MR y el 5/8" foil-backed entran al driver de finishing
(drywall screws, joint compound, joint tape). Falla con accesorios v81cf6."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import accesorios as A
for b in ("1/2\" gyp MOISTURE RESISTANT", "5/8\" gyp FOIL-BACKED"):
    assert b in A.BOARD_DRIVER, b
print("test_board_driver_mr OK")
