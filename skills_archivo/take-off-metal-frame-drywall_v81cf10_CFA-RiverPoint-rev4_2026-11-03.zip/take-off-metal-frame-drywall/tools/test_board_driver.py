#!/usr/bin/env python3
"""test_board_driver.py — BE-CF14: toda familia de gypsum board de canon entra al driver de finishing (compound / tape),
salvo cement board, ballistic panel y sheathing exterior."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import canon, accesorios
fuera = ("cement", "ballistic", "EXTERIOR", "glass mat", "FRT", "1/4")
gyp = [f for f in canon.BOARD_FAM.values() if "gyp" in f.lower() and not any(x in f for x in fuera)]
falta = [f for f in gyp if f not in accesorios.BOARD_DRIVER]
assert not falta, f"familias de gypsum board fuera del driver de finishing: {falta}"
print("test_board_driver OK")
