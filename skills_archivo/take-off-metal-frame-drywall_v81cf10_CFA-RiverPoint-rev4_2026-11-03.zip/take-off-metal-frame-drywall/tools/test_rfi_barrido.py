#!/usr/bin/env python3
"""test_rfi_barrido.py — R80f.6 / BE-CF16: RFI abierto sin barrido completo = falla."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reglas as R
malo = {"rfis": [{"id": "RFI-01", "pregunta": "height?", "delta": "x"}]}
assert R.rfi_barrido_fallas(malo)
bueno = {"rfis": [{"id": "RFI-01", "pregunta": "height?", "delta": "x",
                   "barrido": {"hojas": "ALL", "terminos": ["B.O.", "DECK", "JOIST"], "grep": "set_text.txt: 0 hits"}}]}
assert not R.rfi_barrido_fallas(bueno), R.rfi_barrido_fallas(bueno)
cerrado = {"rfis": [{"id": "RFI-02", "estado": "CLOSED - estimator decision (option A)"}]}
assert not R.rfi_barrido_fallas(cerrado)
print("test_rfi_barrido OK")
