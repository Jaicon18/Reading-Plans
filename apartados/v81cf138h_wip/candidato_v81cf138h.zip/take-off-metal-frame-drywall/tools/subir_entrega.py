#!/usr/bin/env python3
"""subir_entrega.py — BE-121 (usuario 3-nov, INVIOLABLE): CANDADO DE SUBIDA. Única forma de subir una entrega a Drive.

Envuelve /opt/takeoff/gdrive_fetch.py (no lo modifica). Se NIEGA a subir si:
  1. no existe <workdir>/ENTREGA_OK.json, o no es verde (ok = true, 0 FAIL), o viene de una corrida parcial;
  2. algún archivo de la carpeta de entrega cambió, se agregó o se borró DESPUÉS de la compuerta (sha256 distinto al
     registrado, o archivo más nuevo que ENTREGA_OK.json);
  3. drive.parent_id != 1UReOABlgJPIkGLe8-nRO6U-6i7xpKoIc (Claude outputs de la RAÍZ) o es el prohibido de Projects;
  4. la carpeta del proyecto (drive.carpeta_proyecto_id) no aparece EN VIVO como hija de la raíz (gdrive_fetch list);
  5. BE-CF27 (CFA rev10, 5-nov): hay una orden del usuario (U-NNN de ORDENES_DEL_USUARIO.md en el REMOTO, git fetch) que el
     REGLAS_REGISTRO.json del skill con que se corrió la compuerta no tiene: unir el skill y volver a pasar la compuerta.
     $TAKEOFF_REPO = el repo (por defecto /home/user/reading-plans); $SIN_ORDENES_REMOTAS=1 o un $GDRIVE_FETCH falso lo saltan (solo tests).
Sube la carpeta de entrega como subcarpeta NUEVA (nombre de la carpeta de entrega) dentro de la carpeta del proyecto
(gdrive_fetch put nunca sobrescribe; las carpetas se crean en serie, los archivos en paralelo con --workers), por tramos de
--max-min minutos con el avance en <workdir>/SUBIDA_PROGRESO.json; retoma sola tramo tras tramo (lo ya subido con mismo
nombre y tamaño se salta) hasta terminar o --max-tramos, y escribe SUBIDA_OK.json solo con TODO subido (BE-CR28 / P2).

Uso: python3 subir_entrega.py <project_workdir> [--revisar] [--auditoria-carpeta]      (--revisar = solo los candados, sin subir)
         [--workers N]      (put en paralelo; por defecto 6)
         [--max-min M]      (minutos por tramo; por defecto 90; al tope se esperan los archivos en vuelo y sigue otro tramo)
         [--max-tramos T]   (tope duro de tramos; por defecto 10; pasado = SUBIDA BLOQUEADA con el avance en disco)
     python3 subir_entrega.py <project_workdir> --vigente           (U-177: Drive = lo validado por la compuerta con el skill vigente)
     $GDRIVE_FETCH = ruta alternativa del script de Drive (tests); por defecto /opt/takeoff/gdrive_fetch.py
"""
import datetime
import json, re
import os
import subprocess
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import compuerta_entrega as CE  # noqa: E402

GDRIVE = os.environ.get("GDRIVE_FETCH") or "/opt/takeoff/gdrive_fetch.py"


class Bloqueo(Exception):
    pass


def _g(*args):
    p = subprocess.run([sys.executable, "-I", GDRIVE, *args], capture_output=True, text=True, timeout=3600)
    if p.returncode:
        raise Bloqueo(f"gdrive_fetch {args[0]} falló rc {p.returncode}: {(p.stderr or p.stdout)[-300:]}")
    return p.stdout


PREFIJO_BORRAR = "BORRAR (NO USAR) - "                 # U-186 (usuario 12-nov): lo que ya no se ocupa se marca para que el usuario lo borre
RX_VIEJO = re.compile(r"(?i)BORRAR\b|zz\b|.*REPLACED|.*NO USAR")          # nombre de un archivo / carpeta que ya no es vigente
RX_OBSOLETO = re.compile(r"(?i)^zz\b|REPLACED|superseded|NO USAR|^old\b|\bold U-\d+")   # marca de obsoleto (U-186: sin BORRAR = FAIL)


def nombre_borrar(nombre, vigente=None):
    """U-186: 'BORRAR (NO USAR) - <nombre sin zz / sin NO USAR> [- REPLACED BY <vigente>]'. Idempotente."""
    base = re.sub(r"(?i)^(?:BORRAR \(NO USAR\) - )+", "", nombre)
    base = re.sub(r"(?i)^zz\s+(?:NO USAR\s*-\s*)?", "", base).strip()
    out = PREFIJO_BORRAR + base
    if vigente and "REPLACED BY" not in out.upper():
        out += f" - REPLACED BY {vigente}"
    return out


def borrar_fallas(nombres, vigentes=()):
    """U-186 (barrido de Drive): nombre con marca de obsoleto (zz / REPLACED / superseded / NO USAR / old) sin el prefijo BORRAR = FAIL;
    BORRAR en un archivo vigente (los nombres de `vigentes`, o una revisión 'revN' más nueva o igual a la vigente) = FAIL. -> [fallas]"""
    vg = {str(v) for v in vigentes or ()}
    ev = []
    for n in nombres:
        b = n.startswith(PREFIJO_BORRAR)
        if not b and RX_OBSOLETO.search(n):
            ev.append(f"'{n}': ya no se ocupa y no lleva el prefijo '{PREFIJO_BORRAR}' -> '{nombre_borrar(n)}' (U-186)")
        if b and (n[len(PREFIJO_BORRAR):] in vg or any(n.endswith(f" - {v}") and "REPLACED BY" not in n for v in vg)):
            ev.append(f"'{n}': BORRAR en un archivo VIGENTE (U-186: lo vigente nunca lleva BORRAR)")
    return ev


def md5_drive(carpeta_id):
    """{nombre: md5Checksum} de los archivos VIGENTES (sin BORRAR / zz / REPLACED / NO USAR) de una carpeta de Drive."""
    import importlib.util
    import requests
    sp = importlib.util.spec_from_file_location("gdrive_fetch_mod", GDRIVE)
    G = importlib.util.module_from_spec(sp)
    sp.loader.exec_module(G)
    tok, out = G.access_token(), {}
    q = {"q": f"'{carpeta_id}' in parents and trashed = false", "fields": "nextPageToken, files(name,md5Checksum)",
         "includeItemsFromAllDrives": "true", "pageSize": 1000, **G.ALL_DRIVES}
    while True:
        b = requests.get(G.API, params=q, timeout=60, headers=G._auth(tok)).json()
        for f in b.get("files", []):
            if not RX_VIEJO.match(f["name"]):
                out[f["name"]] = f.get("md5Checksum")
        if "nextPageToken" not in b:
            return out
        q["pageToken"] = b["nextPageToken"]


def verificar_vigente(ok, log, listar=md5_drive, subida=None, w=None):
    """U-177 (1): -> fallas de CE.vigente_fallas con el md5 de Drive de las carpetas del PDF y del Excel vigentes. U-201 (6): con la
    excepción del usuario válida (excepcion_usuario_fallas == ''), la comparación de md5 se hace como si la compuerta fuera verde
    (el ENTREGA_OK.json en disco no se toca)."""
    if (not ok.get("ok") or _no_verdes(ok)) and w:
        if excepcion_usuario_fallas(ok, w):
            return ["compuerta no verde sin excepción del usuario válida (U-201 (6))"] if _no_verdes(ok) else \
                CE.vigente_fallas(ok, {}, [x[0] for x in CE.CHEQUEOS], subida)
        ok = dict(ok, ok=True)
    vg = ok.get("vigentes") or {}
    carpetas = {e["carpeta_id"] for e in log for v in vg.values() if os.path.basename(e["archivo"]) == v.get("nombre")}
    md = {}
    for cid in carpetas:
        md.update(listar(cid))
    return CE.vigente_fallas(ok, md, [x[0] for x in CE.CHEQUEOS], subida)    # v131: VERDE de la versión vigente al subir sigue válido


RX_EXC_CHECK = re.compile(r"^(?:CE|CB)_[A-Z0-9_]+$")
RX_EXC_FECHA = re.compile(r"^\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})?)?$")


def _no_verdes(ok):
    """verificación v138a H1: todo estado que no es PASS ni AMBER cuenta como FAIL ('fail', 'ERROR', vacío...)."""
    return [c for c in ok.get("chequeos") or [] if str(c.get("estado")) not in ("PASS", "AMBER")]


def excepcion_usuario_fallas(ok, w):
    """U-201 (6) (usuario 13-nov, v81cf138a): una compuerta con una falla SOLO de proceso se sube únicamente con la excepción
    AUTORIZADA POR EL USUARIO escrita en ENTREGA_OK.json 'excepcion_usuario' {check, texto, fecha, autorizado_por: "usuario"
    [, evidencia]} y en README_REVIEW.md de la entrega (el nombre del chequeo como palabra entera y el texto completo en la MISMA
    sección), solo si el ÚNICO resultado no verde (todo estado que no es PASS / AMBER) es exactamente ese chequeo (nombre y, si la
    excepción la trae, evidencia) y la corrida es COMPLETA (vigentes + todos los chequeos actuales corridos). 'ok' y los resultados
    no se tocan. -> '' si la excepción vale, o la causa"""
    ex = ok.get("excepcion_usuario")
    if not isinstance(ex, dict):
        return "; sin excepcion_usuario autorizada (U-201 (6))"
    for k in ("check", "texto", "fecha", "autorizado_por"):
        if not isinstance(ex.get(k), str) or not ex.get(k).strip():
            return f"; excepcion_usuario incompleta ('{k}' tiene que ser texto no vacío) (U-201 (6))"
    if ex["autorizado_por"] != "usuario":
        return f"; excepcion_usuario no autorizada por el usuario (autorizado_por = {ex['autorizado_por']!r}, tiene que ser 'usuario') (U-201 (6))"
    if not RX_EXC_CHECK.match(ex["check"]):
        return f"; excepcion_usuario: '{ex['check']}' no es el id de un chequeo (CE_… / CB_…) (U-201 (6))"
    if not RX_EXC_FECHA.match(ex["fecha"].strip()):
        return f"; excepcion_usuario: fecha {ex['fecha']!r} no es una fecha ISO (AAAA-MM-DD) (U-201 (6))"
    if len(ex["texto"].strip()) < 30:
        return "; excepcion_usuario: 'texto' demasiado corto (>= 30 caracteres: qué falla, por qué no afecta cantidades, quién autoriza) (U-201 (6))"
    fails = _no_verdes(ok)
    if not fails:
        return "; corrida parcial: la excepción solo cubre un FAIL nombrado (U-201 (6))"
    if len(fails) != 1 or fails[0].get("id") != ex["check"] or fails[0].get("estado") != "FAIL":
        return (f"; la excepción nombra '{ex['check']}' y los resultados no verdes son "
                f"{[(c.get('id'), c.get('estado')) for c in fails]}: solo se sube si el ÚNICO FAIL es ese chequeo (U-201 (6))")
    if ex.get("evidencia") is not None and ex.get("evidencia") != fails[0].get("evidencia"):
        return f"; la evidencia de la excepción no es la del FAIL de {ex['check']} (U-201 (6))"
    corridos = {c.get("id") for c in ok.get("chequeos") or []}
    faltan = [n for n in (x[0] for x in CE.CHEQUEOS) if n not in corridos]
    if not ok.get("vigentes") or faltan:
        return (f"; la excepción solo vale sobre una corrida COMPLETA de la compuerta (vigentes y todos los chequeos actuales"
                f"{'; faltan ' + str(len(faltan)) if faltan else ''}) (U-201 (6))")
    rd = os.path.join(w, ok.get("entrega_dir") or "", "README_REVIEW.md")
    txt = open(rd, encoding="utf-8").read() if os.path.isfile(rd) else ""
    secciones = re.split(r"(?m)^(?=#)", txt)
    rx_chk = re.compile(r"(?<![A-Za-z0-9_])" + re.escape(ex["check"]) + r"(?![A-Za-z0-9_])")
    if not any(rx_chk.search(sec) and ex["texto"].strip() in sec for sec in secciones):
        return (f"; la excepción ({ex['check']}) no está escrita en README_REVIEW.md de la entrega (el chequeo como palabra entera y el "
                "texto completo en la misma sección) (U-201 (6))")
    return ""


def candados(workdir):
    """-> (ENTREGA_OK dict, lista de archivos a subir). Lanza Bloqueo con el motivo."""
    w = os.path.abspath(workdir)
    okp = os.path.join(w, "ENTREGA_OK.json")
    if not os.path.isfile(okp):
        raise Bloqueo("no existe ENTREGA_OK.json: correr compuerta_entrega.py primero")
    ok = json.load(open(okp, encoding="utf-8"))
    malos = [c["id"] for c in ok.get("chequeos") or [] if c.get("estado") == "FAIL"]
    if not ok.get("ok") or malos or _no_verdes(ok):
        causa = excepcion_usuario_fallas(ok, w)          # U-201 (6): única salida de una compuerta no verde
        if causa:
            raise Bloqueo(f"ENTREGA_OK.json NO está en verde (FAIL: {', '.join(str(x) for x in malos) or 'corrida parcial'}){causa}")
    ed = ok.get("entrega_dir")
    if not ed or not os.path.isdir(os.path.join(w, ed)):
        raise Bloqueo("ENTREGA_OK.json sin carpeta de entrega existente")
    t_ok = os.path.getmtime(okp)
    reg = ok.get("archivos") or {}
    real = {os.path.relpath(os.path.join(r, f), w) for r, _, fs in os.walk(os.path.join(w, ed)) for f in fs}
    nuevos, quitados = sorted(real - set(reg)), sorted(set(reg) - real)
    if nuevos or quitados:
        raise Bloqueo(f"la entrega cambió después de la compuerta: nuevos {nuevos[:5]} / faltan {quitados[:5]}")
    rz = CE.resumenes_fallas(os.listdir(os.path.join(w, ed)))   # U-164: no se suben RESUMEN viejos a la raíz
    if rz:
        raise Bloqueo(rz[0])
    rw = CE.rutas_entrega_fallas(((ok.get("drive") or {}).get("carpeta_proyecto")), os.path.basename(ed.rstrip("/")),
                                 [os.path.relpath(os.path.join(w, r), os.path.join(w, ed)) for r in reg], UMBRAL_ARCHIVOS)   # U-165: rutas en Drive
    if rw:
        raise Bloqueo(rw[0])
    mk = [os.path.basename(r) for r in reg if os.sep + "Planos marcados" + os.sep in os.sep + r and "_markups_" in r and r.endswith(".pdf")]
    if mk and not all(re.fullmatch(CE.MARKUPS_RE, b) for b in mk):   # U-165: nombre '<PROY>_markups_revN - OPEN IN BLUEBEAM.pdf'
        raise Bloqueo(f"PDF de markups con nombre fuera de U-165: {mk}")
    for rel, sha in reg.items():
        p = os.path.join(w, rel)
        if CE._sha(p) != sha:
            raise Bloqueo(f"{rel} cambió después de la compuerta (sha256 distinto): volver a correr compuerta_entrega.py")
        if os.path.getmtime(p) > t_ok + 1:
            raise Bloqueo(f"{rel} es más nuevo que ENTREGA_OK.json: volver a correr compuerta_entrega.py")
    d = ok.get("drive") or {}
    if d.get("parent_id") != CE.DRIVE_RAIZ or d.get("parent_id") == CE.DRIVE_PROHIBIDO:
        raise Bloqueo(f"drive.parent_id {d.get('parent_id')} != {CE.DRIVE_RAIZ} (Claude outputs de la RAÍZ)")
    if not d.get("carpeta_proyecto_id"):
        raise Bloqueo("entrega.json sin drive.carpeta_proyecto_id (crearla con gdrive_fetch mkdir "
                      f"{CE.DRIVE_RAIZ} '<proyecto>' y anotar el id)")
    return ok, sorted(reg)


def verificar_padre_en_vivo(d):
    hijos = [json.loads(x) for x in _g("list", CE.DRIVE_RAIZ).splitlines() if x.strip().startswith("{")]
    h = next((x for x in hijos if x.get("id") == d["carpeta_proyecto_id"]), None)
    if not h:
        raise Bloqueo(f"la carpeta {d['carpeta_proyecto_id']} NO es hija de Claude outputs de la raíz ({CE.DRIVE_RAIZ})")
    if d.get("carpeta_proyecto") and h.get("name") != d["carpeta_proyecto"]:
        raise Bloqueo(f"la carpeta {h['id']} se llama '{h.get('name')}', no '{d['carpeta_proyecto']}'")
    return h


RUTA_ORDENES = ".claude/skills/jc-hunter-ordenes/ORDENES_DEL_USUARIO.md"


def ordenes_sin_registro(ordenes_txt, registro):
    """BE-CF27: ids U-NNN de las órdenes del usuario que el registro del skill no tiene."""
    import re
    ids = list(dict.fromkeys(re.findall(r"\[(U-\d+)\s*·", ordenes_txt or "")))
    reg = {str(x.get("id")) for x in (registro or {}).get("reglas") or []}
    return [i for i in ids if i not in reg]


def ordenes_remotas(repo):
    """-> (texto de ORDENES_DEL_USUARIO.md en origin/<rama actual> tras git fetch, origen). Sin red: la copia local."""
    def git(*a):
        return subprocess.run(["git", "-C", repo, *a], capture_output=True, text=True, timeout=120)
    rama = git("rev-parse", "--abbrev-ref", "HEAD").stdout.strip()
    if rama and git("fetch", "-q", "origin", rama).returncode == 0:
        p = git("show", f"origin/{rama}:{RUTA_ORDENES}")
        if p.returncode == 0:
            return p.stdout, f"origin/{rama}"
    loc = os.path.join(repo, RUTA_ORDENES)
    return (open(loc, encoding="utf-8").read() if os.path.isfile(loc) else ""), "local (sin fetch)"


def candado_ordenes():
    if os.environ.get("SIN_ORDENES_REMOTAS") == "1" or os.environ.get("GDRIVE_FETCH"):
        return                                          # tests (Drive falso): sin repo remoto
    repo = os.environ.get("TAKEOFF_REPO") or "/home/user/reading-plans"
    if not os.path.isdir(os.path.join(repo, ".git")):
        return
    txt, origen = ordenes_remotas(repo)
    rp = os.path.join(os.path.dirname(AQUI), "REGLAS_REGISTRO.json")
    falt = ordenes_sin_registro(txt, json.load(open(rp, encoding="utf-8")) if os.path.isfile(rp) else {})
    if falt:
        raise Bloqueo(f"órdenes del usuario en {origen} que el skill de la compuerta no tiene: {falt[:8]} "
                      "(BE-CF27: unir el skill con esas órdenes y volver a pasar compuerta_entrega.py antes de subir)")


# BE-CR28 (CR City Hotel rev2, COORDINACIÓN 6-nov): una subida de miles de archivos se cortó por tiempo y el Excel llegó al final.
# (1) orden de subida: Take-off/, Proposal/, Planos marcados/, archivos de la raíz, Auditoria/ al final (el usuario tiene el Excel primero);
# (2) entrega > UMBRAL_ARCHIVOS: Auditoria/ se sube como UN Auditoria.zip armado en una carpeta temporal desde los MISMOS archivos que
#     verificó la compuerta (sha256), sin perder nada; README_REVIEW.md lo dice (CE_SUBIDA_PAQUETE).
UMBRAL_ARCHIVOS = CE.UMBRAL_AUDITORIA_ZIP   # una sola cifra con la compuerta (U-165)
_ORDEN = {"Take-off": 0, "Proposal": 1, "Planos marcados": 2}


def orden_subida(rel, raiz_ed):
    partes = os.path.relpath(rel, raiz_ed).split(os.sep)
    if len(partes) == 1:
        return (3, rel)
    return (_ORDEN.get(partes[0], 4 if partes[0] == "Auditoria" else 3), rel)


def empaquetar_auditoria(w, raiz_ed, archivos, umbral=UMBRAL_ARCHIVOS):
    """-> (lista de (rel_destino, ruta_local)); con > umbral archivos, los de Auditoria/ van dentro de Auditoria.zip."""
    import tempfile
    import zipfile
    pares = [(rel, os.path.join(w, rel)) for rel in sorted(archivos, key=lambda r: orden_subida(r, raiz_ed))]
    if len(archivos) <= umbral:
        return pares
    aud = os.path.join(raiz_ed, "Auditoria") + os.sep
    dentro = [(rel, loc) for rel, loc in pares if rel.startswith(aud)]
    if not dentro:
        return pares
    zp = os.path.join(tempfile.mkdtemp(prefix="subida_"), "Auditoria.zip")
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for rel, loc in dentro:
            z.write(loc, os.path.relpath(rel, raiz_ed))
    with zipfile.ZipFile(zp) as z:
        assert len(z.namelist()) == len(dentro), "Auditoria.zip incompleto"
    return [(rel, loc) for rel, loc in pares if not rel.startswith(aud)] + [(os.path.join(raiz_ed, "Auditoria.zip"), zp)]


# BE-CR28 / BE-GK31 (post-mortem P2): una subida de miles de archivos en serie (~13 archivos/min, un subproceso por archivo)
# se cortó por el límite de 2 h de las tareas de fondo. Ahora: (1) los 'put' van en paralelo (pool de --workers, 6 por
# defecto; los mkdir siguen en serie y en caché ANTES de los put); (2) la subida va por TRAMOS de --max-min minutos (90 por
# defecto) con el avance en disco (<workdir>/SUBIDA_PROGRESO.json, escritura atómica tras cada archivo); al llegar al tope
# del tramo no se programan más archivos, se esperan los que están en vuelo y sigue el tramo siguiente SOLO, sin preguntar
# (cada tramo vuelve a listar Drive y salta lo que ya está: mismo nombre + mismo tamaño); (3) tope duro --max-tramos (10)
# = Bloqueo. SUBIDA_OK.json se escribe solo con TODO subido. Auditoria/ sigue siendo CARPETA (U-008): la estructura no cambia.
WORKERS = 6
MAX_MIN = 90.0
MAX_TRAMOS = 10


def _ahora_iso():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def _json_atomico(ruta, dato):
    tmp = ruta + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(dato, f, ensure_ascii=False, indent=1)
    os.replace(tmp, ruta)


def _listar(cid):
    out = {}
    for ln in _g("list", cid).splitlines():
        try:
            it = json.loads(ln)
        except ValueError:
            continue
        if isinstance(it, dict):
            out[it.get("name")] = it
    return out


def _carpeta(ids, raiz_ed, rel):
    """mkdir en serie y en caché de la subcarpeta de rel (mkdir reutiliza la existente) -> clave local de la carpeta."""
    sub = os.path.dirname(rel)
    cur = raiz_ed
    for pt in (os.path.relpath(sub, raiz_ed).split(os.sep) if sub != raiz_ed else []):
        if pt in ("", "."):
            continue
        nxt = os.path.join(cur, pt)
        if nxt not in ids:
            ids[nxt] = _g("mkdir", ids[cur], pt).strip().splitlines()[-1]
        cur = nxt
    return cur


def _tramo(plan, ids, hechos, subidos_run, workers, max_min, escribir):
    """Un tramo: re-lista Drive, salta lo ya subido, sube en paralelo hasta el tope de tiempo. -> pendientes que quedan."""
    from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
    import time
    listados, pend = {}, []
    for rel, loc, cur in plan:
        if rel in hechos:
            continue
        if rel in subidos_run:            # subido por un tramo anterior de esta corrida (aunque Drive aún no lo liste): no se duplica
            hechos[rel] = subidos_run[rel]
            continue
        if cur not in listados:
            listados[cur] = _listar(ids[cur])
        ya = listados[cur].get(os.path.basename(rel))
        # R80f.42: mismo nombre Y mismo tamaño = ya subido; mismo nombre con otro tamaño = Bloqueo (nunca se sobrescribe)
        if ya is not None:
            if str(ya.get("size")) != str(os.path.getsize(loc)):
                raise Bloqueo(f"{rel}: ya existe en Drive con otro tamaño ({ya.get('size')} vs {os.path.getsize(loc)}): "
                              "no se sobrescribe; revisar a mano la carpeta")
            hechos[rel] = {"archivo": rel, "carpeta_id": ids[cur], "salida": f"YA SUBIDO (mismo nombre y tamaño) id {ya.get('id')}"}
            continue
        pend.append((rel, loc, cur))
    escribir(len(pend))
    if not pend:
        return 0
    tope = time.monotonic() + max_min * 60
    cola, vuelo, error = list(pend), {}, None
    with ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
        primera = True
        while cola or vuelo:
            # se llena el pool; tras la primera tanda, solo mientras quede tiempo en el tramo (siempre avanza al menos una tanda)
            while cola and len(vuelo) < max(1, workers) and error is None and (primera or time.monotonic() < tope):
                rel, loc, cur = cola.pop(0)
                vuelo[ex.submit(_g, "put", loc, ids[cur])] = (rel, cur)
            primera = False
            if not vuelo:
                break
            listos, _ = wait(list(vuelo), return_when=FIRST_COMPLETED)
            for fu in listos:
                rel, cur = vuelo.pop(fu)
                try:
                    out = fu.result()
                except Exception as e:      # noqa: BLE001 — se esperan los demás en vuelo y se avisa
                    error = error or e
                    continue
                subidos_run[rel] = hechos[rel] = {"archivo": rel, "carpeta_id": ids[cur], "salida": out.strip()[-200:]}
                escribir(len(cola) + len(vuelo))
    escribir(len(cola))
    if error is not None:
        raise error if isinstance(error, Bloqueo) else Bloqueo(f"put falló: {error}")
    return len(cola)


def subir(workdir, solo_revisar=False, auditoria_carpeta=False, workers=WORKERS, max_min=MAX_MIN, max_tramos=MAX_TRAMOS):
    w = os.path.abspath(workdir)
    ok, archivos = candados(w)
    candado_ordenes()
    d = ok["drive"]
    verificar_padre_en_vivo(d)
    if solo_revisar:
        return {"revisado": True, "archivos": len(archivos)}
    raiz_ed = ok["entrega_dir"]
    ids = {raiz_ed: _g("mkdir", d["carpeta_proyecto_id"], os.path.basename(raiz_ed)).strip().splitlines()[-1]}
    # BE-GK31 (Grand Kia, COORDINACIÓN U-008): --auditoria-carpeta sube Auditoria/ DESEMPACADA (como los demás proyectos) en la
    # misma carpeta de entrega (mkdir la reutiliza, lo ya subido con mismo nombre y tamaño se salta) y renombra el
    # Auditoria.zip de la subida anterior a "BORRAR (NO USAR) - Auditoria.zip - REPLACED BY Auditoria/" (U-186; rename, nunca borrar)
    pares = empaquetar_auditoria(w, raiz_ed, archivos, umbral=10 ** 9 if auditoria_carpeta else UMBRAL_ARCHIVOS)
    plan = [(rel, loc, _carpeta(ids, raiz_ed, rel)) for rel, loc in pares]     # todas las carpetas ANTES de los put
    prog_p = os.path.join(w, "SUBIDA_PROGRESO.json")
    hechos, subidos_run = {}, {}
    estado = {"inicio_iso": _ahora_iso(), "tramo": 0}

    def escribir(pendientes):
        _json_atomico(prog_p, {"inicio_iso": estado["inicio_iso"], "tramo": estado["tramo"],
                               "subidos": [rel for rel, _, _ in plan if rel in hechos], "pendientes": pendientes,
                               "total": len(plan), "actualizado_iso": _ahora_iso()})

    while True:
        estado["tramo"] += 1
        if estado["tramo"] > max_tramos:
            falta = len(plan) - len(hechos)
            raise Bloqueo(f"subida sin terminar tras {max_tramos} tramos de {max_min} min ({falta} de {len(plan)} archivos "
                          f"pendientes; avance en {prog_p}): volver a correr subir_entrega.py (retoma) o subir --max-tramos")
        if _tramo(plan, ids, hechos, subidos_run, workers, max_min, escribir) == 0 and len(hechos) == len(plan):
            break
    log = [hechos[rel] for rel, _, _ in plan]
    if auditoria_carpeta:
        for nom, it in _listar(ids[raiz_ed]).items():
            if nom == "Auditoria.zip":
                log.append({"archivo": "Auditoria.zip", "carpeta_id": ids[raiz_ed],
                            "salida": _g("rename", it["id"], nombre_borrar("Auditoria.zip", "Auditoria (folder)")).strip()[-200:]})
    ev = verificar_vigente(ok, log, w=w) if ok.get("vigentes") else []   # U-177 (1): la compuerta vigente siempre escribe 'vigentes'; --vigente lo exige
    if ev:
        raise Bloqueo("U-177 entrega vigente: " + "; ".join(ev))
    ahora_iso = _ahora_iso()
    previa = CE._json(os.path.join(w, "SUBIDA_OK.json")) or {}          # U-184 (1): la PRIMERA subida se conserva entre rondas
    res = {"fecha_iso": ahora_iso, "primera_subida_iso": previa.get("primera_subida_iso") or previa.get("fecha_iso") or ahora_iso,
           "entrega_ok_sha": CE._sha(os.path.join(w, "ENTREGA_OK.json")),
           "corrida": ok.get("corrida"), "entrega_ok": f"ENTREGA_OK_{ok.get('corrida')}.json" if ok.get("corrida") else None,   # BE-GK59
           "drive": d, "carpetas": ids, "subidos": log, "vigente_verificado": sorted((ok.get("vigentes") or {}).keys()),
           "excepcion_usuario": ok.get("excepcion_usuario") if (not ok.get("ok") or _no_verdes(ok)) else None,   # U-201 (6): H4
           "tramos": estado["tramo"]}
    json.dump(res, open(os.path.join(w, "SUBIDA_OK.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return res


def _opcion(argv, nombre, tipo, defecto):
    if nombre in argv:
        i = argv.index(nombre)
        try:
            return tipo(argv[i + 1])
        except (IndexError, ValueError):
            raise SystemExit(f"{nombre} necesita un valor ({tipo.__name__})")
    return defecto


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    if "--vigente" in argv:                           # U-177 (1): antes de reportar o de un bid: Drive = lo validado, skill vigente
        w = os.path.abspath(argv[1])
        ok = json.load(open(os.path.join(w, "ENTREGA_OK.json"), encoding="utf-8"))
        sub = json.load(open(os.path.join(w, "SUBIDA_OK.json"), encoding="utf-8")) if os.path.isfile(os.path.join(w, "SUBIDA_OK.json")) else {}
        log = sub.get("subidos") or []
        ev = verificar_vigente(ok, log, subida=sub, w=w)
        print("ENTREGA VIGENTE: " + ("FAIL - " + "; ".join(ev) if ev else "PASS (Drive = lo que validó la compuerta, con todos los chequeos del skill vigente)"))
        return 1 if ev else 0
    try:
        r = subir(argv[1], "--revisar" in argv, "--auditoria-carpeta" in argv, workers=_opcion(argv, "--workers", int, WORKERS),
                  max_min=_opcion(argv, "--max-min", float, MAX_MIN), max_tramos=_opcion(argv, "--max-tramos", int, MAX_TRAMOS))
    except Bloqueo as e:
        print(f"SUBIDA BLOQUEADA: {e}")
        return 1
    print("CANDADOS OK" + ("" if r.get("revisado") else f" — {len(r['subidos'])} archivos subidos; SUBIDA_OK.json"))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
