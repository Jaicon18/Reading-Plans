# Calificación del take-off: 47.6%

- Materiales por familia (cantidad NET): **45.20%**
- Partition types (LF y número de walls): **50.00%**
- Tolerancia: IGUAL ≤ 2%, CERCA ≤ 10%


## Materiales por familia (calificación principal)

| Familia | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|
| 6" parapet stud | 997.19 | 750.82 | 24.7% | MAL (rango) |
| 6" stud (todos los gauges) | 4,525.47 | 4,495.73 | 0.0% | IGUAL (rango) |
| 3-5/8" stud (todos los gauges) | 6,227.89 | 6,524.39 | 0.0% | IGUAL (rango) |
| 1-5/8" stud | 3,860.10 | 4,074.64 | 4.2% | CERCA (rango) |
| purlin (track to deck) | 214.40 | 228.19 | 0.0% | IGUAL (rango) |
| track de ceilings / soffits | 1,168.97 | 1,316.06 | 0.0% | IGUAL (rango) |
| bottom track (todos) | 1,269.56 | 1,334.65 | 0.0% | IGUAL (rango) |
| top / deflection track (todos) | 1,269.56 | 1,334.65 | 0.0% | IGUAL (rango) |
| header / box beam | 305.63 | 244.72 | 69.1% | MAL (rango) |
| sill track | 67.76 | 66.76 | 43.9% | MAL (rango) |
| bracing C.R. channel | 2,624.23 | 2,560.07 | 0.0% | IGUAL (rango) |
| framed openings MEP | 970.32 | 818.75 | — | NO CALIFICA (excluir) |
| furring channel | 808.88 | 890.73 | 10.1% | MAL (rango) |
| carrying channel | 316.77 | 325.87 | 0.0% | IGUAL (rango) |
| hanger wire | 524.78 | — | — | FALTA |
| 5/8" gyp MOISTURE RESISTANT | 261.80 | 258.91 | 0.0% | IGUAL (rango) |
| 5/8" EXTERIOR gyp sheathing | 944.60 | 926.99 | 0.0% | IGUAL (rango) |
| 5/8" glass mat sheathing | 462.00 | 455.31 | 0.0% | IGUAL (rango) |
| 3/8" gyp board | 57.04 | 66.62 | 5.8% | CERCA (rango) |
| ballistic panel | 74.00 | 86.38 | 3.4% | CERCA (rango) |
| 5/8" gyp board regular (walls + ceilings) | 17,450.60 | 17,562.17 | 0.0% | IGUAL (rango) |
| cement board | 33.80 | 32.51 | 0.0% | IGUAL (rango) |
| FRP | 354.00 | 325.07 | 0.0% | IGUAL (rango) |
| FRT plywood (SF) | 6,507.01 | 6,465.79 | 0.0% | IGUAL (rango) |
| metal trim (corner bead, casing, shadow molding) | 1,267.55 | — | — | FALTA |
| acoustical sealant | 1,166.70 | 813.61 | 7.6% | CERCA (rango) |
| metal stud blocking (362CR / STUD BLOCKING) | 466.00 | 735.45 | 0.0% | IGUAL (rango) |
| FRT blocking | 1,083.90 | 699.80 | 0.0% | IGUAL (rango) |
| additional head track | 56.00 | — | — | FALTA |
| stud reinforcement MEP | 18.00 | — | — | FALTA |
| 2-1/2" CFMF coiling grille head | 7.85 | 16.50 | 57.9% | MAL (rango) |
| extra framing ATM | 109.87 | — | — | FALTA |
| gypsum board jamb return | 95.94 | — | — | FALTA |
| Level 5 finish | 874.83 | — | — | FALTA |
| PVC trim at FRP | 211.20 | — | — | FALTA |
| PAFs and duct sleeves | 275.00 | — | — | FALTA |
| access panel | 1.00 | — | — | FALTA |
| drywall screws | 21,323.33 | — | — | FALTA |
| framing screws | 5,252.00 | — | — | FALTA |
| slab pins | 515.71 | — | — | FALTA |
| expansion anchors | 326.46 | — | — | FALTA |
| joint compound | 1,279.40 | — | — | FALTA |
| joint tape | 6,574.69 | — | — | FALTA |

Renglón por renglón (depende de cómo cada take-off nombra y separa los renglones): 12.30%

## Materiales que no salieron iguales (52 de 57)

| Material | Unit | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|---|
| 6" parapet infill stud 600S162-54 @ 16" O.C. (LF of material | lf | 997.19 | 750.82 | 24.7% | MAL |
| 3-5/8" metal stud 362S137-33 / -68 (LF of material) | lf | 6,123.12 | 6,524.39 | 6.6% | CERCA |
| 1-5/8" metal stud (LF of material) | lf | 3,860.10 | 4,074.64 | 5.6% | CERCA |
| Bottom track 6" | lf | 293.04 | — | — | FALTA |
| Bottom track 3-5/8" | lf | 244.34 | — | — | FALTA |
| Parapet bottom track 600T125-54 (PAF to steel beam) | lf | 269.37 | 1,334.65 | 395.5% | MAL |
| Parapet top track 600T125-54 | lf | 269.37 | 1,334.65 | 395.5% | MAL |
| Bottom track - roof step 4/A02.02, vestibule heads 4-7/A12.1 | lf | 176.84 | — | — | FALTA |
| Top track - roof step 4/A02.02, vestibule heads 4-7/A12.10,  | lf | 176.84 | — | — | FALTA |
| Bottom track 1-5/8" | lf | 285.97 | — | — | FALTA |
| Top / deflection track 6" | lf | 293.04 | — | — | FALTA |
| Top / deflection track 3-5/8" | lf | 244.34 | — | — | FALTA |
| Top / deflection track 1-5/8" | lf | 285.97 | — | — | FALTA |
| Track, ceilings / soffits / canopy | lf | 1,168.97 | 1,316.06 | 12.6% | MAL |
| Bracing 1-1/2" C.R. channel @ 48" O.C. | lf | 2,624.23 | 2,560.07 | 2.4% | CERCA |
| Additional head track at openings over 4'-0" wide | lf | 56.00 | — | — | FALTA |
| Header / metal stud box beam | lf | 305.63 | 735.45 | 140.6% | MAL |
| Framed openings - MEP, light slots and diffusers | lf | 970.32 | 818.75 | 15.6% | MAL |
| Stud reinforcement at MEP penetrations | pcs | 18.00 | — | — | FALTA |
| 3-5/8" stud, CSR soffit 10/A09.33 (LF) | lf | 104.77 | — | — | FALTA |
| 2-1/2" CFMF @ 16" O.C. at coiling grille head (4/A08.21) | lf | 7.85 | — | — | FALTA |
| Purlin 1x1x1 16 ga, top track to deck | lf | 214.40 | 228.19 | 6.4% | CERCA |
| Furring channel (ceilings) | lf | 808.88 | — | — | FALTA |
| Carrying channel (ceilings) | lf | 316.77 | — | — | FALTA |
| Hanger wire | lf | 524.78 | — | — | FALTA |
| Extra framing - sistered stud and furring at the ATM recess | lf | 109.87 | — | — | FALTA |
| FRP WC-3 | sf | 354.00 | — | — | FALTA |
| Cement board (substrate under the FRP cove base band) | sf | 33.80 | — | — | FALTA |
| Exterior sheathing 5/8" FRT plywood bonded to 2-1/2" polyiso | sf | 3,754.28 | — | — | FALTA |
| 5/8" glass mat sheathing (exterior face of the stud) | sf | 462.00 | — | — | FALTA |
| Gypsum board jamb return at openings | sf | 95.94 | — | — | FALTA |
| Ballistic panel 3/8" UL752 | sf | 74.00 | 86.38 | 16.7% | MAL |
| 3/8" gypsum board | sf | 57.04 | 66.62 | 16.8% | MAL |
| FRT plywood substrate | sf | 632.49 | — | — | FALTA |
| Level 5 finish | sf | 874.83 | — | — | FALTA |
| 5/8" FRT plywood sheathing (canopy and soffits) | sf | 1,872.88 | 6,465.79 | 245.2% | MAL |
| METAL trim - corner bead, casing bead, shadow molding, gypsu | lf | 1,267.55 | — | — | FALTA |
| PVC trim - edge trim molding and inside corner molding at th | lf | 211.20 | — | — | FALTA |
| Power-driven fasteners and duct sleeves | pcs | 275.00 | — | — | FALTA |
| Blocking FRT / 2X FRT wood | lf | 1,083.90 | 699.80 | 35.4% | MAL |
| Acoustical sealant | lf | 957.52 | 813.61 | 15.0% | MAL |
| Access panel 2'x2' | pcs | 1.00 | — | — | FALTA |
| 5/8" FRT plywood at canopy column wraps | sf | 220.50 | — | — | FALTA |
| 3/4" FRT plywood at storefront piers | sf | 26.86 | — | — | FALTA |
| Sealant at base of gypsum (exterior, not acoustical) | lf | 209.18 | — | — | FALTA |
| Stud blocking 362CR22 at edge of gypboard (4/S5.20) | lf | 466.00 | — | — | FALTA |
| Drywall screws 1-1/4" bugle head | pcs | 21,323.33 | — | — | FALTA |
| Framing screws, pan head self-drilling | pcs | 5,252.00 | — | — | FALTA |
| Power-driven fasteners, slab pins for the bottom track | pcs | 515.71 | — | — | FALTA |
| Expansion anchors Hilti 1/4" Kwik Bolt II, exterior bottom t | pcs | 326.46 | — | — | FALTA |
| Joint compound, all purpose | lb | 1,279.40 | — | — | FALTA |
| Joint tape, paper | lf | 6,574.69 | — | — | FALTA |

## Materiales que solo están en el candidato (SOBRA)

- 2-1/2" metal stud (coiling grille head) (lf): 16.50
- Header / box beam (7/S5.20 header schedule) (lf): 244.72
- 7/8" furring channel @ 16" O.C. (lf): 890.73
- 1-1/2" carrying channel @ 48" O.C. (lf): 325.87
- 12 GA hanger wire @ 48" O.C. (pcs): 121.00
- 5/8" glass mat sheathing (base 0'-6" + canopy band) (sf): 455.31
- Batt insulation in partitions (sound) (sf): 4,932.50
- FRP panel restrooms 113/114 (5'-0" above cove base) (sf): 325.07
- Cement board behind tile cove base (6") (sf): 32.51

## Partition types que no salieron iguales (9 de 14)

| Type | Walls ref | Walls cand | LF ref | LF cand | Dif | Estado |
|---|---|---|---|---|---|---|
| A1 | 9 | 12 | 78.37 | 85.86 | 0.0% | CERCA |
| A1K | 3 | 5 | 7.99 | 9.54 | 10.9% | MAL (rango) |
| A5 | 4 | 5 | 39.12 | 34.25 | 12.5% | MAL (rango) |
| BULKHEAD-G | 2 | — | 45.00 | — | — | EN OTRA HOJA (Material Summary) |
| C1 | 8 | 4 | 48.77 | 33.03 | 30.7% | MAL (rango) |
| CANOPY-COL | 4 | — | 22.67 | — | — | EN OTRA HOJA (Material Summary) |
| EXT-6CFMF | 6 | — | 217.64 | — | — | FALTA |
| EXT-PARAPET | 6 | — | 217.64 | — | — | FALTA |
| G | 10 | 11 | 80.88 | 81.86 | 1.2% | CERCA |

## Types que solo están en el candidato (SOBRA)

- BULKHEAD: 6 walls, 45.00 LF
- CEILING_TRANSITION: 4 walls, 82.13 LF
- COLUMN_WRAP: 8 walls, 47.63 LF
- DOOR_BULKHEAD: 2 walls, 22.46 LF
- EXT: 10 walls, 237.69 LF
- FASCIA_BOX: 6 walls, 244.71 LF
- GRILLE_HEAD: 1 walls, 13.33 LF
- PARAPET: 9 walls, 266.27 LF
- ROOF_STEP: 3 walls, 155.20 LF
- SOFFIT_SIDE: 2 walls, 24.03 LF
- STOREFRONT_CRIPPLES: 2 walls, 23.59 LF

Antes de dar un MAL por error de Claude, abre el renglón: a veces la referencia o el emparejamiento de nombres es el que está mal (regla del artículo: leer cada resultado).
