# Calificación del take-off: 31.5%

- Materiales por familia (cantidad NET): **29.80%**
- Partition types (LF y número de walls): **33.30%**
- Tolerancia: IGUAL ≤ 2%, CERCA ≤ 10%


## Materiales por familia (calificación principal)

| Familia | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|
| 6" parapet stud | 997.19 | 214.60 | 78.5% | MAL (rango) |
| 6" stud (todos los gauges) | 4,525.47 | 6,459.52 | 41.0% | MAL (rango) |
| 3-5/8" stud (todos los gauges) | 6,227.89 | 5,669.45 | 13.5% | MAL (rango) |
| 1-5/8" stud | 3,860.10 | 4,582.72 | 17.2% | MAL (rango) |
| purlin (track to deck) | 214.40 | — | — | FALTA |
| track de ceilings / soffits | 1,168.97 | 964.92 | 27.1% | MAL (rango) |
| bottom track (todos) | 1,269.56 | 992.24 | 26.4% | MAL (rango) |
| top / deflection track (todos) | 1,269.56 | 992.24 | 26.4% | MAL (rango) |
| header / box beam | 305.63 | 278.46 | 64.8% | MAL (rango) |
| sill track | 67.76 | 66.92 | 43.8% | MAL (rango) |
| bracing C.R. channel | 2,624.23 | 2,464.67 | 0.0% | IGUAL (rango) |
| framed openings MEP | 970.32 | 798.00 | — | NO CALIFICA (excluir) |
| furring channel | 808.88 | 731.93 | 5.7% | CERCA (rango) |
| carrying channel | 316.77 | 243.98 | 0.0% | IGUAL (rango) |
| hanger wire | 524.78 | 360.43 | 0.0% | IGUAL (rango) |
| 5/8" gyp MOISTURE RESISTANT | 261.80 | 182.39 | 0.0% | IGUAL (rango) |
| 5/8" EXTERIOR gyp sheathing | 944.60 | 1,322.00 | 35.1% | MAL (rango) |
| 5/8" glass mat sheathing | 462.00 | 461.99 | 0.0% | IGUAL (rango) |
| 3/8" gyp board | 57.04 | 69.22 | 10.0% | CERCA (rango) |
| ballistic panel | 74.00 | 89.12 | 6.7% | CERCA (rango) |
| 5/8" gyp board regular (walls + ceilings) | 17,450.60 | 17,665.72 | 0.0% | IGUAL (rango) |
| cement board | 33.80 | — | — | FALTA |
| FRP | 354.00 | 364.60 | 7.2% | CERCA (rango) |
| FRT plywood (SF) | 6,507.01 | 7,260.74 | 5.9% | CERCA (rango) |
| metal trim (corner bead, casing, shadow molding) | 1,267.55 | 968.51 | 0.0% | IGUAL (rango) |
| acoustical sealant | 1,166.70 | 928.51 | 0.0% | IGUAL (rango) |
| metal stud blocking (362CR / STUD BLOCKING) | 466.00 | 466.00 | 14.5% | MAL (rango) |
| FRT blocking | 1,083.90 | 720.94 | 0.0% | IGUAL (rango) |
| additional head track | 56.00 | — | — | FALTA |
| stud reinforcement MEP | 18.00 | — | — | FALTA |
| 2-1/2" CFMF coiling grille head | 7.85 | 47.00 | 349.8% | MAL (rango) |
| extra framing ATM | 109.87 | — | — | FALTA |
| gypsum board jamb return | 95.94 | — | — | FALTA |
| Level 5 finish | 874.83 | 745.00 | 0.0% | IGUAL (rango) |
| PVC trim at FRP | 211.20 | — | — | FALTA |
| PAFs and duct sleeves | 275.00 | — | — | FALTA |
| access panel | 1.00 | — | — | FALTA |
| drywall screws | 21,323.33 | — | — | FALTA |
| framing screws | 5,252.00 | — | — | FALTA |
| slab pins | 515.71 | — | — | FALTA |
| expansion anchors | 326.46 | — | — | FALTA |
| joint compound | 1,279.40 | — | — | FALTA |
| joint tape | 6,574.69 | — | — | FALTA |

Renglón por renglón (depende de cómo cada take-off nombra y separa los renglones): 4.40%

## Materiales que no salieron iguales (56 de 57)

| Material | Unit | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|---|
| 6" metal stud 600S137-33 / -68 (LF of material) | lf | 4,525.47 | 1,401.88 | 69.0% | MAL |
| 6" parapet infill stud 600S162-54 @ 16" O.C. (LF of material | lf | 997.19 | 214.60 | 78.5% | MAL |
| 3-5/8" metal stud 362S137-33 / -68 (LF of material) | lf | 6,123.12 | 3,881.62 | 36.6% | MAL |
| 1-5/8" metal stud (LF of material) | lf | 3,860.10 | 4,582.72 | 18.7% | MAL |
| Bottom track 6" | lf | 293.04 | 78.14 | 73.3% | MAL |
| Bottom track 3-5/8" | lf | 244.34 | 296.50 | 21.3% | MAL |
| Parapet bottom track 600T125-54 (PAF to steel beam) | lf | 269.37 | — | — | FALTA |
| Parapet top track 600T125-54 | lf | 269.37 | — | — | FALTA |
| Bottom track - roof step 4/A02.02, vestibule heads 4-7/A12.1 | lf | 176.84 | — | — | FALTA |
| Top track - roof step 4/A02.02, vestibule heads 4-7/A12.10,  | lf | 176.84 | — | — | FALTA |
| Bottom track 1-5/8" | lf | 285.97 | 296.44 | 3.7% | CERCA |
| Top / deflection track 6" | lf | 293.04 | 78.14 | 73.3% | MAL |
| Top / deflection track 3-5/8" | lf | 244.34 | 138.18 | 43.4% | MAL |
| Top / deflection track 1-5/8" | lf | 285.97 | 90.00 | 68.5% | MAL |
| Track, ceilings / soffits / canopy | lf | 1,168.97 | 186.50 | 84.0% | MAL |
| Bracing 1-1/2" C.R. channel @ 48" O.C. | lf | 2,624.23 | 2,464.67 | 6.1% | CERCA |
| Additional head track at openings over 4'-0" wide | lf | 56.00 | — | — | FALTA |
| Header / metal stud box beam | lf | 305.63 | — | — | FALTA |
| Sill track | lf | 67.76 | 5.08 | 92.5% | MAL |
| Framed openings - MEP, light slots and diffusers | lf | 970.32 | 112.00 | 88.5% | MAL |
| Stud reinforcement at MEP penetrations | pcs | 18.00 | — | — | FALTA |
| 3-5/8" stud, CSR soffit 10/A09.33 (LF) | lf | 104.77 | — | — | FALTA |
| 2-1/2" CFMF @ 16" O.C. at coiling grille head (4/A08.21) | lf | 7.85 | — | — | FALTA |
| Purlin 1x1x1 16 ga, top track to deck | lf | 214.40 | — | — | FALTA |
| Furring channel (ceilings) | lf | 808.88 | — | — | FALTA |
| Carrying channel (ceilings) | lf | 316.77 | — | — | FALTA |
| Hanger wire | lf | 524.78 | 360.43 | 31.3% | MAL |
| Extra framing - sistered stud and furring at the ATM recess | lf | 109.87 | — | — | FALTA |
| 5/8" gypsum board, regular | sf | 17,450.60 | 16,618.77 | 4.8% | CERCA |
| 5/8" gypsum board, MOISTURE RESISTANT | sf | 261.80 | 182.39 | 30.3% | MAL |
| 5/8" EXTERIOR gypsum sheathing (deck to top of parapet) | sf | 944.60 | 1,322.00 | 40.0% | MAL |
| FRP WC-3 | sf | 354.00 | — | — | FALTA |
| Cement board (substrate under the FRP cove base band) | sf | 33.80 | — | — | FALTA |
| Exterior sheathing 5/8" FRT plywood bonded to 2-1/2" polyiso | sf | 3,754.28 | 4,299.32 | 14.5% | MAL |
| 5/8" glass mat sheathing (exterior face of the stud) | sf | 462.00 | 356.24 | 22.9% | MAL |
| Gypsum board jamb return at openings | sf | 95.94 | — | — | FALTA |
| Ballistic panel 3/8" UL752 | sf | 74.00 | 89.12 | 20.4% | MAL |
| 3/8" gypsum board | sf | 57.04 | 69.22 | 21.4% | MAL |
| FRT plywood substrate | sf | 632.49 | — | — | FALTA |
| Level 5 finish | sf | 874.83 | 745.00 | 14.8% | MAL |
| 5/8" FRT plywood sheathing (canopy and soffits) | sf | 1,872.88 | 2,135.06 | 14.0% | MAL |
| METAL trim - corner bead, casing bead, shadow molding, gypsu | lf | 1,267.55 | 112.00 | 91.2% | MAL |
| PVC trim - edge trim molding and inside corner molding at th | lf | 211.20 | — | — | FALTA |
| Power-driven fasteners and duct sleeves | pcs | 275.00 | — | — | FALTA |
| Blocking FRT / 2X FRT wood | lf | 1,083.90 | 158.20 | 85.4% | MAL |
| Acoustical sealant | lf | 957.52 | 668.46 | 30.2% | MAL |
| Access panel 2'x2' | pcs | 1.00 | — | — | FALTA |
| 5/8" FRT plywood at canopy column wraps | sf | 220.50 | — | — | FALTA |
| 3/4" FRT plywood at storefront piers | sf | 26.86 | 33.00 | 22.9% | MAL |
| Sealant at base of gypsum (exterior, not acoustical) | lf | 209.18 | 260.05 | 24.3% | MAL |
| Drywall screws 1-1/4" bugle head | pcs | 21,323.33 | — | — | FALTA |
| Framing screws, pan head self-drilling | pcs | 5,252.00 | — | — | FALTA |
| Power-driven fasteners, slab pins for the bottom track | pcs | 515.71 | — | — | FALTA |
| Expansion anchors Hilti 1/4" Kwik Bolt II, exterior bottom t | pcs | 326.46 | — | — | FALTA |
| Joint compound, all purpose | lb | 1,279.40 | — | — | FALTA |
| Joint tape, paper | lf | 6,574.69 | — | — | FALTA |

## Materiales que solo están en el candidato (SOBRA)

- 1-5/8" top track 162T125-33 (secure to structure) (lf): 206.44
- 2-1/2" bottom track 250T125-33 (coiling grille drop) (lf): 13.50
- 2-1/2" metal stud 250S137-33 (coiling grille head drop / ATM sister) (lf): 47.00
- 2-1/2" top track 250T125-33 (coiling grille drop) (lf): 13.50
- 3-5/8" metal stud 14 GA 362S137-68 @ 24" O.C. (A1K ballistic) (lf): 207.39
- 3-5/8" metal stud 362S137-33 canopy column wraps (lf): 168.00
- 3-5/8" metal stud 362S137-33 canopy fascia framing @ 16" O.C. (lf): 339.25
- 3-5/8" metal stud 362S137-33 canopy soffit framing @ 16" O.C. (lf): 1,073.19
- 3-5/8" top track 362T125-33 (secure to structure) (lf): 158.32
- 6" bottom track 600T125-33 exterior (lf): 260.05
- 6" metal stud 14 GA 600S137-68 @ 24" O.C. (B2K ballistic) (lf): 76.88
- 6" metal stud 600S162-54 exterior CFMF @ 16" O.C. (lf): 4,423.42
- 6" metal stud 600S162-54 exterior CFMF extra at corners (@12" within 6 (lf): 557.34
- 6" parapet infill bottom track 600T125-54 (lf): 47.61
- 6" parapet infill top track 600T125-54 (lf): 47.61
- 6" top deflection track 600T200-97 exterior (lf): 260.05
- canopy soffit / fascia bottom track 362T125-33 (lf): 240.76
- canopy soffit / fascia top track 362T125-33 (lf): 240.76
- carrying channel 1-1/2" @ 48" O.C. (GWB ceilings) (lf): 243.98
- casing bead J/L (office front jambs, window & storefront returns, A1K) (lf): 384.30
- ceiling track 362T125-33 (GWB ceilings perimeter) (lf): 296.90
- corner bead (lf): 400.11
- framed opening - Knox box recessed 7x7x3 (exterior) (pcs): 1.00
- framed opening for recessed fixture - canopy UU (2 x length per fixtur (lf): 686.00
- furring channel 7/8" @ 16" O.C. (GWB ceilings) (lf): 731.93
- header 362T125-43 18 GA single track (interior doors, R.O.+1'-4") (lf): 70.41
- header box beam 2-60CSJ14 exterior openings (R.O.+1'-4") (lf): 115.81
- header box beam over office front (CONT. BOX BEAM, R.O.+1'-4") (lf): 53.00
- header box beam over vestibule glazing 2-362CSJ20 (R.O.+1'-4") (lf): 39.24
- shadow molding (lf): 184.10
- sill track 600T125-33 (R.O.+8" each side) (lf): 61.84
- vertical deflection clip at exterior studs (pcs): 280.00
- 3/4" FRT plywood (piers / column wraps) (sf): 140.91
- 3/4" FRT plywood (type F public side, to deck) (sf): 268.45
- 3/4" FRT plywood at storefront / door heads & sills (sf): 85.00
- 3/4" FRT plywood backboard painted (key note 6, NER 121 / Electrical 1 (sf): 278.00
- 3/4" FRT plywood blocking (CSR soffit 10/A09.33) (lf): 24.38
- 3/4" FRT plywood blocking (box beam, office bulkheads) (lf): 45.00
- 3/4" FRT plywood blocking - 85" monitor (13/A12.02) (sf): 21.00
- 3/4" FRT plywood blocking at parapet top (4/A09.26) (lf): 307.66
- 5/8" glass mat sheathing (base strip slab to T/BASE 0'-6") (sf): 105.75
- 5/8" gyp board regular (ceilings) (sf): 1,046.95
- FRP panel (restrooms WC-3, 5'-0" over cove base + mop sink) (sf): 364.60
- FRT blocking - 2x at roof step top (4/A02.02) (lf): 51.70
- FRT blocking - coiling grille jambs (3/A08.21) (lf): 29.00
- FRT blocking - door wall stops (2'-0" each) (lf): 28.00
- FRT blocking - lockers CW-16 (key note 5) (lf): 5.00
- FRT blocking - roof hatch ladder (key notes 3,4) (lf): 8.00
- FRT blocking - toilet accessories (lf): 44.00
- FRT blocking - wall equipment (note C A02.01: monitor arms, phones, ho (lf): 20.00
- sound attenuation batt above ceiling (restrooms, A04.01 note 11) (sf): 153.20
- sound attenuation batt insulation (partition cavity) (sf): 5,134.48
- taping & finishing Level 4 (all gyp board surfaces, assumed) (sf): 17,172.33

## Partition types que no salieron iguales (13 de 14)

| Type | Walls ref | Walls cand | LF ref | LF cand | Dif | Estado |
|---|---|---|---|---|---|---|
| A1 | 9 | 7 | 78.37 | 79.17 | 0.0% | CERCA |
| A1K | 3 | 3 | 7.99 | 8.97 | 4.3% | CERCA (rango) |
| A5 | 4 | 5 | 39.12 | 37.23 | 4.8% | CERCA (rango) |
| B | 6 | 6 | 60.78 | 50.03 | 17.7% | MAL |
| B2 | 4 | 3 | 38.73 | 38.74 | 0.0% | CERCA |
| B2K | 1 | 1 | 1.26 | 2.17 | 72.2% | MAL |
| BULKHEAD-G | 2 | — | 45.00 | — | — | EN OTRA HOJA (Material Summary) |
| C1 | 8 | 4 | 48.77 | 34.60 | 27.5% | MAL (rango) |
| CANOPY-COL | 4 | — | 22.67 | — | — | EN OTRA HOJA (Material Summary) |
| EXT-6CFMF | 6 | — | 217.64 | — | — | FALTA |
| EXT-PARAPET | 6 | — | 217.64 | — | — | FALTA |
| G | 10 | 13 | 80.88 | 87.79 | 8.5% | CERCA |
| G1 | 3 | 2 | 17.11 | 15.43 | 9.8% | CERCA |

## Types que solo están en el candidato (SOBRA)

- BULKHEAD: 9 walls, 80.24 LF
- CEILING: 5 walls, 0.00 LF
- COLUMN: 1 walls, 19.32 LF
- EXT: 9 walls, 260.05 LF
- FASCIA: 1 walls, 240.76 LF
- PARAPET: 2 walls, 47.61 LF
- PIER/COLUMN: 1 walls, 13.42 LF
- ROOF: 1 walls, 51.70 LF
- SOFFIT: 6 walls, 0.00 LF

Antes de dar un MAL por error de Claude, abre el renglón: a veces la referencia o el emparejamiento de nombres es el que está mal (regla del artículo: leer cada resultado).
