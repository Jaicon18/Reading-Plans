# Calificación del take-off: 77.4%

- Materiales por familia (cantidad NET): **86.90%**
- Partition types (LF y número de walls): **67.90%**
- Tolerancia: IGUAL ≤ 2%, CERCA ≤ 10%


## Materiales por familia (calificación principal)

| Familia | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|
| 6" parapet stud | 997.19 | 1,001.59 | 0.0% | IGUAL (rango) |
| 6" stud (todos los gauges) | 4,525.47 | 4,575.61 | 0.0% | IGUAL (rango) |
| 3-5/8" stud (todos los gauges) | 6,227.89 | 6,750.80 | 0.0% | IGUAL (rango) |
| 1-5/8" stud | 3,860.10 | 3,926.00 | 0.0% | IGUAL (rango) |
| purlin (track to deck) | 214.40 | 180.29 | 0.0% | IGUAL (rango) |
| track de ceilings / soffits | 1,168.97 | 1,295.89 | 2.1% | CERCA (rango) |
| bottom track (todos) | 1,269.56 | 1,315.07 | 2.4% | CERCA (rango) |
| top / deflection track (todos) | 1,269.56 | 1,315.07 | 2.4% | CERCA (rango) |
| header / box beam | 305.63 | 868.55 | 9.7% | CERCA (rango) |
| sill track | 67.76 | 119.09 | 0.0% | IGUAL (rango) |
| bracing C.R. channel | 2,624.23 | 2,474.22 | 0.0% | IGUAL (rango) |
| framed openings MEP | 970.32 | 945.54 | 0.0% | IGUAL (rango) |
| furring channel | 808.88 | 770.57 | 0.0% | IGUAL (rango) |
| carrying channel | 316.77 | 323.73 | 0.0% | IGUAL (rango) |
| hanger wire | 524.78 | 530.10 | 0.0% | IGUAL (rango) |
| 5/8" gyp MOISTURE RESISTANT | 261.80 | 258.81 | 0.0% | IGUAL (rango) |
| 5/8" EXTERIOR gyp sheathing | 944.60 | 931.49 | 0.0% | IGUAL (rango) |
| 5/8" glass mat sheathing | 462.00 | 477.52 | 0.0% | IGUAL (rango) |
| 3/8" gyp board | 57.04 | 64.53 | 2.5% | CERCA (rango) |
| ballistic panel | 74.00 | 84.14 | 0.0% | IGUAL (rango) |
| 5/8" gyp board regular (walls + ceilings) | 17,450.60 | 17,198.98 | 0.0% | IGUAL (rango) |
| cement board | 33.80 | 33.38 | 0.0% | IGUAL (rango) |
| FRP | 354.00 | 349.75 | 2.9% | CERCA (rango) |
| FRT plywood (SF) | 6,507.01 | 6,931.50 | 0.0% | IGUAL (rango) |
| metal trim (corner bead, casing, shadow molding) | 1,267.55 | 809.78 | 0.0% | IGUAL (rango) |
| acoustical sealant | 1,166.70 | 1,408.30 | 2.9% | CERCA (rango) |
| metal stud blocking (362CR / STUD BLOCKING) | 466.00 | 626.52 | 0.0% | IGUAL (rango) |
| FRT blocking | 1,083.90 | 855.00 | 0.0% | IGUAL (rango) |
| additional head track | 56.00 | 56.00 | 0.0% | IGUAL (rango) |
| stud reinforcement MEP | 18.00 | 26.00 | 0.0% | IGUAL (rango) |
| 2-1/2" CFMF coiling grille head | 7.85 | 10.43 | 0.0% | IGUAL (rango) |
| extra framing ATM | 109.87 | 23.66 | 52.6% | MAL (rango) |
| gypsum board jamb return | 95.94 | 67.16 | 0.0% | IGUAL (rango) |
| Level 5 finish | 874.83 | 712.78 | 0.0% | IGUAL (rango) |
| PVC trim at FRP | 211.20 | 219.50 | 0.0% | IGUAL (rango) |
| PAFs and duct sleeves | 275.00 | 293.00 | 0.0% | IGUAL (rango) |
| access panel | 1.00 | 1.00 | 0.0% | IGUAL (rango) |
| drywall screws | 21,323.33 | 21,026.78 | 0.0% | IGUAL (rango) |
| framing screws | 5,252.00 | 7,044.00 | — | NO CALIFICA (consistencia) |
| slab pins | 515.71 | 481.36 | 0.0% | IGUAL (rango) |
| expansion anchors | 326.46 | 367.23 | 12.5% | MAL (rango) |
| joint compound | 1,279.40 | 1,261.61 | 0.0% | IGUAL (rango) |
| joint tape | 6,574.69 | 6,483.26 | 0.0% | IGUAL (rango) |

Renglón por renglón (depende de cómo cada take-off nombra y separa los renglones): 31.60%

## Materiales que no salieron iguales (43 de 57)

| Material | Unit | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|---|
| 3-5/8" metal stud 362S137-33 / -68 (LF of material) | lf | 6,123.12 | 6,750.80 | 10.3% | MAL |
| Bottom track 6" | lf | 293.04 | — | — | FALTA |
| Bottom track 3-5/8" | lf | 244.34 | — | — | FALTA |
| Parapet bottom track 600T125-54 (PAF to steel beam) | lf | 269.37 | 1,315.07 | 388.2% | MAL |
| Parapet top track 600T125-54 | lf | 269.37 | — | — | FALTA |
| Bottom track - roof step 4/A02.02, vestibule heads 4-7/A12.1 | lf | 176.84 | — | — | FALTA |
| Top track - roof step 4/A02.02, vestibule heads 4-7/A12.10,  | lf | 176.84 | — | — | FALTA |
| Bottom track 1-5/8" | lf | 285.97 | — | — | FALTA |
| Top / deflection track 6" | lf | 293.04 | — | — | FALTA |
| Top / deflection track 3-5/8" | lf | 244.34 | — | — | FALTA |
| Top / deflection track 1-5/8" | lf | 285.97 | — | — | FALTA |
| Track, ceilings / soffits / canopy | lf | 1,168.97 | 1,295.89 | 10.9% | MAL |
| Bracing 1-1/2" C.R. channel @ 48" O.C. | lf | 2,624.23 | 2,474.22 | 5.7% | CERCA |
| Header / metal stud box beam | lf | 305.63 | 868.55 | 184.2% | MAL |
| Sill track | lf | 67.76 | 119.09 | 75.8% | MAL |
| Framed openings - MEP, light slots and diffusers | lf | 970.32 | 945.54 | 2.6% | CERCA |
| Stud reinforcement at MEP penetrations | pcs | 18.00 | 26.00 | 44.4% | MAL |
| 3-5/8" stud, CSR soffit 10/A09.33 (LF) | lf | 104.77 | — | — | FALTA |
| 2-1/2" CFMF @ 16" O.C. at coiling grille head (4/A08.21) | lf | 7.85 | 10.43 | 32.9% | MAL |
| Purlin 1x1x1 16 ga, top track to deck | lf | 214.40 | 180.29 | 15.9% | MAL |
| Furring channel (ceilings) | lf | 808.88 | — | — | FALTA |
| Carrying channel (ceilings) | lf | 316.77 | — | — | FALTA |
| Extra framing - sistered stud and furring at the ATM recess | lf | 109.87 | 23.66 | 78.5% | MAL |
| Exterior sheathing 5/8" FRT plywood bonded to 2-1/2" polyiso | sf | 3,754.28 | 3,990.77 | 6.3% | CERCA |
| 5/8" glass mat sheathing (exterior face of the stud) | sf | 462.00 | 477.52 | 3.4% | CERCA |
| Gypsum board jamb return at openings | sf | 95.94 | 67.16 | 30.0% | MAL |
| Ballistic panel 3/8" UL752 | sf | 74.00 | 84.14 | 13.7% | MAL |
| 3/8" gypsum board | sf | 57.04 | — | — | FALTA |
| FRT plywood substrate | sf | 632.49 | — | — | FALTA |
| Level 5 finish | sf | 874.83 | 712.78 | 18.5% | MAL |
| 5/8" FRT plywood sheathing (canopy and soffits) | sf | 1,872.88 | 2,114.12 | 12.9% | MAL |
| METAL trim - corner bead, casing bead, shadow molding, gypsu | lf | 1,267.55 | 809.78 | 36.1% | MAL |
| PVC trim - edge trim molding and inside corner molding at th | lf | 211.20 | 219.50 | 3.9% | CERCA |
| Power-driven fasteners and duct sleeves | pcs | 275.00 | 293.00 | 6.5% | CERCA |
| Blocking FRT / 2X FRT wood | lf | 1,083.90 | 855.00 | 21.1% | MAL |
| Acoustical sealant | lf | 957.52 | 1,209.67 | 26.3% | MAL |
| 5/8" FRT plywood at canopy column wraps | sf | 220.50 | — | — | FALTA |
| 3/4" FRT plywood at storefront piers | sf | 26.86 | 826.61 | 2977.5% | MAL |
| Sealant at base of gypsum (exterior, not acoustical) | lf | 209.18 | 198.63 | 5.0% | CERCA |
| Stud blocking 362CR22 at edge of gypboard (4/S5.20) | lf | 466.00 | 626.52 | 34.4% | MAL |
| Framing screws, pan head self-drilling | pcs | 5,252.00 | 7,044.00 | 34.1% | MAL |
| Power-driven fasteners, slab pins for the bottom track | pcs | 515.71 | 481.36 | 6.7% | CERCA |
| Expansion anchors Hilti 1/4" Kwik Bolt II, exterior bottom t | pcs | 326.46 | 367.23 | 12.5% | MAL |

## Materiales que solo están en el candidato (SOBRA)

- Top / deflection track (all sizes) (lf): 1,315.07
- 7/8" furring channel (hat) (lf): 770.57
- 1-1/2" carrying channel (C.R.) (lf): 323.73
- 3/8" gyp board over ballistic panel (sf): 64.53
- Hanger wire 12 ga - hanger count (one per hanger, height per room) (pcs): 113.00

## Partition types que no salieron iguales (9 de 14)

| Type | Walls ref | Walls cand | LF ref | LF cand | Dif | Estado |
|---|---|---|---|---|---|---|
| A1 | 9 | 6 | 78.37 | 90.32 | 0.0% | CERCA |
| A1K | 3 | 2 | 7.99 | 8.60 | 0.0% | CERCA |
| A5 | 4 | 3 | 39.12 | 42.62 | 0.0% | CERCA |
| B | 6 | 5 | 60.78 | 60.27 | 0.8% | CERCA |
| B2K | 1 | 1 | 1.26 | 2.21 | 75.2% | MAL |
| C1 | 8 | 11 | 48.77 | 47.91 | 0.0% | CERCA |
| EXT-PARAPET | 8 | 8 | 269.37 | 269.17 | 0.0% | IGUAL (rango) |
| G | 10 | 8 | 80.88 | 81.59 | 0.9% | CERCA |
| G1 | 3 | 3 | 17.11 | 18.46 | 7.9% | CERCA |

## Types que solo están en el candidato (SOBRA)

- OTHER: 29 walls, 552.87 LF

Antes de dar un MAL por error de Claude, abre el renglón: a veces la referencia o el emparejamiento de nombres es el que está mal (regla del artículo: leer cada resultado).
