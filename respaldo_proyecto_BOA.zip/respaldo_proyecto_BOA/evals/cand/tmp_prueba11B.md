# Calificación del take-off: 42.5%

- Materiales por familia (cantidad NET): **47.60%**
- Partition types (LF y número de walls): **37.50%**
- Tolerancia: IGUAL ≤ 2%, CERCA ≤ 10%


## Materiales por familia (calificación principal)

| Familia | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|
| 6" parapet stud | 997.19 | 911.35 | 8.6% | CERCA (rango) |
| 6" stud (todos los gauges) | 4,525.47 | 4,823.42 | 5.3% | CERCA (rango) |
| 3-5/8" stud (todos los gauges) | 6,227.89 | 6,699.36 | 0.0% | IGUAL (rango) |
| 1-5/8" stud | 3,860.10 | 3,976.25 | 0.0% | IGUAL (rango) |
| purlin (track to deck) | 214.40 | 274.63 | 0.0% | IGUAL (rango) |
| track de ceilings / soffits | 1,168.97 | 1,118.15 | 15.5% | MAL (rango) |
| bottom track (todos) | 1,269.56 | 1,405.56 | 4.3% | CERCA (rango) |
| top / deflection track (todos) | 1,269.56 | 1,408.89 | 4.6% | CERCA (rango) |
| header / box beam | 305.63 | 226.38 | 71.4% | MAL (rango) |
| sill track | 67.76 | 63.12 | 47.0% | MAL (rango) |
| bracing C.R. channel | 2,624.23 | 2,496.98 | 0.0% | IGUAL (rango) |
| framed openings MEP | 970.32 | 949.36 | — | NO CALIFICA (excluir) |
| furring channel | 808.88 | 369.48 | 52.4% | MAL (rango) |
| carrying channel | 316.77 | 353.79 | 9.9% | CERCA (rango) |
| hanger wire | 524.78 | 547.76 | 3.7% | CERCA (rango) |
| 5/8" gyp MOISTURE RESISTANT | 261.80 | 259.03 | 0.0% | IGUAL (rango) |
| 5/8" EXTERIOR gyp sheathing | 944.60 | 913.32 | 0.0% | IGUAL (rango) |
| 5/8" glass mat sheathing | 462.00 | 354.91 | 8.3% | CERCA (rango) |
| 3/8" gyp board | 57.04 | 65.55 | 4.1% | CERCA (rango) |
| ballistic panel | 74.00 | 86.10 | 3.1% | CERCA (rango) |
| 5/8" gyp board regular (walls + ceilings) | 17,450.60 | 17,618.61 | 0.0% | IGUAL (rango) |
| cement board | 33.80 | 31.33 | 0.0% | IGUAL (rango) |
| FRP | 354.00 | 337.23 | 0.0% | IGUAL (rango) |
| FRT plywood (SF) | 6,507.01 | 6,834.98 | 0.0% | IGUAL (rango) |
| metal trim (corner bead, casing, shadow molding) | 1,267.55 | 1,313.68 | 0.0% | IGUAL (rango) |
| acoustical sealant | 1,166.70 | 1,212.68 | 0.0% | IGUAL (rango) |
| metal stud blocking (362CR / STUD BLOCKING) | 466.00 | 801.81 | 3.5% | CERCA (rango) |
| FRT blocking | 1,083.90 | 820.98 | 0.0% | IGUAL (rango) |
| additional head track | 56.00 | 56.00 | 0.0% | IGUAL (rango) |
| stud reinforcement MEP | 18.00 | — | — | FALTA |
| 2-1/2" CFMF coiling grille head | 7.85 | 47.30 | 352.6% | MAL (rango) |
| extra framing ATM | 109.87 | 27.16 | 45.5% | MAL (rango) |
| gypsum board jamb return | 95.94 | — | — | FALTA |
| Level 5 finish | 874.83 | 703.99 | 0.0% | IGUAL (rango) |
| PVC trim at FRP | 211.20 | — | — | FALTA |
| PAFs and duct sleeves | 275.00 | — | — | FALTA |
| access panel | 1.00 | — | — | FALTA |
| drywall screws | 21,323.33 | — | — | FALTA |
| framing screws | 5,252.00 | — | — | FALTA |
| slab pins | 515.71 | — | — | FALTA |
| expansion anchors | 326.46 | — | — | FALTA |
| joint compound | 1,279.40 | — | — | FALTA |
| joint tape | 6,574.69 | — | — | FALTA |

Renglón por renglón (depende de cómo cada take-off nombra y separa los renglones): 3.50%

## Materiales que no salieron iguales (55 de 57)

| Material | Unit | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|---|
| 6" metal stud 600S137-33 / -68 (LF of material) | lf | 4,525.47 | 1,381.96 | 69.5% | MAL |
| 6" parapet infill stud 600S162-54 @ 16" O.C. (LF of material | lf | 997.19 | 249.16 | 75.0% | MAL |
| 3-5/8" metal stud 362S137-33 / -68 (LF of material) | lf | 6,123.12 | 136.63 | 97.8% | MAL |
| 1-5/8" metal stud (LF of material) | lf | 3,860.10 | — | — | FALTA |
| Bottom track 6" | lf | 293.04 | 86.35 | 70.5% | MAL |
| Bottom track 3-5/8" | lf | 244.34 | 208.22 | 14.8% | MAL |
| Parapet bottom track 600T125-54 (PAF to steel beam) | lf | 269.37 | 51.73 | 80.8% | MAL |
| Parapet top track 600T125-54 | lf | 269.37 | 75.33 | 72.0% | MAL |
| Bottom track - roof step 4/A02.02, vestibule heads 4-7/A12.1 | lf | 176.84 | 15.65 | 91.2% | MAL |
| Top track - roof step 4/A02.02, vestibule heads 4-7/A12.10,  | lf | 176.84 | 15.65 | 91.2% | MAL |
| Bottom track 1-5/8" | lf | 285.97 | 202.04 | 29.3% | MAL |
| Top / deflection track 6" | lf | 293.04 | 86.35 | 70.5% | MAL |
| Top / deflection track 3-5/8" | lf | 244.34 | 208.22 | 14.8% | MAL |
| Top / deflection track 1-5/8" | lf | 285.97 | 202.04 | 29.3% | MAL |
| Track, ceilings / soffits / canopy | lf | 1,168.97 | 36.80 | 96.9% | MAL |
| Bracing 1-1/2" C.R. channel @ 48" O.C. | lf | 2,624.23 | 1,489.90 | 43.2% | MAL |
| Additional head track at openings over 4'-0" wide | lf | 56.00 | 37.33 | 33.3% | MAL |
| Header / metal stud box beam | lf | 305.63 | — | — | FALTA |
| Sill track | lf | 67.76 | 37.33 | 44.9% | MAL |
| Framed openings - MEP, light slots and diffusers | lf | 970.32 | 27.84 | 97.1% | MAL |
| Stud reinforcement at MEP penetrations | pcs | 18.00 | — | — | FALTA |
| 3-5/8" stud, CSR soffit 10/A09.33 (LF) | lf | 104.77 | — | — | FALTA |
| 2-1/2" CFMF @ 16" O.C. at coiling grille head (4/A08.21) | lf | 7.85 | — | — | FALTA |
| Purlin 1x1x1 16 ga, top track to deck | lf | 214.40 | 168.72 | 21.3% | MAL |
| Furring channel (ceilings) | lf | 808.88 | — | — | FALTA |
| Carrying channel (ceilings) | lf | 316.77 | — | — | FALTA |
| Hanger wire | lf | 524.78 | 236.25 | 55.0% | MAL |
| Extra framing - sistered stud and furring at the ATM recess | lf | 109.87 | — | — | FALTA |
| 5/8" gypsum board, regular | sf | 17,450.60 | 11,539.74 | 33.9% | MAL |
| 5/8" EXTERIOR gypsum sheathing (deck to top of parapet) | sf | 944.60 | 218.25 | 76.9% | MAL |
| FRP WC-3 | sf | 354.00 | 148.28 | 58.1% | MAL |
| Cement board (substrate under the FRP cove base band) | sf | 33.80 | — | — | FALTA |
| Exterior sheathing 5/8" FRT plywood bonded to 2-1/2" polyiso | sf | 3,754.28 | 1,158.39 | 69.1% | MAL |
| 5/8" glass mat sheathing (exterior face of the stud) | sf | 462.00 | 84.77 | 81.7% | MAL |
| Gypsum board jamb return at openings | sf | 95.94 | — | — | FALTA |
| Ballistic panel 3/8" UL752 | sf | 74.00 | 86.10 | 16.4% | MAL |
| 3/8" gypsum board | sf | 57.04 | 65.55 | 14.9% | MAL |
| FRT plywood substrate | sf | 632.49 | 10.00 | 98.4% | MAL |
| Level 5 finish | sf | 874.83 | 106.15 | 87.9% | MAL |
| 5/8" FRT plywood sheathing (canopy and soffits) | sf | 1,872.88 | 1,026.23 | 45.2% | MAL |
| METAL trim - corner bead, casing bead, shadow molding, gypsu | lf | 1,267.55 | 96.00 | 92.4% | MAL |
| PVC trim - edge trim molding and inside corner molding at th | lf | 211.20 | — | — | FALTA |
| Power-driven fasteners and duct sleeves | pcs | 275.00 | — | — | FALTA |
| Blocking FRT / 2X FRT wood | lf | 1,083.90 | 13.50 | 98.8% | MAL |
| Acoustical sealant | lf | 957.52 | 818.95 | 14.5% | MAL |
| Access panel 2'x2' | pcs | 1.00 | — | — | FALTA |
| 3/4" FRT plywood at storefront piers | sf | 26.86 | 251.80 | 837.5% | MAL |
| Sealant at base of gypsum (exterior, not acoustical) | lf | 209.18 | 16.81 | 92.0% | MAL |
| Stud blocking 362CR22 at edge of gypboard (4/S5.20) | lf | 466.00 | 2.00 | 99.6% | MAL |
| Drywall screws 1-1/4" bugle head | pcs | 21,323.33 | — | — | FALTA |
| Framing screws, pan head self-drilling | pcs | 5,252.00 | — | — | FALTA |
| Power-driven fasteners, slab pins for the bottom track | pcs | 515.71 | — | — | FALTA |
| Expansion anchors Hilti 1/4" Kwik Bolt II, exterior bottom t | pcs | 326.46 | — | — | FALTA |
| Joint compound, all purpose | lb | 1,279.40 | — | — | FALTA |
| Joint tape, paper | lf | 6,574.69 | — | — | FALTA |

## Materiales que solo están en el candidato (SOBRA)

- 6" metal stud 600S162-54 - exterior walls NORTH (grid G/F) (lf): 613.58
- 6" metal stud 600S162-54 - exterior walls EAST (grid 8) (lf): 1,041.49
- 6" metal stud 600S162-54 - exterior walls SOUTH (grid A) (lf): 541.75
- 6" metal stud 600S162-54 - exterior walls WEST (grid 2/D/3) (lf): 1,198.52
- 3-5/8" metal stud 362S137-33 @16" - interior partitions A1/B/C1/F (lf): 3,131.00
- 6" metal stud 600S137-68 (14 GA) @24" - ballistic partition B2K (lf): 46.12
- 1-5/8" metal stud 162S125-33 @16" double row - partitions G/G1 (lf): 3,536.27
- Batt insulation 3-1/2" - interior partitions (sf): 2,125.23
- Bracing clip (C.R. channel to stud) - interior partitions (pcs): 3,540.00
- Header 3-5/8" track header (R.O. + 1'-4") - interior doors (lf): 36.61
- Batt insulation 6" - interior partitions (sf): 1,033.18
- Header 6" track header (R.O. + 1'-4") - interior doors (lf): 33.18
- Batt insulation 1-1/2" (double row cavity) - G/G1 (sf): 1,553.21
- Sill track 3-5/8" (R.O. + 1'-4") - ATM walk-up F wall (lf): 3.58
- 5/8" gypsum board regular - interior face of exterior walls NORTH (gri (sf): 525.33
- 5/8" gypsum board regular - interior face of exterior walls EAST (grid (sf): 1,036.29
- 5/8" gypsum board regular - interior face of exterior walls SOUTH (gri (sf): 621.00
- 5/8" gypsum board regular - interior face of exterior walls WEST (grid (sf): 1,079.80
- 6" bottom track 600T125-33 (exterior wall) - NORTH (grid G/F) (lf): 16.81
- 6" bottom track 600T125-33 - cripples sobre steel header storefront -  (lf): 38.81
- 6" deflection (top) track 600T200-97 bajo perimeter beam - NORTH (grid (lf): 55.62
- 6" bottom track 600T125-33 (exterior wall) - EAST (grid 8) (lf): 75.33
- 6" deflection (top) track 600T200-97 bajo perimeter beam - EAST (grid  (lf): 75.33
- 6" bottom track 600T125-33 (exterior wall) - SOUTH (grid A) (lf): 48.40
- 6" deflection (top) track 600T200-97 bajo perimeter beam - SOUTH (grid (lf): 51.73
- 6" bottom track 600T125-33 (exterior wall) - WEST (grid 2/D/3) (lf): 73.19
- 6" bottom track 600T125-33 - cripples sobre steel header storefront -  (lf): 6.50
- 6" deflection (top) track 600T200-97 bajo perimeter beam - WEST (grid  (lf): 79.69
- Bracing 1-1/2" C.R. channel/bridging @48" (exterior wall) - NORTH (gri (lf): 166.88
- Bracing 1-1/2" C.R. channel/bridging @48" (exterior wall) - EAST (grid (lf): 201.05
- Bracing 1-1/2" C.R. channel/bridging @48" (exterior wall) - SOUTH (gri (lf): 103.46
- Bracing 1-1/2" C.R. channel/bridging @48" (exterior wall) - WEST (grid (lf): 214.12
- Header / box beam CFMF (R.O.+1'-4") - EAST (grid 8) (lf): 37.33
- Header / box beam CFMF (R.O.+1'-4") - SOUTH (grid A) (lf): 4.67
- Header / box beam CFMF (R.O.+1'-4") - WEST (grid 2/D/3) (lf): 22.21
- Sill track 600T125 (R.O.+1'-4") - WEST (grid 2/D/3) (lf): 22.21
- Additional head track (opng > 4'-0") - WEST (grid 2/D/3) (lf): 18.67
- FRT plywood 3/4" opening liner (jambs/head/sill, 1 ply) - NORTH (grid  (lf): 72.81
- FRT plywood 3/4" opening liner (jambs/head/sill, 1 ply) - EAST (grid 8 (lf): 80.00
- FRT plywood 3/4" opening liner (jambs/head/sill, 1 ply) - SOUTH (grid  (lf): 19.67
- FRT plywood 3/4" opening liner (jambs/head/sill, 1 ply) - WEST (grid 2 (lf): 63.50
- Sealant at base of gypsum (exterior wall, 1 bead) - EAST (grid 8) (lf): 75.33
- Sealant at base of gypsum (exterior wall, 1 bead) - SOUTH (grid A) (lf): 48.40
- Sealant at base of gypsum (exterior wall, 1 bead) - WEST (grid 2/D/3) (lf): 73.19
- Stud blocking 362CR22 (junta horizontal board, 1 fila) - NORTH (grid G (lf): 55.62
- Stud blocking 362CR22 (junta horizontal board, 1 fila) - EAST (grid 8) (lf): 75.33
- Stud blocking 362CR22 (junta horizontal board, 1 fila) - SOUTH (grid A (lf): 51.73
- Stud blocking 362CR22 (junta horizontal board, 1 fila) - WEST (grid 2/ (lf): 79.69
- FRT plywood 5/8" bonded to 2-1/2" polyiso (nailbase) - NORTH (grid G/F (sf): 606.32
- Glass mat sheathing 5/8" - banda base T/SLAB a T/BASE 0'-6" - NORTH (g (sf): 9.88
- Glass mat sheathing 5/8" - banda canopy (T/STUD 12'-7" - B/STUD 10'-7  (sf): 115.90
- Glass mat sheathing 5/8" - banda base T/SLAB a T/BASE 0'-6" - EAST (gr (sf): 38.64
- FRT plywood 5/8" bonded to 2-1/2" polyiso (nailbase) - SOUTH (grid A) (sf): 838.43
- Glass mat sheathing 5/8" - banda base T/SLAB a T/BASE 0'-6" - SOUTH (g (sf): 25.17
- Glass mat sheathing 5/8" - banda canopy (T/STUD 12'-7" - B/STUD 10'-7  (sf): 43.87
- FRT plywood 5/8" bonded to 2-1/2" polyiso (nailbase) - WEST (grid 2/D/ (sf): 1,247.64
- Glass mat sheathing 5/8" - banda base T/SLAB a T/BASE 0'-6" - WEST (gr (sf): 36.68
- Parapet infill stud 600S162-54 @16" - NORTH (grid G/F) (lf): 150.33
- Parapet infill track 600T125-54 TOP - NORTH (grid G/F) (lf): 55.62
- Parapet infill track 600T125-54 BOTTOM - NORTH (grid G/F) (lf): 55.62
- Bracing 1-1/2" C.R. channel parapet infill (>= 4 ft) - NORTH (grid G/F (lf): 16.72
- Exterior gypsum sheathing 5/8" parapet cara roof side - NORTH (grid G/ (sf): 151.19
- FRT plywood 3/4" parapet blocking (1 ply, top of parapet) - NORTH (gri (lf): 55.62
- Parapet infill stud 600S162-54 @16" - EAST (grid 8) (lf): 211.97
- Parapet infill track 600T125-54 BOTTOM - EAST (grid 8) (lf): 75.33
- Bracing 1-1/2" C.R. channel parapet infill (>= 4 ft) - EAST (grid 8) (lf): 24.95
- FRT plywood 3/4" parapet blocking (1 ply, top of parapet) - EAST (grid (lf): 75.33
- Parapet infill track 600T125-54 TOP - SOUTH (grid A) (lf): 51.73
- Bracing 1-1/2" C.R. channel parapet infill (>= 4 ft) - SOUTH (grid A) (lf): 51.73
- Exterior gypsum sheathing 5/8" parapet cara roof side - SOUTH (grid A) (sf): 252.72
- FRT plywood 3/4" parapet blocking (1 ply, top of parapet) - SOUTH (gri (lf): 51.73
- Parapet infill stud 600S162-54 @16" - WEST (grid 2/D/3) (lf): 299.89
- Parapet infill track 600T125-54 TOP - WEST (grid 2/D/3) (lf): 79.69
- Parapet infill track 600T125-54 BOTTOM - WEST (grid 2/D/3) (lf): 79.69
- Bracing 1-1/2" C.R. channel parapet infill (>= 4 ft) - WEST (grid 2/D/ (lf): 53.40
- Exterior gypsum sheathing 5/8" parapet cara roof side - WEST (grid 2/D (sf): 291.16
- FRT plywood 3/4" parapet blocking (1 ply, top of parapet) - WEST (grid (lf): 79.69
- 3-5/8" stud (362S137-33) storefront piers 1 & 2/A09.25 (framing interi (lf): 153.75
- 3-5/8" track piers 1 & 2/A09.25 (bottom) (lf): 5.50
- 3-5/8" track piers 1 & 2/A09.25 (top) (lf): 5.50
- 3-5/8" stud as soffit joist @16" canopy - C-G vestibule front (3/A09.2 (lf): 45.00
- Ceiling/soffit track 3-5/8" ambos extremos de joists - C-G vestibule f (lf): 35.38
- FRT plywood 5/8" ext. grade - soffit canopy - C-G vestibule front (3/A (sf): 53.06
- 3-5/8" stud fascia @16" canopy - C-G vestibule front (3/A09.26, secc.  (lf): 27.97
- Ceiling/soffit track 3-5/8" fascia box (top + bottom) - C-G vestibule  (lf): 35.38
- FRT plywood 5/8" ext. grade - fascia canopy - C-G vestibule front (3/A (sf): 50.67
- 3-5/8" stud as soffit joist @16" canopy - C-F north 4->8 (3/A09.26, se (lf): 131.31
- Ceiling/soffit track 3-5/8" ambos extremos de joists - C-F north 4->8  (lf): 82.23
- FRT plywood 5/8" ext. grade - soffit canopy - C-F north 4->8 (3/A09.26 (sf): 168.53
- 3-5/8" stud fascia @16" canopy - C-F north 4->8 (3/A09.26, secc. C 4'- (lf): 63.40
- Ceiling/soffit track 3-5/8" fascia box (top + bottom) - C-F north 4->8 (lf): 86.04
- FRT plywood 5/8" ext. grade - fascia canopy - C-F north 4->8 (3/A09.26 (sf): 123.24
- 3-5/8" stud as soffit joist @16" canopy - C-E east F->B.2 (7/A09.26, s (lf): 81.81
- Ceiling/soffit track 3-5/8" ambos extremos de joists - C-E east F->B.2 (lf): 84.67
- FRT plywood 5/8" ext. grade - soffit canopy - C-E east F->B.2 (7/A09.2 (sf): 104.95
- 3-5/8" stud fascia @16" canopy - C-E east F->B.2 (7/A09.26, secc. D 3' (lf): 72.72
- Ceiling/soffit track 3-5/8" fascia box (top + bottom) - C-E east F->B. (lf): 100.75
- FRT plywood 5/8" ext. grade - fascia canopy - C-E east F->B.2 (7/A09.2 (sf): 144.30
- 3-5/8" stud as soffit joist @16" canopy - C-S south 3.4->5.6 (7/A09.26 (lf): 44.62
- Ceiling/soffit track 3-5/8" ambos extremos de joists - C-S south 3.4-> (lf): 44.33
- FRT plywood 5/8" ext. grade - soffit canopy - C-S south 3.4->5.6 (7/A0 (sf): 54.95
- 3-5/8" stud fascia @16" canopy - C-S south 3.4->5.6 (7/A09.26 SIM, sec (lf): 42.89
- Ceiling/soffit track 3-5/8" fascia box (top + bottom) - C-S south 3.4- (lf): 56.25
- FRT plywood 5/8" ext. grade - fascia canopy - C-S south 3.4->5.6 (7/A0 (sf): 80.57
- 3-5/8" stud as soffit joist @16" canopy - C-DU drive-up (15,16/A09.27) (lf): 823.25
- Ceiling/soffit track 3-5/8" ambos extremos de joists - C-DU (lf): 113.67
- 3-5/8" stud fascia @16" canopy - C-DU (lf): 136.11
- Ceiling/soffit track 3-5/8" fascia box (top + bottom) - C-DU (lf): 190.04
- FRT plywood 5/8" ext. grade - fascia canopy - C-DU (sf): 272.20
- 3-5/8" stud canopy columns (4) 5/A09.25 (lf): 339.33
- 3-5/8" bottom track canopy columns (lf): 19.33
- 3-5/8" top track canopy columns (lf): 19.33
- Bracing 1-1/2" C.R. channel canopy columns (lf): 38.67
- Framed opening canopy luminaires - lados (2 x largo schedule) 3-5/8" t (lf): 686.00
- 3-5/8" stud @16" roof step 4/A02.02 (3 corridas) (lf): 308.16
- 3-5/8" bottom track roof step (3 corridas) (lf): 155.19
- 3-5/8" top track roof step (3 corridas) (lf): 155.19
- 2x FRT blocking roof step (top) (lf): 51.73
- FRT plywood 5/8" bonded to polyiso - roof step run 1 (sf): 161.03
- 5/8" gypsum board - roof step interior (run 2 + run 3 + fondo) (sf): 304.06
- Purlin 1x1x1 16GA track paralelo al flute (roof step, 2 tracks a deck) (lf): 77.59
- 2x FRT blocking roof hatch curb (lf): 14.00
- Metal trim - corner bead (jamb returns de ventanas/storefront, cara in (lf): 216.31
- Metal trim - L-bead (board contra storefront/window frame) (lf): 216.31
- 5/8" gypsum board - ceiling (100 VESTIBULE) (sf): 124.17
- Furring channel 7/8" hat 25ga @16" O.C. - ceiling (100 VESTIBULE) (lf): 110.74
- Carrying channel 1-1/2" CRC @48" O.C. - ceiling (100 VESTIBULE) (lf): 48.44
- Hanger wire 12 ga @48" x 48" - ceiling (100 VESTIBULE) (lf): 96.75
- Ceiling track (perimeter) - ceiling (100 VESTIBULE) (lf): 48.12
- 5/8" gypsum board - ceiling (113 MEN'S RESTROOM) (sf): 75.57
- Furring channel 7/8" hat 25ga @16" O.C. - ceiling (113 MEN'S RESTROOM) (lf): 66.67
- Carrying channel 1-1/2" CRC @48" O.C. - ceiling (113 MEN'S RESTROOM) (lf): 35.20
- Hanger wire 12 ga @48" x 48" - ceiling (113 MEN'S RESTROOM) (lf): 52.63
- 5/8" gypsum board - ceiling (114 WOMEN'S RESTROOM) (sf): 75.60
- Furring channel 7/8" hat 25ga @16" O.C. - ceiling (114 WOMEN'S RESTROO (lf): 66.67
- Carrying channel 1-1/2" CRC @48" O.C. - ceiling (114 WOMEN'S RESTROOM) (lf): 35.20
- Hanger wire 12 ga @48" x 48" - ceiling (114 WOMEN'S RESTROOM) (lf): 54.63
- Ceiling track (perimeter) - ceiling (114 WOMEN'S RESTROOM) (lf): 36.80
- 5/8" gypsum board - ceiling (101 24 HR VESTIBULE) (sf): 152.00
- Furring channel 7/8" hat 25ga @16" O.C. - ceiling (101 24 HR VESTIBULE (lf): 125.40
- Carrying channel 1-1/2" CRC @48" O.C. - ceiling (101 24 HR VESTIBULE) (lf): 54.95
- Hanger wire 12 ga @48" x 48" - ceiling (101 24 HR VESTIBULE) (lf): 107.50
- Ceiling track (perimeter) - ceiling (101 24 HR VESTIBULE) (lf): 52.80
- 5/8" gypsum board - ceiling (104 WAITING) (sf): 510.81
- 3-5/8" stud ceiling joists @16" O.C. (104 WAITING) (lf): 408.65
- Carrying channel 1-1/2" CRC @48" O.C. (104 WAITING) (lf): 180.00
- Ceiling / soffit track 3-5/8" (perimeter joist ends) (104 WAITING) (lf): 60.00
- 5/8" gypsum board - drop face (104 WAITING drop N edge (E-W, parallel  (sf): 17.03
- 3-5/8" stud vertical @16" O.C. to deck (104 WAITING drop N edge (E-W,  (lf): 61.25
- 3-5/8" stud kicker/bracing @48" O.C. (104 WAITING drop N edge (E-W, pa (lf): 37.12
- Bottom track 3-5/8" (104 WAITING drop N edge (E-W, parallel to flute)) (lf): 17.03
- Top track 3-5/8" at deck (104 WAITING drop N edge (E-W, parallel to fl (lf): 17.03
- Purlin 1x1x1 16ga across min 2 flutes (104 WAITING drop N edge (E-W, p (lf): 12.77
- Metal trim - corner L bead (104 WAITING drop N edge (E-W, parallel to  (lf): 17.03
- Metal trim - shadow molding (104 WAITING drop N edge (E-W, parallel to (lf): 17.03
- 5/8" gypsum board - drop face (104 WAITING drop E edge (N-S)) (sf): 30.00
- 3-5/8" stud vertical @16" O.C. to deck (104 WAITING drop E edge (N-S)) (lf): 105.00
- 3-5/8" stud kicker/bracing @48" O.C. (104 WAITING drop E edge (N-S)) (lf): 55.68
- Bottom track 3-5/8" (104 WAITING drop E edge (N-S)) (lf): 30.00
- Top track 3-5/8" at deck (104 WAITING drop E edge (N-S)) (lf): 30.00
- Metal trim - corner L bead (104 WAITING drop E edge (N-S)) (lf): 30.00
- Metal trim - shadow molding (104 WAITING drop E edge (N-S)) (lf): 30.00
- 5/8" gypsum board - drop face (104 WAITING drop W edge (N-S)) (sf): 30.00
- 3-5/8" stud vertical @16" O.C. to deck (104 WAITING drop W edge (N-S)) (lf): 105.00
- 3-5/8" stud kicker/bracing @48" O.C. (104 WAITING drop W edge (N-S)) (lf): 55.68
- Bottom track 3-5/8" (104 WAITING drop W edge (N-S)) (lf): 30.00
- Top track 3-5/8" at deck (104 WAITING drop W edge (N-S)) (lf): 30.00
- Metal trim - corner L bead (104 WAITING drop W edge (N-S)) (lf): 30.00
- Metal trim - shadow molding (104 WAITING drop W edge (N-S)) (lf): 30.00
- 5/8" gypsum board - transition drop (103 CENTRAL ZONE transition 11'-6 (sf): 19.51
- 3-5/8" stud vertical @16" O.C. to deck (103 CENTRAL ZONE transition 11 (lf): 31.88
- 3-5/8" stud kicker @48" O.C. (103 CENTRAL ZONE transition 11'-6" -> 9' (lf): 27.05
- Bottom track 3-5/8" (103 CENTRAL ZONE transition 11'-6" -> 9'-0" (E-W, (lf): 5.09
- Top track 3-5/8" at deck (103 CENTRAL ZONE transition 11'-6" -> 9'-0"  (lf): 5.09
- Purlin 1x1x1 16ga (103 CENTRAL ZONE transition 11'-6" -> 9'-0" (E-W, y (lf): 3.82
- Metal trim - corner bead (103 CENTRAL ZONE transition 11'-6" -> 9'-0"  (lf): 10.19
- Metal trim - shadow molding (103 CENTRAL ZONE transition 11'-6" -> 9'- (lf): 10.19
- 5/8" gypsum board - soffit bottom (CSR LINE SOFFIT (N-S, x1653.96-1715 (sf): 41.05
- 5/8" gypsum board - soffit vertical faces (CSR LINE SOFFIT (N-S, x1653 (sf): 36.04
- 3-5/8" stud vertical @16" O.C. to deck, 2 rows (CSR LINE SOFFIT (N-S,  (lf): 73.75
- 3-5/8" stud vertical @16" O.C. to deck, 2 rows (CSR LINE SOFFIT (N-S,  (lf): 60.63
- 3-5/8" stud soffit bottom joists @16" O.C. (CSR LINE SOFFIT (N-S, x165 (lf): 37.59
- Top track 3-5/8" at deck (cont. track + PDF) (CSR LINE SOFFIT (N-S, x1 (lf): 24.03
- Ceiling / soffit track 3-5/8" - soffit bottom + ends (CSR LINE SOFFIT  (lf): 30.86
- Metal trim - corner bead (CSR LINE SOFFIT (N-S, x1653.96-1715.40, y112 (lf): 24.03
- FRT plywood 5/8" blocking - soffit bottom full width (CSR LINE SOFFIT  (lf): 12.01
- Bracing (C.R. channel bridging) 1 row x 2 stud rows (CSR LINE SOFFIT ( (lf): 24.03
- 3-5/8" stud @16" O.C. above head to deck (VESTIBULE HEAD 100/101 glazi (lf): 69.88
- Header / box beam (VESTIBULE HEAD 100/101 glazing (E-W, elev 3/A12.10, (lf): 16.98
- Bracing (C.R. channel) 1 row (VESTIBULE HEAD 100/101 glazing (E-W, ele (lf): 15.65
- Purlin 1x1x1 16ga (VESTIBULE HEAD 100/101 glazing (E-W, elev 3/A12.10, (lf): 11.73
- 3-5/8" stud @16" O.C. above head to deck (VESTIBULE HEAD 100/Central Z (lf): 32.25
- Header / box beam (VESTIBULE HEAD 100/Central Zone glazing grid 4 (N-S (lf): 7.75
- Bottom track (VESTIBULE HEAD 100/Central Zone glazing grid 4 (N-S, ele (lf): 6.42
- Top track at deck (VESTIBULE HEAD 100/Central Zone glazing grid 4 (N-S (lf): 6.42
- Bracing (C.R. channel) 1 row (VESTIBULE HEAD 100/Central Zone glazing  (lf): 6.42
- 5/8" gypsum board - head face to Central Zone (VESTIBULE HEAD 100/Cent (sf): 12.83
- Metal trim - corner bead at 10'-0" (VESTIBULE HEAD 100/Central Zone gl (lf): 6.42
- 5/8" gypsum board 2 layers - office face to deck (OFFICE BULKHEAD OFFI (sf): 110.00
- 5/8" gypsum board 2 layers - lobby face to deck (OFFICE BULKHEAD OFFIC (sf): 110.00
- 5/8" gypsum board - bulkhead bottom (OFFICE BULKHEAD OFFICE 1 ME 105 ( (sf): 5.00
- 1-5/8" stud cripples double row @16" above box beam (OFFICE BULKHEAD O (lf): 73.33
- Header / box beam - cont. box beam (OFFICE BULKHEAD OFFICE 1 ME 105 (x (lf): 8.83
- Top track - cont. slip track at deck, 2 rows (OFFICE BULKHEAD OFFICE 1 (lf): 15.00
- Bottom track on box beam, 2 rows (OFFICE BULKHEAD OFFICE 1 ME 105 (x~1 (lf): 15.00
- FRT blocking 3/4" plywood under box beam (OFFICE BULKHEAD OFFICE 1 ME  (lf): 7.50
- Soundguard isolator by Marinoware (OFFICE BULKHEAD OFFICE 1 ME 105 (x~ (lf): 7.50
- Metal trim - corner bead (OFFICE BULKHEAD OFFICE 1 ME 105 (x~1640 N-S; (lf): 15.00
- Metal trim - shadow molding (OFFICE BULKHEAD OFFICE 1 ME 105 (x~1640 N (lf): 15.00
- Acoustical sealant - top at deck, 2 runs (OFFICE BULKHEAD OFFICE 1 ME  (lf): 15.00
- Acoustical sealant - bottom at office front, 2 runs (OFFICE BULKHEAD O (lf): 15.00
- Batt insulation in bulkhead (OFFICE BULKHEAD OFFICE 1 ME 105 (x~1640 N (sf): 55.00
- Bracing (C.R. channel) 1 row x 2 rows (OFFICE BULKHEAD OFFICE 1 ME 105 (lf): 15.00
- 5/8" gypsum board 2 layers - office face to deck (OFFICE BULKHEAD OFFI (sf): 110.00
- 5/8" gypsum board 2 layers - lobby face to deck (OFFICE BULKHEAD OFFIC (sf): 110.00
- 5/8" gypsum board - bulkhead bottom (OFFICE BULKHEAD OFFICE 2 CL 106 ( (sf): 5.00
- 1-5/8" stud cripples double row @16" above box beam (OFFICE BULKHEAD O (lf): 73.33
- Header / box beam - cont. box beam (OFFICE BULKHEAD OFFICE 2 CL 106 (x (lf): 8.83
- Top track - cont. slip track at deck, 2 rows (OFFICE BULKHEAD OFFICE 2 (lf): 15.00
- Bottom track on box beam, 2 rows (OFFICE BULKHEAD OFFICE 2 CL 106 (x~1 (lf): 15.00
- FRT blocking 3/4" plywood under box beam (OFFICE BULKHEAD OFFICE 2 CL  (lf): 7.50
- Soundguard isolator by Marinoware (OFFICE BULKHEAD OFFICE 2 CL 106 (x~ (lf): 7.50
- Metal trim - corner bead (OFFICE BULKHEAD OFFICE 2 CL 106 (x~1640 N-S; (lf): 15.00
- Metal trim - shadow molding (OFFICE BULKHEAD OFFICE 2 CL 106 (x~1640 N (lf): 15.00
- Acoustical sealant - top at deck, 2 runs (OFFICE BULKHEAD OFFICE 2 CL  (lf): 15.00
- Acoustical sealant - bottom at office front, 2 runs (OFFICE BULKHEAD O (lf): 15.00
- Batt insulation in bulkhead (OFFICE BULKHEAD OFFICE 2 CL 106 (x~1640 N (sf): 55.00
- Bracing (C.R. channel) 1 row x 2 rows (OFFICE BULKHEAD OFFICE 2 CL 106 (lf): 15.00
- 5/8" gypsum board 2 layers - office face to deck (OFFICE BULKHEAD OFFI (sf): 110.00
- 5/8" gypsum board 2 layers - lobby face to deck (OFFICE BULKHEAD OFFIC (sf): 110.00
- 5/8" gypsum board - bulkhead bottom (OFFICE BULKHEAD OFFICE 3 SB 107 ( (sf): 5.00
- 1-5/8" stud cripples double row @16" above box beam (OFFICE BULKHEAD O (lf): 73.33
- Header / box beam - cont. box beam (OFFICE BULKHEAD OFFICE 3 SB 107 (x (lf): 8.83
- Top track - cont. slip track at deck, 2 rows (OFFICE BULKHEAD OFFICE 3 (lf): 15.00
- Bottom track on box beam, 2 rows (OFFICE BULKHEAD OFFICE 3 SB 107 (x~1 (lf): 15.00
- FRT blocking 3/4" plywood under box beam (OFFICE BULKHEAD OFFICE 3 SB  (lf): 7.50
- Soundguard isolator by Marinoware (OFFICE BULKHEAD OFFICE 3 SB 107 (x~ (lf): 7.50
- Metal trim - corner bead (OFFICE BULKHEAD OFFICE 3 SB 107 (x~1640 N-S; (lf): 15.00
- Metal trim - shadow molding (OFFICE BULKHEAD OFFICE 3 SB 107 (x~1640 N (lf): 15.00
- Acoustical sealant - top at deck, 2 runs (OFFICE BULKHEAD OFFICE 3 SB  (lf): 15.00
- Acoustical sealant - bottom at office front, 2 runs (OFFICE BULKHEAD O (lf): 15.00
- Batt insulation in bulkhead (OFFICE BULKHEAD OFFICE 3 SB 107 (x~1640 N (sf): 55.00
- Bracing (C.R. channel) 1 row x 2 rows (OFFICE BULKHEAD OFFICE 3 SB 107 (lf): 15.00
- 5/8" gypsum board 2 layers - office face to deck (OFFICE BULKHEAD OFFI (sf): 110.00
- 5/8" gypsum board 2 layers - lobby face to deck (OFFICE BULKHEAD OFFIC (sf): 110.00
- 5/8" gypsum board - bulkhead bottom (OFFICE BULKHEAD OFFICE 4 CB 108 ( (sf): 5.00
- 1-5/8" stud cripples double row @16" above box beam (OFFICE BULKHEAD O (lf): 73.33
- Header / box beam - cont. box beam (OFFICE BULKHEAD OFFICE 4 CB 108 (x (lf): 8.83
- Top track - cont. slip track at deck, 2 rows (OFFICE BULKHEAD OFFICE 4 (lf): 15.00
- Bottom track on box beam, 2 rows (OFFICE BULKHEAD OFFICE 4 CB 108 (x~1 (lf): 15.00
- FRT blocking 3/4" plywood under box beam (OFFICE BULKHEAD OFFICE 4 CB  (lf): 7.50
- Soundguard isolator by Marinoware (OFFICE BULKHEAD OFFICE 4 CB 108 (x~ (lf): 7.50
- Metal trim - corner bead (OFFICE BULKHEAD OFFICE 4 CB 108 (x~1640 N-S; (lf): 15.00
- Metal trim - shadow molding (OFFICE BULKHEAD OFFICE 4 CB 108 (x~1640 N (lf): 15.00
- Acoustical sealant - top at deck, 2 runs (OFFICE BULKHEAD OFFICE 4 CB  (lf): 15.00
- Acoustical sealant - bottom at office front, 2 runs (OFFICE BULKHEAD O (lf): 15.00
- Batt insulation in bulkhead (OFFICE BULKHEAD OFFICE 4 CB 108 (x~1640 N (sf): 55.00
- Bracing (C.R. channel) 1 row x 2 rows (OFFICE BULKHEAD OFFICE 4 CB 108 (lf): 15.00
- 5/8" gypsum board 2 layers - office face to deck (OFFICE BULKHEAD OFFI (sf): 110.00
- 5/8" gypsum board 2 layers - lobby face to deck (OFFICE BULKHEAD OFFIC (sf): 110.00
- 5/8" gypsum board - bulkhead bottom (OFFICE BULKHEAD OFFICE 5 CB 109 ( (sf): 5.00
- 1-5/8" stud cripples double row @16" above box beam (OFFICE BULKHEAD O (lf): 73.33
- Header / box beam - cont. box beam (OFFICE BULKHEAD OFFICE 5 CB 109 (x (lf): 8.83
- Top track - cont. slip track at deck, 2 rows (OFFICE BULKHEAD OFFICE 5 (lf): 15.00
- Bottom track on box beam, 2 rows (OFFICE BULKHEAD OFFICE 5 CB 109 (x~1 (lf): 15.00
- FRT blocking 3/4" plywood under box beam (OFFICE BULKHEAD OFFICE 5 CB  (lf): 7.50
- Soundguard isolator by Marinoware (OFFICE BULKHEAD OFFICE 5 CB 109 (x~ (lf): 7.50
- Metal trim - corner bead (OFFICE BULKHEAD OFFICE 5 CB 109 (x~1130 N-S; (lf): 15.00
- Metal trim - shadow molding (OFFICE BULKHEAD OFFICE 5 CB 109 (x~1130 N (lf): 15.00
- Acoustical sealant - top at deck, 2 runs (OFFICE BULKHEAD OFFICE 5 CB  (lf): 15.00
- Acoustical sealant - bottom at office front, 2 runs (OFFICE BULKHEAD O (lf): 15.00
- Batt insulation in bulkhead (OFFICE BULKHEAD OFFICE 5 CB 109 (x~1130 N (sf): 55.00
- Bracing (C.R. channel) 1 row x 2 rows (OFFICE BULKHEAD OFFICE 5 CB 109 (lf): 15.00
- 5/8" gypsum board 2 layers - office face to deck (OFFICE BULKHEAD OFFI (sf): 110.00
- 5/8" gypsum board 2 layers - lobby face to deck (OFFICE BULKHEAD OFFIC (sf): 110.00
- 5/8" gypsum board - bulkhead bottom (OFFICE BULKHEAD OFFICE 6 CB 110 ( (sf): 5.00
- 1-5/8" stud cripples double row @16" above box beam (OFFICE BULKHEAD O (lf): 73.33
- Header / box beam - cont. box beam (OFFICE BULKHEAD OFFICE 6 CB 110 (x (lf): 8.83
- Top track - cont. slip track at deck, 2 rows (OFFICE BULKHEAD OFFICE 6 (lf): 15.00
- Bottom track on box beam, 2 rows (OFFICE BULKHEAD OFFICE 6 CB 110 (x~1 (lf): 15.00
- FRT blocking 3/4" plywood under box beam (OFFICE BULKHEAD OFFICE 6 CB  (lf): 7.50
- Soundguard isolator by Marinoware (OFFICE BULKHEAD OFFICE 6 CB 110 (x~ (lf): 7.50
- Metal trim - corner bead (OFFICE BULKHEAD OFFICE 6 CB 110 (x~1130 N-S; (lf): 15.00
- Metal trim - shadow molding (OFFICE BULKHEAD OFFICE 6 CB 110 (x~1130 N (lf): 15.00
- Acoustical sealant - top at deck, 2 runs (OFFICE BULKHEAD OFFICE 6 CB  (lf): 15.00
- Acoustical sealant - bottom at office front, 2 runs (OFFICE BULKHEAD O (lf): 15.00
- Batt insulation in bulkhead (OFFICE BULKHEAD OFFICE 6 CB 110 (x~1130 N (sf): 55.00
- Bracing (C.R. channel) 1 row x 2 rows (OFFICE BULKHEAD OFFICE 6 CB 110 (lf): 15.00
- Framed opening - R-11C/R-11CE 12' trimless slot in Waiting GWB (4 pcs: (lf): 96.00
- Framed opening - R-11A 4' trimless slot in CSR soffit (2 pcs R-11A,b) (lf): 16.00
- Metal trim - gypsum edge trim at R-11A slots (CSR) (lf): 16.00
- Framed opening - linear slot diffuser 4'-0" (100 VESTIBULE row at stor (lf): 27.84
- Framed opening - linear slot diffuser 4'-0" (101 24 HR VESTIBULE strai (lf): 27.84
- Framed opening - linear slot diffuser 4'-0" (101 24 HR VESTIBULE diago (lf): 27.84
- Framed opening - 2'x2' HVAC diffuser/grille in restroom GWB (113: 2, 1 (lf): 32.00
- Framed opening - 2'x2' locking access panel (key note 4) in Vestibule  (lf): 8.00
- FRT plywood blocking 3/4" - 85" media monitor (Samsung QP85A-8K + Chie (lf): 3.69
- Stud blocking 362CR22 (metal, 4/S5.20) - ARTWORK 4'-0" x 4'-0" @ 3'-0" (lf): 8.00
- Stud blocking 362CR22 (metal, 4/S5.20) - ARTWORK 4'-0" x 4'-0" @ 3'-0" (lf): 8.00
- Stud blocking 362CR22 (metal, 4/S5.20) - ARTWORK 4'-0" x 4'-0" @ 3'-0" (lf): 8.00
- Stud blocking 362CR22 (metal, 4/S5.20) - ARTWORK 4'-0" x 4'-0" @ 3'-0" (lf): 8.00
- Stud blocking 362CR22 (metal, 4/S5.20) - ARTWORK 4'-0" x 4'-0" @ 3'-0" (lf): 8.00
- Stud blocking 362CR22 (metal, 4/S5.20) - ARTWORK 4'-0" x 4'-0" @ 3'-0" (lf): 8.00
- Stud blocking 362CR22 (metal, 4/S5.20) - COMBO BOARD equip. 7 (48"W x  (lf): 8.00
- Stud blocking 362CR22 (metal, 4/S5.20) - CORK BOARD equip. 69 (36"W x  (lf): 8.00
- Stud blocking 362CR22 (metal, 4/S5.20) - CORK BOARD equip. 69 drawn 4' (lf): 10.67
- Stud blocking 362CR22 (metal, 4/S5.20) - WALL CLOCK equip. 9 (10" dia) (lf): 1.33
- Stud blocking 362CR22 (metal, 4/S5.20) - COAT HOOKS equip. 3 bar #1 (1 (lf): 2.67
- Stud blocking 362CR22 (metal, 4/S5.20) - COAT HOOKS equip. 3 bar #2 (1 (lf): 2.67
- Stud blocking 362CR22 (metal, 4/S5.20) - LOCKERS CW-16 (keynote 5) 4.8 (lf): 10.67
- Stud blocking 362CR22 (metal, 4/S5.20) - FIRE EXTINGUISHER BRACKET FEC (lf): 1.33
- Stud blocking 362CR22 (metal, 4/S5.20) - COAT HOOK equip. 3 #1 (lf): 1.33
- Stud blocking 362CR22 (metal, 4/S5.20) - COAT HOOK equip. 3 #2 (lf): 1.33
- Stud blocking 362CR22 (metal, 4/S5.20) - HAND SANITIZER equip. 64 (6.1 (lf): 1.33
- Stud blocking 362CR22 (metal, 4/S5.20) - HAND SANITIZER equip. 64 (6.1 (lf): 1.33
- Stud blocking 362CR22 (metal, 4/S5.20) - HAND SANITIZER equip. 64 (6.1 (lf): 1.33
- Stud blocking 362CR22 (metal, 4/S5.20) - WALL PHONE equip. 24 (Cisco 8 (lf): 1.33
- Stud blocking 362CR22 (metal, 4/S5.20) - WALL PHONE equip. 24 (Cisco 8 (lf): 1.33
- Stud blocking 362CR22 (metal, 4/S5.20) - WALL PHONE equip. 24 (Cisco 8 (lf): 1.33
- Stud blocking 362CR22 (metal, 4/S5.20) - SECURITY MONITOR equip. 58 on (lf): 1.33
- Stud blocking 362CR22 (metal, 4/S5.20) - SECURITY MONITOR equip. 58 on (lf): 1.33
- Stud blocking 362CR22 (metal, 4/S5.20) - TA-19 MIRROR (wellness, not t (lf): 5.33
- Stud blocking 362CR22 (metal, 4/S5.20) - WALL STOP door 113 (lf): 2.00
- Stud blocking 362CR22 (metal, 4/S5.20) - WALL STOP door 114 (lf): 2.00
- Stud blocking 362CR22 (metal, 4/S5.20) - WALL STOP door 115 (lf): 2.00
- Stud blocking 362CR22 (metal, 4/S5.20) - WALL STOP door 116 (lf): 2.00
- Stud blocking 362CR22 (metal, 4/S5.20) - WALL STOP door 117 (lf): 2.00
- Stud blocking 362CR22 (metal, 4/S5.20) - WALL STOP door 118A (lf): 2.00
- Stud blocking 362CR22 (metal, 4/S5.20) - WALL STOP door 118B (lf): 2.00
- Stud blocking 362CR22 (metal, 4/S5.20) - WALL STOP door 119 (lf): 2.00
- FRT blocking - TA-7 ADA LED backlit mirror 2'-0" W (vector) (lf): 5.33
- FRT blocking - TA-4 grab bar 36" (lf): 4.00
- FRT blocking - Lavatory PF-02 wall-hung, no carrier (20" W vector) (lf): 2.67
- FRT blocking - TA-3 grab bar 42" (lf): 4.00
- FRT blocking - TA-5 vertical grab bar 18" (top+bottom flange pieces) (lf): 2.67
- FRT blocking - TA-10 toilet paper dispenser (lf): 1.33
- FRT blocking - TA-17 seat cover dispenser (15.8" vector) (lf): 1.33
- FRT blocking - TA-16 KB208 baby changing station (34" vector) (lf): 8.00
- FRT blocking - TA-8 touchless soap dispenser (lf): 1.33
- FRT blocking - TA-7 ADA LED backlit mirror 2'-0" W (vector) (2) (lf): 5.33
- FRT blocking - TA-4 grab bar 36" (2) (lf): 4.00
- FRT blocking - Lavatory PF-02 wall-hung, no carrier (20" W vector) (2) (lf): 2.67
- FRT blocking - TA-3 grab bar 42" (2) (lf): 4.00
- FRT blocking - TA-5 vertical grab bar 18" (top+bottom flange pieces) ( (lf): 2.67
- FRT blocking - TA-10 toilet paper dispenser (2) (lf): 1.33
- FRT blocking - TA-17 seat cover dispenser (15.8" vector) (2) (lf): 1.33
- FRT blocking - TA-16 KB208 baby changing station (34" vector) (2) (lf): 8.00
- FRT blocking - TA-8 touchless soap dispenser (2) (lf): 1.33
- FRT blocking - TA-9 sanitary napkin disposal (10.7" vector) (lf): 1.33
- FRT blocking (FRTW) - MW01 printer cabinet (full height, in niche) (lf): 6.25
- FRT blocking (FRTW) - MW05 storage shelving - standards (lf): 21.00
- FRT blocking (FRTW) - MW06A janitor shelving #1 - standards (lf): 9.00
- FRT blocking (FRTW) - MW06A janitor shelving #2 - standards (lf): 9.00
- FRT blocking (FRTW) - MW06 mop/broom holder on WC-2 (lf): 1.33
- FRT blocking (FRTW) - MW07 base cabinet (counter) (lf): 6.62
- FRT blocking (FRTW) - MW07 upper (open shelving) (lf): 13.25
- FRT blocking (FRTW) - MW08 base cabinet w/ sink (lf): 7.58
- FRT blocking (FRTW) - MW12 base L (N 7'-0" + W return 2'-3 1/4") (lf): 9.27
- FRT blocking (FRTW) - MW12 uppers (N 5.687 + W 2.869 vector) (lf): 17.11
- FRT blocking (FRTW) - MW13 shelving/locking cabinets full height (lf): 23.08
- FRT blocking (FRTW) - MW18 base cabinet (lf): 3.33
- FRT blocking (FRTW) - MW18 shelving standards (lf): 9.00
- FRT blocking (FRTW) - MW21 break room counter (metal angle both sides) (lf): 10.00
- FRT wood blocking - coiling grille 103 jamb boxes (lf): 67.71
- FRT blocking - vestibule glass wall terminations (lf): 40.00
- FRT blocking 2x - roof ladder brackets (lf): 8.00
- FRT 2x4 perimeter framing - WU ATM plinth (9T) (lf): 12.83
- FRT 4x4 framing - WU ATM plinth (9T) (lf): 5.33
- FRT plywood backboard 3/4" painted white - ELECTRICAL 120 N wall (sf): 76.66
- FRT plywood backboard 3/4" painted white - ELECTRICAL 120 W wall (sf): 46.66
- FRT plywood backboard 3/4" painted white - ELECTRICAL 120 S wall (sf): 76.66
- FRT plywood backboard 3/4" painted white - NER 121 W wall (sf): 60.00
- Cementitious backer board under CT-12C cove base - MEN'S RESTROOM 113 (sf): 14.83
- FRP WC-3 (Marlite Symmetrix) - WOMEN'S RESTROOM 114 (sf): 164.95
- Cementitious backer board under CT-12C cove base - WOMEN'S RESTROOM 11 (sf): 16.50
- FRP WC-2 glass fiber reinforced panel - JANITOR CLOSET 112 at mop sink (sf): 24.00
- Level 5 finish - behind WC-18 felt panels (offices 1-6) (sf): 597.84
- Header 6" CFMF box beam - coiling grille 103 head (lf): 14.67
- 2-1/2" metal stud 250S125-33 @16" - coiling grille 103 head fascia (lf): 11.00
- Bottom track 2-1/2" - coiling grille 103 head (lf): 13.33
- Top track 2-1/2" - coiling grille 103 head (lf): 13.33
- 5/8" gypsum board regular - coiling grille 103 head fascia (sf): 37.78
- Metal trim - corner bead - coiling grille 103 head (lf): 26.67
- Metal stud blocking 362CR22 at horizontal board joint - interior parti (lf): 379.47
- Metal stud blocking 362CR22 - drinking fountain PF-06 bi-level (Corrid (lf): 12.00
- Metal trim - corner bead - office front jambs (10/A12.01) (lf): 193.00
- FRT plywood blocking 3/4" - office front jambs (10/A12.01) (lf): 96.50
- Sound batt insulation above GWB ceiling - restrooms 113/114 (A04.01 KN (sf): 151.17
- FRT blocking 2x - water heater WH-1 platform (Janitor 112) (lf): 8.00
- 2-1/2" metal stud 250S125-33 sistered to 6" stud - drive-up ATM 9D (6/ (lf): 36.30
- Bottom track 2-1/2" - drive-up ATM 9D sister framing (lf): 4.50
- Top track 2-1/2" - drive-up ATM 9D sister framing (lf): 4.50
- Mineral wool insulation - drive-up ATM 9D (6/A08.11) (sf): 32.62
- Metal stud blocking 362CR22 - light fixture on wall over door frame (A (lf): 5.33
- Metal stud blocking 362CR22 - EUH-1 unit heater Janitor 112 (M00.03, E (lf): 2.67
- Metal trim - corner bead (criterio 53.1) - interior partition outside  (lf): 164.50

## Partition types que no salieron iguales (13 de 14)

| Type | Walls ref | Walls cand | LF ref | LF cand | Dif | Estado |
|---|---|---|---|---|---|---|
| A1 | 9 | 9 | 78.37 | 82.94 | 0.0% | IGUAL (rango) |
| A1K | 3 | 3 | 7.99 | 9.07 | 5.5% | CERCA (rango) |
| A5 | 4 | 5 | 39.12 | 38.39 | 0.0% | CERCA |
| B2 | 4 | 3 | 38.73 | 46.28 | 19.5% | MAL |
| B2K | 1 | 1 | 1.26 | 1.69 | 34.4% | MAL |
| BULKHEAD-G | 2 | — | 45.00 | — | — | EN OTRA HOJA (Material Summary) |
| C1 | 8 | 6 | 48.77 | 39.01 | 18.2% | MAL (rango) |
| CANOPY-COL | 4 | — | 22.67 | — | — | EN OTRA HOJA (Material Summary) |
| EXT-6CFMF | 6 | — | 217.64 | — | — | FALTA |
| EXT-PARAPET | 6 | — | 217.64 | — | — | FALTA |
| F | 1 | 1 | 17.76 | 16.92 | 4.8% | CERCA |
| G | 10 | 11 | 80.88 | 82.56 | 2.1% | CERCA |
| G1 | 3 | 3 | 17.11 | 18.46 | 7.9% | CERCA |

## Types que solo están en el candidato (SOBRA)

- EXT: 10 walls, 262.38 LF

Antes de dar un MAL por error de Claude, abre el renglón: a veces la referencia o el emparejamiento de nombres es el que está mal (regla del artículo: leer cada resultado).
