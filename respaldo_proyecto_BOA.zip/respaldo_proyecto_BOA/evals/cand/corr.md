# Calificación del take-off: 25.9%

- Materiales por familia (cantidad NET): **20.00%**
- Partition types (LF y número de walls): **31.80%**
- Tolerancia: IGUAL ≤ 2%, CERCA ≤ 10%


## Materiales por familia (calificación principal)

| Familia | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|
| 6" parapet stud | 973.34 | 966.55 | 0.7% | IGUAL |
| 6" stud (todos los gauges) | 5,486.56 | 5,700.56 | 3.9% | CERCA |
| 3-5/8" stud (todos los gauges) | 4,928.59 | 3,372.09 | 31.6% | MAL |
| 1-5/8" stud | 4,547.72 | 3,998.25 | 12.1% | MAL |
| track de ceilings / soffits | 1,154.00 | — | — | FALTA |
| bottom track (todos) | 1,024.13 | 1,115.43 | 8.9% | CERCA |
| top / deflection track (todos) | 1,165.94 | 1,115.43 | 4.3% | CERCA |
| header / box beam | 221.86 | 216.61 | 2.4% | CERCA |
| sill track | 65.09 | 50.18 | 22.9% | MAL |
| bracing C.R. channel | 2,557.43 | 2,313.48 | 9.5% | CERCA |
| framed openings MEP | 165.67 | 95.00 | 42.7% | MAL |
| furring channel | 719.21 | — | — | FALTA |
| carrying channel | 239.74 | — | — | FALTA |
| hanger wire | 293.00 | — | — | FALTA |
| 5/8" gyp MOISTURE RESISTANT | 261.80 | 180.54 | 31.0% | MAL |
| 5/8" EXTERIOR gyp sheathing | 783.89 | 824.34 | 5.2% | CERCA |
| 5/8" glass mat sheathing | 2,939.76 | 3,246.20 | 10.4% | MAL |
| 3/8" gyp board | 57.04 | 170.44 | 198.8% | MAL |
| ballistic panel | 74.00 | 206.64 | 179.2% | MAL |
| 5/8" gyp board regular (walls + ceilings) | 16,339.80 | 17,425.95 | 6.6% | CERCA |
| FRP | 352.45 | 323.50 | 8.2% | CERCA |
| FRT plywood (SF) | 7,223.31 | 260.15 | 96.4% | MAL |
| metal trim (corner bead, casing, shadow molding) | 514.77 | 147.01 | 71.4% | MAL |
| acoustical sealant | 1,438.10 | 1,717.38 | 19.4% | MAL |
| FRT blocking | 748.00 | 104.00 | 86.1% | MAL |

Renglón por renglón (depende de cómo cada take-off nombra y separa los renglones): 4.80%

## Materiales que no salieron iguales (50 de 52)

| Material | Unit | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|---|
| 6" metal stud 600S137-33 / -68 (LF of material) | lf | 5,486.56 | 1,794.36 | 67.3% | MAL |
| 3-5/8" metal stud 362S137-33 / -68 (LF of material) | lf | 4,928.59 | 3,061.71 | 37.9% | MAL |
| 1-5/8" metal stud (LF of material) | lf | 4,547.72 | 3,998.25 | 12.1% | MAL |
| Bottom track 6" | lf | 293.04 | — | — | FALTA |
| Bottom track 3-5/8" | lf | 227.48 | — | — | FALTA |
| Parapet bottom track 600T125-54 (PAF to steel beam) | lf | 217.64 | 524.98 | 141.2% | MAL |
| Parapet top track 600T125-54 | lf | 217.64 | 590.45 | 171.3% | MAL |
| Bottom track 1-5/8" | lf | 285.97 | — | — | FALTA |
| Top / deflection track 6" | lf | 293.04 | — | — | FALTA |
| Top / deflection track 3-5/8" | lf | 227.48 | — | — | FALTA |
| Top / deflection track 1-5/8" | lf | 285.97 | — | — | FALTA |
| Track, ceilings / soffits / canopy | lf | 1,154.00 | — | — | FALTA |
| Bracing 1-1/2" C.R. channel @ 48" O.C. | lf | 2,557.43 | — | — | FALTA |
| Additional head track at openings over 4'-0" wide | lf | 0.00 | 95.00 | 9500000000000.0% | MAL |
| Header / metal stud box beam | lf | 221.86 | — | — | FALTA |
| Sill track | lf | 65.09 | 50.18 | 22.9% | MAL |
| Framed openings - MEP, light slots and diffusers | lf | 165.67 | — | — | FALTA |
| Stud reinforcement at MEP penetrations | pcs | 18.00 | — | — | FALTA |
| 3-5/8" stud, CSR soffit (pieces - length pending) | pcs | 26.00 | — | — | FALTA |
| Purlin 1x1x1 16 ga, top track to deck | lf | 141.81 | — | — | FALTA |
| Furring channel (ceilings) | lf | 719.21 | — | — | FALTA |
| Carrying channel (ceilings) | lf | 239.74 | — | — | FALTA |
| Hanger wire | lf | 293.00 | — | — | FALTA |
| Extra framing - sistered stud and furring at the ATM recess | lf | 109.87 | — | — | FALTA |
| 5/8" gypsum board, MOISTURE RESISTANT | sf | 261.80 | 180.54 | 31.0% | MAL |
| 5/8" EXTERIOR gypsum sheathing (deck to top of parapet) | sf | 783.89 | 824.34 | 5.2% | CERCA |
| FRP WC-3 | sf | 338.00 | 16.00 | 95.3% | MAL |
| Cement board (substrate under the FRP cove base band) | sf | 14.45 | — | — | FALTA |
| Exterior sheathing 5/8" FRT plywood bonded to 2-1/2" polyiso | sf | 4,224.28 | — | — | FALTA |
| 5/8" glass mat sheathing (exterior face of the stud) | sf | 2,939.76 | 3,246.20 | 10.4% | MAL |
| Gypsum board jamb return at openings | sf | 101.07 | — | — | FALTA |
| Ballistic panel 3/8" UL752 | sf | 74.00 | 206.64 | 179.2% | MAL |
| 3/8" gypsum board | sf | 57.04 | 170.44 | 198.8% | MAL |
| FRT plywood substrate | sf | 647.95 | — | — | FALTA |
| Level 5 finish | sf | 490.43 | — | — | FALTA |
| 5/8" FRT plywood sheathing (canopy and soffits) | sf | 1,768.38 | — | — | FALTA |
| METAL trim - corner bead, casing bead, shadow molding, gypsu | lf | 514.77 | — | — | FALTA |
| PVC trim - edge trim molding and inside corner molding at th | lf | 4.00 | — | — | FALTA |
| Power-driven fasteners and duct sleeves | pcs | 239.00 | — | — | FALTA |
| Blocking FRT / 2X FRT wood | lf | 748.00 | 104.00 | 86.1% | MAL |
| Acoustical sealant | lf | 1,220.50 | 1,717.38 | 40.7% | MAL |
| Access panel 2'x2' | pcs | 1.00 | — | — | FALTA |
| 5/8" FRT plywood at canopy column wraps | sf | 255.50 | — | — | FALTA |
| 3/4" FRT plywood at storefront piers | sf | 327.20 | 260.15 | 20.5% | MAL |
| Sealant at base of gypsum (exterior, not acoustical) | lf | 217.60 | — | — | FALTA |
| Drywall screws 1-1/4" bugle head | pcs | 20,239.30 | — | — | FALTA |
| Framing screws, pan head self-drilling | pcs | 2,996.00 | — | — | FALTA |
| Power-driven fasteners, slab pins for the bottom track | pcs | 403.25 | — | — | FALTA |
| Joint compound, all purpose | lb | 1,214.36 | — | — | FALTA |
| Joint tape, paper | lf | 6,240.45 | — | — | FALTA |

## Materiales que solo están en el candidato (SOBRA)

- 3-5/8" metal stud 14 GA 362S137-68 (lf): 310.38
- 6" metal stud 14 GA 600S137-68 (lf): 61.50
- 6" metal stud 600S137-33 (exterior + storefront bands) (lf): 3,844.70
- Bottom track - interior (all sizes; split by stud size in Takeoff) (lf): 590.45
- Top deflection track exterior 600T200-97 / parapet 600T125-54 (lf): 524.98
- Header (track headers / CSJ) + box beams (lf): 216.61
- 1 1/2" C.R. channel bracing (lf): 2,313.48
- Clips at bracing (pcs): 5,814.00
- FRP-1 restroom wall panels + PVC trims (sf): 307.50
- 5/8" gypsum board (ceilings + CSR soffit) (sf): 994.54
- 3/4" FRT plywood strips (bulkheads + storefront heads) (lf): 95.04
- Corner bead (lf): 102.01
- Shadow molding (lf): 45.00
- Ceiling transition GB 11-0 to ACT 11-6 (kicker framing, 7/A09.33) (lf): 77.03
- Batt insulation (interior partitions + bulkheads) (sf): 5,727.80

## Partition types que no salieron iguales (10 de 12)

| Type | Walls ref | Walls cand | LF ref | LF cand | Dif | Estado |
|---|---|---|---|---|---|---|
| A1K | 3 | 4 | 7.99 | 23.62 | 195.6% | MAL |
| A5 | 4 | 3 | 39.12 | 42.12 | 7.7% | CERCA |
| B2 | 4 | 3 | 35.01 | 50.90 | 45.4% | MAL |
| B2K | 1 | 1 | 1.26 | 2.21 | 75.4% | MAL |
| BULKHEAD-G | 2 | — | 45.00 | — | — | EN OTRA HOJA (Opening Bands) |
| C1 | 8 | 3 | 39.91 | 29.35 | 26.5% | MAL |
| CANOPY-COL | 4 | — | 22.67 | — | — | FALTA |
| F | 1 | 1 | 17.76 | 16.92 | 4.7% | CERCA |
| G | 10 | 10 | 80.88 | 77.92 | 3.7% | CERCA |
| G1 | 3 | 4 | 17.11 | 20.30 | 18.6% | MAL |

Types exteriores no comparados aquí (el candidato los tiene en su hoja Exterior; sus materiales sí cuentan en la tabla por familia): EXT-6CFMF, EXT-PARAPET

Antes de dar un MAL por error de Claude, abre el renglón: a veces la referencia o el emparejamiento de nombres es el que está mal (regla del artículo: leer cada resultado).
