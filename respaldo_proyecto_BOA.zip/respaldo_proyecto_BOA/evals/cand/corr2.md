# Calificación del take-off: 29.5%

- Materiales por familia (cantidad NET): **34.00%**
- Partition types (LF y número de walls): **25.00%**
- Tolerancia: IGUAL ≤ 2%, CERCA ≤ 10%


## Materiales por familia (calificación principal)

| Familia | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|
| 6" parapet stud | 973.34 | 1,036.43 | 6.5% | CERCA |
| 6" stud (todos los gauges) | 5,486.56 | 5,321.17 | 3.0% | CERCA |
| 3-5/8" stud (todos los gauges) | 4,928.59 | 6,154.95 | 24.9% | MAL |
| 1-5/8" stud | 4,547.72 | 4,071.75 | 10.5% | MAL |
| track de ceilings / soffits | 1,154.00 | 554.50 | 51.9% | MAL |
| bottom track (todos) | 1,024.13 | 1,090.20 | 6.5% | CERCA |
| top / deflection track (todos) | 1,165.94 | 1,188.09 | 1.9% | IGUAL |
| header / box beam | 221.86 | 198.03 | 10.7% | MAL |
| sill track | 65.09 | 58.00 | 10.9% | MAL |
| bracing C.R. channel | 2,557.43 | 1,804.11 | 29.5% | MAL |
| framed openings MEP | 165.67 | — | — | FALTA |
| furring channel | 719.21 | 706.20 | 1.8% | IGUAL |
| carrying channel | 239.74 | 235.40 | 1.8% | IGUAL |
| hanger wire | 293.00 | 282.27 | 3.7% | CERCA |
| 5/8" gyp MOISTURE RESISTANT | 261.80 | 261.82 | 0.0% | IGUAL |
| 5/8" EXTERIOR gyp sheathing | 783.89 | 1,107.39 | 41.3% | MAL |
| 5/8" glass mat sheathing | 2,939.76 | 0.00 | 100.0% | MAL |
| 3/8" gyp board | 57.04 | 38.05 | 33.3% | MAL |
| ballistic panel | 74.00 | 60.88 | 17.7% | MAL |
| 5/8" gyp board regular (walls + ceilings) | 16,339.80 | 17,207.51 | 5.3% | CERCA |
| FRP | 352.45 | 334.20 | 5.2% | CERCA |
| cement board | — | 0.00 | — | SOBRA |
| FRT plywood (SF) | 7,223.31 | 7,346.09 | 1.7% | IGUAL |
| metal trim (corner bead, casing, shadow molding) | 514.77 | 1,332.82 | 158.9% | MAL |
| acoustical sealant | 1,438.10 | 1,190.56 | 17.2% | MAL |
| FRT blocking | 748.00 | 722.25 | 3.4% | CERCA |

Renglón por renglón (depende de cómo cada take-off nombra y separa los renglones): 9.60%

## Materiales que no salieron iguales (50 de 52)

| Material | Unit | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|---|
| 6" metal stud 600S137-33 / -68 (LF of material) | lf | 5,486.56 | 5,321.17 | 3.0% | CERCA |
| 6" parapet infill stud 600S162-54 @ 16" O.C. (LF of material | lf | 973.34 | 1,036.43 | 6.5% | CERCA |
| 3-5/8" metal stud 362S137-33 / -68 (LF of material) | lf | 4,928.59 | 6,154.95 | 24.9% | MAL |
| 1-5/8" metal stud (LF of material) | lf | 4,547.72 | 4,071.75 | 10.5% | MAL |
| Bottom track 6" | lf | 293.04 | — | — | FALTA |
| Bottom track 3-5/8" | lf | 227.48 | — | — | FALTA |
| Parapet bottom track 600T125-54 (PAF to steel beam) | lf | 217.64 | 1,090.20 | 400.9% | MAL |
| Parapet top track 600T125-54 | lf | 217.64 | 1,188.09 | 445.9% | MAL |
| Bottom track 1-5/8" | lf | 285.97 | — | — | FALTA |
| Top / deflection track 6" | lf | 293.04 | — | — | FALTA |
| Top / deflection track 3-5/8" | lf | 227.48 | — | — | FALTA |
| Top / deflection track 1-5/8" | lf | 285.97 | — | — | FALTA |
| Track, ceilings / soffits / canopy | lf | 1,154.00 | 554.50 | 51.9% | MAL |
| Bracing 1-1/2" C.R. channel @ 48" O.C. | lf | 2,557.43 | 1,804.11 | 29.5% | MAL |
| Additional head track at openings over 4'-0" wide | lf | 0.00 | — | — | FALTA |
| Header / metal stud box beam | lf | 221.86 | — | — | FALTA |
| Sill track | lf | 65.09 | 58.00 | 10.9% | MAL |
| Framed openings - MEP, light slots and diffusers | lf | 165.67 | — | — | FALTA |
| Stud reinforcement at MEP penetrations | pcs | 18.00 | — | — | FALTA |
| 3-5/8" stud, CSR soffit (pieces - length pending) | pcs | 26.00 | — | — | FALTA |
| Purlin 1x1x1 16 ga, top track to deck | lf | 141.81 | — | — | FALTA |
| Furring channel (ceilings) | lf | 719.21 | — | — | FALTA |
| Carrying channel (ceilings) | lf | 239.74 | — | — | FALTA |
| Hanger wire | lf | 293.00 | 282.27 | 3.7% | CERCA |
| Extra framing - sistered stud and furring at the ATM recess | lf | 109.87 | — | — | FALTA |
| 5/8" gypsum board, regular | sf | 16,339.80 | 17,207.51 | 5.3% | CERCA |
| 5/8" EXTERIOR gypsum sheathing (deck to top of parapet) | sf | 783.89 | 1,107.39 | 41.3% | MAL |
| Cement board (substrate under the FRP cove base band) | sf | 14.45 | 0.00 | 100.0% | MAL |
| Exterior sheathing 5/8" FRT plywood bonded to 2-1/2" polyiso | sf | 4,224.28 | — | — | FALTA |
| 5/8" glass mat sheathing (exterior face of the stud) | sf | 2,939.76 | 0.00 | 100.0% | MAL |
| Gypsum board jamb return at openings | sf | 101.07 | — | — | FALTA |
| Ballistic panel 3/8" UL752 | sf | 74.00 | 60.88 | 17.7% | MAL |
| 3/8" gypsum board | sf | 57.04 | 38.05 | 33.3% | MAL |
| FRT plywood substrate | sf | 647.95 | 7,346.09 | 1033.7% | MAL |
| Level 5 finish | sf | 490.43 | 914.60 | 86.5% | MAL |
| 5/8" FRT plywood sheathing (canopy and soffits) | sf | 1,768.38 | — | — | FALTA |
| METAL trim - corner bead, casing bead, shadow molding, gypsu | lf | 514.77 | 1,332.82 | 158.9% | MAL |
| PVC trim - edge trim molding and inside corner molding at th | lf | 4.00 | — | — | FALTA |
| Power-driven fasteners and duct sleeves | pcs | 239.00 | — | — | FALTA |
| Blocking FRT / 2X FRT wood | lf | 748.00 | 722.25 | 3.4% | CERCA |
| Acoustical sealant | lf | 1,220.50 | 1,190.56 | 2.5% | CERCA |
| Access panel 2'x2' | pcs | 1.00 | — | — | FALTA |
| 5/8" FRT plywood at canopy column wraps | sf | 255.50 | — | — | FALTA |
| 3/4" FRT plywood at storefront piers | sf | 327.20 | — | — | FALTA |
| Sealant at base of gypsum (exterior, not acoustical) | lf | 217.60 | — | — | FALTA |
| Drywall screws 1-1/4" bugle head | pcs | 20,239.30 | — | — | FALTA |
| Framing screws, pan head self-drilling | pcs | 2,996.00 | — | — | FALTA |
| Power-driven fasteners, slab pins for the bottom track | pcs | 403.25 | — | — | FALTA |
| Joint compound, all purpose | lb | 1,214.36 | — | — | FALTA |
| Joint tape, paper | lf | 6,240.45 | — | — | FALTA |

## Materiales que solo están en el candidato (SOBRA)

- 2-1/2" Metal Stud (LF) (lf): 18.00
- Header / box beam (LF) (lf): 198.03
- Batt insulation (SF) (sf): 5,289.77
- Furring channel 7/8" (LF) (lf): 706.20
- Carrying channel 1-1/2" (LF) (lf): 235.40
- Framed openings MEP / recessed (EA) (pcs): 9.00

## Partition types que no salieron iguales (11 de 14)

| Type | Walls ref | Walls cand | LF ref | LF cand | Dif | Estado |
|---|---|---|---|---|---|---|
| A1 | 9 | 9 | 78.37 | 73.86 | 5.8% | CERCA |
| A1K | 3 | 3 | 7.99 | 6.35 | 20.5% | MAL |
| A5 | 4 | 5 | 39.12 | 33.84 | 13.5% | MAL |
| B | 6 | 9 | 60.78 | 68.55 | 12.8% | MAL |
| B2 | 4 | 6 | 35.01 | 27.86 | 20.4% | MAL |
| BULKHEAD-G | 2 | — | 45.00 | — | — | FALTA |
| C1 | 8 | 5 | 39.91 | 53.25 | 33.4% | MAL |
| CANOPY-COL | 4 | — | 22.67 | — | — | FALTA |
| EXT-6CFMF | 6 | — | 217.64 | — | — | FALTA |
| EXT-PARAPET | 6 | — | 217.64 | — | — | FALTA |
| G | 10 | 16 | 80.88 | 123.62 | 52.9% | MAL |

## Types que solo están en el candidato (SOBRA)

- BULKHEAD: 2 walls, 29.89 LF
- CANOPY: 3 walls, 1651.47 LF
- COLUMN: 1 walls, 19.33 LF
- DOOR: 14 walls, 42.50 LF
- EXT: 11 walls, 269.35 LF
- FRAMED: 1 walls, 9.00 LF
- FRP: 2 walls, 75.10 LF
- FRT: 9 walls, 765.59 LF
- GWB: 5 walls, 941.60 LF
- INSULATION: 1 walls, 152.40 LF
- LEVEL: 1 walls, 914.60 LF
- MEP: 17 walls, 2208.00 LF
- PARAPET: 2 walls, 48.04 LF
- SOFFIT: 1 walls, 12.01 LF

Antes de dar un MAL por error de Claude, abre el renglón: a veces la referencia o el emparejamiento de nombres es el que está mal (regla del artículo: leer cada resultado).
