# Calificación del take-off: 36.2%

- Materiales por familia (cantidad NET): **26.20%**
- Partition types (LF y número de walls): **46.20%**
- Tolerancia: IGUAL ≤ 2%, CERCA ≤ 10%


## Materiales por familia (calificación principal)

| Familia | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|
| 6" parapet stud | 997.19 | 817.25 | 18.0% | MAL (rango) |
| 6" stud (todos los gauges) | 4,525.47 | 5,862.38 | 28.0% | MAL (rango) |
| 3-5/8" stud (todos los gauges) | 6,227.89 | 5,797.95 | 11.5% | MAL (rango) |
| 1-5/8" stud | 3,860.10 | 4,401.75 | 12.6% | MAL (rango) |
| purlin (track to deck) | 214.40 | 316.90 | 10.9% | MAL (rango) |
| track de ceilings / soffits | 1,168.97 | 1,282.61 | 3.1% | CERCA (rango) |
| bottom track (todos) | 1,269.56 | 1,359.53 | 0.0% | IGUAL (rango) |
| top / deflection track (todos) | 1,269.56 | 882.32 | 34.5% | MAL (rango) |
| header / box beam | 305.63 | 195.20 | 75.4% | MAL (rango) |
| sill track | 67.76 | 57.00 | 52.1% | MAL (rango) |
| bracing C.R. channel | 2,624.23 | 2,336.35 | 6.1% | CERCA (rango) |
| framed openings MEP | 970.32 | 623.60 | — | NO CALIFICA (excluir) |
| furring channel | 808.88 | 714.75 | 7.9% | CERCA (rango) |
| carrying channel | 316.77 | 238.25 | 0.0% | IGUAL (rango) |
| hanger wire | 524.78 | 339.32 | 0.0% | IGUAL (rango) |
| 5/8" gyp MOISTURE RESISTANT | 261.80 | 268.56 | 2.6% | CERCA (rango) |
| 5/8" EXTERIOR gyp sheathing | 944.60 | 998.51 | 2.1% | CERCA (rango) |
| 5/8" glass mat sheathing | 462.00 | 3,401.02 | 620.4% | MAL (rango) |
| 3/8" gyp board | 57.04 | 67.55 | 7.3% | CERCA (rango) |
| ballistic panel | 74.00 | 86.32 | 3.3% | CERCA (rango) |
| 5/8" gyp board regular (walls + ceilings) | 17,450.60 | 17,469.03 | 0.0% | IGUAL (rango) |
| cement board | 33.80 | — | — | FALTA |
| FRP | 354.00 | 369.00 | 8.5% | CERCA (rango) |
| FRT plywood (SF) | 6,507.01 | 6,591.74 | 0.0% | IGUAL (rango) |
| metal trim (corner bead, casing, shadow molding) | 1,267.55 | 909.29 | 0.0% | IGUAL (rango) |
| acoustical sealant | 1,166.70 | 1,221.51 | 0.0% | IGUAL (rango) |
| metal stud blocking (362CR / STUD BLOCKING) | 466.00 | — | — | FALTA |
| FRT blocking | 1,083.90 | 552.47 | 11.9% | MAL (rango) |
| additional head track | 56.00 | — | — | FALTA |
| stud reinforcement MEP | 18.00 | — | — | FALTA |
| 2-1/2" CFMF coiling grille head | 7.85 | — | — | FALTA |
| extra framing ATM | 109.87 | — | — | FALTA |
| gypsum board jamb return | 95.94 | — | — | FALTA |
| Level 5 finish | 874.83 | 633.06 | 11.2% | MAL (rango) |
| PVC trim at FRP | 211.20 | — | — | FALTA |
| PAFs and duct sleeves | 275.00 | — | — | FALTA |
| access panel | 1.00 | — | — | FALTA |
| drywall screws | 21,323.33 | — | — | FALTA |
| framing screws | 5,252.00 | — | — | FALTA |
| slab pins | 515.71 | — | — | FALTA |
| expansion anchors | 326.46 | — | — | FALTA |
| joint compound | 1,279.40 | — | — | FALTA |
| joint tape | 6,574.69 | — | — | FALTA |

Renglón por renglón (depende de cómo cada take-off nombra y separa los renglones): 9.60%

## Materiales que no salieron iguales (55 de 57)

| Material | Unit | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|---|
| 6" metal stud 600S137-33 / -68 (LF of material) | lf | 4,525.47 | 76.88 | 98.3% | MAL |
| 6" parapet infill stud 600S162-54 @ 16" O.C. (LF of material | lf | 997.19 | 817.25 | 18.0% | MAL |
| 3-5/8" metal stud 362S137-33 / -68 (LF of material) | lf | 6,123.12 | 155.19 | 97.5% | MAL |
| 1-5/8" metal stud (LF of material) | lf | 3,860.10 | 4,401.75 | 14.0% | MAL |
| Bottom track 6" | lf | 293.04 | 317.29 | 8.3% | CERCA |
| Bottom track 3-5/8" | lf | 244.34 | 212.43 | 13.1% | MAL |
| Parapet bottom track 600T125-54 (PAF to steel beam) | lf | 269.37 | — | — | FALTA |
| Parapet top track 600T125-54 | lf | 269.37 | — | — | FALTA |
| Bottom track - roof step 4/A02.02, vestibule heads 4-7/A12.1 | lf | 176.84 | — | — | FALTA |
| Top track - roof step 4/A02.02, vestibule heads 4-7/A12.10,  | lf | 176.84 | — | — | FALTA |
| Top / deflection track 6" | lf | 293.04 | 80.60 | 72.5% | MAL |
| Top / deflection track 3-5/8" | lf | 244.34 | 163.87 | 32.9% | MAL |
| Track, ceilings / soffits / canopy | lf | 1,168.97 | 480.82 | 58.9% | MAL |
| Bracing 1-1/2" C.R. channel @ 48" O.C. | lf | 2,624.23 | 2,336.35 | 11.0% | MAL |
| Additional head track at openings over 4'-0" wide | lf | 56.00 | — | — | FALTA |
| Header / metal stud box beam | lf | 305.63 | — | — | FALTA |
| Sill track | lf | 67.76 | 57.00 | 15.9% | MAL |
| Framed openings - MEP, light slots and diffusers | lf | 970.32 | 42.00 | 95.7% | MAL |
| Stud reinforcement at MEP penetrations | pcs | 18.00 | — | — | FALTA |
| 3-5/8" stud, CSR soffit 10/A09.33 (LF) | lf | 104.77 | — | — | FALTA |
| 2-1/2" CFMF @ 16" O.C. at coiling grille head (4/A08.21) | lf | 7.85 | — | — | FALTA |
| Purlin 1x1x1 16 ga, top track to deck | lf | 214.40 | 316.90 | 47.8% | MAL |
| Furring channel (ceilings) | lf | 808.88 | — | — | FALTA |
| Carrying channel (ceilings) | lf | 316.77 | — | — | FALTA |
| Hanger wire | lf | 524.78 | 339.32 | 35.3% | MAL |
| Extra framing - sistered stud and furring at the ATM recess | lf | 109.87 | — | — | FALTA |
| 5/8" gypsum board, regular | sf | 17,450.60 | 16,396.18 | 6.0% | CERCA |
| 5/8" gypsum board, MOISTURE RESISTANT | sf | 261.80 | 268.56 | 2.6% | CERCA |
| 5/8" EXTERIOR gypsum sheathing (deck to top of parapet) | sf | 944.60 | 998.51 | 5.7% | CERCA |
| FRP WC-3 | sf | 354.00 | — | — | FALTA |
| Cement board (substrate under the FRP cove base band) | sf | 33.80 | — | — | FALTA |
| Exterior sheathing 5/8" FRT plywood bonded to 2-1/2" polyiso | sf | 3,754.28 | 4,191.59 | 11.6% | MAL |
| 5/8" glass mat sheathing (exterior face of the stud) | sf | 462.00 | 3,401.02 | 636.2% | MAL |
| Gypsum board jamb return at openings | sf | 95.94 | — | — | FALTA |
| Ballistic panel 3/8" UL752 | sf | 74.00 | 67.55 | 8.7% | CERCA |
| 3/8" gypsum board | sf | 57.04 | — | — | FALTA |
| FRT plywood substrate | sf | 632.49 | — | — | FALTA |
| Level 5 finish | sf | 874.83 | 633.06 | 27.6% | MAL |
| 5/8" FRT plywood sheathing (canopy and soffits) | sf | 1,872.88 | 1,443.20 | 22.9% | MAL |
| METAL trim - corner bead, casing bead, shadow molding, gypsu | lf | 1,267.55 | 96.00 | 92.4% | MAL |
| PVC trim - edge trim molding and inside corner molding at th | lf | 211.20 | — | — | FALTA |
| Power-driven fasteners and duct sleeves | pcs | 275.00 | — | — | FALTA |
| Blocking FRT / 2X FRT wood | lf | 1,083.90 | — | — | FALTA |
| Acoustical sealant | lf | 957.52 | 1,002.98 | 4.7% | CERCA |
| Access panel 2'x2' | pcs | 1.00 | — | — | FALTA |
| 5/8" FRT plywood at canopy column wraps | sf | 220.50 | 480.82 | 118.1% | MAL |
| 3/4" FRT plywood at storefront piers | sf | 26.86 | 284.13 | 957.8% | MAL |
| Sealant at base of gypsum (exterior, not acoustical) | lf | 209.18 | 218.53 | 4.5% | CERCA |
| Stud blocking 362CR22 at edge of gypboard (4/S5.20) | lf | 466.00 | — | — | FALTA |
| Drywall screws 1-1/4" bugle head | pcs | 21,323.33 | — | — | FALTA |
| Framing screws, pan head self-drilling | pcs | 5,252.00 | — | — | FALTA |
| Power-driven fasteners, slab pins for the bottom track | pcs | 515.71 | — | — | FALTA |
| Expansion anchors Hilti 1/4" Kwik Bolt II, exterior bottom t | pcs | 326.46 | — | — | FALTA |
| Joint compound, all purpose | lb | 1,279.40 | — | — | FALTA |
| Joint tape, paper | lf | 6,574.69 | — | — | FALTA |

## Materiales que solo están en el candidato (SOBRA)

- 3-5/8" bottom track 362T125-33 (14 GA: 68 mil per 4/A12.01) (lf): 8.59
- 3-5/8" canopy fascia track 362T125-33 (top + bottom, soffit) (lf): 480.82
- 3-5/8" metal stud 362S137-33 (lf): 4,184.32
- 3-5/8" metal stud 362S137-33 - canopy fascia framing (lf): 376.04
- 3-5/8" metal stud 362S137-33 - canopy soffit framing @ 16" O.C. (lf): 1,082.40
- 3-5/8" top slip / deflection track 362T125-33 (14 GA: 68 mil per 4/A12 (lf): 8.59
- 3-5/8" top track 362T125-33 (secured to structure) (lf): 71.88
- 3/4" FRT plywood backboard (Electrical 120 + NER 121, key note 6) (sf): 192.00
- 3/8" UL752 Level-2 ballistic fiberglass panel (NIJ II) to 8'-0" (sf): 86.32
- 5/8" gyp board - ceilings & soffits (sf): 1,072.85
- 6" bottom track 600T125-33 (14 GA: 68 mil per 4/A12.01) (lf): 2.20
- 6" metal stud 600S137-33 (lf): 5,785.50
- 6" parapet infill track 600T125-54 (top & bottom) (lf): 527.68
- 6" top deflection track 600T200-97 at B.O.D. (exterior, per schedule) (lf): 263.84
- 6" top slip / deflection track 600T125-33 (14 GA: 68 mil per 4/A12.01) (lf): 2.20
- FRP panel WC-3 at janitor mop sink (allowance) (sf): 24.00
- FRP panel WC-3 restrooms (5'-0" above 6" base) (sf): 345.00
- FRT blocking 3/4" plywood (FRTW for future, CSR soffit) (lf): 12.67
- FRT blocking 3/4" plywood - 85" monitor (lf): 12.00
- FRT blocking 3/4" plywood - door wall stops (lf): 28.00
- FRT blocking 3/4" plywood - millwork (lf): 147.96
- FRT blocking 3/4" plywood - roof hatch ladder (lf): 4.00
- FRT blocking 3/4" plywood - toilet accessories (lf): 39.00
- FRT blocking 3/4" plywood at parapet top (lf): 263.84
- FRT blocking 3/4" plywood under box beam (lf): 45.00
- carrying channel 1-1/2" @ 48" O.C. (GB ceilings) (lf): 238.25
- ceiling track - perimeter of GB ceilings (lf): 270.29
- framed opening for 2'x2' access panel (key note 4) (lf): 8.00
- framed opening for recessed canopy linear light (lf): 477.60
- framed opening for recessed fixture R-11 (12') in GB ceiling (lf): 96.00
- furring channel 7/8" @ 16" O.C. (GB ceilings) (lf): 714.75
- header / box beam at exterior windows and door 123 (R.O. + 1'-4") (lf): 61.67
- header / box beam at interior door openings (R.O. + 1'-4") (lf): 65.86
- header / box beam at office fronts (CONT. BOX BEAM, R.O. + 1'-4") (lf): 53.00
- header / box beam at storefront 103 (13'-4" R.O. + 1'-4"; span > S5.20 (lf): 14.67
- metal trim - L-bead / J-bead (casing) at storefront head & jamb return (lf): 96.31
- metal trim - L-bead / J-bead (casing) at window returns (lf): 120.00
- metal trim - casing bead at ballistic wall ends (4/A12.01) (lf): 87.60
- metal trim - corner bead (lf): 342.36
- metal trim - shadow molding at scheduled ceiling (lf): 167.02
- soffit track - CONT. TRACK at deck and soffit bottom (lf): 50.68
- sound batt insulation in partitions (SF) (sf): 5,146.34

## Partition types que no salieron iguales (12 de 14)

| Type | Walls ref | Walls cand | LF ref | LF cand | Dif | Estado |
|---|---|---|---|---|---|---|
| A1 | 9 | 10 | 78.37 | 89.86 | 0.0% | IGUAL (rango) |
| A1K | 3 | 2 | 7.99 | 8.59 | 0.0% | CERCA |
| A5 | 4 | 5 | 39.12 | 38.18 | 2.4% | CERCA (rango) |
| B2 | 4 | 5 | 38.73 | 42.42 | 9.5% | CERCA |
| B2K | 1 | 1 | 1.26 | 2.20 | 74.6% | MAL |
| BULKHEAD-G | 2 | — | 45.00 | — | — | FALTA |
| C1 | 8 | 5 | 48.77 | 53.40 | 8.8% | CERCA (rango) |
| CANOPY-COL | 4 | — | 22.67 | — | — | EN OTRA HOJA (Material Summary) |
| EXT-6CFMF | 6 | — | 217.64 | — | — | FALTA |
| EXT-PARAPET | 6 | — | 217.64 | — | — | FALTA |
| F | 1 | 1 | 17.76 | 18.48 | 4.0% | CERCA |
| G | 10 | 11 | 80.88 | 83.56 | 3.3% | CERCA |

## Types que solo están en el candidato (SOBRA)

- BULKHEAD: 7 walls, 58.33 LF
- EXTERIOR: 11 walls, 263.84 LF

Antes de dar un MAL por error de Claude, abre el renglón: a veces la referencia o el emparejamiento de nombres es el que está mal (regla del artículo: leer cada resultado).
