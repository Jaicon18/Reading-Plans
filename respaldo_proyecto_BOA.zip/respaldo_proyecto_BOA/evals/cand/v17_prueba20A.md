# Calificación del take-off: 83.3%

- Materiales por familia (cantidad NET): **88.10%**
- Partition types (LF y número de walls): **78.60%**
- Tolerancia: IGUAL ≤ 2%, CERCA ≤ 10%


## Materiales por familia (calificación principal)

| Familia | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|
| 6" parapet stud | 997.19 | 1,001.58 | 0.0% | IGUAL (rango) |
| 6" stud (todos los gauges) | 4,525.47 | 4,587.69 | 0.0% | IGUAL (rango) |
| 3-5/8" stud (todos los gauges) | 6,227.89 | 6,879.25 | 3.2% | CERCA (rango) |
| 1-5/8" stud | 3,860.10 | 3,983.76 | 0.0% | IGUAL (rango) |
| purlin (track to deck) | 214.40 | 202.03 | 0.0% | IGUAL (rango) |
| track de ceilings / soffits | 1,168.97 | 1,254.43 | 5.2% | CERCA (rango) |
| bottom track (todos) | 1,269.56 | 1,393.32 | 3.4% | CERCA (rango) |
| top / deflection track (todos) | 1,269.56 | 1,393.32 | 3.4% | CERCA (rango) |
| header / box beam | 305.63 | 792.29 | 0.0% | IGUAL (rango) |
| sill track | 67.76 | 119.12 | 0.0% | IGUAL (rango) |
| bracing C.R. channel | 2,624.23 | 2,463.62 | 0.0% | IGUAL (rango) |
| framed openings MEP | 970.32 | 940.27 | 0.0% | IGUAL (rango) |
| furring channel | 808.88 | 777.07 | 0.0% | IGUAL (rango) |
| carrying channel | 316.77 | 324.17 | 0.0% | IGUAL (rango) |
| hanger wire | 524.78 | 533.62 | 0.0% | IGUAL (rango) |
| 5/8" gyp MOISTURE RESISTANT | 261.80 | 261.74 | 0.0% | IGUAL (rango) |
| 5/8" EXTERIOR gyp sheathing | 944.60 | 935.76 | 0.0% | IGUAL (rango) |
| 5/8" glass mat sheathing | 462.00 | 477.95 | 0.0% | IGUAL (rango) |
| 3/8" gyp board | 57.04 | 63.92 | 0.0% | IGUAL (rango) |
| ballistic panel | 74.00 | 82.32 | 0.0% | IGUAL (rango) |
| 5/8" gyp board regular (walls + ceilings) | 17,450.60 | 17,713.32 | 0.0% | IGUAL (rango) |
| cement board | 33.80 | 31.80 | 0.0% | IGUAL (rango) |
| FRP | 354.00 | 334.00 | 0.0% | IGUAL (rango) |
| FRT plywood (SF) | 6,507.01 | 6,386.42 | 0.0% | IGUAL (rango) |
| metal trim (corner bead, casing, shadow molding) | 1,267.55 | 1,107.75 | 0.0% | IGUAL (rango) |
| acoustical sealant | 1,166.70 | 1,383.04 | 0.0% | IGUAL (rango) |
| metal stud blocking (362CR / STUD BLOCKING) | 466.00 | 722.33 | 0.0% | IGUAL (rango) |
| FRT blocking | 1,083.90 | 1,049.55 | 0.0% | IGUAL (rango) |
| additional head track | 56.00 | 56.00 | 0.0% | IGUAL (rango) |
| stud reinforcement MEP | 18.00 | 71.00 | 102.9% | MAL (rango) |
| 2-1/2" CFMF coiling grille head | 7.85 | 10.43 | 0.0% | IGUAL (rango) |
| extra framing ATM | 109.87 | 18.00 | 63.9% | MAL (rango) |
| gypsum board jamb return | 95.94 | 67.16 | 0.0% | IGUAL (rango) |
| Level 5 finish | 874.83 | 712.88 | 0.0% | IGUAL (rango) |
| PVC trim at FRP | 211.20 | 213.20 | 0.0% | IGUAL (rango) |
| PAFs and duct sleeves | 275.00 | 316.00 | 5.7% | CERCA (rango) |
| access panel | 1.00 | 1.00 | 0.0% | IGUAL (rango) |
| drywall screws | 21,323.33 | 21,646.78 | 0.0% | IGUAL (rango) |
| framing screws | 5,252.00 | 7,260.00 | — | NO CALIFICA (consistencia) |
| slab pins | 515.71 | 530.81 | 2.9% | CERCA (rango) |
| expansion anchors | 326.46 | 332.83 | 0.0% | IGUAL (rango) |
| joint compound | 1,279.40 | 1,298.81 | 0.0% | IGUAL (rango) |
| joint tape | 6,574.69 | 6,674.42 | 0.0% | IGUAL (rango) |

Renglón por renglón (depende de cómo cada take-off nombra y separa los renglones): 35.10%

## Materiales que no salieron iguales (41 de 57)

| Material | Unit | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|---|
| 3-5/8" metal stud 362S137-33 / -68 (LF of material) | lf | 6,123.12 | 6,879.25 | 12.3% | MAL |
| 1-5/8" metal stud (LF of material) | lf | 3,860.10 | 3,983.76 | 3.2% | CERCA |
| Bottom track 6" | lf | 293.04 | 90.62 | 69.1% | MAL |
| Bottom track 3-5/8" | lf | 244.34 | 154.77 | 36.7% | MAL |
| Parapet bottom track 600T125-54 (PAF to steel beam) | lf | 269.37 | — | — | FALTA |
| Parapet top track 600T125-54 | lf | 269.37 | — | — | FALTA |
| Bottom track - roof step 4/A02.02, vestibule heads 4-7/A12.1 | lf | 176.84 | — | — | FALTA |
| Top track - roof step 4/A02.02, vestibule heads 4-7/A12.10,  | lf | 176.84 | — | — | FALTA |
| Top / deflection track 6" | lf | 293.04 | 90.62 | 69.1% | MAL |
| Top / deflection track 3-5/8" | lf | 244.34 | 154.77 | 36.7% | MAL |
| Track, ceilings / soffits / canopy | lf | 1,168.97 | — | — | FALTA |
| Bracing 1-1/2" C.R. channel @ 48" O.C. | lf | 2,624.23 | 2,463.62 | 6.1% | CERCA |
| Header / metal stud box beam | lf | 305.63 | 792.29 | 159.2% | MAL |
| Sill track | lf | 67.76 | 119.12 | 75.8% | MAL |
| Framed openings - MEP, light slots and diffusers | lf | 970.32 | — | — | FALTA |
| Stud reinforcement at MEP penetrations | pcs | 18.00 | 71.00 | 294.4% | MAL |
| 3-5/8" stud, CSR soffit 10/A09.33 (LF) | lf | 104.77 | — | — | FALTA |
| 2-1/2" CFMF @ 16" O.C. at coiling grille head (4/A08.21) | lf | 7.85 | 10.43 | 32.9% | MAL |
| Purlin 1x1x1 16 ga, top track to deck | lf | 214.40 | 202.03 | 5.8% | CERCA |
| Furring channel (ceilings) | lf | 808.88 | — | — | FALTA |
| Carrying channel (ceilings) | lf | 316.77 | — | — | FALTA |
| Extra framing - sistered stud and furring at the ATM recess | lf | 109.87 | 18.00 | 83.6% | MAL |
| FRP WC-3 | sf | 354.00 | — | — | FALTA |
| Cement board (substrate under the FRP cove base band) | sf | 33.80 | 31.80 | 5.9% | CERCA |
| Exterior sheathing 5/8" FRT plywood bonded to 2-1/2" polyiso | sf | 3,754.28 | 3,955.15 | 5.4% | CERCA |
| 5/8" glass mat sheathing (exterior face of the stud) | sf | 462.00 | 477.95 | 3.5% | CERCA |
| Gypsum board jamb return at openings | sf | 95.94 | 67.16 | 30.0% | MAL |
| Ballistic panel 3/8" UL752 | sf | 74.00 | 82.32 | 11.2% | MAL |
| 3/8" gypsum board | sf | 57.04 | 63.92 | 12.1% | MAL |
| FRT plywood substrate | sf | 632.49 | — | — | FALTA |
| Level 5 finish | sf | 874.83 | 712.88 | 18.5% | MAL |
| 5/8" FRT plywood sheathing (canopy and soffits) | sf | 1,872.88 | 2,154.14 | 15.0% | MAL |
| METAL trim - corner bead, casing bead, shadow molding, gypsu | lf | 1,267.55 | 1,107.75 | 12.6% | MAL |
| Power-driven fasteners and duct sleeves | pcs | 275.00 | 316.00 | 14.9% | MAL |
| Blocking FRT / 2X FRT wood | lf | 1,083.90 | 1,049.55 | 3.2% | CERCA |
| Acoustical sealant | lf | 957.52 | — | — | FALTA |
| 5/8" FRT plywood at canopy column wraps | sf | 220.50 | — | — | FALTA |
| 3/4" FRT plywood at storefront piers | sf | 26.86 | 277.13 | 931.8% | MAL |
| Stud blocking 362CR22 at edge of gypboard (4/S5.20) | lf | 466.00 | 722.33 | 55.0% | MAL |
| Framing screws, pan head self-drilling | pcs | 5,252.00 | 7,260.00 | 38.2% | MAL |
| Power-driven fasteners, slab pins for the bottom track | pcs | 515.71 | 530.81 | 2.9% | CERCA |

## Materiales que solo están en el candidato (SOBRA)

- Ceiling / soffit track 3-5/8" (ceiling perimeter, soffits, transitions (lf): 1,254.43
- Furring channel 7/8" (suspended GWB ceilings) (lf): 777.07
- Carrying channel 1-1/2" C.R. (suspended GWB ceilings) (lf): 324.17
- FRP panel (restrooms to 5'-0", mop sink) (sf): 334.00
- Acoustical sealant (partition top / bottom beads per type detail) (lf): 1,173.93
- Framed openings MEP (recessed fixtures, slot diffusers, access panel)  (lf): 940.27
- Bottom track 6" 54 mil 600T125-54 (exterior CFMF) (lf): 215.61
- Bottom track 6" 600T125-33 (B2, gauge per 7/S5.20) (lf): 44.67
- Bottom track 3-5/8" 362T125-33 (A1, B, C1) (lf): 147.06
- Bottom track 3-5/8" 33 mil 362T125-33 (A1, A5 group) (lf): 90.88
- Bottom track 6" 33 mil 600T125-33 (A5) (lf): 42.23
- Bottom track 3-5/8" 14 GA 362T 14 ga (A1K, 4/A12.01) (lf): 8.60
- Bottom track 6" 14 GA 600T 14 ga (B2K, 4/A12.01) (lf): 2.21
- Bottom track 2-1/2" - grille head (lf): 13.33
- Bottom track 6" 54 mil - parapet (lf): 269.84
- Bottom track 3-5/8" - vestibule head (lf): 22.07
- Top / deflection track 6" 54 mil 600T125-54 (exterior CFMF) (lf): 215.61
- Top / deflection track 6" 600T125-33 (B2, gauge per 7/S5.20) (lf): 44.67
- Top / deflection track 3-5/8" 362T125-33 (A1, B, C1) (lf): 147.06
- Top / deflection track 3-5/8" 33 mil 362T125-33 (A1, A5 group) (lf): 90.88
- Top / deflection track 6" 33 mil 600T125-33 (A5) (lf): 42.23
- Top / deflection track 3-5/8" 14 GA 362T 14 ga (A1K, 4/A12.01) (lf): 8.60
- Top / deflection track 6" 14 GA 600T 14 ga (B2K, 4/A12.01) (lf): 2.21
- Top / deflection track 2-1/2" - grille head (lf): 13.33
- Top / deflection track 6" 54 mil - parapet (lf): 269.84
- Top / deflection track 3-5/8" - vestibule head (lf): 22.07
- Hanger wire 12 ga - hanger count (one per hanger, height per room) (pcs): 113.00

## Partition types que no salieron iguales (10 de 14)

| Type | Walls ref | Walls cand | LF ref | LF cand | Dif | Estado |
|---|---|---|---|---|---|---|
| A1 | 9 | 10 | 78.37 | 90.88 | 0.0% | IGUAL (rango) |
| A1K | 3 | 3 | 7.99 | 8.60 | 0.0% | IGUAL (rango) |
| A5 | 4 | 4 | 39.12 | 42.23 | 0.0% | IGUAL (rango) |
| B2K | 1 | 1 | 1.26 | 2.21 | 75.2% | MAL |
| C1 | 8 | 8 | 48.77 | 47.21 | 0.0% | IGUAL (rango) |
| EXT-6CFMF | 6 | 8 | 217.64 | 221.88 | 2.0% | CERCA |
| EXT-PARAPET | 8 | 8 | 269.37 | 269.84 | 0.0% | IGUAL (rango) |
| F | 1 | 1 | 17.76 | 16.91 | 4.8% | CERCA |
| G | 10 | 11 | 80.88 | 81.92 | 1.3% | CERCA |
| G1 | 3 | 4 | 17.11 | 18.79 | 9.8% | CERCA |

## Types que solo están en el candidato (SOBRA)

- OTHER: 29 walls, 630.23 LF

Antes de dar un MAL por error de Claude, abre el renglón: a veces la referencia o el emparejamiento de nombres es el que está mal (regla del artículo: leer cada resultado).
