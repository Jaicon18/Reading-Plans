# Calificación del take-off: 27.4%

- Materiales por familia (cantidad NET): **24.00%**
- Partition types (LF y número de walls): **30.80%**
- Tolerancia: IGUAL ≤ 2%, CERCA ≤ 10%


## Materiales por familia (calificación principal)

| Familia | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|
| 6" parapet stud | 973.34 | 817.25 | 16.0% | MAL |
| 6" stud (todos los gauges) | 5,486.56 | 5,862.38 | 6.8% | CERCA |
| 3-5/8" stud (todos los gauges) | 4,928.59 | 5,797.95 | 17.6% | MAL |
| 1-5/8" stud | 4,547.72 | 4,401.75 | 3.2% | CERCA |
| track de ceilings / soffits | 1,154.00 | 1,282.61 | 11.1% | MAL |
| bottom track (todos) | 1,024.13 | 1,359.53 | 32.7% | MAL |
| top / deflection track (todos) | 1,165.94 | 1,199.22 | 2.9% | CERCA |
| header / box beam | 221.86 | 195.20 | 12.0% | MAL |
| sill track | 65.09 | 57.00 | 12.4% | MAL |
| bracing C.R. channel | 2,557.43 | 2,336.35 | 8.6% | CERCA |
| framed openings MEP | 165.67 | 623.60 | 276.4% | MAL |
| furring channel | 719.21 | 714.75 | 0.6% | IGUAL |
| carrying channel | 239.74 | 238.25 | 0.6% | IGUAL |
| hanger wire | 293.00 | 339.32 | 15.8% | MAL |
| 5/8" gyp MOISTURE RESISTANT | 261.80 | 268.56 | 2.6% | CERCA |
| 5/8" EXTERIOR gyp sheathing | 783.89 | 998.51 | 27.4% | MAL |
| 5/8" glass mat sheathing | 2,939.76 | 3,401.02 | 15.7% | MAL |
| 3/8" gyp board | 57.04 | 67.55 | 18.4% | MAL |
| ballistic panel | 74.00 | 86.32 | 16.6% | MAL |
| 5/8" gyp board regular (walls + ceilings) | 16,339.80 | 17,469.03 | 6.9% | CERCA |
| FRP | 352.45 | 369.00 | 4.7% | CERCA |
| FRT plywood (SF) | 7,223.31 | 6,591.74 | 8.7% | CERCA |
| metal trim (corner bead, casing, shadow molding) | 514.77 | 909.29 | 76.6% | MAL |
| acoustical sealant | 1,438.10 | 1,221.51 | 15.1% | MAL |
| FRT blocking | 748.00 | 552.47 | 26.1% | MAL |

Renglón por renglón (depende de cómo cada take-off nombra y separa los renglones): 15.40%

## Materiales que no salieron iguales (47 de 52)

| Material | Unit | Referencia | Candidato | Dif | Estado |
|---|---|---|---|---|---|
| 6" metal stud 600S137-33 / -68 (LF of material) | lf | 5,486.56 | 76.88 | 98.6% | MAL |
| 6" parapet infill stud 600S162-54 @ 16" O.C. (LF of material | lf | 973.34 | 817.25 | 16.0% | MAL |
| 3-5/8" metal stud 362S137-33 / -68 (LF of material) | lf | 4,928.59 | 155.19 | 96.9% | MAL |
| 1-5/8" metal stud (LF of material) | lf | 4,547.72 | 4,401.75 | 3.2% | CERCA |
| Bottom track 6" | lf | 293.04 | 317.29 | 8.3% | CERCA |
| Bottom track 3-5/8" | lf | 227.48 | 212.43 | 6.6% | CERCA |
| Parapet bottom track 600T125-54 (PAF to steel beam) | lf | 217.64 | — | — | FALTA |
| Parapet top track 600T125-54 | lf | 217.64 | — | — | FALTA |
| Top / deflection track 6" | lf | 293.04 | 80.60 | 72.5% | MAL |
| Top / deflection track 3-5/8" | lf | 227.48 | 163.87 | 28.0% | MAL |
| Track, ceilings / soffits / canopy | lf | 1,154.00 | 480.82 | 58.3% | MAL |
| Bracing 1-1/2" C.R. channel @ 48" O.C. | lf | 2,557.43 | 2,336.35 | 8.6% | CERCA |
| Additional head track at openings over 4'-0" wide | lf | 0.00 | — | — | FALTA |
| Header / metal stud box beam | lf | 221.86 | — | — | FALTA |
| Sill track | lf | 65.09 | 57.00 | 12.4% | MAL |
| Framed openings - MEP, light slots and diffusers | lf | 165.67 | 42.00 | 74.6% | MAL |
| Stud reinforcement at MEP penetrations | pcs | 18.00 | — | — | FALTA |
| 3-5/8" stud, CSR soffit (pieces - length pending) | pcs | 26.00 | — | — | FALTA |
| Purlin 1x1x1 16 ga, top track to deck | lf | 141.81 | 316.90 | 123.5% | MAL |
| Furring channel (ceilings) | lf | 719.21 | — | — | FALTA |
| Carrying channel (ceilings) | lf | 239.74 | — | — | FALTA |
| Hanger wire | lf | 293.00 | 339.32 | 15.8% | MAL |
| Extra framing - sistered stud and furring at the ATM recess | lf | 109.87 | — | — | FALTA |
| 5/8" gypsum board, MOISTURE RESISTANT | sf | 261.80 | 268.56 | 2.6% | CERCA |
| 5/8" EXTERIOR gypsum sheathing (deck to top of parapet) | sf | 783.89 | 998.51 | 27.4% | MAL |
| FRP WC-3 | sf | 338.00 | — | — | FALTA |
| Cement board (substrate under the FRP cove base band) | sf | 14.45 | — | — | FALTA |
| 5/8" glass mat sheathing (exterior face of the stud) | sf | 2,939.76 | 3,401.02 | 15.7% | MAL |
| Gypsum board jamb return at openings | sf | 101.07 | — | — | FALTA |
| Ballistic panel 3/8" UL752 | sf | 74.00 | 67.55 | 8.7% | CERCA |
| 3/8" gypsum board | sf | 57.04 | — | — | FALTA |
| FRT plywood substrate | sf | 647.95 | — | — | FALTA |
| Level 5 finish | sf | 490.43 | 633.06 | 29.1% | MAL |
| 5/8" FRT plywood sheathing (canopy and soffits) | sf | 1,768.38 | 1,443.20 | 18.4% | MAL |
| METAL trim - corner bead, casing bead, shadow molding, gypsu | lf | 514.77 | 96.00 | 81.4% | MAL |
| PVC trim - edge trim molding and inside corner molding at th | lf | 4.00 | — | — | FALTA |
| Power-driven fasteners and duct sleeves | pcs | 239.00 | — | — | FALTA |
| Blocking FRT / 2X FRT wood | lf | 748.00 | — | — | FALTA |
| Acoustical sealant | lf | 1,220.50 | 1,002.98 | 17.8% | MAL |
| Access panel 2'x2' | pcs | 1.00 | — | — | FALTA |
| 5/8" FRT plywood at canopy column wraps | sf | 255.50 | 480.82 | 88.2% | MAL |
| 3/4" FRT plywood at storefront piers | sf | 327.20 | 284.13 | 13.2% | MAL |
| Drywall screws 1-1/4" bugle head | pcs | 20,239.30 | — | — | FALTA |
| Framing screws, pan head self-drilling | pcs | 2,996.00 | — | — | FALTA |
| Power-driven fasteners, slab pins for the bottom track | pcs | 403.25 | — | — | FALTA |
| Joint compound, all purpose | lb | 1,214.36 | — | — | FALTA |
| Joint tape, paper | lf | 6,240.45 | — | — | FALTA |

## Materiales que solo están en el candidato (SOBRA)

- 3-5/8" bottom track 362T125-33 (14 GA: 68 mil per 4/A12.01) (lf): 8.59
- 3-5/8" canopy fascia track 362T125-33 (top + bottom, soffit) (lf): 480.82
- 3-5/8" metal stud 362S137-33 (lf): 4,184.32
- 3-5/8" metal stud 362S137-33 - canopy fascia framing (lf): 376.04
- 3-5/8" metal stud 362S137-33 - canopy soffit framing @ 16" O.C. (lf): 1,082.40
- 3-5/8" top slip / deflection track 362T125-33 (14 GA: 68 mil per 4/A12 (lf): 8.59
- 3-5/8" top track 362T125-33 (secured to structure) (lf): 71.88
- 3/4" FRT plywood backboard (Electrical 120 + NER 121, key note 6) (sf): 192.00
- 3/8" UL752 Level-2 ballistic fiberglass panel (NIJ II) to 8'-0" (sf): 86.32
- 5/8" gyp board - ceilings & soffits (sf): 1,072.85
- 6" bottom track 600T125-33 (14 GA: 68 mil per 4/A12.01) (lf): 2.20
- 6" metal stud 600S137-33 (lf): 5,785.50
- 6" parapet infill track 600T125-54 (top & bottom) (lf): 527.68
- 6" top deflection track 600T200-97 at B.O.D. (exterior, per schedule) (lf): 263.84
- 6" top slip / deflection track 600T125-33 (14 GA: 68 mil per 4/A12.01) (lf): 2.20
- FRP panel WC-3 at janitor mop sink (allowance) (sf): 24.00
- FRP panel WC-3 restrooms (5'-0" above 6" base) (sf): 345.00
- FRT blocking 3/4" plywood (FRTW for future, CSR soffit) (lf): 12.67
- FRT blocking 3/4" plywood - 85" monitor (lf): 12.00
- FRT blocking 3/4" plywood - door wall stops (lf): 28.00
- FRT blocking 3/4" plywood - millwork (lf): 147.96
- FRT blocking 3/4" plywood - roof hatch ladder (lf): 4.00
- FRT blocking 3/4" plywood - toilet accessories (lf): 39.00
- FRT blocking 3/4" plywood at parapet top (lf): 263.84
- FRT blocking 3/4" plywood under box beam (lf): 45.00
- carrying channel 1-1/2" @ 48" O.C. (GB ceilings) (lf): 238.25
- ceiling track - perimeter of GB ceilings (lf): 270.29
- framed opening for 2'x2' access panel (key note 4) (lf): 8.00
- framed opening for recessed canopy linear light (lf): 477.60
- framed opening for recessed fixture R-11 (12') in GB ceiling (lf): 96.00
- furring channel 7/8" @ 16" O.C. (GB ceilings) (lf): 714.75
- header / box beam at exterior windows and door 123 (R.O. + 1'-4") (lf): 61.67
- header / box beam at interior door openings (R.O. + 1'-4") (lf): 65.86
- header / box beam at office fronts (CONT. BOX BEAM, R.O. + 1'-4") (lf): 53.00
- header / box beam at storefront 103 (13'-4" R.O. + 1'-4"; span > S5.20 (lf): 14.67
- metal trim - L-bead / J-bead (casing) at storefront head & jamb return (lf): 96.31
- metal trim - L-bead / J-bead (casing) at window returns (lf): 120.00
- metal trim - casing bead at ballistic wall ends (4/A12.01) (lf): 87.60
- metal trim - corner bead (lf): 342.36
- metal trim - shadow molding at scheduled ceiling (lf): 167.02
- soffit track - CONT. TRACK at deck and soffit bottom (lf): 50.68
- sound batt insulation in partitions (SF) (sf): 5,146.34

## Partition types que no salieron iguales (12 de 14)

| Type | Walls ref | Walls cand | LF ref | LF cand | Dif | Estado |
|---|---|---|---|---|---|---|
| A1 | 9 | 10 | 78.37 | 89.86 | 14.7% | MAL |
| A1K | 3 | 2 | 7.99 | 8.59 | 7.5% | CERCA |
| A5 | 4 | 5 | 39.12 | 38.18 | 2.4% | CERCA |
| B2 | 4 | 5 | 35.01 | 42.42 | 21.2% | MAL |
| B2K | 1 | 1 | 1.26 | 2.20 | 74.6% | MAL |
| BULKHEAD-G | 2 | — | 45.00 | — | — | FALTA |
| C1 | 8 | 5 | 39.91 | 53.40 | 33.8% | MAL |
| CANOPY-COL | 4 | — | 22.67 | — | — | EN OTRA HOJA (Material Summary) |
| EXT-6CFMF | 6 | — | 217.64 | — | — | FALTA |
| EXT-PARAPET | 6 | — | 217.64 | — | — | FALTA |
| F | 1 | 1 | 17.76 | 18.48 | 4.0% | CERCA |
| G | 10 | 11 | 80.88 | 83.56 | 3.3% | CERCA |

## Types que solo están en el candidato (SOBRA)

- BULKHEAD: 7 walls, 58.33 LF
- EXTERIOR: 11 walls, 263.84 LF

Antes de dar un MAL por error de Claude, abre el renglón: a veces la referencia o el emparejamiento de nombres es el que está mal (regla del artículo: leer cada resultado).
